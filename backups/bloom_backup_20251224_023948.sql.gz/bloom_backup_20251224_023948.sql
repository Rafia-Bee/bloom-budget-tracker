--
-- PostgreSQL database dump
--

\restrict 3c4KgasaNOr9FTzJY9y389uDuLdIJutdmpE9hUMKJ4MtCMKDaT9atBagEzKrZ1w

-- Dumped from database version 17.7 (bdc8956)
-- Dumped by pg_dump version 17.7 (Ubuntu 17.7-3.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO neondb_owner;

--
-- Name: budget_periods; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.budget_periods (
    id integer NOT NULL,
    user_id integer NOT NULL,
    salary_period_id integer,
    week_number integer,
    budget_amount integer,
    start_date date NOT NULL,
    end_date date NOT NULL,
    period_type character varying(50) NOT NULL,
    created_at timestamp without time zone,
    CONSTRAINT check_budget_period_date_order CHECK ((start_date <= end_date))
);


ALTER TABLE public.budget_periods OWNER TO neondb_owner;

--
-- Name: budget_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.budget_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_periods_id_seq OWNER TO neondb_owner;

--
-- Name: budget_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.budget_periods_id_seq OWNED BY public.budget_periods.id;


--
-- Name: credit_card_settings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.credit_card_settings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    credit_limit integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.credit_card_settings OWNER TO neondb_owner;

--
-- Name: credit_card_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.credit_card_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.credit_card_settings_id_seq OWNER TO neondb_owner;

--
-- Name: credit_card_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.credit_card_settings_id_seq OWNED BY public.credit_card_settings.id;


--
-- Name: debts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.debts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(200) NOT NULL,
    original_amount integer NOT NULL,
    current_balance integer NOT NULL,
    monthly_payment integer NOT NULL,
    archived boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    CONSTRAINT check_debt_positive_current CHECK ((current_balance >= 0)),
    CONSTRAINT check_debt_positive_original CHECK ((original_amount > 0)),
    CONSTRAINT check_debt_positive_payment CHECK ((monthly_payment > 0))
);


ALTER TABLE public.debts OWNER TO neondb_owner;

--
-- Name: debts_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.debts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.debts_id_seq OWNER TO neondb_owner;

--
-- Name: debts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.debts_id_seq OWNED BY public.debts.id;


--
-- Name: expense_name_mappings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.expense_name_mappings (
    id integer NOT NULL,
    expense_name character varying(200) NOT NULL,
    subcategory character varying(100) NOT NULL,
    confidence double precision,
    last_updated timestamp without time zone
);


ALTER TABLE public.expense_name_mappings OWNER TO neondb_owner;

--
-- Name: expense_name_mappings_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.expense_name_mappings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expense_name_mappings_id_seq OWNER TO neondb_owner;

--
-- Name: expense_name_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.expense_name_mappings_id_seq OWNED BY public.expense_name_mappings.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    user_id integer NOT NULL,
    budget_period_id integer,
    recurring_template_id integer,
    name character varying(200) NOT NULL,
    amount integer NOT NULL,
    category character varying(100) NOT NULL,
    subcategory character varying(100),
    date date NOT NULL,
    due_date character varying(50),
    payment_method character varying(20) NOT NULL,
    notes text,
    receipt_url character varying(500),
    is_fixed_bill boolean NOT NULL,
    created_at timestamp without time zone,
    CONSTRAINT check_expense_positive_amount CHECK ((amount > 0))
);


ALTER TABLE public.expenses OWNER TO neondb_owner;

--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expenses_id_seq OWNER TO neondb_owner;

--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: goals; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.goals (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    target_amount integer NOT NULL,
    target_date date,
    subcategory_name character varying(100) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    CONSTRAINT check_goal_positive_amount CHECK ((target_amount > 0))
);


ALTER TABLE public.goals OWNER TO neondb_owner;

--
-- Name: goals_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.goals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.goals_id_seq OWNER TO neondb_owner;

--
-- Name: goals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.goals_id_seq OWNED BY public.goals.id;


--
-- Name: income; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.income (
    id integer NOT NULL,
    user_id integer NOT NULL,
    budget_period_id integer,
    type character varying(50) NOT NULL,
    amount integer NOT NULL,
    scheduled_date date,
    actual_date date,
    created_at timestamp without time zone,
    CONSTRAINT check_income_positive_amount CHECK ((amount > 0))
);


ALTER TABLE public.income OWNER TO neondb_owner;

--
-- Name: income_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.income_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.income_id_seq OWNER TO neondb_owner;

--
-- Name: income_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.income_id_seq OWNED BY public.income.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.password_reset_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    is_used boolean NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO neondb_owner;

--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.password_reset_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.password_reset_tokens_id_seq OWNER TO neondb_owner;

--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.password_reset_tokens_id_seq OWNED BY public.password_reset_tokens.id;


--
-- Name: period_suggestions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.period_suggestions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    budget_period_id integer NOT NULL,
    suggestion_type character varying(100) NOT NULL,
    amount integer NOT NULL,
    status character varying(20),
    created_at timestamp without time zone
);


ALTER TABLE public.period_suggestions OWNER TO neondb_owner;

--
-- Name: period_suggestions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.period_suggestions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.period_suggestions_id_seq OWNER TO neondb_owner;

--
-- Name: period_suggestions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.period_suggestions_id_seq OWNED BY public.period_suggestions.id;


--
-- Name: recurring_expenses; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.recurring_expenses (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(200) NOT NULL,
    amount integer NOT NULL,
    category character varying(100) NOT NULL,
    subcategory character varying(100),
    payment_method character varying(20) NOT NULL,
    frequency character varying(20) NOT NULL,
    frequency_value integer,
    day_of_month integer,
    day_of_week integer,
    start_date date NOT NULL,
    end_date date,
    next_due_date date NOT NULL,
    is_active boolean NOT NULL,
    is_fixed_bill boolean NOT NULL,
    notes text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    CONSTRAINT check_recurring_positive_amount CHECK ((amount > 0))
);


ALTER TABLE public.recurring_expenses OWNER TO neondb_owner;

--
-- Name: recurring_expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.recurring_expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recurring_expenses_id_seq OWNER TO neondb_owner;

--
-- Name: recurring_expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.recurring_expenses_id_seq OWNED BY public.recurring_expenses.id;


--
-- Name: salary_periods; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.salary_periods (
    id integer NOT NULL,
    user_id integer NOT NULL,
    initial_debit_balance integer NOT NULL,
    initial_credit_balance integer NOT NULL,
    credit_limit integer NOT NULL,
    credit_budget_allowance integer NOT NULL,
    salary_amount integer,
    total_budget_amount integer NOT NULL,
    fixed_bills_total integer NOT NULL,
    remaining_amount integer NOT NULL,
    weekly_budget integer NOT NULL,
    weekly_debit_budget integer NOT NULL,
    weekly_credit_budget integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone,
    CONSTRAINT check_salary_period_date_order CHECK ((start_date <= end_date)),
    CONSTRAINT check_salary_period_positive_credit_limit CHECK ((credit_limit >= 0))
);


ALTER TABLE public.salary_periods OWNER TO neondb_owner;

--
-- Name: salary_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.salary_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.salary_periods_id_seq OWNER TO neondb_owner;

--
-- Name: salary_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.salary_periods_id_seq OWNED BY public.salary_periods.id;


--
-- Name: subcategories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.subcategories (
    id integer NOT NULL,
    user_id integer,
    category character varying(100) NOT NULL,
    name character varying(100) NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.subcategories OWNER TO neondb_owner;

--
-- Name: subcategories_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.subcategories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subcategories_id_seq OWNER TO neondb_owner;

--
-- Name: subcategories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.subcategories_id_seq OWNED BY public.subcategories.id;


--
-- Name: user_defaults; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.user_defaults (
    id integer NOT NULL,
    user_id integer NOT NULL,
    default_expense_name character varying(200),
    default_category character varying(100),
    default_subcategory character varying(100),
    default_payment_method character varying(20)
);


ALTER TABLE public.user_defaults OWNER TO neondb_owner;

--
-- Name: user_defaults_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.user_defaults_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_defaults_id_seq OWNER TO neondb_owner;

--
-- Name: user_defaults_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.user_defaults_id_seq OWNED BY public.user_defaults.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone,
    failed_login_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp without time zone,
    recurring_lookahead_days integer DEFAULT 14 NOT NULL,
    CONSTRAINT check_user_failed_attempts CHECK ((failed_login_attempts >= 0)),
    CONSTRAINT check_user_lookahead_range CHECK (((recurring_lookahead_days >= 7) AND (recurring_lookahead_days <= 90)))
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: budget_periods id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.budget_periods ALTER COLUMN id SET DEFAULT nextval('public.budget_periods_id_seq'::regclass);


--
-- Name: credit_card_settings id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_card_settings ALTER COLUMN id SET DEFAULT nextval('public.credit_card_settings_id_seq'::regclass);


--
-- Name: debts id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.debts ALTER COLUMN id SET DEFAULT nextval('public.debts_id_seq'::regclass);


--
-- Name: expense_name_mappings id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expense_name_mappings ALTER COLUMN id SET DEFAULT nextval('public.expense_name_mappings_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: goals id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.goals ALTER COLUMN id SET DEFAULT nextval('public.goals_id_seq'::regclass);


--
-- Name: income id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income ALTER COLUMN id SET DEFAULT nextval('public.income_id_seq'::regclass);


--
-- Name: password_reset_tokens id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens ALTER COLUMN id SET DEFAULT nextval('public.password_reset_tokens_id_seq'::regclass);


--
-- Name: period_suggestions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.period_suggestions ALTER COLUMN id SET DEFAULT nextval('public.period_suggestions_id_seq'::regclass);


--
-- Name: recurring_expenses id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_expenses ALTER COLUMN id SET DEFAULT nextval('public.recurring_expenses_id_seq'::regclass);


--
-- Name: salary_periods id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.salary_periods ALTER COLUMN id SET DEFAULT nextval('public.salary_periods_id_seq'::regclass);


--
-- Name: subcategories id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories ALTER COLUMN id SET DEFAULT nextval('public.subcategories_id_seq'::regclass);


--
-- Name: user_defaults id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_defaults ALTER COLUMN id SET DEFAULT nextval('public.user_defaults_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.alembic_version (version_num) FROM stdin;
c5d8e9a2b1f3
\.


--
-- Data for Name: budget_periods; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.budget_periods (id, user_id, salary_period_id, week_number, budget_amount, start_date, end_date, period_type, created_at) FROM stdin;
1	1	1	1	18365	2025-11-20	2025-11-26	weekly	2025-12-04 16:06:13.903987
2	1	1	2	18365	2025-11-27	2025-12-03	weekly	2025-12-04 16:06:13.903989
3	1	1	3	18365	2025-12-04	2025-12-10	weekly	2025-12-04 16:06:13.90399
4	1	1	4	18365	2025-12-11	2025-12-19	weekly	2025-12-04 16:06:13.90399
5	1	2	1	20743	2025-12-20	2025-12-26	weekly	2025-12-17 10:14:43.949622
6	1	2	2	20743	2025-12-27	2026-01-02	weekly	2025-12-17 10:14:43.949624
7	1	2	3	20743	2026-01-03	2026-01-09	weekly	2025-12-17 10:14:43.949625
8	1	2	4	20743	2026-01-10	2026-01-19	weekly	2025-12-17 10:14:43.949625
9	3	3	1	50000	2025-12-23	2025-12-29	weekly	2025-12-23 16:45:25.74918
10	3	3	2	50000	2025-12-30	2026-01-05	weekly	2025-12-23 16:45:25.749183
11	3	3	3	50000	2026-01-06	2026-01-12	weekly	2025-12-23 16:45:25.749184
12	3	3	4	50000	2026-01-13	2026-01-22	weekly	2025-12-23 16:45:25.749184
\.


--
-- Data for Name: credit_card_settings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.credit_card_settings (id, user_id, credit_limit, created_at, updated_at) FROM stdin;
1	1	150000	2025-12-04 16:05:51.79458	2025-12-04 16:05:51.794584
2	2	150000	2025-12-05 22:12:33.70062	2025-12-05 22:12:33.700624
3	3	150000	2025-12-23 15:51:20.432803	2025-12-23 15:51:20.432808
\.


--
-- Data for Name: debts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.debts (id, user_id, name, original_amount, current_balance, monthly_payment, archived, created_at, updated_at) FROM stdin;
6	1	Telia Rahoitus	100000	75455	4546	f	2025-12-04 16:06:13.723429	2025-12-22 23:49:01.029762
5	1	Elisa (Phone)	84840	63630	3535	f	2025-12-04 16:06:13.718028	2025-12-22 23:49:49.151239
4	1	Klarna Gigantti	63773	53127	5323	f	2025-12-04 16:06:13.712809	2025-12-22 23:51:51.848399
3	1	Klarna Turkish Airlines Business	54422	43943	10479	f	2025-12-04 16:06:13.707428	2025-12-22 23:52:47.838394
2	1	Klarna Turkish Airlines New	117469	76305	10291	f	2025-12-04 16:06:13.701772	2025-12-22 23:53:23.500407
1	1	Klarna Turkish Airlines Old	205855	33645	10080	f	2025-12-04 16:06:13.692827	2025-12-22 23:53:58.129611
\.


--
-- Data for Name: expense_name_mappings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.expense_name_mappings (id, expense_name, subcategory, confidence, last_updated) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.expenses (id, user_id, budget_period_id, recurring_template_id, name, amount, category, subcategory, date, due_date, payment_method, notes, receipt_url, is_fixed_bill, created_at) FROM stdin;
1	1	\N	\N	Pre-existing Credit Card Debt	141058	Debt	Credit Card	2025-11-19	N/A	Credit card	Existing credit card balance at budget period start	\N	f	2025-12-04 16:06:13.914645
2	1	2	1	Telia	4546	Debt Payments	Telia Rahoitus	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:13.991189
3	1	2	2	Elisa	3535	Debt Payments	Elisa (Phone)	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.001089
4	1	2	3	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.009865
5	1	2	4	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.018561
6	1	2	5	Klarna Turkish Airlines Old	10080	Debt Payments	Klarna Turkish Airlines Old	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.030294
7	1	2	\N	Rent	94718	Fixed Expenses	Rent	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.039037
8	1	2	\N	DNA	3490	Fixed Expenses	Subscriptions	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.047386
11	1	1	\N	Wise Europe SA	4233	Flexible Expenses	Shopping	2025-11-22	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.102966
12	1	1	\N	Wise	3888	Flexible Expenses	Shopping	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.116186
13	1	1	\N	UBER   *TRIP	18	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.125584
14	1	1	\N	Nordea Responsible Global	5000	Flexible Expenses	Shopping	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.134744
15	1	1	\N	UBER   *TRIP	37	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.143014
16	1	1	\N	UBR* PENDING.UBER.COM	366	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.191232
17	1	1	\N	UBR* PENDING.UBER.COM	277	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.2
18	1	1	\N	UBER   *TRIP	243	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.209241
19	1	1	\N	UBER   *TRIP	73	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.217657
20	1	1	\N	UBR* PENDING.UBER.COM	118	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.225929
21	1	2	\N	PAYPAL *DISNEYPLUS	1099	Fixed Expenses	Subscriptions	2025-11-28	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.234435
22	1	2	\N	Retail NLD Amsterdam UBER *TRIP HELP.UBER.C	2059	Flexible Expenses	Transportation	2025-11-27	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.287782
23	1	1	\N	Retail FIN Finland Wolt Oy	2614	Flexible Expenses	Food	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.297088
24	1	1	\N	Retail FIN HELSINKI VFI*Armina Oy ITIS	6767	Flexible Expenses	Shopping	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.30562
25	1	1	\N	Retail NLD HELP.UBER.COM UBER *TRIP	1969	Flexible Expenses	Transportation	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.313831
26	1	1	\N	Retail NLD Amsterdam UBER *TRIP HELP.UBER.C	1939	Flexible Expenses	Transportation	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.322517
27	1	1	\N	Retail FIN Helsinki BIBI Bistro	1619	Flexible Expenses	Shopping	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.33067
28	1	1	\N	Retail NLD Amsterdam UBER *TRIP HELP.UBER.C	1854	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.33925
29	1	1	\N	Retail FIN Finland Wolt Oy	543	Flexible Expenses	Food	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.347687
30	1	1	\N	Retail FIN Espoo KFC Iso Omena	1175	Flexible Expenses	Shopping	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.393561
31	1	1	\N	Retail NLD HELP.UBER.COM UBER *TRIP	1697	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.401544
32	1	1	\N	TRY 1182.18 Retail TUR ISTANBUL F17 OBICA MOZ	2487	Flexible Expenses	Shopping	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.409402
33	1	1	\N	TRY 40.00 Retail NLD HELP.UBER.COM UBER *	84	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.417416
34	1	1	\N	TRY 655.00 Retail NLD HELP.UBER.COM UBER *	1378	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.425739
35	1	1	\N	TRY 1221.00 Retail TUR ISTANBUL TAKSI YONETIM	2577	Flexible Expenses	Shopping	2025-11-24	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.433975
36	1	1	\N	Retail TUR ISTANBUL GNC AIRPORT HOTEL	100	Flexible Expenses	Shopping	2025-11-24	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.442823
37	1	1	\N	Retail TUR ISTANBUL GNC AIRPORT HOTEL	3000	Flexible Expenses	Shopping	2025-11-24	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.493253
38	1	1	\N	TRY 1650.00 Retail TUR ISTANBUL GNC AIRPORT H	3483	Flexible Expenses	Shopping	2025-11-24	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.502175
39	1	1	\N	USD 67.95 Retail TUR ANKARA E-VISA TURKEY	6048	Flexible Expenses	Shopping	2025-11-23	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.510495
40	1	1	\N	BDT 560.00 Retail BGD Shantinagar T FRESH &	405	Flexible Expenses	Shopping	2025-11-21	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.518961
41	1	1	\N	BDT 400.00 Retail BGD Shantinagar T HAKKA EX	290	Flexible Expenses	Shopping	2025-11-21	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.527468
42	1	1	\N	BDT 1680.00 Retail BGD Gulshan Model KIVAHAN	1223	Flexible Expenses	Shopping	2025-11-20	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.535601
43	1	1	\N	BDT 470.00 Retail BGD Gulshan Model ALFRESCO	343	Flexible Expenses	Shopping	2025-11-20	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.587727
44	1	1	\N	Payment to Klarna Turkish Airlines Old	4112	Debt Payments	Klarna Turkish Airlines Old	2025-11-26	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.597124
45	1	2	11	Insinööriliitto	3525	Fixed Expenses	Insurance	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.605679
46	1	2	\N	Mee6	4203	Flexible Expenses	Entertainment	2025-11-29	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.614016
47	1	2	\N	ImageGPT	2241	Flexible Expenses	Entertainment	2025-11-29	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.622792
48	1	2	\N	Namecheap	637	Flexible Expenses	Entertainment	2025-11-29	N/A	Credit card	\N	\N	f	2025-12-04 16:06:14.631742
10	1	1	\N	Credit card repayment	99104	Debt Payments	Credit Card	2025-11-20	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.094241
49	1	2	\N	Wolt	5004	Flexible Expenses	Food	2025-11-30	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.686852
51	1	2	\N	Snapchat	99	Flexible Expenses	Entertainment	2025-11-30	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.707763
52	1	2	\N	YouTube	1499	Flexible Expenses	Entertainment	2025-11-30	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.716167
53	1	2	\N	Wolt	1478	Flexible Expenses	Food	2025-12-02	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.724467
54	1	2	\N	Wolt	3356	Flexible Expenses	Food	2025-12-03	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.73294
9	1	2	\N	Fortum	2651	Fixed Expenses	Utilities	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.056033
55	1	3	\N	Wolt	6212	Flexible Expenses	Food	2025-12-04	N/A	Debit card	\N	\N	f	2025-12-04 16:07:50.508079
56	1	3	\N	Wolt	3294	Flexible Expenses	Food	2025-12-04	N/A	Debit card	\N	\N	f	2025-12-04 16:09:32.892452
57	1	3	\N	Wolt	1027	Flexible Expenses	Food	2025-12-05	N/A	Debit card	\N	\N	f	2025-12-05 11:18:41.340793
58	1	3	\N	Wolt	2424	Flexible Expenses	Food	2025-12-05	N/A	Debit card	\N	\N	f	2025-12-05 11:18:55.891369
59	1	3	\N	Wolt	3271	Flexible Expenses	Food	2025-12-06	N/A	Credit card	\N	\N	f	2025-12-06 10:25:51.052266
60	1	3	\N	Wolt	2101	Flexible Expenses	Food	2025-12-05	N/A	Debit card	\N	\N	f	2025-12-06 14:11:36.395363
61	1	\N	\N	Uber	1304	Flexible Expenses	Transportation	2025-12-07	N/A	Debit card	\N	\N	f	2025-12-07 17:29:07.343085
62	1	\N	\N	Uber	1251	Flexible Expenses	Transportation	2025-12-07	N/A	Debit card	\N	\N	f	2025-12-07 17:29:33.885755
63	1	\N	\N	Wolt	2840	Flexible Expenses	Food	2025-12-07	N/A	Debit card	\N	\N	f	2025-12-07 17:29:44.937947
64	1	\N	\N	Nordea	465	Fixed Expenses	Subscriptions	2025-12-10	N/A	Debit card	\N	\N	f	2025-12-10 08:14:21.791929
65	1	\N	\N	Wolt	1351	Flexible Expenses	Food	2025-12-10	N/A	Debit card	\N	\N	f	2025-12-10 10:55:44.808684
66	1	\N	\N	Wolt	3054	Flexible Expenses	Food	2025-12-10	N/A	Debit card	\N	\N	f	2025-12-10 10:55:55.959342
67	1	\N	\N	Uber	912	Flexible Expenses	Transportation	2025-12-11	N/A	Debit card	\N	\N	f	2025-12-11 10:47:24.381581
68	1	\N	\N	Sodexo Nokia	860	Flexible Expenses	Food	2025-12-11	N/A	Debit card	\N	\N	f	2025-12-11 10:47:48.478915
69	1	\N	\N	Settlement Survivors	692	Flexible Expenses	Entertainment	2025-12-11	N/A	Credit card	\N	\N	f	2025-12-11 10:48:29.418718
70	1	\N	\N	Nordea Credit	99	Fixed Expenses	Subscriptions	2025-12-11	N/A	Credit card	\N	\N	f	2025-12-11 10:48:52.431043
71	1	\N	\N	HSL	320	Flexible Expenses	Transportation	2025-12-11	N/A	Debit card	\N	\N	f	2025-12-11 21:22:50.721342
72	1	\N	\N	Uber	1378	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	\N	\N	f	2025-12-11 21:24:18.577382
73	1	\N	\N	Wolt	1626	Flexible Expenses	Food	2025-12-12	N/A	Debit card	\N	\N	f	2025-12-12 12:39:14.744577
85	1	\N	\N	Wolt	1999	Flexible Expenses	Food	2025-12-12	N/A	Credit card	\N	\N	f	2025-12-12 23:57:15.117517
86	1	\N	\N	Wolt	5129	Flexible Expenses	Food	2025-12-12	N/A	Credit card	\N	\N	f	2025-12-12 23:57:24.640442
87	1	\N	\N	Verkkokauppa (OnePlus Buds Pro 4)	8590	Flexible Expenses	Shopping	2025-12-12	N/A	Debit card	\N	\N	f	2025-12-12 23:58:13.154874
88	1	\N	\N	Adjusting credit	10	Fixed Expenses	Utilities	2025-12-12	N/A	Credit card	\N	\N	f	2025-12-12 23:58:48.067889
78	1	\N	5	Klarna Turkish Airlines Old	10080	Debt Payments	Klarna Turkish Airlines Old	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.26532
74	1	\N	1	Telia	4546	Debt Payments	Telia Rahoitus	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.226641
75	1	\N	2	Elisa	3535	Debt Payments	Elisa (Phone)	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.237049
76	1	\N	3	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.246338
77	1	\N	4	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.255959
82	1	\N	10	DNA	3490	Fixed Expenses	Subscriptions	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.33003
80	1	\N	8	Rent	94718	Fixed Expenses	Rent	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.284605
100	1	\N	\N	Caruna	4583	Fixed Expenses	Utilities	2025-12-19	N/A	Debit card	\N	\N	f	2025-12-13 00:01:33.115932
114	1	\N	\N	Canva Subscription	600	Flexible Expenses	Shopping	2025-12-15	N/A	Debit card	\N	\N	f	2025-12-15 15:40:41.915651
113	1	\N	15	Telia Dot	810	Fixed Expenses	Subscriptions	2025-12-15	N/A	Debit card	\N	\N	f	2025-12-15 15:08:07.937896
115	1	\N	\N	Prime Video	699	Flexible Expenses	Entertainment	2025-12-15	N/A	Debit card	\N	\N	f	2025-12-15 15:41:37.334051
118	1	\N	16	Discord	999	Fixed Expenses	Subscriptions	2025-12-16	N/A	Credit card	\N	\N	f	2025-12-16 14:24:00.304481
121	1	\N	\N	Wolt	1711	Flexible Expenses	Food	2025-12-16	N/A	Debit card	\N	\N	f	2025-12-16 14:26:21.878437
122	1	\N	\N	Wolt	2672	Flexible Expenses	Food	2025-12-16	N/A	Debit card	\N	\N	f	2025-12-16 14:26:27.815188
128	1	\N	\N	Temu	6045	Flexible Expenses	Shopping	2025-12-17	N/A	Debit card	\N	\N	f	2025-12-17 09:38:16.68101
130	1	\N	\N	Wolt	1487	Flexible Expenses	Food	2025-12-17	N/A	Credit card	\N	\N	f	2025-12-17 16:07:58.844461
131	1	\N	\N	Wolt	2270	Flexible Expenses	Food	2025-12-17	N/A	Credit card	\N	\N	f	2025-12-17 16:08:11.427218
132	1	\N	\N	Wolt	2365	Flexible Expenses	Food	2025-12-18	N/A	Debit card	\N	\N	f	2025-12-18 22:23:55.164613
133	1	\N	\N	Netflix	949	Flexible Expenses	Entertainment	2025-12-18	N/A	Credit card	\N	\N	f	2025-12-18 22:24:50.576909
134	1	\N	\N	Temu	4215	Flexible Expenses	Shopping	2025-12-19	N/A	Debit card	\N	\N	f	2025-12-19 07:53:36.408135
81	1	\N	9	Fortum	1788	Fixed Expenses	Utilities	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.293648
135	1	\N	\N	Savings	5000	Savings & Investments	Emergency Fund	2025-12-19	N/A	Debit card	\N	\N	f	2025-12-20 16:55:12.277545
137	1	\N	\N	Klarna Turkish Airlines Business Payment	10479	Debt Payments	Klarna Turkish Airlines Business	2025-12-19	N/A	Debit card	\N	\N	f	2025-12-21 13:24:38.400549
138	1	\N	\N	Wolt	2796	Flexible Expenses	Food	2025-12-21	N/A	Debit card	\N	\N	f	2025-12-21 13:25:10.284668
140	1	\N	\N	Wolt	4549	Flexible Expenses	Food	2025-12-21	N/A	Debit card	\N	\N	f	2025-12-21 15:45:20.225022
127	1	\N	\N	Zooplus	4946	Flexible Expenses	Cat Stuff	2025-12-17	N/A	Debit card	\N	\N	f	2025-12-16 23:57:32.64
125	1	\N	\N	Credit repayment	80000	Debt Payments	Credit Card	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-16 23:56:34.555753
141	1	\N	12	YouTube	1499	Flexible Expenses	Entertainment	2025-12-30	N/A	Debit card	\N	\N	t	2025-12-22 23:54:35.07162
142	1	\N	16	Discord	999	Fixed Expenses	Subscriptions	2026-01-16	N/A	Credit card	\N	\N	t	2025-12-23 00:25:02.137551
143	1	\N	9	Fortum	3000	Fixed Expenses	Utilities	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.212115
144	1	\N	10	DNA	3490	Fixed Expenses	Subscriptions	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.219266
145	1	\N	1	Telia	4546	Debt Payments	Telia Rahoitus	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.225717
146	1	\N	3	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.231736
147	1	\N	8	Rent	94718	Fixed Expenses	Rent	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.237762
148	1	\N	5	Klarna Turkish Airlines Old	10080	Debt Payments	Klarna Turkish Airlines Old	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.243697
149	1	\N	18	Investment (Nordea) Contribution	5000	Savings & Investments	Investment (Nordea)	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-23 00:25:02.249619
150	1	\N	2	Elisa	3535	Debt Payments	Elisa (Phone)	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.255682
151	1	\N	4	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.261507
152	1	\N	11	Insinööriliitto	3525	Fixed Expenses	Insurance	2026-01-15	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.314166
153	1	\N	15	Telia Dot	810	Fixed Expenses	Subscriptions	2026-01-15	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.320684
154	3	\N	\N	Emergency	55000	Savings & Investments	Emergency Fund	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-23 16:46:44.230719
155	3	\N	\N	Wolt	2400	Fixed Expenses	Insurance	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-23 16:48:17.557856
156	1	\N	\N	Proton vpn	999	Flexible Expenses	Entertainment	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-23 18:44:26.114863
157	1	\N	\N	Wolt	3311	Flexible Expenses	Food	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-24 01:18:34.460833
158	1	\N	\N	Wolt	1520	Flexible Expenses	Food	2025-12-23	N/A	Credit card	\N	\N	f	2025-12-24 01:19:10.006105
\.


--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.goals (id, user_id, name, description, target_amount, target_date, subcategory_name, is_active, created_at, updated_at) FROM stdin;
2	1	Investment (Nordea)	\N	100000	2026-12-31	Investment (Nordea)	t	2025-12-22 23:43:36.744481	2025-12-22 23:43:36.744483
3	1	Emergency Fund	\N	200000	\N	Emergency Fund	t	2025-12-23 00:02:04.667374	2025-12-23 00:02:04.667376
4	3	Emergency Fund	For an emergency fund nigga	700000	\N	Emergency Fund	t	2025-12-23 16:44:06.685006	2025-12-23 16:44:06.68501
\.


--
-- Data for Name: income; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.income (id, user_id, budget_period_id, type, amount, scheduled_date, actual_date, created_at) FROM stdin;
1	1	\N	Initial Balance	307200	2025-11-20	2025-11-20	2025-12-04 16:06:13.923676
2	1	2	Other	30350	2025-11-27	2025-11-27	2025-12-04 16:06:14.746151
3	1	\N	Salary	281545	2025-12-19	2025-12-19	2025-12-16 22:12:14.124386
5	3	\N	Initial Balance	200000	2025-12-23	2025-12-23	2025-12-23 16:45:25.789574
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.password_reset_tokens (id, user_id, token, expires_at, is_used, created_at) FROM stdin;
\.


--
-- Data for Name: period_suggestions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.period_suggestions (id, user_id, budget_period_id, suggestion_type, amount, status, created_at) FROM stdin;
\.


--
-- Data for Name: recurring_expenses; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.recurring_expenses (id, user_id, name, amount, category, subcategory, payment_method, frequency, frequency_value, day_of_month, day_of_week, start_date, end_date, next_due_date, is_active, is_fixed_bill, notes, created_at, updated_at) FROM stdin;
12	1	YouTube	1499	Flexible Expenses	Entertainment	Debit card	monthly	\N	30	\N	2025-11-30	\N	2026-01-28	t	t	\N	2025-12-04 16:06:13.887384	2025-12-22 23:54:35.067762
16	1	Discord	999	Fixed Expenses	Subscriptions	Credit card	monthly	\N	16	\N	2026-01-16	\N	2026-02-16	t	t	\N	2025-12-16 14:23:59.9971	2025-12-23 00:25:02.130609
9	1	Fortum	3000	Fixed Expenses	Utilities	Debit card	monthly	\N	20	\N	2025-12-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.825636	2025-12-23 00:25:02.144444
10	1	DNA	3490	Fixed Expenses	Subscriptions	Debit card	monthly	\N	20	\N	2025-12-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.831015	2025-12-23 00:25:02.216822
1	1	Telia	4546	Debt Payments	Telia Rahoitus	Debit card	monthly	\N	20	\N	2025-11-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.734805	2025-12-23 00:25:02.223035
3	1	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	Debit card	monthly	\N	20	\N	2025-11-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.790754	2025-12-23 00:25:02.229528
8	1	Rent	94718	Fixed Expenses	Rent	Debit card	monthly	\N	20	\N	2025-12-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.820155	2025-12-23 00:25:02.23557
5	1	Klarna Turkish Airlines Old	10080	Debt Payments	Klarna Turkish Airlines Old	Debit card	monthly	\N	20	\N	2025-11-24	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.802794	2025-12-23 00:25:02.241496
2	1	Elisa	3535	Debt Payments	Elisa (Phone)	Debit card	monthly	\N	20	\N	2025-11-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.744124	2025-12-23 00:25:02.25322
4	1	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	Debit card	monthly	\N	20	\N	2025-11-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.797164	2025-12-23 00:25:02.259373
11	1	Insinööriliitto	3525	Fixed Expenses	Insurance	Debit card	monthly	\N	15	\N	2026-01-15	\N	2026-02-15	t	t	\N	2025-12-04 16:06:13.836541	2025-12-23 00:25:02.26527
15	1	Telia Dot	810	Fixed Expenses	Subscriptions	Debit card	monthly	\N	15	\N	2026-01-15	\N	2026-02-15	t	t	\N	2025-12-15 15:08:07.74988	2025-12-23 00:25:02.318549
18	1	Investment (Nordea) Contribution	5000	Savings & Investments	Investment (Nordea)	Debit card	monthly	\N	20	\N	2025-12-23	\N	2026-01-20	t	t	\N	2025-12-23 00:23:52.47975	2025-12-23 00:25:27.120137
19	3	Emergency Fund Contribution	1500	Savings & Investments	Emergency Fund	Credit card	monthly	\N	1	\N	2025-12-23	\N	2025-12-23	t	f	\N	2025-12-23 16:44:37.639115	2025-12-23 16:44:37.639117
\.


--
-- Data for Name: salary_periods; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.salary_periods (id, user_id, initial_debit_balance, initial_credit_balance, credit_limit, credit_budget_allowance, salary_amount, total_budget_amount, fixed_bills_total, remaining_amount, weekly_budget, weekly_debit_budget, weekly_credit_budget, start_date, end_date, is_active, created_at) FROM stdin;
1	1	307200	8942	150000	0	\N	73462	233738	73462	18365	18365	0	2025-11-20	2025-12-19	f	2025-12-04 16:06:13.895815
2	1	289374	50178	150000	20000	\N	82975	226399	82975	20743	15743	5000	2025-12-20	2026-01-19	t	2025-12-17 10:14:43.940326
3	3	200000	0	2000000	0	\N	200000	0	200000	50000	50000	0	2025-12-23	2026-01-22	t	2025-12-23 16:45:25.738348
\.


--
-- Data for Name: subcategories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.subcategories (id, user_id, category, name, is_system, is_active, created_at, updated_at) FROM stdin;
1	\N	Flexible Expenses	Food	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
2	\N	Savings & Investments	Other	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
3	\N	Fixed Expenses	Subscriptions	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
4	\N	Flexible Expenses	Shopping	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
5	\N	Fixed Expenses	Other	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
7	\N	Fixed Expenses	Rent	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
8	\N	Debt Payments	Other	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
9	\N	Flexible Expenses	Other	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
10	\N	Fixed Expenses	Insurance	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
13	\N	Debt Payments	Credit Card	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
14	\N	Flexible Expenses	Entertainment	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
15	\N	Fixed Expenses	Utilities	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
16	\N	Flexible Expenses	Transportation	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
17	\N	Flexible Expenses	Health	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
18	1	Flexible Expenses	Cat Stuff	f	t	2025-12-22 23:35:38.262498	2025-12-22 23:35:38.2625
20	1	Savings & Investments	Investment (Nordea)	f	t	2025-12-22 23:43:36.735751	2025-12-22 23:43:36.735753
21	1	Savings & Investments	Emergency Fund	f	t	2025-12-23 00:02:04.65833	2025-12-23 00:02:04.658332
22	3	Savings & Investments	Emergency Fund	f	t	2025-12-23 16:44:06.66174	2025-12-23 16:44:06.661744
23	3	Flexible Expenses	Bullshit spending	f	t	2025-12-23 16:50:54.530363	2025-12-23 16:51:33.969076
\.


--
-- Data for Name: user_defaults; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.user_defaults (id, user_id, default_expense_name, default_category, default_subcategory, default_payment_method) FROM stdin;
1	1	Wolt	Flexible Expenses	Food	credit
2	2	Wolt	Flexible Expenses	Food	credit
3	3	Wolt	Flexible Expenses	Food	credit
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, email, password_hash, created_at, failed_login_attempts, locked_until, recurring_lookahead_days) FROM stdin;
2	big-boss@bloom-tracker.app	scrypt:32768:8:1$rMuIqMrQKzV7RHjD$61d89186211c4125f5157f52013d9077d6d0c8711de2036fb01e48d9d8b367c63ee2d9d8ed92d9d149819526e0cc97c879237c3dac1d7ccc8ab535075e24992a	2025-12-05 22:12:33.602733	0	\N	14
1	saiyuriye.rafia@gmail.com	scrypt:32768:8:1$NTBL2jq9wdswJ317$a866f96e54aca726260d216f04bafb477ea426ef8b0e70d692ebf7cf7845861bffea341bc39be6659d6e06e7ec33768e519f3f35ba523f62a5df1bb625f9a905	2025-12-04 16:05:51.698396	0	\N	30
3	psarakismichail@gmail.com	scrypt:32768:8:1$k9ddNY6qoqP6pvQF$2473df38dc19c5554b6c1e5e37bb86f3211579fb7777ffd799d748e431e5f1c7f88387309348f5b51e917d6bdd44cec57d1f2bd8d4e9c0b15d0df9d54e7bfcbf	2025-12-23 15:51:20.404149	0	\N	14
\.


--
-- Name: budget_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.budget_periods_id_seq', 12, true);


--
-- Name: credit_card_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.credit_card_settings_id_seq', 3, true);


--
-- Name: debts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.debts_id_seq', 6, true);


--
-- Name: expense_name_mappings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.expense_name_mappings_id_seq', 1, false);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.expenses_id_seq', 158, true);


--
-- Name: goals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.goals_id_seq', 4, true);


--
-- Name: income_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.income_id_seq', 5, true);


--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.password_reset_tokens_id_seq', 1, false);


--
-- Name: period_suggestions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.period_suggestions_id_seq', 1, false);


--
-- Name: recurring_expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.recurring_expenses_id_seq', 19, true);


--
-- Name: salary_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.salary_periods_id_seq', 3, true);


--
-- Name: subcategories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.subcategories_id_seq', 23, true);


--
-- Name: user_defaults_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.user_defaults_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: budget_periods budget_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.budget_periods
    ADD CONSTRAINT budget_periods_pkey PRIMARY KEY (id);


--
-- Name: credit_card_settings credit_card_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_card_settings
    ADD CONSTRAINT credit_card_settings_pkey PRIMARY KEY (id);


--
-- Name: credit_card_settings credit_card_settings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_card_settings
    ADD CONSTRAINT credit_card_settings_user_id_key UNIQUE (user_id);


--
-- Name: debts debts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_pkey PRIMARY KEY (id);


--
-- Name: expense_name_mappings expense_name_mappings_expense_name_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expense_name_mappings
    ADD CONSTRAINT expense_name_mappings_expense_name_key UNIQUE (expense_name);


--
-- Name: expense_name_mappings expense_name_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expense_name_mappings
    ADD CONSTRAINT expense_name_mappings_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id);


--
-- Name: income income_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_key UNIQUE (token);


--
-- Name: period_suggestions period_suggestions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.period_suggestions
    ADD CONSTRAINT period_suggestions_pkey PRIMARY KEY (id);


--
-- Name: recurring_expenses recurring_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_expenses
    ADD CONSTRAINT recurring_expenses_pkey PRIMARY KEY (id);


--
-- Name: salary_periods salary_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.salary_periods
    ADD CONSTRAINT salary_periods_pkey PRIMARY KEY (id);


--
-- Name: subcategories subcategories_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT subcategories_pkey PRIMARY KEY (id);


--
-- Name: user_defaults user_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_defaults
    ADD CONSTRAINT user_defaults_pkey PRIMARY KEY (id);


--
-- Name: user_defaults user_defaults_user_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_defaults
    ADD CONSTRAINT user_defaults_user_id_key UNIQUE (user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_budget_period_active; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_budget_period_active ON public.budget_periods USING btree (user_id, start_date, end_date);


--
-- Name: idx_goal_user_active; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_goal_user_active ON public.goals USING btree (user_id, is_active);


--
-- Name: idx_goal_user_subcategory; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_goal_user_subcategory ON public.goals USING btree (user_id, subcategory_name);


--
-- Name: ix_budget_periods_end_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_budget_periods_end_date ON public.budget_periods USING btree (end_date);


--
-- Name: ix_budget_periods_start_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_budget_periods_start_date ON public.budget_periods USING btree (start_date);


--
-- Name: ix_budget_periods_user_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_budget_periods_user_id ON public.budget_periods USING btree (user_id);


--
-- Name: ix_subcategories_category; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_subcategories_category ON public.subcategories USING btree (category);


--
-- Name: ix_subcategories_user_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_subcategories_user_id ON public.subcategories USING btree (user_id);


--
-- Name: budget_periods budget_periods_salary_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.budget_periods
    ADD CONSTRAINT budget_periods_salary_period_id_fkey FOREIGN KEY (salary_period_id) REFERENCES public.salary_periods(id);


--
-- Name: budget_periods budget_periods_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.budget_periods
    ADD CONSTRAINT budget_periods_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: credit_card_settings credit_card_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_card_settings
    ADD CONSTRAINT credit_card_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: debts debts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: expenses expenses_budget_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_budget_period_id_fkey FOREIGN KEY (budget_period_id) REFERENCES public.budget_periods(id);


--
-- Name: expenses expenses_recurring_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_recurring_template_id_fkey FOREIGN KEY (recurring_template_id) REFERENCES public.recurring_expenses(id);


--
-- Name: expenses expenses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: goals fk_goal_user; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT fk_goal_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subcategories fk_subcategory_user; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT fk_subcategory_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: goals goals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: income income_budget_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_budget_period_id_fkey FOREIGN KEY (budget_period_id) REFERENCES public.budget_periods(id);


--
-- Name: income income_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: period_suggestions period_suggestions_budget_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.period_suggestions
    ADD CONSTRAINT period_suggestions_budget_period_id_fkey FOREIGN KEY (budget_period_id) REFERENCES public.budget_periods(id);


--
-- Name: period_suggestions period_suggestions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.period_suggestions
    ADD CONSTRAINT period_suggestions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: recurring_expenses recurring_expenses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_expenses
    ADD CONSTRAINT recurring_expenses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: salary_periods salary_periods_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.salary_periods
    ADD CONSTRAINT salary_periods_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: subcategories subcategories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT subcategories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_defaults user_defaults_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_defaults
    ADD CONSTRAINT user_defaults_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

\unrestrict 3c4KgasaNOr9FTzJY9y389uDuLdIJutdmpE9hUMKJ4MtCMKDaT9atBagEzKrZ1w

