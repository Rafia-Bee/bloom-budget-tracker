--
-- PostgreSQL database dump
--

\restrict lvZZOXdpz0B0iXiqBxtbYFXCzhBeDagDdZOwZLfzQzt0BhrzuTb03SnEEilVi3r

-- Dumped from database version 17.7 (bdc8956)
-- Dumped by pg_dump version 17.7 (Ubuntu 17.7-3.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO neondb_owner;

--
-- Name: budget_periods; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.budget_periods (
    id integer NOT NULL,
    user_id integer NOT NULL,
    salary_period_id integer,
    week_number integer,
    budget_amount integer,
    start_date date NOT NULL,
    end_date date NOT NULL,
    period_type character varying(50) NOT NULL,
    created_at timestamp without time zone,
    CONSTRAINT check_budget_period_date_order CHECK ((start_date <= end_date)),
    CONSTRAINT check_budget_period_date_range CHECK ((start_date <= end_date)),
    CONSTRAINT check_budget_period_week_number CHECK (((week_number IS NULL) OR (week_number >= 1)))
);


ALTER TABLE public.budget_periods OWNER TO neondb_owner;

--
-- Name: budget_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.budget_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_periods_id_seq OWNER TO neondb_owner;

--
-- Name: budget_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.budget_periods_id_seq OWNED BY public.budget_periods.id;


--
-- Name: credit_card_settings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.credit_card_settings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    credit_limit integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.credit_card_settings OWNER TO neondb_owner;

--
-- Name: credit_card_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.credit_card_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.credit_card_settings_id_seq OWNER TO neondb_owner;

--
-- Name: credit_card_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.credit_card_settings_id_seq OWNED BY public.credit_card_settings.id;


--
-- Name: debts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.debts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(200) NOT NULL,
    original_amount integer NOT NULL,
    current_balance integer NOT NULL,
    monthly_payment integer NOT NULL,
    archived boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    CONSTRAINT check_debt_positive_current CHECK ((current_balance >= 0)),
    CONSTRAINT check_debt_positive_original CHECK ((original_amount > 0)),
    CONSTRAINT check_debt_positive_payment CHECK ((monthly_payment > 0))
);


ALTER TABLE public.debts OWNER TO neondb_owner;

--
-- Name: debts_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.debts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.debts_id_seq OWNER TO neondb_owner;

--
-- Name: debts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.debts_id_seq OWNED BY public.debts.id;


--
-- Name: exchange_rates; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.exchange_rates (
    id integer NOT NULL,
    base_currency character varying(3) NOT NULL,
    target_currency character varying(3) NOT NULL,
    rate double precision NOT NULL,
    rate_date date NOT NULL,
    fetched_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT exchange_rates_rate_check CHECK ((rate > (0)::double precision))
);


ALTER TABLE public.exchange_rates OWNER TO neondb_owner;

--
-- Name: exchange_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.exchange_rates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.exchange_rates_id_seq OWNER TO neondb_owner;

--
-- Name: exchange_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.exchange_rates_id_seq OWNED BY public.exchange_rates.id;


--
-- Name: expense_name_mappings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.expense_name_mappings (
    id integer NOT NULL,
    expense_name character varying(200) NOT NULL,
    subcategory character varying(100) NOT NULL,
    confidence double precision,
    last_updated timestamp without time zone
);


ALTER TABLE public.expense_name_mappings OWNER TO neondb_owner;

--
-- Name: expense_name_mappings_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.expense_name_mappings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expense_name_mappings_id_seq OWNER TO neondb_owner;

--
-- Name: expense_name_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.expense_name_mappings_id_seq OWNED BY public.expense_name_mappings.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    user_id integer NOT NULL,
    budget_period_id integer,
    recurring_template_id integer,
    name character varying(200) NOT NULL,
    amount integer NOT NULL,
    category character varying(100) NOT NULL,
    subcategory character varying(100),
    date date NOT NULL,
    due_date character varying(50),
    payment_method character varying(20) NOT NULL,
    notes text,
    receipt_url character varying(500),
    is_fixed_bill boolean NOT NULL,
    created_at timestamp without time zone,
    currency character varying(3) DEFAULT 'EUR'::character varying NOT NULL,
    original_amount integer,
    exchange_rate_used double precision,
    deleted_at timestamp without time zone,
    updated_at timestamp without time zone,
    CONSTRAINT check_expense_positive_amount CHECK ((amount > 0))
);


ALTER TABLE public.expenses OWNER TO neondb_owner;

--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expenses_id_seq OWNER TO neondb_owner;

--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: goals; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.goals (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    target_amount integer NOT NULL,
    target_date date,
    subcategory_name character varying(100) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    initial_amount integer DEFAULT 0 NOT NULL,
    deleted_at timestamp without time zone,
    CONSTRAINT check_goal_positive_amount CHECK ((target_amount > 0))
);


ALTER TABLE public.goals OWNER TO neondb_owner;

--
-- Name: goals_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.goals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.goals_id_seq OWNER TO neondb_owner;

--
-- Name: goals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.goals_id_seq OWNED BY public.goals.id;


--
-- Name: income; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.income (
    id integer NOT NULL,
    user_id integer NOT NULL,
    budget_period_id integer,
    type character varying(50) NOT NULL,
    amount integer NOT NULL,
    scheduled_date date,
    actual_date date,
    created_at timestamp without time zone,
    currency character varying(3) DEFAULT 'EUR'::character varying NOT NULL,
    original_amount integer,
    exchange_rate_used double precision,
    deleted_at timestamp without time zone,
    updated_at timestamp without time zone,
    CONSTRAINT check_income_positive_amount CHECK ((amount > 0))
);


ALTER TABLE public.income OWNER TO neondb_owner;

--
-- Name: income_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.income_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.income_id_seq OWNER TO neondb_owner;

--
-- Name: income_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.income_id_seq OWNED BY public.income.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.password_reset_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    is_used boolean NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO neondb_owner;

--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.password_reset_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.password_reset_tokens_id_seq OWNER TO neondb_owner;

--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.password_reset_tokens_id_seq OWNED BY public.password_reset_tokens.id;


--
-- Name: period_suggestions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.period_suggestions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    budget_period_id integer NOT NULL,
    suggestion_type character varying(100) NOT NULL,
    amount integer NOT NULL,
    status character varying(20),
    created_at timestamp without time zone
);


ALTER TABLE public.period_suggestions OWNER TO neondb_owner;

--
-- Name: period_suggestions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.period_suggestions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.period_suggestions_id_seq OWNER TO neondb_owner;

--
-- Name: period_suggestions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.period_suggestions_id_seq OWNED BY public.period_suggestions.id;


--
-- Name: rate_limits; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.rate_limits (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    "timestamp" timestamp without time zone
);


ALTER TABLE public.rate_limits OWNER TO neondb_owner;

--
-- Name: rate_limits_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.rate_limits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rate_limits_id_seq OWNER TO neondb_owner;

--
-- Name: rate_limits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.rate_limits_id_seq OWNED BY public.rate_limits.id;


--
-- Name: recurring_expenses; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.recurring_expenses (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(200) NOT NULL,
    amount integer NOT NULL,
    category character varying(100) NOT NULL,
    subcategory character varying(100),
    payment_method character varying(20) NOT NULL,
    frequency character varying(20) NOT NULL,
    frequency_value integer,
    day_of_month integer,
    day_of_week integer,
    start_date date NOT NULL,
    end_date date,
    next_due_date date NOT NULL,
    is_active boolean NOT NULL,
    is_fixed_bill boolean NOT NULL,
    notes text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    CONSTRAINT check_recurring_positive_amount CHECK ((amount > 0))
);


ALTER TABLE public.recurring_expenses OWNER TO neondb_owner;

--
-- Name: recurring_expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.recurring_expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recurring_expenses_id_seq OWNER TO neondb_owner;

--
-- Name: recurring_expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.recurring_expenses_id_seq OWNED BY public.recurring_expenses.id;


--
-- Name: salary_periods; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.salary_periods (
    id integer NOT NULL,
    user_id integer NOT NULL,
    initial_debit_balance integer NOT NULL,
    initial_credit_balance integer NOT NULL,
    credit_limit integer NOT NULL,
    credit_budget_allowance integer NOT NULL,
    salary_amount integer,
    total_budget_amount integer NOT NULL,
    fixed_bills_total integer NOT NULL,
    remaining_amount integer NOT NULL,
    weekly_budget integer NOT NULL,
    weekly_debit_budget integer NOT NULL,
    weekly_credit_budget integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    num_sub_periods integer DEFAULT 4 NOT NULL,
    CONSTRAINT check_salary_period_date_order CHECK ((start_date <= end_date)),
    CONSTRAINT check_salary_period_positive_credit_limit CHECK ((credit_limit >= 0))
);


ALTER TABLE public.salary_periods OWNER TO neondb_owner;

--
-- Name: salary_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.salary_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.salary_periods_id_seq OWNER TO neondb_owner;

--
-- Name: salary_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.salary_periods_id_seq OWNED BY public.salary_periods.id;


--
-- Name: subcategories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.subcategories (
    id integer NOT NULL,
    user_id integer,
    category character varying(100) NOT NULL,
    name character varying(100) NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.subcategories OWNER TO neondb_owner;

--
-- Name: subcategories_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.subcategories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subcategories_id_seq OWNER TO neondb_owner;

--
-- Name: subcategories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.subcategories_id_seq OWNED BY public.subcategories.id;


--
-- Name: user_defaults; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.user_defaults (
    id integer NOT NULL,
    user_id integer NOT NULL,
    default_expense_name character varying(200),
    default_category character varying(100),
    default_subcategory character varying(100),
    default_payment_method character varying(20)
);


ALTER TABLE public.user_defaults OWNER TO neondb_owner;

--
-- Name: user_defaults_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.user_defaults_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_defaults_id_seq OWNER TO neondb_owner;

--
-- Name: user_defaults_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.user_defaults_id_seq OWNED BY public.user_defaults.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone,
    failed_login_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp without time zone,
    recurring_lookahead_days integer DEFAULT 14 NOT NULL,
    default_currency character varying(3) DEFAULT 'EUR'::character varying NOT NULL,
    CONSTRAINT check_user_failed_attempts CHECK ((failed_login_attempts >= 0)),
    CONSTRAINT check_user_lookahead_range CHECK (((recurring_lookahead_days >= 7) AND (recurring_lookahead_days <= 90)))
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: budget_periods id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.budget_periods ALTER COLUMN id SET DEFAULT nextval('public.budget_periods_id_seq'::regclass);


--
-- Name: credit_card_settings id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_card_settings ALTER COLUMN id SET DEFAULT nextval('public.credit_card_settings_id_seq'::regclass);


--
-- Name: debts id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.debts ALTER COLUMN id SET DEFAULT nextval('public.debts_id_seq'::regclass);


--
-- Name: exchange_rates id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.exchange_rates ALTER COLUMN id SET DEFAULT nextval('public.exchange_rates_id_seq'::regclass);


--
-- Name: expense_name_mappings id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expense_name_mappings ALTER COLUMN id SET DEFAULT nextval('public.expense_name_mappings_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: goals id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.goals ALTER COLUMN id SET DEFAULT nextval('public.goals_id_seq'::regclass);


--
-- Name: income id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income ALTER COLUMN id SET DEFAULT nextval('public.income_id_seq'::regclass);


--
-- Name: password_reset_tokens id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens ALTER COLUMN id SET DEFAULT nextval('public.password_reset_tokens_id_seq'::regclass);


--
-- Name: period_suggestions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.period_suggestions ALTER COLUMN id SET DEFAULT nextval('public.period_suggestions_id_seq'::regclass);


--
-- Name: rate_limits id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.rate_limits ALTER COLUMN id SET DEFAULT nextval('public.rate_limits_id_seq'::regclass);


--
-- Name: recurring_expenses id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_expenses ALTER COLUMN id SET DEFAULT nextval('public.recurring_expenses_id_seq'::regclass);


--
-- Name: salary_periods id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.salary_periods ALTER COLUMN id SET DEFAULT nextval('public.salary_periods_id_seq'::regclass);


--
-- Name: subcategories id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories ALTER COLUMN id SET DEFAULT nextval('public.subcategories_id_seq'::regclass);


--
-- Name: user_defaults id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_defaults ALTER COLUMN id SET DEFAULT nextval('public.user_defaults_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.alembic_version (version_num) FROM stdin;
06c2d739938b
i1j2k3l4m5n6
\.


--
-- Data for Name: budget_periods; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.budget_periods (id, user_id, salary_period_id, week_number, budget_amount, start_date, end_date, period_type, created_at) FROM stdin;
1	1	1	1	18365	2025-11-20	2025-11-26	weekly	2025-12-04 16:06:13.903987
2	1	1	2	18365	2025-11-27	2025-12-03	weekly	2025-12-04 16:06:13.903989
3	1	1	3	18365	2025-12-04	2025-12-10	weekly	2025-12-04 16:06:13.90399
4	1	1	4	18365	2025-12-11	2025-12-19	weekly	2025-12-04 16:06:13.90399
5	1	2	1	20743	2025-12-20	2025-12-26	weekly	2025-12-17 10:14:43.949622
9	3	3	1	50000	2025-12-23	2025-12-29	weekly	2025-12-23 16:45:25.74918
10	3	3	2	50000	2025-12-30	2026-01-05	weekly	2025-12-23 16:45:25.749183
11	3	3	3	50000	2026-01-06	2026-01-12	weekly	2025-12-23 16:45:25.749184
12	3	3	4	50000	2026-01-13	2026-01-22	weekly	2025-12-23 16:45:25.749184
6	1	2	2	17389	2025-12-27	2026-01-02	weekly	2025-12-17 10:14:43.949624
7	1	2	3	17389	2026-01-03	2026-01-09	weekly	2025-12-17 10:14:43.949625
8	1	2	4	17389	2026-01-10	2026-01-19	weekly	2025-12-17 10:14:43.949625
\.


--
-- Data for Name: credit_card_settings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.credit_card_settings (id, user_id, credit_limit, created_at, updated_at) FROM stdin;
1	1	150000	2025-12-04 16:05:51.79458	2025-12-04 16:05:51.794584
2	2	150000	2025-12-05 22:12:33.70062	2025-12-05 22:12:33.700624
3	3	150000	2025-12-23 15:51:20.432803	2025-12-23 15:51:20.432808
\.


--
-- Data for Name: debts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.debts (id, user_id, name, original_amount, current_balance, monthly_payment, archived, created_at, updated_at, deleted_at) FROM stdin;
6	1	Telia Rahoitus	100000	75455	4546	f	2025-12-04 16:06:13.723429	2025-12-22 23:49:01.029762	\N
5	1	Elisa (Phone)	84840	63630	3535	f	2025-12-04 16:06:13.718028	2025-12-22 23:49:49.151239	\N
4	1	Klarna Gigantti	63773	53127	5323	f	2025-12-04 16:06:13.712809	2025-12-22 23:51:51.848399	\N
3	1	Klarna Turkish Airlines Business	54422	43943	10479	f	2025-12-04 16:06:13.707428	2025-12-22 23:52:47.838394	\N
2	1	Klarna Turkish Airlines New	117469	76305	10291	f	2025-12-04 16:06:13.701772	2025-12-22 23:53:23.500407	\N
1	1	Klarna Turkish Airlines Old	205855	33645	10080	f	2025-12-04 16:06:13.692827	2025-12-22 23:53:58.129611	\N
\.


--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.exchange_rates (id, base_currency, target_currency, rate, rate_date, fetched_at) FROM stdin;
232	BDT	AED	0.030051	2025-12-25	2025-12-25 14:48:04.663885
233	BDT	AFN	0.538188	2025-12-25	2025-12-25 14:48:05.374567
10	EUR	AWG	2.109255	2025-12-25	2025-12-25 14:00:47.26393
234	BDT	ALL	0.669419	2025-12-25	2025-12-25 14:48:05.97569
235	BDT	AMD	3.12223	2025-12-25	2025-12-25 14:48:06.464829
14	EUR	BBD	2.35671	2025-12-25	2025-12-25 14:00:50.964889
236	BDT	ANG	0.014647	2025-12-25	2025-12-25 14:48:06.782005
237	BDT	AOA	7.66021	2025-12-25	2025-12-25 14:48:07.276226
15	EUR	BDT	144.026155	2025-12-25	2025-12-25 14:00:52.265055
238	BDT	ARS	11.88323	2025-12-25	2025-12-25 14:48:07.878169
239	BDT	AUD	0.012204	2025-12-25	2025-12-25 14:48:08.474699
16	EUR	BGN	1.95583	2025-12-25	2025-12-25 14:00:53.664051
240	BDT	AWG	0.014647	2025-12-25	2025-12-25 14:48:08.964049
241	BDT	AZN	0.013917	2025-12-25	2025-12-25 14:48:09.381616
242	BDT	BAM	0.01358	2025-12-25	2025-12-25 14:48:09.963287
243	BDT	BBD	0.016365	2025-12-25	2025-12-25 14:48:10.377981
244	BDT	BGN	0.01358	2025-12-25	2025-12-25 14:48:10.763726
245	BDT	BHD	0.003077	2025-12-25	2025-12-25 14:48:10.983178
246	BDT	BIF	24.206115	2025-12-25	2025-12-25 14:48:11.364216
247	BDT	BMD	0.008183	2025-12-25	2025-12-25 14:48:11.679973
248	BDT	BND	0.010505	2025-12-25	2025-12-25 14:48:11.987781
249	BDT	BOB	0.056693	2025-12-25	2025-12-25 14:48:12.280273
250	BDT	BRL	0.045173	2025-12-25	2025-12-25 14:48:12.564442
251	BDT	BSD	0.008183	2025-12-25	2025-12-25 14:48:12.862953
252	BDT	BTN	0.733957	2025-12-25	2025-12-25 14:48:13.179484
253	BDT	BWP	0.111417	2025-12-25	2025-12-25 14:48:13.473548
254	BDT	BYN	0.023776	2025-12-25	2025-12-25 14:48:13.775082
255	BDT	BZD	0.016365	2025-12-25	2025-12-25 14:48:14.062902
256	BDT	CAD	0.011189	2025-12-25	2025-12-25 14:48:14.284857
257	BDT	CDF	18.636023	2025-12-25	2025-12-25 14:48:14.58798
258	BDT	CHF	0.006446	2025-12-25	2025-12-25 14:48:14.864486
259	BDT	CLF	0.000188	2025-12-25	2025-12-25 14:48:15.177006
260	BDT	CLP	7.431352	2025-12-25	2025-12-25 14:48:15.478888
261	BDT	CNH	0.057365	2025-12-25	2025-12-25 14:48:15.76291
262	BDT	CNY	0.057484	2025-12-25	2025-12-25 14:48:15.988099
263	BDT	COP	30.853449	2025-12-25	2025-12-25 14:48:16.290361
264	BDT	CRC	4.073267	2025-12-25	2025-12-25 14:48:16.581774
265	BDT	CUP	0.196383	2025-12-25	2025-12-25 14:48:16.789983
266	BDT	CVE	0.76559	2025-12-25	2025-12-25 14:48:17.163101
267	BDT	CZK	0.168565	2025-12-25	2025-12-25 14:48:17.383795
268	BDT	DJF	1.454226	2025-12-25	2025-12-25 14:48:17.686084
269	BDT	DKK	0.051799	2025-12-25	2025-12-25 14:48:17.882705
270	BDT	DOP	0.512705	2025-12-25	2025-12-25 14:48:18.184007
271	BDT	DZD	1.060646	2025-12-25	2025-12-25 14:48:18.386673
272	BDT	EGP	0.388718	2025-12-25	2025-12-25 14:48:18.689111
273	BDT	ERN	0.12274	2025-12-25	2025-12-25 14:48:18.98164
274	BDT	ETB	1.274565	2025-12-25	2025-12-25 14:48:19.290395
275	BDT	EUR	0.006943	2025-12-25	2025-12-25 14:48:19.588041
276	BDT	FJD	0.018606	2025-12-25	2025-12-25 14:48:19.97904
277	BDT	FKP	0.006059	2025-12-25	2025-12-25 14:48:20.278606
278	BDT	FOK	0.051799	2025-12-25	2025-12-25 14:48:20.58393
279	BDT	GBP	0.006059	2025-12-25	2025-12-25 14:48:20.878458
280	BDT	GEL	0.02206	2025-12-25	2025-12-25 14:48:21.086672
281	BDT	GGP	0.006059	2025-12-25	2025-12-25 14:48:21.386127
282	BDT	GHS	0.092629	2025-12-25	2025-12-25 14:48:21.67882
283	BDT	GIP	0.006059	2025-12-25	2025-12-25 14:48:21.888193
284	BDT	GMD	0.607194	2025-12-25	2025-12-25 14:48:22.187128
285	BDT	GNF	71.492839	2025-12-25	2025-12-25 14:48:22.488463
286	BDT	GTQ	0.06271	2025-12-25	2025-12-25 14:48:22.793983
287	BDT	GYD	1.712091	2025-12-25	2025-12-25 14:48:23.175583
288	BDT	HKD	0.06362	2025-12-25	2025-12-25 14:48:23.484727
289	BDT	HNL	0.215792	2025-12-25	2025-12-25 14:48:23.776428
290	BDT	HRK	0.052313	2025-12-25	2025-12-25 14:48:23.983625
291	BDT	HTG	1.071565	2025-12-25	2025-12-25 14:48:24.293145
292	BDT	HUF	2.706089	2025-12-25	2025-12-25 14:48:24.585658
293	BDT	IDR	137.217669	2025-12-25	2025-12-25 14:48:24.792356
294	BDT	ILS	0.026047	2025-12-25	2025-12-25 14:48:25.176924
295	BDT	IMP	0.006059	2025-12-25	2025-12-25 14:48:25.462967
296	BDT	INR	0.733957	2025-12-25	2025-12-25 14:48:25.691203
297	BDT	IQD	10.719963	2025-12-25	2025-12-25 14:48:25.992432
298	BDT	IRR	351.99914	2025-12-25	2025-12-25 14:48:26.284093
299	BDT	ISK	1.027335	2025-12-25	2025-12-25 14:48:26.580273
300	BDT	JEP	0.006059	2025-12-25	2025-12-25 14:48:26.875412
301	BDT	JMD	1.307392	2025-12-25	2025-12-25 14:48:27.089827
302	BDT	JOD	0.005801	2025-12-25	2025-12-25 14:48:27.390705
303	BDT	JPY	1.275715	2025-12-25	2025-12-25 14:48:27.681673
304	BDT	KES	1.055364	2025-12-25	2025-12-25 14:48:27.981569
305	BDT	KGS	0.715882	2025-12-25	2025-12-25 14:48:28.280634
306	BDT	KHR	32.840386	2025-12-25	2025-12-25 14:48:28.579849
307	BDT	KID	0.012204	2025-12-25	2025-12-25 14:48:28.887979
308	BDT	KMF	3.415822	2025-12-25	2025-12-25 14:48:29.173876
309	BDT	KRW	11.845218	2025-12-25	2025-12-25 14:48:29.463149
310	BDT	KWD	0.002499	2025-12-25	2025-12-25 14:48:29.764195
311	BDT	KYD	0.006819	2025-12-25	2025-12-25 14:48:29.989568
312	BDT	KZT	4.175405	2025-12-25	2025-12-25 14:48:30.262415
313	BDT	LAK	177.479347	2025-12-25	2025-12-25 14:48:30.483264
314	BDT	LBP	732.345753	2025-12-25	2025-12-25 14:48:31.073947
315	BDT	LKR	2.533017	2025-12-25	2025-12-25 14:48:31.777271
316	BDT	LRD	1.451775	2025-12-25	2025-12-25 14:48:32.664154
317	BDT	LSL	0.136367	2025-12-25	2025-12-25 14:48:33.462698
391	BDT	ZAR	0.136367	2025-12-25	2025-12-25 14:48:59.76412
392	BDT	ZMW	0.184122	2025-12-25	2025-12-25 14:49:00.262663
393	BDT	ZWL	0.212966	2025-12-25	2025-12-25 14:49:00.581205
394	EUR	AED	4.327508	2025-12-26	2025-12-26 00:52:37.835689
395	EUR	AFN	77.434793	2025-12-26	2025-12-26 00:52:38.137134
396	EUR	ALL	96.421234	2025-12-26	2025-12-26 00:52:38.536002
397	EUR	AMD	449.869768	2025-12-26	2025-12-26 00:52:38.920033
398	EUR	ANG	2.109255	2025-12-26	2025-12-26 00:52:39.533525
399	EUR	AOA	1108.346135	2025-12-26	2025-12-26 00:52:39.927923
400	EUR	ARS	1711.265744	2025-12-26	2025-12-26 00:52:40.319071
401	EUR	AUD	1.757653	2025-12-26	2025-12-26 00:52:40.828556
402	EUR	AWG	2.109255	2025-12-26	2025-12-26 00:52:41.03841
403	EUR	AZN	2.005254	2025-12-26	2025-12-26 00:52:41.242239
404	EUR	BAM	1.95583	2025-12-26	2025-12-26 00:52:41.520622
405	EUR	BBD	2.35671	2025-12-26	2025-12-26 00:52:41.739648
406	EUR	BDT	144.026155	2025-12-26	2025-12-26 00:52:42.036509
407	EUR	BGN	1.95583	2025-12-26	2025-12-26 00:52:42.242011
408	EUR	BHD	0.443061	2025-12-26	2025-12-26 00:52:42.532369
409	EUR	BIF	3499.394018	2025-12-26	2025-12-26 00:52:42.738579
410	EUR	BMD	1.178355	2025-12-26	2025-12-26 00:52:42.941744
411	EUR	BND	1.512756	2025-12-26	2025-12-26 00:52:43.143013
412	EUR	BOB	8.166893	2025-12-26	2025-12-26 00:52:43.435646
413	EUR	BRL	6.506005	2025-12-26	2025-12-26 00:52:43.63874
414	EUR	BSD	1.178355	2025-12-26	2025-12-26 00:52:43.937775
415	EUR	BTN	105.670888	2025-12-26	2025-12-26 00:52:44.140412
416	EUR	BWP	16.298807	2025-12-26	2025-12-26 00:52:44.343287
417	EUR	BYN	3.427656	2025-12-26	2025-12-26 00:52:44.539693
418	EUR	BZD	2.35671	2025-12-26	2025-12-26 00:52:44.740783
419	EUR	CAD	1.611689	2025-12-26	2025-12-26 00:52:45.036828
39	EUR	CZK	24.273338	2025-12-25	2025-12-25 14:01:21.265099
1	EUR	AED	4.327508	2025-12-25	2025-12-25 14:00:37.663632
65	EUR	HUF	389.227875	2025-12-25	2025-12-25 14:01:49.365006
3	EUR	AFN	77.434793	2025-12-25	2025-12-25 14:00:38.962435
40	EUR	DJF	209.418392	2025-12-25	2025-12-25 14:01:22.659798
4	EUR	ALL	96.421234	2025-12-25	2025-12-25 14:00:40.563029
5	EUR	AMD	449.869768	2025-12-25	2025-12-25 14:00:41.368354
41	EUR	DKK	7.461265	2025-12-25	2025-12-25 14:01:23.866539
6	EUR	ANG	2.109255	2025-12-25	2025-12-25 14:00:42.866322
318	BDT	LYD	0.044343	2025-12-25	2025-12-25 14:48:34.56457
42	EUR	DOP	73.957209	2025-12-25	2025-12-25 14:01:24.966777
7	EUR	AOA	1108.346135	2025-12-25	2025-12-25 14:00:44.363804
8	EUR	ARS	1711.265744	2025-12-25	2025-12-25 14:00:45.364136
43	EUR	DZD	152.823944	2025-12-25	2025-12-25 14:01:26.066524
9	EUR	AUD	1.757653	2025-12-25	2025-12-25 14:00:46.76436
66	EUR	IDR	19718.198961	2025-12-25	2025-12-25 14:01:50.565758
11	EUR	AZN	2.005254	2025-12-25	2025-12-25 14:00:48.264857
13	EUR	BAM	1.95583	2025-12-25	2025-12-25 14:00:49.564761
44	EUR	EGP	56.116859	2025-12-25	2025-12-25 14:01:27.765972
17	EUR	BHD	0.443061	2025-12-25	2025-12-25 14:00:54.764429
68	EUR	ILS	3.751828	2025-12-25	2025-12-25 14:01:51.365118
18	EUR	BIF	3499.394018	2025-12-25	2025-12-25 14:00:55.966388
45	EUR	ERN	17.675322	2025-12-25	2025-12-25 14:01:29.064496
19	EUR	BMD	1.178355	2025-12-25	2025-12-25 14:00:56.964917
70	EUR	IMP	0.872552	2025-12-25	2025-12-25 14:01:52.266334
20	EUR	BND	1.512756	2025-12-25	2025-12-25 14:00:58.563897
46	EUR	ETB	181.952086	2025-12-25	2025-12-25 14:01:30.06451
21	EUR	BOB	8.166893	2025-12-25	2025-12-25 14:00:59.065021
22	EUR	BRL	6.506005	2025-12-25	2025-12-25 14:01:00.360163
71	EUR	INR	105.671233	2025-12-25	2025-12-25 14:01:53.365128
47	EUR	FJD	2.679777	2025-12-25	2025-12-25 14:01:31.26775
23	EUR	BSD	1.178355	2025-12-25	2025-12-25 14:01:01.565125
24	EUR	BTN	105.670888	2025-12-25	2025-12-25 14:01:02.764742
81	EUR	KHR	4735.960526	2025-12-25	2025-12-25 14:02:05.067907
48	EUR	FKP	0.872552	2025-12-25	2025-12-25 14:01:32.564556
25	EUR	BWP	16.298807	2025-12-25	2025-12-25 14:01:03.96474
26	EUR	BYN	3.427656	2025-12-25	2025-12-25 14:01:05.264781
27	EUR	BZD	2.35671	2025-12-25	2025-12-25 14:01:06.564185
28	EUR	CAD	1.611689	2025-12-25	2025-12-25 14:01:07.967096
29	EUR	CDF	2686.067164	2025-12-25	2025-12-25 14:01:08.763636
30	EUR	CHF	0.928554	2025-12-25	2025-12-25 14:01:09.766506
72	EUR	IQD	1544.776824	2025-12-25	2025-12-25 14:01:54.465955
31	EUR	CLF	0.027101	2025-12-25	2025-12-25 14:01:11.366988
32	EUR	CLP	1071.185109	2025-12-25	2025-12-25 14:01:12.665736
49	EUR	FOK	7.461265	2025-12-25	2025-12-25 14:01:33.860301
33	EUR	CNH	8.259695	2025-12-25	2025-12-25 14:01:13.663921
34	EUR	CNY	8.27748	2025-12-25	2025-12-25 14:01:14.866058
103	EUR	MNT	4159.918972	2025-12-25	2025-12-25 14:02:23.764102
35	EUR	COP	4437.75716	2025-12-25	2025-12-25 14:01:16.364151
50	EUR	GBP	0.872552	2025-12-25	2025-12-25 14:01:35.065353
73	EUR	IRR	50055.669571	2025-12-25	2025-12-25 14:01:55.663785
36	EUR	CRC	587.930617	2025-12-25	2025-12-25 14:01:17.56315
51	EUR	GEL	3.179354	2025-12-25	2025-12-25 14:01:35.865316
37	EUR	CUP	28.280515	2025-12-25	2025-12-25 14:01:18.963609
52	EUR	GGP	0.872552	2025-12-25	2025-12-25 14:01:36.965869
38	EUR	CVE	110.265	2025-12-25	2025-12-25 14:01:20.664476
54	EUR	GHS	13.302211	2025-12-25	2025-12-25 14:01:38.263423
55	EUR	GIP	0.872552	2025-12-25	2025-12-25 14:01:38.964545
56	EUR	GMD	87.454612	2025-12-25	2025-12-25 14:01:40.866413
57	EUR	GNF	10295.45819	2025-12-25	2025-12-25 14:01:41.563699
58	EUR	GTQ	9.036739	2025-12-25	2025-12-25 14:01:42.66118
60	EUR	GYD	246.698424	2025-12-25	2025-12-25 14:01:43.764207
83	EUR	KID	1.757652	2025-12-25	2025-12-25 14:02:05.964072
61	EUR	HKD	9.161437	2025-12-25	2025-12-25 14:01:44.860306
62	EUR	HNL	31.097286	2025-12-25	2025-12-25 14:01:45.964701
74	EUR	ISK	148.015102	2025-12-25	2025-12-25 14:01:56.865677
63	EUR	HRK	7.5345	2025-12-25	2025-12-25 14:01:47.262535
98	EUR	MAD	10.745973	2025-12-25	2025-12-25 14:02:18.167937
64	EUR	HTG	154.411411	2025-12-25	2025-12-25 14:01:48.465102
84	EUR	KMF	491.96775	2025-12-25	2025-12-25 14:02:06.966129
85	EUR	KRW	1707.500739	2025-12-25	2025-12-25 14:02:07.660223
75	EUR	JEP	0.872552	2025-12-25	2025-12-25 14:01:58.264573
76	EUR	JMD	188.108472	2025-12-25	2025-12-25 14:01:59.26715
87	EUR	KWD	0.36144	2025-12-25	2025-12-25 14:02:08.964343
77	EUR	JOD	0.835454	2025-12-25	2025-12-25 14:02:00.464238
88	EUR	KYD	0.981962	2025-12-25	2025-12-25 14:02:09.774816
89	EUR	KZT	604.688772	2025-12-25	2025-12-25 14:02:10.766629
78	EUR	JPY	183.761551	2025-12-25	2025-12-25 14:02:01.559837
79	EUR	KES	152.084181	2025-12-25	2025-12-25 14:02:02.664555
91	EUR	LAK	25596.94192	2025-12-25	2025-12-25 14:02:12.064612
80	EUR	KGS	103.059665	2025-12-25	2025-12-25 14:02:03.762976
92	EUR	LBP	105462.753719	2025-12-25	2025-12-25 14:02:12.864716
93	EUR	LKR	364.95757	2025-12-25	2025-12-25 14:02:13.664966
94	EUR	LRD	209.399615	2025-12-25	2025-12-25 14:02:15.663207
95	EUR	LSL	19.626682	2025-12-25	2025-12-25 14:02:15.963336
97	EUR	LYD	6.38032	2025-12-25	2025-12-25 14:02:16.865448
99	EUR	MDL	19.814089	2025-12-25	2025-12-25 14:02:19.065989
110	EUR	MWK	2055.851882	2025-12-25	2025-12-25 14:02:28.164094
100	EUR	MGA	5307.255534	2025-12-25	2025-12-25 14:02:20.163873
104	EUR	MOP	9.437042	2025-12-25	2025-12-25 14:02:25.064061
101	EUR	MKD	61.4843	2025-12-25	2025-12-25 14:02:21.660231
102	EUR	MMK	2479.74508	2025-12-25	2025-12-25 14:02:22.865264
111	EUR	MXN	21.121538	2025-12-25	2025-12-25 14:02:28.96394
105	EUR	MRU	46.994777	2025-12-25	2025-12-25 14:02:26.364924
109	EUR	MVR	18.237276	2025-12-25	2025-12-25 14:02:27.274293
107	EUR	MUR	54.199771	2025-12-25	2025-12-25 14:02:27.365284
112	EUR	MYR	4.771733	2025-12-25	2025-12-25 14:02:29.764237
113	EUR	MZN	75.349015	2025-12-25	2025-12-25 14:02:31.264308
116	EUR	NGN	1707.140579	2025-12-25	2025-12-25 14:02:33.465819
115	EUR	NAD	19.626682	2025-12-25	2025-12-25 14:02:32.766362
117	EUR	NIO	43.404423	2025-12-25	2025-12-25 14:02:34.464009
119	EUR	NOK	11.791112	2025-12-25	2025-12-25 14:02:35.164829
120	EUR	NPR	169.073422	2025-12-25	2025-12-25 14:02:35.764956
121	EUR	NZD	2.018995	2025-12-25	2025-12-25 14:02:36.274832
122	EUR	OMR	0.453074	2025-12-25	2025-12-25 14:02:36.863554
123	EUR	PAB	1.178355	2025-12-25	2025-12-25 14:02:37.367402
124	EUR	PEN	3.965922	2025-12-25	2025-12-25 14:02:37.963539
126	EUR	PGK	5.094031	2025-12-25	2025-12-25 14:02:38.185927
127	EUR	PHP	69.242381	2025-12-25	2025-12-25 14:02:38.463986
128	EUR	PKR	330.39864	2025-12-25	2025-12-25 14:02:38.685347
129	EUR	PLN	4.214352	2025-12-25	2025-12-25 14:02:38.888412
130	EUR	PYG	7986.800269	2025-12-25	2025-12-25 14:02:39.179194
131	EUR	QAR	4.289211	2025-12-25	2025-12-25 14:02:39.384317
132	EUR	RON	5.090097	2025-12-25	2025-12-25 14:02:39.665169
133	EUR	RSD	117.36913	2025-12-25	2025-12-25 14:02:39.877329
134	EUR	RUB	92.841887	2025-12-25	2025-12-25 14:02:40.082791
135	EUR	RWF	1721.600633	2025-12-25	2025-12-25 14:02:40.364019
136	EUR	SAR	4.41883	2025-12-25	2025-12-25 14:02:40.585125
137	EUR	SBD	9.532682	2025-12-25	2025-12-25 14:02:40.875762
138	EUR	SCR	17.199192	2025-12-25	2025-12-25 14:02:41.085484
139	EUR	SDG	526.988287	2025-12-25	2025-12-25 14:02:41.382449
140	EUR	SEK	10.802992	2025-12-25	2025-12-25 14:02:41.591396
141	EUR	SGD	1.512756	2025-12-25	2025-12-25 14:02:41.889753
142	EUR	SHP	0.872552	2025-12-25	2025-12-25 14:02:42.179215
143	EUR	SLE	28.414724	2025-12-25	2025-12-25 14:02:42.48051
144	EUR	SOS	672.771963	2025-12-25	2025-12-25 14:02:42.790179
145	EUR	SRD	45.246135	2025-12-25	2025-12-25 14:02:43.08802
146	EUR	SSP	5566.917231	2025-12-25	2025-12-25 14:02:43.386334
147	EUR	STN	24.5	2025-12-25	2025-12-25 14:02:43.679741
148	EUR	SYP	12980.000305	2025-12-25	2025-12-25 14:02:43.884506
149	EUR	SZL	19.626682	2025-12-25	2025-12-25 14:02:44.186331
150	EUR	THB	36.62098	2025-12-25	2025-12-25 14:02:44.38846
151	EUR	TJS	10.892974	2025-12-25	2025-12-25 14:02:44.678934
152	EUR	TMT	4.127584	2025-12-25	2025-12-25 14:02:44.982901
153	EUR	TND	3.407744	2025-12-25	2025-12-25 14:02:45.27758
154	EUR	TOP	2.83195	2025-12-25	2025-12-25 14:02:45.484839
155	EUR	TRY	50.520792	2025-12-25	2025-12-25 14:02:45.774965
156	EUR	TTD	8.670925	2025-12-25	2025-12-25 14:02:45.9853
157	EUR	TVD	1.757652	2025-12-25	2025-12-25 14:02:46.185773
319	BDT	MAD	0.074642	2025-12-25	2025-12-25 14:48:35.566111
158	EUR	TWD	37.038321	2025-12-25	2025-12-25 14:10:44.390149
320	BDT	MDL	0.137559	2025-12-25	2025-12-25 14:48:36.075582
321	BDT	MGA	37.3122	2025-12-25	2025-12-25 14:48:36.382856
161	EUR	TZS	2898.306324	2025-12-25	2025-12-25 14:10:45.687145
322	BDT	MKD	0.427623	2025-12-25	2025-12-25 14:48:36.68124
323	BDT	MMK	17.205044	2025-12-25	2025-12-25 14:48:36.884177
165	EUR	UAH	49.625692	2025-12-25	2025-12-25 14:10:46.786241
324	BDT	MNT	28.91163	2025-12-25	2025-12-25 14:48:37.18578
325	BDT	MOP	0.065529	2025-12-25	2025-12-25 14:48:37.477071
169	EUR	UGX	4231.607935	2025-12-25	2025-12-25 14:10:47.789093
326	BDT	MRU	0.326326	2025-12-25	2025-12-25 14:48:37.764493
327	BDT	MUR	0.376576	2025-12-25	2025-12-25 14:48:37.987821
173	EUR	USD	1.178355	2025-12-25	2025-12-25 14:10:49.187211
328	BDT	MVR	0.12655	2025-12-25	2025-12-25 14:48:38.375502
329	BDT	MWK	14.249909	2025-12-25	2025-12-25 14:48:38.588551
177	EUR	UYU	46.067809	2025-12-25	2025-12-25 14:10:50.587387
330	BDT	MXN	0.146506	2025-12-25	2025-12-25 14:48:38.884256
180	EUR	UZS	14278.457713	2025-12-25	2025-12-25 14:10:50.988556
331	BDT	MYR	0.03313	2025-12-25	2025-12-25 14:48:39.090007
332	BDT	MZN	0.523055	2025-12-25	2025-12-25 14:48:39.463855
184	EUR	VES	342.936342	2025-12-25	2025-12-25 14:10:52.086561
333	BDT	NAD	0.136367	2025-12-25	2025-12-25 14:48:39.690585
334	BDT	NGN	11.891306	2025-12-25	2025-12-25 14:48:39.989283
188	EUR	VND	30876.727797	2025-12-25	2025-12-25 14:10:53.187519
335	BDT	NIO	0.301201	2025-12-25	2025-12-25 14:48:40.283318
336	BDT	NOK	0.081843	2025-12-25	2025-12-25 14:48:40.491187
192	EUR	VUV	142.491814	2025-12-25	2025-12-25 14:10:54.288378
337	BDT	NPR	1.174331	2025-12-25	2025-12-25 14:48:40.785362
338	BDT	NZD	0.01402	2025-12-25	2025-12-25 14:48:41.077246
196	EUR	WST	3.261647	2025-12-25	2025-12-25 14:10:55.686876
339	BDT	OMR	0.003146	2025-12-25	2025-12-25 14:48:41.286685
340	BDT	PAB	0.008183	2025-12-25	2025-12-25 14:48:41.563583
200	EUR	XAF	655.957	2025-12-25	2025-12-25 14:10:56.889456
203	EUR	XCD	3.181558	2025-12-25	2025-12-25 14:10:57.48638
341	BDT	PEN	0.027545	2025-12-25	2025-12-25 14:48:41.7869
342	BDT	PGK	0.035347	2025-12-25	2025-12-25 14:48:42.07994
206	EUR	XDR	0.85636	2025-12-25	2025-12-25 14:10:58.487889
343	BDT	PHP	0.480582	2025-12-25	2025-12-25 14:48:42.38138
344	BDT	PKR	2.294097	2025-12-25	2025-12-25 14:48:42.679177
210	EUR	XOF	655.957	2025-12-25	2025-12-25 14:10:59.787348
345	BDT	PLN	0.029269	2025-12-25	2025-12-25 14:48:42.98513
213	EUR	XPF	119.332	2025-12-25	2025-12-25 14:11:00.686539
346	BDT	PYG	55.485938	2025-12-25	2025-12-25 14:48:43.264351
217	EUR	YER	281.237368	2025-12-25	2025-12-25 14:11:01.387009
347	BDT	QAR	0.029785	2025-12-25	2025-12-25 14:48:43.577905
348	BDT	RON	0.03533	2025-12-25	2025-12-25 14:48:43.886386
220	EUR	ZAR	19.624667	2025-12-25	2025-12-25 14:11:02.18606
349	BDT	RSD	0.815368	2025-12-25	2025-12-25 14:48:44.188508
350	BDT	RUB	0.63927	2025-12-25	2025-12-25 14:48:44.488018
224	EUR	ZMW	26.520207	2025-12-25	2025-12-25 14:11:03.088139
351	BDT	RWF	11.932685	2025-12-25	2025-12-25 14:48:45.163716
352	BDT	SAR	0.030685	2025-12-25	2025-12-25 14:48:45.787716
228	EUR	ZWL	30.6958	2025-12-25	2025-12-25 14:11:04.08865
353	BDT	SBD	0.066296	2025-12-25	2025-12-25 14:48:46.081509
354	BDT	SCR	0.118299	2025-12-25	2025-12-25 14:48:46.378988
355	BDT	SDG	4.187704	2025-12-25	2025-12-25 14:48:46.681882
356	BDT	SEK	0.07499	2025-12-25	2025-12-25 14:48:46.974487
357	BDT	SGD	0.010505	2025-12-25	2025-12-25 14:48:47.275006
358	BDT	SHP	0.006059	2025-12-25	2025-12-25 14:48:47.577754
359	BDT	SLE	0.197564	2025-12-25	2025-12-25 14:48:47.873062
360	BDT	SOS	4.669046	2025-12-25	2025-12-25 14:48:48.163822
361	BDT	SRD	0.314576	2025-12-25	2025-12-25 14:48:48.488372
362	BDT	SSP	38.129934	2025-12-25	2025-12-25 14:48:48.789448
363	BDT	STN	0.170108	2025-12-25	2025-12-25 14:48:49.083785
364	BDT	SYP	90.190389	2025-12-25	2025-12-25 14:48:49.388088
365	BDT	SZL	0.136367	2025-12-25	2025-12-25 14:48:49.687312
366	BDT	THB	0.254203	2025-12-25	2025-12-25 14:48:50.075002
367	BDT	TJS	0.075568	2025-12-25	2025-12-25 14:48:50.373086
368	BDT	TMT	0.028648	2025-12-25	2025-12-25 14:48:50.679058
369	BDT	TND	0.023635	2025-12-25	2025-12-25 14:48:51.179716
370	BDT	TOP	0.019675	2025-12-25	2025-12-25 14:48:51.582302
371	BDT	TRY	0.350592	2025-12-25	2025-12-25 14:48:52.079689
372	BDT	TTD	0.05567	2025-12-25	2025-12-25 14:48:52.565136
373	BDT	TVD	0.012204	2025-12-25	2025-12-25 14:48:52.981837
374	BDT	TWD	0.257315	2025-12-25	2025-12-25 14:48:53.463697
375	BDT	TZS	20.268654	2025-12-25	2025-12-25 14:48:53.875707
376	BDT	UAH	0.3439	2025-12-25	2025-12-25 14:48:54.276935
377	BDT	UGX	29.507974	2025-12-25	2025-12-25 14:48:54.683243
378	BDT	USD	0.008183	2025-12-25	2025-12-25 14:48:55.074775
379	BDT	UYU	0.319729	2025-12-25	2025-12-25 14:48:55.285504
380	BDT	UZS	99.325623	2025-12-25	2025-12-25 14:48:55.582304
381	BDT	VES	2.38403	2025-12-25	2025-12-25 14:48:55.885582
382	BDT	VND	215.083175	2025-12-25	2025-12-25 14:48:56.264719
383	BDT	VUV	0.986867	2025-12-25	2025-12-25 14:48:56.562599
384	BDT	WST	0.022683	2025-12-25	2025-12-25 14:48:56.785518
385	BDT	XAF	4.55443	2025-12-25	2025-12-25 14:48:57.078609
386	BDT	XCD	0.022093	2025-12-25	2025-12-25 14:48:57.366223
387	BDT	XDR	0.005941	2025-12-25	2025-12-25 14:48:57.69383
388	BDT	XOF	4.55443	2025-12-25	2025-12-25 14:48:58.079791
389	BDT	XPF	0.828544	2025-12-25	2025-12-25 14:48:58.474982
390	BDT	YER	1.951447	2025-12-25	2025-12-25 14:48:59.181709
420	EUR	CDF	2686.067164	2025-12-26	2025-12-26 00:52:45.237445
421	EUR	CHF	0.928554	2025-12-26	2025-12-26 00:52:45.445625
422	EUR	CLF	0.027101	2025-12-26	2025-12-26 00:52:45.728554
423	EUR	CLP	1071.185109	2025-12-26	2025-12-26 00:52:45.941709
424	EUR	CNH	8.259695	2025-12-26	2025-12-26 00:52:46.237521
425	EUR	CNY	8.27748	2025-12-26	2025-12-26 00:52:46.520122
426	EUR	COP	4437.75716	2025-12-26	2025-12-26 00:52:46.744649
427	EUR	CRC	587.930617	2025-12-26	2025-12-26 00:52:47.118802
428	EUR	CUP	28.280515	2025-12-26	2025-12-26 00:52:47.335664
429	EUR	CVE	110.265	2025-12-26	2025-12-26 00:52:47.535606
430	EUR	CZK	24.273338	2025-12-26	2025-12-26 00:52:47.739815
431	EUR	DJF	209.418392	2025-12-26	2025-12-26 00:52:48.018783
432	EUR	DKK	7.461265	2025-12-26	2025-12-26 00:52:48.241665
433	EUR	DOP	73.957209	2025-12-26	2025-12-26 00:52:48.54326
434	EUR	DZD	152.823944	2025-12-26	2025-12-26 00:52:48.819715
435	EUR	EGP	56.116859	2025-12-26	2025-12-26 00:52:49.041098
436	EUR	ERN	17.675322	2025-12-26	2025-12-26 00:52:49.341907
437	EUR	ETB	181.952086	2025-12-26	2025-12-26 00:52:49.63981
438	EUR	FJD	2.679777	2025-12-26	2025-12-26 00:52:49.932842
439	EUR	FKP	0.872552	2025-12-26	2025-12-26 00:52:50.138766
440	EUR	FOK	7.461265	2025-12-26	2025-12-26 00:52:50.437036
441	EUR	GBP	0.872552	2025-12-26	2025-12-26 00:52:50.64376
442	EUR	GEL	3.179354	2025-12-26	2025-12-26 00:52:50.943489
443	EUR	GGP	0.872552	2025-12-26	2025-12-26 00:52:51.244729
444	EUR	GHS	13.302211	2025-12-26	2025-12-26 00:52:51.519853
445	EUR	GIP	0.872552	2025-12-26	2025-12-26 00:52:51.750792
446	EUR	GMD	87.454612	2025-12-26	2025-12-26 00:52:51.942276
447	EUR	GNF	10295.45819	2025-12-26	2025-12-26 00:52:52.219924
448	EUR	GTQ	9.036739	2025-12-26	2025-12-26 00:52:52.427969
449	EUR	GYD	246.335846	2025-12-26	2025-12-26 00:52:52.805569
450	EUR	HKD	9.161038	2025-12-26	2025-12-26 00:52:52.941409
451	EUR	HNL	31.052379	2025-12-26	2025-12-26 00:52:53.327452
452	EUR	HRK	7.5345	2025-12-26	2025-12-26 00:52:53.819042
453	EUR	HTG	154.18447	2025-12-26	2025-12-26 00:52:54.418634
454	EUR	HUF	389.359462	2025-12-26	2025-12-26 00:52:55.120514
455	EUR	IDR	19734.933824	2025-12-26	2025-12-26 00:52:55.519727
456	EUR	ILS	3.754583	2025-12-26	2025-12-26 00:52:55.821033
457	EUR	IMP	0.872056	2025-12-26	2025-12-26 00:52:56.040544
458	EUR	INR	105.718536	2025-12-26	2025-12-26 00:52:56.34027
459	EUR	IQD	1542.506438	2025-12-26	2025-12-26 00:52:56.54184
460	EUR	IRR	50021.725081	2025-12-26	2025-12-26 00:52:56.844629
461	EUR	ISK	148.014024	2025-12-26	2025-12-26 00:52:57.218735
462	EUR	JEP	0.872056	2025-12-26	2025-12-26 00:52:57.44425
463	EUR	JMD	187.757152	2025-12-26	2025-12-26 00:52:57.733492
464	EUR	JOD	0.835764	2025-12-26	2025-12-26 00:52:57.946993
465	EUR	JPY	183.762937	2025-12-26	2025-12-26 00:52:58.248942
466	EUR	KES	151.942762	2025-12-26	2025-12-26 00:52:58.544592
467	EUR	KGS	103.000823	2025-12-26	2025-12-26 00:52:58.842306
468	EUR	KHR	4729	2025-12-26	2025-12-26 00:52:59.139607
469	EUR	KID	1.757297	2025-12-26	2025-12-26 00:52:59.437213
470	EUR	KMF	491.96775	2025-12-26	2025-12-26 00:52:59.655782
471	EUR	KRW	1704.784388	2025-12-26	2025-12-26 00:52:59.934001
472	EUR	KWD	0.360894	2025-12-26	2025-12-26 00:53:00.145664
473	EUR	KYD	0.982326	2025-12-26	2025-12-26 00:53:00.442725
474	EUR	KZT	601.898534	2025-12-26	2025-12-26 00:53:00.730639
475	EUR	LAK	25511.81021	2025-12-26	2025-12-26 00:53:00.950381
476	EUR	LBP	105501.886944	2025-12-26	2025-12-26 00:53:01.233168
477	EUR	LKR	364.53462	2025-12-26	2025-12-26 00:53:01.447551
478	EUR	LRD	209.369867	2025-12-26	2025-12-26 00:53:01.641093
479	EUR	LSL	19.620184	2025-12-26	2025-12-26 00:53:01.94109
480	EUR	LYD	6.372976	2025-12-26	2025-12-26 00:53:02.137311
481	EUR	MAD	10.736311	2025-12-26	2025-12-26 00:53:02.33494
482	EUR	MDL	19.745623	2025-12-26	2025-12-26 00:53:02.629787
483	EUR	MGA	5322.554329	2025-12-26	2025-12-26 00:53:02.828991
484	EUR	MKD	61.4887	2025-12-26	2025-12-26 00:53:03.035922
485	EUR	MMK	2476.029464	2025-12-26	2025-12-26 00:53:03.248537
486	EUR	MNT	4168.698668	2025-12-26	2025-12-26 00:53:03.542972
487	EUR	MOP	9.43502	2025-12-26	2025-12-26 00:53:03.936202
488	EUR	MRU	46.888976	2025-12-26	2025-12-26 00:53:04.427724
489	EUR	MUR	54.150559	2025-12-26	2025-12-26 00:53:04.920241
490	EUR	MVR	18.214329	2025-12-26	2025-12-26 00:53:05.328568
491	EUR	MWK	2052.481162	2025-12-26	2025-12-26 00:53:05.718685
492	EUR	MXN	21.130693	2025-12-26	2025-12-26 00:53:05.937805
493	EUR	MYR	4.768235	2025-12-26	2025-12-26 00:53:06.14239
494	EUR	MZN	75.279302	2025-12-26	2025-12-26 00:53:06.341474
495	EUR	NAD	19.620184	2025-12-26	2025-12-26 00:53:06.541309
496	EUR	NGN	1706.711685	2025-12-26	2025-12-26 00:53:06.842769
497	EUR	NIO	43.359618	2025-12-26	2025-12-26 00:53:07.138917
498	EUR	NOK	11.796106	2025-12-26	2025-12-26 00:53:07.438896
499	EUR	NPR	169.129649	2025-12-26	2025-12-26 00:53:07.732879
500	EUR	AED	4.32401	2025-12-29	2025-12-29 12:00:39.215135
501	EUR	AFN	77.399773	2025-12-29	2025-12-29 12:00:39.508196
502	EUR	ALL	96.293063	2025-12-29	2025-12-29 12:00:39.797518
503	EUR	AMD	449.102486	2025-12-29	2025-12-29 12:00:40.08896
504	EUR	ANG	2.10755	2025-12-29	2025-12-29 12:00:40.314136
505	EUR	AOA	1085.839956	2025-12-29	2025-12-29 12:00:40.611358
506	EUR	ARS	1709.882347	2025-12-29	2025-12-29 12:00:40.906762
507	EUR	AUD	1.754666	2025-12-29	2025-12-29 12:00:41.111465
508	EUR	AWG	2.10755	2025-12-29	2025-12-29 12:00:41.411069
509	EUR	AZN	2.001181	2025-12-29	2025-12-29 12:00:41.705645
510	EUR	BAM	1.95583	2025-12-29	2025-12-29 12:00:41.987422
511	EUR	BBD	2.354804	2025-12-29	2025-12-29 12:00:42.212136
512	EUR	BDT	143.947084	2025-12-29	2025-12-29 12:00:42.488492
513	EUR	BGN	1.95583	2025-12-29	2025-12-29 12:00:42.70518
514	EUR	BHD	0.442703	2025-12-29	2025-12-29 12:00:42.914866
515	EUR	BIF	3489.988593	2025-12-29	2025-12-29 12:00:43.216532
516	EUR	BMD	1.177402	2025-12-29	2025-12-29 12:00:43.509761
517	EUR	BND	1.512581	2025-12-29	2025-12-29 12:00:43.802008
518	EUR	BOB	8.147883	2025-12-29	2025-12-29 12:00:44.016976
519	EUR	BRL	6.52672	2025-12-29	2025-12-29 12:00:44.297862
520	EUR	BSD	1.177402	2025-12-29	2025-12-29 12:00:44.598877
521	EUR	BTN	105.722091	2025-12-29	2025-12-29 12:00:44.888967
522	EUR	BWP	16.033031	2025-12-29	2025-12-29 12:00:45.189142
523	EUR	BYN	3.430432	2025-12-29	2025-12-29 12:00:45.496675
524	EUR	BZD	2.354804	2025-12-29	2025-12-29 12:00:45.788149
525	EUR	CAD	1.609342	2025-12-29	2025-12-29 12:00:46.01028
526	EUR	CDF	2701.481203	2025-12-29	2025-12-29 12:00:46.306217
527	EUR	CHF	0.929046	2025-12-29	2025-12-29 12:00:46.597921
528	EUR	CLF	0.026945	2025-12-29	2025-12-29 12:00:46.890064
529	EUR	CLP	1065.050875	2025-12-29	2025-12-29 12:00:47.206185
530	EUR	CNH	8.248027	2025-12-29	2025-12-29 12:00:47.504822
531	EUR	CNY	8.257927	2025-12-29	2025-12-29 12:00:47.81284
532	EUR	COP	4367.276616	2025-12-29	2025-12-29 12:00:48.104886
533	EUR	CRC	582.887343	2025-12-29	2025-12-29 12:00:48.407399
534	EUR	CUP	28.257653	2025-12-29	2025-12-29 12:00:48.711122
535	EUR	CVE	110.265	2025-12-29	2025-12-29 12:00:49.007585
536	EUR	CZK	24.261925	2025-12-29	2025-12-29 12:00:49.306567
537	EUR	DJF	209.249097	2025-12-29	2025-12-29 12:00:49.608498
538	EUR	DKK	7.46045	2025-12-29	2025-12-29 12:00:49.906367
539	EUR	DOP	73.847073	2025-12-29	2025-12-29 12:00:50.187221
540	EUR	DZD	152.452995	2025-12-29	2025-12-29 12:00:50.408164
541	EUR	EGP	56.004069	2025-12-29	2025-12-29 12:00:50.615767
542	EUR	ERN	17.661033	2025-12-29	2025-12-29 12:00:50.901777
543	EUR	ETB	182.279229	2025-12-29	2025-12-29 12:00:51.113787
544	EUR	FJD	2.6704	2025-12-29	2025-12-29 12:00:51.312839
545	EUR	FKP	0.872418	2025-12-29	2025-12-29 12:00:51.688251
546	EUR	FOK	7.46045	2025-12-29	2025-12-29 12:00:51.91056
547	EUR	GBP	0.872419	2025-12-29	2025-12-29 12:00:52.209083
548	EUR	GEL	3.172044	2025-12-29	2025-12-29 12:00:52.514847
549	EUR	GGP	0.872418	2025-12-29	2025-12-29 12:00:52.80233
550	EUR	GHS	13.020714	2025-12-29	2025-12-29 12:00:53.091918
551	EUR	GIP	0.872418	2025-12-29	2025-12-29 12:00:53.408655
552	EUR	GMD	87.234308	2025-12-29	2025-12-29 12:00:53.812875
553	EUR	GNF	10267.636869	2025-12-29	2025-12-29 12:00:54.189846
554	EUR	GTQ	9.016493	2025-12-29	2025-12-29 12:00:54.41241
555	EUR	GYD	246.262509	2025-12-29	2025-12-29 12:00:54.707742
556	EUR	HKD	9.149235	2025-12-29	2025-12-29 12:00:54.997327
557	EUR	HNL	31.027207	2025-12-29	2025-12-29 12:00:55.215456
558	EUR	HRK	7.5345	2025-12-29	2025-12-29 12:00:55.513436
559	EUR	HTG	154.204721	2025-12-29	2025-12-29 12:00:55.886901
560	EUR	HUF	387.098124	2025-12-29	2025-12-29 12:00:56.113768
561	EUR	IDR	19731.998832	2025-12-29	2025-12-29 12:00:56.414821
562	EUR	ILS	3.756927	2025-12-29	2025-12-29 12:00:56.706438
563	EUR	IMP	0.872418	2025-12-29	2025-12-29 12:00:56.987099
564	EUR	INR	105.722102	2025-12-29	2025-12-29 12:00:57.205304
565	EUR	IQD	1542.04721	2025-12-29	2025-12-29 12:00:57.505998
566	EUR	IRR	50830.476173	2025-12-29	2025-12-29 12:00:57.798884
567	EUR	ISK	147.983593	2025-12-29	2025-12-29 12:00:58.08735
568	EUR	JEP	0.872418	2025-12-29	2025-12-29 12:00:58.314766
569	EUR	JMD	187.655895	2025-12-29	2025-12-29 12:00:58.687196
570	EUR	JOD	0.834778	2025-12-29	2025-12-29 12:00:58.912207
571	EUR	JPY	184.245489	2025-12-29	2025-12-29 12:00:59.212077
572	EUR	KES	151.776425	2025-12-29	2025-12-29 12:00:59.414668
573	EUR	KGS	102.94942	2025-12-29	2025-12-29 12:00:59.708503
574	EUR	KHR	4727.592105	2025-12-29	2025-12-29 12:01:00.003534
575	EUR	KID	1.754665	2025-12-29	2025-12-29 12:01:00.308032
576	EUR	KMF	491.96775	2025-12-29	2025-12-29 12:01:00.512276
577	EUR	KRW	1696.405265	2025-12-29	2025-12-29 12:01:00.711797
578	EUR	KWD	0.360809	2025-12-29	2025-12-29 12:01:01.003085
579	EUR	KYD	0.981168	2025-12-29	2025-12-29 12:01:01.213002
580	EUR	KZT	593.06877	2025-12-29	2025-12-29 12:01:01.517514
581	EUR	LAK	25532.459614	2025-12-29	2025-12-29 12:01:01.811216
582	EUR	LBP	105377.497009	2025-12-29	2025-12-29 12:01:02.087989
583	EUR	LKR	364.009075	2025-12-29	2025-12-29 12:01:02.307038
584	EUR	LRD	209.019222	2025-12-29	2025-12-29 12:01:02.588231
585	EUR	LSL	19.622429	2025-12-29	2025-12-29 12:01:02.904319
586	EUR	LYD	6.371079	2025-12-29	2025-12-29 12:01:03.12312
587	EUR	MAD	10.732058	2025-12-29	2025-12-29 12:01:03.403465
588	EUR	MDL	19.702079	2025-12-29	2025-12-29 12:01:03.688334
589	EUR	MGA	5354.115465	2025-12-29	2025-12-29 12:01:03.912884
590	EUR	MKD	61.495	2025-12-29	2025-12-29 12:01:04.203817
591	EUR	MMK	2474.214231	2025-12-29	2025-12-29 12:01:04.487718
592	EUR	MNT	4153.077948	2025-12-29	2025-12-29 12:01:04.706806
593	EUR	MOP	9.424202	2025-12-29	2025-12-29 12:01:04.999106
594	EUR	MRU	46.807843	2025-12-29	2025-12-29 12:01:05.213304
595	EUR	MUR	54.077408	2025-12-29	2025-12-29 12:01:05.588975
596	EUR	MVR	18.198443	2025-12-29	2025-12-29 12:01:05.904213
597	EUR	MWK	2042.776724	2025-12-29	2025-12-29 12:01:06.38844
598	EUR	MXN	21.079979	2025-12-29	2025-12-29 12:01:07.000875
599	EUR	MYR	4.766868	2025-12-29	2025-12-29 12:01:07.789113
\.


--
-- Data for Name: expense_name_mappings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.expense_name_mappings (id, expense_name, subcategory, confidence, last_updated) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.expenses (id, user_id, budget_period_id, recurring_template_id, name, amount, category, subcategory, date, due_date, payment_method, notes, receipt_url, is_fixed_bill, created_at, currency, original_amount, exchange_rate_used, deleted_at, updated_at) FROM stdin;
174	1	\N	\N	Wolt	3542	Flexible Expenses	Food	2025-12-31	N/A	Credit card	\N	\N	f	2026-01-01 12:39:24.380325	EUR	\N	\N	\N	\N
175	1	\N	\N	Wolt	1999	Flexible Expenses	Food	2025-12-31	N/A	Credit card	\N	\N	f	2026-01-01 12:39:36.191134	EUR	\N	\N	\N	\N
176	1	\N	\N	Nordea Credit Interest	466	Flexible Expenses	Other	2026-01-01	N/A	Credit card	\N	\N	f	2026-01-01 12:40:22.722058	EUR	\N	\N	\N	\N
2	1	2	1	Telia	4546	Debt Payments	Telia Rahoitus	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:13.991189	EUR	\N	\N	\N	2025-12-04 16:06:13.991189
49	1	2	\N	Wolt	5004	Flexible Expenses	Food	2025-11-30	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.686852	EUR	\N	\N	\N	2025-12-04 16:06:14.686852
51	1	2	\N	Snapchat	99	Flexible Expenses	Entertainment	2025-11-30	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.707763	EUR	\N	\N	\N	2025-12-04 16:06:14.707763
52	1	2	\N	YouTube	1499	Flexible Expenses	Entertainment	2025-11-30	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.716167	EUR	\N	\N	\N	2025-12-04 16:06:14.716167
53	1	2	\N	Wolt	1478	Flexible Expenses	Food	2025-12-02	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.724467	EUR	\N	\N	\N	2025-12-04 16:06:14.724467
54	1	2	\N	Wolt	3356	Flexible Expenses	Food	2025-12-03	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.73294	EUR	\N	\N	\N	2025-12-04 16:06:14.73294
9	1	2	\N	Fortum	2651	Fixed Expenses	Utilities	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.056033	EUR	\N	\N	\N	2025-12-04 16:06:14.056033
1	1	\N	\N	Pre-existing Credit Card Debt	141058	Debt	Credit Card	2025-11-19	N/A	Credit card	Existing credit card balance at budget period start	\N	f	2025-12-04 16:06:13.914645	EUR	\N	\N	\N	2025-12-04 16:06:13.914645
3	1	2	2	Elisa	3535	Debt Payments	Elisa (Phone)	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.001089	EUR	\N	\N	\N	2025-12-04 16:06:14.001089
4	1	2	3	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.009865	EUR	\N	\N	\N	2025-12-04 16:06:14.009865
5	1	2	4	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.018561	EUR	\N	\N	\N	2025-12-04 16:06:14.018561
6	1	2	5	Klarna Turkish Airlines Old	10080	Debt Payments	Klarna Turkish Airlines Old	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.030294	EUR	\N	\N	\N	2025-12-04 16:06:14.030294
7	1	2	\N	Rent	94718	Fixed Expenses	Rent	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.039037	EUR	\N	\N	\N	2025-12-04 16:06:14.039037
8	1	2	\N	DNA	3490	Fixed Expenses	Subscriptions	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.047386	EUR	\N	\N	\N	2025-12-04 16:06:14.047386
11	1	1	\N	Wise Europe SA	4233	Flexible Expenses	Shopping	2025-11-22	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.102966	EUR	\N	\N	\N	2025-12-04 16:06:14.102966
12	1	1	\N	Wise	3888	Flexible Expenses	Shopping	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.116186	EUR	\N	\N	\N	2025-12-04 16:06:14.116186
13	1	1	\N	UBER   *TRIP	18	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.125584	EUR	\N	\N	\N	2025-12-04 16:06:14.125584
14	1	1	\N	Nordea Responsible Global	5000	Flexible Expenses	Shopping	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.134744	EUR	\N	\N	\N	2025-12-04 16:06:14.134744
15	1	1	\N	UBER   *TRIP	37	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.143014	EUR	\N	\N	\N	2025-12-04 16:06:14.143014
16	1	1	\N	UBR* PENDING.UBER.COM	366	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.191232	EUR	\N	\N	\N	2025-12-04 16:06:14.191232
17	1	1	\N	UBR* PENDING.UBER.COM	277	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.2	EUR	\N	\N	\N	2025-12-04 16:06:14.2
18	1	1	\N	UBER   *TRIP	243	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.209241	EUR	\N	\N	\N	2025-12-04 16:06:14.209241
19	1	1	\N	UBER   *TRIP	73	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.217657	EUR	\N	\N	\N	2025-12-04 16:06:14.217657
20	1	1	\N	UBR* PENDING.UBER.COM	118	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.225929	EUR	\N	\N	\N	2025-12-04 16:06:14.225929
21	1	2	\N	PAYPAL *DISNEYPLUS	1099	Fixed Expenses	Subscriptions	2025-11-28	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.234435	EUR	\N	\N	\N	2025-12-04 16:06:14.234435
22	1	2	\N	Retail NLD Amsterdam UBER *TRIP HELP.UBER.C	2059	Flexible Expenses	Transportation	2025-11-27	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.287782	EUR	\N	\N	\N	2025-12-04 16:06:14.287782
23	1	1	\N	Retail FIN Finland Wolt Oy	2614	Flexible Expenses	Food	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.297088	EUR	\N	\N	\N	2025-12-04 16:06:14.297088
24	1	1	\N	Retail FIN HELSINKI VFI*Armina Oy ITIS	6767	Flexible Expenses	Shopping	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.30562	EUR	\N	\N	\N	2025-12-04 16:06:14.30562
25	1	1	\N	Retail NLD HELP.UBER.COM UBER *TRIP	1969	Flexible Expenses	Transportation	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.313831	EUR	\N	\N	\N	2025-12-04 16:06:14.313831
26	1	1	\N	Retail NLD Amsterdam UBER *TRIP HELP.UBER.C	1939	Flexible Expenses	Transportation	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.322517	EUR	\N	\N	\N	2025-12-04 16:06:14.322517
27	1	1	\N	Retail FIN Helsinki BIBI Bistro	1619	Flexible Expenses	Shopping	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.33067	EUR	\N	\N	\N	2025-12-04 16:06:14.33067
28	1	1	\N	Retail NLD Amsterdam UBER *TRIP HELP.UBER.C	1854	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.33925	EUR	\N	\N	\N	2025-12-04 16:06:14.33925
29	1	1	\N	Retail FIN Finland Wolt Oy	543	Flexible Expenses	Food	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.347687	EUR	\N	\N	\N	2025-12-04 16:06:14.347687
30	1	1	\N	Retail FIN Espoo KFC Iso Omena	1175	Flexible Expenses	Shopping	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.393561	EUR	\N	\N	\N	2025-12-04 16:06:14.393561
31	1	1	\N	Retail NLD HELP.UBER.COM UBER *TRIP	1697	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.401544	EUR	\N	\N	\N	2025-12-04 16:06:14.401544
32	1	1	\N	TRY 1182.18 Retail TUR ISTANBUL F17 OBICA MOZ	2487	Flexible Expenses	Shopping	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.409402	EUR	\N	\N	\N	2025-12-04 16:06:14.409402
33	1	1	\N	TRY 40.00 Retail NLD HELP.UBER.COM UBER *	84	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.417416	EUR	\N	\N	\N	2025-12-04 16:06:14.417416
34	1	1	\N	TRY 655.00 Retail NLD HELP.UBER.COM UBER *	1378	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.425739	EUR	\N	\N	\N	2025-12-04 16:06:14.425739
35	1	1	\N	TRY 1221.00 Retail TUR ISTANBUL TAKSI YONETIM	2577	Flexible Expenses	Shopping	2025-11-24	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.433975	EUR	\N	\N	\N	2025-12-04 16:06:14.433975
36	1	1	\N	Retail TUR ISTANBUL GNC AIRPORT HOTEL	100	Flexible Expenses	Shopping	2025-11-24	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.442823	EUR	\N	\N	\N	2025-12-04 16:06:14.442823
37	1	1	\N	Retail TUR ISTANBUL GNC AIRPORT HOTEL	3000	Flexible Expenses	Shopping	2025-11-24	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.493253	EUR	\N	\N	\N	2025-12-04 16:06:14.493253
38	1	1	\N	TRY 1650.00 Retail TUR ISTANBUL GNC AIRPORT H	3483	Flexible Expenses	Shopping	2025-11-24	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.502175	EUR	\N	\N	\N	2025-12-04 16:06:14.502175
39	1	1	\N	USD 67.95 Retail TUR ANKARA E-VISA TURKEY	6048	Flexible Expenses	Shopping	2025-11-23	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.510495	EUR	\N	\N	\N	2025-12-04 16:06:14.510495
40	1	1	\N	BDT 560.00 Retail BGD Shantinagar T FRESH &	405	Flexible Expenses	Shopping	2025-11-21	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.518961	EUR	\N	\N	\N	2025-12-04 16:06:14.518961
41	1	1	\N	BDT 400.00 Retail BGD Shantinagar T HAKKA EX	290	Flexible Expenses	Shopping	2025-11-21	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.527468	EUR	\N	\N	\N	2025-12-04 16:06:14.527468
42	1	1	\N	BDT 1680.00 Retail BGD Gulshan Model KIVAHAN	1223	Flexible Expenses	Shopping	2025-11-20	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.535601	EUR	\N	\N	\N	2025-12-04 16:06:14.535601
43	1	1	\N	BDT 470.00 Retail BGD Gulshan Model ALFRESCO	343	Flexible Expenses	Shopping	2025-11-20	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.587727	EUR	\N	\N	\N	2025-12-04 16:06:14.587727
44	1	1	\N	Payment to Klarna Turkish Airlines Old	4112	Debt Payments	Klarna Turkish Airlines Old	2025-11-26	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.597124	EUR	\N	\N	\N	2025-12-04 16:06:14.597124
45	1	2	11	Insinööriliitto	3525	Fixed Expenses	Insurance	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.605679	EUR	\N	\N	\N	2025-12-04 16:06:14.605679
46	1	2	\N	Mee6	4203	Flexible Expenses	Entertainment	2025-11-29	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.614016	EUR	\N	\N	\N	2025-12-04 16:06:14.614016
47	1	2	\N	ImageGPT	2241	Flexible Expenses	Entertainment	2025-11-29	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.622792	EUR	\N	\N	\N	2025-12-04 16:06:14.622792
48	1	2	\N	Namecheap	637	Flexible Expenses	Entertainment	2025-11-29	N/A	Credit card	\N	\N	f	2025-12-04 16:06:14.631742	EUR	\N	\N	\N	2025-12-04 16:06:14.631742
10	1	1	\N	Credit card repayment	99104	Debt Payments	Credit Card	2025-11-20	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.094241	EUR	\N	\N	\N	2025-12-04 16:06:14.094241
55	1	3	\N	Wolt	6212	Flexible Expenses	Food	2025-12-04	N/A	Debit card	\N	\N	f	2025-12-04 16:07:50.508079	EUR	\N	\N	\N	2025-12-04 16:07:50.508079
56	1	3	\N	Wolt	3294	Flexible Expenses	Food	2025-12-04	N/A	Debit card	\N	\N	f	2025-12-04 16:09:32.892452	EUR	\N	\N	\N	2025-12-04 16:09:32.892452
57	1	3	\N	Wolt	1027	Flexible Expenses	Food	2025-12-05	N/A	Debit card	\N	\N	f	2025-12-05 11:18:41.340793	EUR	\N	\N	\N	2025-12-05 11:18:41.340793
58	1	3	\N	Wolt	2424	Flexible Expenses	Food	2025-12-05	N/A	Debit card	\N	\N	f	2025-12-05 11:18:55.891369	EUR	\N	\N	\N	2025-12-05 11:18:55.891369
59	1	3	\N	Wolt	3271	Flexible Expenses	Food	2025-12-06	N/A	Credit card	\N	\N	f	2025-12-06 10:25:51.052266	EUR	\N	\N	\N	2025-12-06 10:25:51.052266
60	1	3	\N	Wolt	2101	Flexible Expenses	Food	2025-12-05	N/A	Debit card	\N	\N	f	2025-12-06 14:11:36.395363	EUR	\N	\N	\N	2025-12-06 14:11:36.395363
61	1	\N	\N	Uber	1304	Flexible Expenses	Transportation	2025-12-07	N/A	Debit card	\N	\N	f	2025-12-07 17:29:07.343085	EUR	\N	\N	\N	2025-12-07 17:29:07.343085
62	1	\N	\N	Uber	1251	Flexible Expenses	Transportation	2025-12-07	N/A	Debit card	\N	\N	f	2025-12-07 17:29:33.885755	EUR	\N	\N	\N	2025-12-07 17:29:33.885755
63	1	\N	\N	Wolt	2840	Flexible Expenses	Food	2025-12-07	N/A	Debit card	\N	\N	f	2025-12-07 17:29:44.937947	EUR	\N	\N	\N	2025-12-07 17:29:44.937947
64	1	\N	\N	Nordea	465	Fixed Expenses	Subscriptions	2025-12-10	N/A	Debit card	\N	\N	f	2025-12-10 08:14:21.791929	EUR	\N	\N	\N	2025-12-10 08:14:21.791929
65	1	\N	\N	Wolt	1351	Flexible Expenses	Food	2025-12-10	N/A	Debit card	\N	\N	f	2025-12-10 10:55:44.808684	EUR	\N	\N	\N	2025-12-10 10:55:44.808684
66	1	\N	\N	Wolt	3054	Flexible Expenses	Food	2025-12-10	N/A	Debit card	\N	\N	f	2025-12-10 10:55:55.959342	EUR	\N	\N	\N	2025-12-10 10:55:55.959342
67	1	\N	\N	Uber	912	Flexible Expenses	Transportation	2025-12-11	N/A	Debit card	\N	\N	f	2025-12-11 10:47:24.381581	EUR	\N	\N	\N	2025-12-11 10:47:24.381581
68	1	\N	\N	Sodexo Nokia	860	Flexible Expenses	Food	2025-12-11	N/A	Debit card	\N	\N	f	2025-12-11 10:47:48.478915	EUR	\N	\N	\N	2025-12-11 10:47:48.478915
69	1	\N	\N	Settlement Survivors	692	Flexible Expenses	Entertainment	2025-12-11	N/A	Credit card	\N	\N	f	2025-12-11 10:48:29.418718	EUR	\N	\N	\N	2025-12-11 10:48:29.418718
70	1	\N	\N	Nordea Credit	99	Fixed Expenses	Subscriptions	2025-12-11	N/A	Credit card	\N	\N	f	2025-12-11 10:48:52.431043	EUR	\N	\N	\N	2025-12-11 10:48:52.431043
71	1	\N	\N	HSL	320	Flexible Expenses	Transportation	2025-12-11	N/A	Debit card	\N	\N	f	2025-12-11 21:22:50.721342	EUR	\N	\N	\N	2025-12-11 21:22:50.721342
72	1	\N	\N	Uber	1378	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	\N	\N	f	2025-12-11 21:24:18.577382	EUR	\N	\N	\N	2025-12-11 21:24:18.577382
73	1	\N	\N	Wolt	1626	Flexible Expenses	Food	2025-12-12	N/A	Debit card	\N	\N	f	2025-12-12 12:39:14.744577	EUR	\N	\N	\N	2025-12-12 12:39:14.744577
85	1	\N	\N	Wolt	1999	Flexible Expenses	Food	2025-12-12	N/A	Credit card	\N	\N	f	2025-12-12 23:57:15.117517	EUR	\N	\N	\N	2025-12-12 23:57:15.117517
86	1	\N	\N	Wolt	5129	Flexible Expenses	Food	2025-12-12	N/A	Credit card	\N	\N	f	2025-12-12 23:57:24.640442	EUR	\N	\N	\N	2025-12-12 23:57:24.640442
87	1	\N	\N	Verkkokauppa (OnePlus Buds Pro 4)	8590	Flexible Expenses	Shopping	2025-12-12	N/A	Debit card	\N	\N	f	2025-12-12 23:58:13.154874	EUR	\N	\N	\N	2025-12-12 23:58:13.154874
88	1	\N	\N	Adjusting credit	10	Fixed Expenses	Utilities	2025-12-12	N/A	Credit card	\N	\N	f	2025-12-12 23:58:48.067889	EUR	\N	\N	\N	2025-12-12 23:58:48.067889
78	1	\N	5	Klarna Turkish Airlines Old	10080	Debt Payments	Klarna Turkish Airlines Old	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.26532	EUR	\N	\N	\N	2025-12-12 12:42:47.26532
74	1	\N	1	Telia	4546	Debt Payments	Telia Rahoitus	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.226641	EUR	\N	\N	\N	2025-12-12 12:42:47.226641
75	1	\N	2	Elisa	3535	Debt Payments	Elisa (Phone)	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.237049	EUR	\N	\N	\N	2025-12-12 12:42:47.237049
76	1	\N	3	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.246338	EUR	\N	\N	\N	2025-12-12 12:42:47.246338
77	1	\N	4	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.255959	EUR	\N	\N	\N	2025-12-12 12:42:47.255959
82	1	\N	10	DNA	3490	Fixed Expenses	Subscriptions	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.33003	EUR	\N	\N	\N	2025-12-12 12:42:47.33003
80	1	\N	8	Rent	94718	Fixed Expenses	Rent	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.284605	EUR	\N	\N	\N	2025-12-12 12:42:47.284605
100	1	\N	\N	Caruna	4583	Fixed Expenses	Utilities	2025-12-19	N/A	Debit card	\N	\N	f	2025-12-13 00:01:33.115932	EUR	\N	\N	\N	2025-12-13 00:01:33.115932
114	1	\N	\N	Canva Subscription	600	Flexible Expenses	Shopping	2025-12-15	N/A	Debit card	\N	\N	f	2025-12-15 15:40:41.915651	EUR	\N	\N	\N	2025-12-15 15:40:41.915651
113	1	\N	15	Telia Dot	810	Fixed Expenses	Subscriptions	2025-12-15	N/A	Debit card	\N	\N	f	2025-12-15 15:08:07.937896	EUR	\N	\N	\N	2025-12-15 15:08:07.937896
115	1	\N	\N	Prime Video	699	Flexible Expenses	Entertainment	2025-12-15	N/A	Debit card	\N	\N	f	2025-12-15 15:41:37.334051	EUR	\N	\N	\N	2025-12-15 15:41:37.334051
118	1	\N	16	Discord	999	Fixed Expenses	Subscriptions	2025-12-16	N/A	Credit card	\N	\N	f	2025-12-16 14:24:00.304481	EUR	\N	\N	\N	2025-12-16 14:24:00.304481
121	1	\N	\N	Wolt	1711	Flexible Expenses	Food	2025-12-16	N/A	Debit card	\N	\N	f	2025-12-16 14:26:21.878437	EUR	\N	\N	\N	2025-12-16 14:26:21.878437
122	1	\N	\N	Wolt	2672	Flexible Expenses	Food	2025-12-16	N/A	Debit card	\N	\N	f	2025-12-16 14:26:27.815188	EUR	\N	\N	\N	2025-12-16 14:26:27.815188
128	1	\N	\N	Temu	6045	Flexible Expenses	Shopping	2025-12-17	N/A	Debit card	\N	\N	f	2025-12-17 09:38:16.68101	EUR	\N	\N	\N	2025-12-17 09:38:16.68101
130	1	\N	\N	Wolt	1487	Flexible Expenses	Food	2025-12-17	N/A	Credit card	\N	\N	f	2025-12-17 16:07:58.844461	EUR	\N	\N	\N	2025-12-17 16:07:58.844461
131	1	\N	\N	Wolt	2270	Flexible Expenses	Food	2025-12-17	N/A	Credit card	\N	\N	f	2025-12-17 16:08:11.427218	EUR	\N	\N	\N	2025-12-17 16:08:11.427218
132	1	\N	\N	Wolt	2365	Flexible Expenses	Food	2025-12-18	N/A	Debit card	\N	\N	f	2025-12-18 22:23:55.164613	EUR	\N	\N	\N	2025-12-18 22:23:55.164613
133	1	\N	\N	Netflix	949	Flexible Expenses	Entertainment	2025-12-18	N/A	Credit card	\N	\N	f	2025-12-18 22:24:50.576909	EUR	\N	\N	\N	2025-12-18 22:24:50.576909
134	1	\N	\N	Temu	4215	Flexible Expenses	Shopping	2025-12-19	N/A	Debit card	\N	\N	f	2025-12-19 07:53:36.408135	EUR	\N	\N	\N	2025-12-19 07:53:36.408135
81	1	\N	9	Fortum	1788	Fixed Expenses	Utilities	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.293648	EUR	\N	\N	\N	2025-12-12 12:42:47.293648
135	1	\N	\N	Savings	5000	Savings & Investments	Emergency Fund	2025-12-19	N/A	Debit card	\N	\N	f	2025-12-20 16:55:12.277545	EUR	\N	\N	\N	2025-12-20 16:55:12.277545
137	1	\N	\N	Klarna Turkish Airlines Business Payment	10479	Debt Payments	Klarna Turkish Airlines Business	2025-12-19	N/A	Debit card	\N	\N	f	2025-12-21 13:24:38.400549	EUR	\N	\N	\N	2025-12-21 13:24:38.400549
138	1	\N	\N	Wolt	2796	Flexible Expenses	Food	2025-12-21	N/A	Debit card	\N	\N	f	2025-12-21 13:25:10.284668	EUR	\N	\N	\N	2025-12-21 13:25:10.284668
140	1	\N	\N	Wolt	4549	Flexible Expenses	Food	2025-12-21	N/A	Debit card	\N	\N	f	2025-12-21 15:45:20.225022	EUR	\N	\N	\N	2025-12-21 15:45:20.225022
127	1	\N	\N	Zooplus	4946	Flexible Expenses	Cat Stuff	2025-12-17	N/A	Debit card	\N	\N	f	2025-12-16 23:57:32.64	EUR	\N	\N	\N	2025-12-16 23:57:32.64
125	1	\N	\N	Credit repayment	80000	Debt Payments	Credit Card	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-16 23:56:34.555753	EUR	\N	\N	\N	2025-12-16 23:56:34.555753
141	1	\N	12	YouTube	1499	Flexible Expenses	Entertainment	2025-12-30	N/A	Debit card	\N	\N	t	2025-12-22 23:54:35.07162	EUR	\N	\N	\N	2025-12-22 23:54:35.07162
142	1	\N	16	Discord	999	Fixed Expenses	Subscriptions	2026-01-16	N/A	Credit card	\N	\N	t	2025-12-23 00:25:02.137551	EUR	\N	\N	\N	2025-12-23 00:25:02.137551
143	1	\N	9	Fortum	3000	Fixed Expenses	Utilities	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.212115	EUR	\N	\N	\N	2025-12-23 00:25:02.212115
144	1	\N	10	DNA	3490	Fixed Expenses	Subscriptions	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.219266	EUR	\N	\N	\N	2025-12-23 00:25:02.219266
145	1	\N	1	Telia	4546	Debt Payments	Telia Rahoitus	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.225717	EUR	\N	\N	\N	2025-12-23 00:25:02.225717
146	1	\N	3	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.231736	EUR	\N	\N	\N	2025-12-23 00:25:02.231736
147	1	\N	8	Rent	94718	Fixed Expenses	Rent	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.237762	EUR	\N	\N	\N	2025-12-23 00:25:02.237762
148	1	\N	5	Klarna Turkish Airlines Old	10080	Debt Payments	Klarna Turkish Airlines Old	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.243697	EUR	\N	\N	\N	2025-12-23 00:25:02.243697
149	1	\N	18	Investment (Nordea) Contribution	5000	Savings & Investments	Investment (Nordea)	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-23 00:25:02.249619	EUR	\N	\N	\N	2025-12-23 00:25:02.249619
150	1	\N	2	Elisa	3535	Debt Payments	Elisa (Phone)	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.255682	EUR	\N	\N	\N	2025-12-23 00:25:02.255682
151	1	\N	4	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.261507	EUR	\N	\N	\N	2025-12-23 00:25:02.261507
152	1	\N	11	Insinööriliitto	3525	Fixed Expenses	Insurance	2026-01-15	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.314166	EUR	\N	\N	\N	2025-12-23 00:25:02.314166
153	1	\N	15	Telia Dot	810	Fixed Expenses	Subscriptions	2026-01-15	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.320684	EUR	\N	\N	\N	2025-12-23 00:25:02.320684
154	3	\N	\N	Emergency	55000	Savings & Investments	Emergency Fund	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-23 16:46:44.230719	EUR	\N	\N	\N	2025-12-23 16:46:44.230719
155	3	\N	\N	Wolt	2400	Fixed Expenses	Insurance	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-23 16:48:17.557856	EUR	\N	\N	\N	2025-12-23 16:48:17.557856
156	1	\N	\N	Proton vpn	999	Flexible Expenses	Entertainment	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-23 18:44:26.114863	EUR	\N	\N	\N	2025-12-23 18:44:26.114863
157	1	\N	\N	Wolt	3311	Flexible Expenses	Food	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-24 01:18:34.460833	EUR	\N	\N	\N	2025-12-24 01:18:34.460833
158	1	\N	\N	Wolt	1520	Flexible Expenses	Food	2025-12-23	N/A	Credit card	\N	\N	f	2025-12-24 01:19:10.006105	EUR	\N	\N	\N	2025-12-24 01:19:10.006105
159	1	\N	\N	Wolt	1478	Flexible Expenses	Food	2025-12-24	N/A	Credit card	\N	\N	f	2025-12-24 22:52:06.079252	EUR	\N	\N	\N	2025-12-24 22:52:06.079252
160	1	\N	18	Investment (Nordea) Contribution	5000	Savings & Investments	Investment (Nordea)	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-25 20:33:33.013964	EUR	\N	\N	\N	2025-12-25 20:33:33.013964
163	1	\N	\N	Wolt	3131	Flexible Expenses	Food	2025-12-26	N/A	Credit card	\N	\N	f	2025-12-26 00:53:58.440674	EUR	\N	\N	\N	2025-12-26 00:53:58.440674
164	1	\N	\N	Wolt	2371	Flexible Expenses	Food	2025-12-26	N/A	Credit card	\N	\N	f	2025-12-26 00:54:07.718831	EUR	\N	\N	\N	2025-12-26 00:54:07.718831
162	1	\N	21	GH Copilot	2660	Fixed Expenses	Subscriptions	2025-12-25	N/A	Debit card	\N	\N	t	2025-12-25 22:52:49.855037	EUR	\N	\N	\N	2025-12-25 22:52:49.855037
169	1	\N	\N	Shakerapu Uber TO BE REFUNDED LATER	2717	Flexible Expenses	Transportation	2025-12-26	N/A	Debit card	\N	\N	f	2025-12-27 20:21:39.263007	EUR	\N	\N	\N	2025-12-27 20:21:39.263007
167	1	\N	\N	Pharmace	2087	Flexible Expenses	Health	2025-12-26	N/A	Credit card	\N	\N	f	2025-12-26 15:46:23.778589	EUR	\N	\N	\N	2025-12-26 15:46:23.778589
168	1	\N	\N	Ikea	4736	Flexible Expenses	Shopping	2025-12-26	N/A	Credit card	\N	\N	f	2025-12-26 16:08:29.451183	EUR	\N	\N	\N	2025-12-26 16:08:29.451183
170	1	\N	\N	Wolt	1351	Flexible Expenses	Food	2025-12-27	N/A	Credit card	\N	\N	f	2025-12-27 20:22:55.7972	EUR	\N	\N	\N	2025-12-27 20:22:55.7972
171	1	\N	\N	Wolt	2376	Flexible Expenses	Food	2025-12-27	N/A	Credit card	\N	\N	f	2025-12-27 20:23:17.984519	EUR	\N	\N	\N	2025-12-27 20:23:17.984519
172	1	\N	\N	Wolt	2696	Flexible Expenses	Food	2025-12-29	N/A	Credit card	\N	\N	f	2025-12-29 17:55:28.790884	EUR	\N	\N	\N	2025-12-29 17:55:28.790884
173	1	\N	\N	Wolt	2326	Flexible Expenses	Food	2025-12-29	N/A	Credit card	\N	\N	f	2025-12-29 17:55:41.000062	EUR	\N	\N	\N	2025-12-29 17:55:41.000062
\.


--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.goals (id, user_id, name, description, target_amount, target_date, subcategory_name, is_active, created_at, updated_at, initial_amount, deleted_at) FROM stdin;
4	3	Emergency Fund	For an emergency fund nigga	700000	\N	Emergency Fund	t	2025-12-23 16:44:06.685006	2025-12-23 16:44:06.68501	0	\N
3	1	Emergency Fund	\N	200000	\N	Emergency Fund	t	2025-12-23 00:02:04.667374	2025-12-25 14:46:43.906066	34754	\N
2	1	Investment (Nordea)	\N	100000	2026-12-31	Investment (Nordea)	t	2025-12-22 23:43:36.744481	2025-12-25 14:47:10.676058	5036	\N
\.


--
-- Data for Name: income; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.income (id, user_id, budget_period_id, type, amount, scheduled_date, actual_date, created_at, currency, original_amount, exchange_rate_used, deleted_at, updated_at) FROM stdin;
1	1	\N	Initial Balance	307200	2025-11-20	2025-11-20	2025-12-04 16:06:13.923676	EUR	\N	\N	\N	2025-12-04 16:06:13.923676
2	1	2	Other	30350	2025-11-27	2025-11-27	2025-12-04 16:06:14.746151	EUR	\N	\N	\N	2025-12-04 16:06:14.746151
3	1	\N	Salary	281545	2025-12-19	2025-12-19	2025-12-16 22:12:14.124386	EUR	\N	\N	\N	2025-12-16 22:12:14.124386
5	3	\N	Initial Balance	200000	2025-12-23	2025-12-23	2025-12-23 16:45:25.789574	EUR	\N	\N	\N	2025-12-23 16:45:25.789574
6	1	\N	Other	1700	2025-12-26	2025-12-26	2025-12-26 00:55:18.222986	EUR	\N	\N	\N	2025-12-26 00:55:18.222986
7	1	\N	Other	33	2026-01-01	2026-01-01	2026-01-01 12:41:14.635775	EUR	\N	\N	\N	\N
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.password_reset_tokens (id, user_id, token, expires_at, is_used, created_at) FROM stdin;
\.


--
-- Data for Name: period_suggestions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.period_suggestions (id, user_id, budget_period_id, suggestion_type, amount, status, created_at) FROM stdin;
\.


--
-- Data for Name: rate_limits; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.rate_limits (id, key, "timestamp") FROM stdin;
\.


--
-- Data for Name: recurring_expenses; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.recurring_expenses (id, user_id, name, amount, category, subcategory, payment_method, frequency, frequency_value, day_of_month, day_of_week, start_date, end_date, next_due_date, is_active, is_fixed_bill, notes, created_at, updated_at, deleted_at) FROM stdin;
12	1	YouTube	1499	Flexible Expenses	Entertainment	Debit card	monthly	\N	30	\N	2025-11-30	\N	2026-01-28	t	t	\N	2025-12-04 16:06:13.887384	2025-12-22 23:54:35.067762	\N
16	1	Discord	999	Fixed Expenses	Subscriptions	Credit card	monthly	\N	16	\N	2026-01-16	\N	2026-02-16	t	t	\N	2025-12-16 14:23:59.9971	2025-12-23 00:25:02.130609	\N
9	1	Fortum	3000	Fixed Expenses	Utilities	Debit card	monthly	\N	20	\N	2025-12-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.825636	2025-12-23 00:25:02.144444	\N
10	1	DNA	3490	Fixed Expenses	Subscriptions	Debit card	monthly	\N	20	\N	2025-12-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.831015	2025-12-23 00:25:02.216822	\N
1	1	Telia	4546	Debt Payments	Telia Rahoitus	Debit card	monthly	\N	20	\N	2025-11-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.734805	2025-12-23 00:25:02.223035	\N
3	1	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	Debit card	monthly	\N	20	\N	2025-11-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.790754	2025-12-23 00:25:02.229528	\N
8	1	Rent	94718	Fixed Expenses	Rent	Debit card	monthly	\N	20	\N	2025-12-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.820155	2025-12-23 00:25:02.23557	\N
5	1	Klarna Turkish Airlines Old	10080	Debt Payments	Klarna Turkish Airlines Old	Debit card	monthly	\N	20	\N	2025-11-24	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.802794	2025-12-23 00:25:02.241496	\N
2	1	Elisa	3535	Debt Payments	Elisa (Phone)	Debit card	monthly	\N	20	\N	2025-11-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.744124	2025-12-23 00:25:02.25322	\N
4	1	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	Debit card	monthly	\N	20	\N	2025-11-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.797164	2025-12-23 00:25:02.259373	\N
11	1	Insinööriliitto	3525	Fixed Expenses	Insurance	Debit card	monthly	\N	15	\N	2026-01-15	\N	2026-02-15	t	t	\N	2025-12-04 16:06:13.836541	2025-12-23 00:25:02.26527	\N
15	1	Telia Dot	810	Fixed Expenses	Subscriptions	Debit card	monthly	\N	15	\N	2026-01-15	\N	2026-02-15	t	t	\N	2025-12-15 15:08:07.74988	2025-12-23 00:25:02.318549	\N
19	3	Emergency Fund Contribution	1500	Savings & Investments	Emergency Fund	Credit card	monthly	\N	1	\N	2025-12-23	\N	2025-12-23	t	f	\N	2025-12-23 16:44:37.639115	2025-12-23 16:44:37.639117	\N
18	1	Investment (Nordea) Contribution	5000	Savings & Investments	Investment (Nordea)	Debit card	monthly	\N	20	\N	2025-12-23	\N	2026-02-20	t	t	\N	2025-12-23 00:23:52.47975	2025-12-25 20:33:33.047035	\N
21	1	GH Copilot	3000	Fixed Expenses	Subscriptions	Debit card	monthly	\N	26	\N	2025-12-25	\N	2026-01-26	t	t	\N	2025-12-25 22:52:44.319215	2025-12-25 22:52:49.863801	\N
\.


--
-- Data for Name: salary_periods; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.salary_periods (id, user_id, initial_debit_balance, initial_credit_balance, credit_limit, credit_budget_allowance, salary_amount, total_budget_amount, fixed_bills_total, remaining_amount, weekly_budget, weekly_debit_budget, weekly_credit_budget, start_date, end_date, is_active, created_at, updated_at, num_sub_periods) FROM stdin;
1	1	307200	8942	150000	0	\N	73462	233738	73462	18365	18365	0	2025-11-20	2025-12-19	f	2025-12-04 16:06:13.895815	2025-12-04 16:06:13.895815	4
3	3	200000	0	2000000	0	\N	200000	0	200000	50000	50000	0	2025-12-23	2026-01-22	t	2025-12-23 16:45:25.738348	2025-12-23 16:45:25.738348	4
2	1	289374	50178	150000	20000	\N	69558	239816	69558	17389	12389	5000	2025-12-20	2026-01-19	t	2025-12-17 10:14:43.940326	2025-12-17 10:14:43.940326	4
\.


--
-- Data for Name: subcategories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.subcategories (id, user_id, category, name, is_system, is_active, created_at, updated_at) FROM stdin;
1	\N	Flexible Expenses	Food	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
2	\N	Savings & Investments	Other	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
3	\N	Fixed Expenses	Subscriptions	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
4	\N	Flexible Expenses	Shopping	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
5	\N	Fixed Expenses	Other	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
7	\N	Fixed Expenses	Rent	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
8	\N	Debt Payments	Other	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
9	\N	Flexible Expenses	Other	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
10	\N	Fixed Expenses	Insurance	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
13	\N	Debt Payments	Credit Card	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
14	\N	Flexible Expenses	Entertainment	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
15	\N	Fixed Expenses	Utilities	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
16	\N	Flexible Expenses	Transportation	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
17	\N	Flexible Expenses	Health	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
18	1	Flexible Expenses	Cat Stuff	f	t	2025-12-22 23:35:38.262498	2025-12-22 23:35:38.2625
20	1	Savings & Investments	Investment (Nordea)	f	t	2025-12-22 23:43:36.735751	2025-12-22 23:43:36.735753
21	1	Savings & Investments	Emergency Fund	f	t	2025-12-23 00:02:04.65833	2025-12-23 00:02:04.658332
22	3	Savings & Investments	Emergency Fund	f	t	2025-12-23 16:44:06.66174	2025-12-23 16:44:06.661744
23	3	Flexible Expenses	Bullshit spending	f	t	2025-12-23 16:50:54.530363	2025-12-23 16:51:33.969076
\.


--
-- Data for Name: user_defaults; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.user_defaults (id, user_id, default_expense_name, default_category, default_subcategory, default_payment_method) FROM stdin;
1	1	Wolt	Flexible Expenses	Food	credit
2	2	Wolt	Flexible Expenses	Food	credit
3	3	Wolt	Flexible Expenses	Food	credit
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, email, password_hash, created_at, failed_login_attempts, locked_until, recurring_lookahead_days, default_currency) FROM stdin;
2	big-boss@bloom-tracker.app	scrypt:32768:8:1$rMuIqMrQKzV7RHjD$61d89186211c4125f5157f52013d9077d6d0c8711de2036fb01e48d9d8b367c63ee2d9d8ed92d9d149819526e0cc97c879237c3dac1d7ccc8ab535075e24992a	2025-12-05 22:12:33.602733	0	\N	14	EUR
3	psarakismichail@gmail.com	scrypt:32768:8:1$k9ddNY6qoqP6pvQF$2473df38dc19c5554b6c1e5e37bb86f3211579fb7777ffd799d748e431e5f1c7f88387309348f5b51e917d6bdd44cec57d1f2bd8d4e9c0b15d0df9d54e7bfcbf	2025-12-23 15:51:20.404149	0	\N	14	EUR
1	saiyuriye.rafia@gmail.com	scrypt:32768:8:1$NTBL2jq9wdswJ317$a866f96e54aca726260d216f04bafb477ea426ef8b0e70d692ebf7cf7845861bffea341bc39be6659d6e06e7ec33768e519f3f35ba523f62a5df1bb625f9a905	2025-12-04 16:05:51.698396	0	\N	30	EUR
\.


--
-- Name: budget_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.budget_periods_id_seq', 12, true);


--
-- Name: credit_card_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.credit_card_settings_id_seq', 3, true);


--
-- Name: debts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.debts_id_seq', 6, true);


--
-- Name: exchange_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.exchange_rates_id_seq', 599, true);


--
-- Name: expense_name_mappings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.expense_name_mappings_id_seq', 1, false);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.expenses_id_seq', 176, true);


--
-- Name: goals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.goals_id_seq', 4, true);


--
-- Name: income_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.income_id_seq', 7, true);


--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.password_reset_tokens_id_seq', 1, false);


--
-- Name: period_suggestions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.period_suggestions_id_seq', 1, false);


--
-- Name: rate_limits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.rate_limits_id_seq', 1, false);


--
-- Name: recurring_expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.recurring_expenses_id_seq', 22, true);


--
-- Name: salary_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.salary_periods_id_seq', 3, true);


--
-- Name: subcategories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.subcategories_id_seq', 23, true);


--
-- Name: user_defaults_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.user_defaults_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: budget_periods budget_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.budget_periods
    ADD CONSTRAINT budget_periods_pkey PRIMARY KEY (id);


--
-- Name: credit_card_settings credit_card_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_card_settings
    ADD CONSTRAINT credit_card_settings_pkey PRIMARY KEY (id);


--
-- Name: credit_card_settings credit_card_settings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_card_settings
    ADD CONSTRAINT credit_card_settings_user_id_key UNIQUE (user_id);


--
-- Name: debts debts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_pkey PRIMARY KEY (id);


--
-- Name: exchange_rates exchange_rates_base_currency_target_currency_rate_date_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_base_currency_target_currency_rate_date_key UNIQUE (base_currency, target_currency, rate_date);


--
-- Name: exchange_rates exchange_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_pkey PRIMARY KEY (id);


--
-- Name: expense_name_mappings expense_name_mappings_expense_name_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expense_name_mappings
    ADD CONSTRAINT expense_name_mappings_expense_name_key UNIQUE (expense_name);


--
-- Name: expense_name_mappings expense_name_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expense_name_mappings
    ADD CONSTRAINT expense_name_mappings_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id);


--
-- Name: income income_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_key UNIQUE (token);


--
-- Name: period_suggestions period_suggestions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.period_suggestions
    ADD CONSTRAINT period_suggestions_pkey PRIMARY KEY (id);


--
-- Name: rate_limits rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_pkey PRIMARY KEY (id);


--
-- Name: recurring_expenses recurring_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_expenses
    ADD CONSTRAINT recurring_expenses_pkey PRIMARY KEY (id);


--
-- Name: salary_periods salary_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.salary_periods
    ADD CONSTRAINT salary_periods_pkey PRIMARY KEY (id);


--
-- Name: subcategories subcategories_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT subcategories_pkey PRIMARY KEY (id);


--
-- Name: subcategories uq_subcategory_user_category_name; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT uq_subcategory_user_category_name UNIQUE (user_id, category, name);


--
-- Name: user_defaults user_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_defaults
    ADD CONSTRAINT user_defaults_pkey PRIMARY KEY (id);


--
-- Name: user_defaults user_defaults_user_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_defaults
    ADD CONSTRAINT user_defaults_user_id_key UNIQUE (user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_budget_period_active; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_budget_period_active ON public.budget_periods USING btree (user_id, start_date, end_date);


--
-- Name: idx_debts_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_debts_deleted_at ON public.debts USING btree (deleted_at);


--
-- Name: idx_exchange_rate_lookup; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_exchange_rate_lookup ON public.exchange_rates USING btree (base_currency, target_currency, rate_date);


--
-- Name: idx_expenses_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_expenses_deleted_at ON public.expenses USING btree (deleted_at);


--
-- Name: idx_goal_user_active; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_goal_user_active ON public.goals USING btree (user_id, is_active);


--
-- Name: idx_goal_user_subcategory; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_goal_user_subcategory ON public.goals USING btree (user_id, subcategory_name);


--
-- Name: idx_goals_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_goals_deleted_at ON public.goals USING btree (deleted_at);


--
-- Name: idx_income_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_income_deleted_at ON public.income USING btree (deleted_at);


--
-- Name: idx_recurring_expenses_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_recurring_expenses_deleted_at ON public.recurring_expenses USING btree (deleted_at);


--
-- Name: ix_budget_periods_end_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_budget_periods_end_date ON public.budget_periods USING btree (end_date);


--
-- Name: ix_budget_periods_start_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_budget_periods_start_date ON public.budget_periods USING btree (start_date);


--
-- Name: ix_budget_periods_user_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_budget_periods_user_id ON public.budget_periods USING btree (user_id);


--
-- Name: ix_exchange_rates_base_currency; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_exchange_rates_base_currency ON public.exchange_rates USING btree (base_currency);


--
-- Name: ix_exchange_rates_rate_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_exchange_rates_rate_date ON public.exchange_rates USING btree (rate_date);


--
-- Name: ix_exchange_rates_target_currency; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_exchange_rates_target_currency ON public.exchange_rates USING btree (target_currency);


--
-- Name: ix_rate_limits_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_rate_limits_key ON public.rate_limits USING btree (key);


--
-- Name: ix_rate_limits_timestamp; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_rate_limits_timestamp ON public.rate_limits USING btree ("timestamp");


--
-- Name: ix_subcategories_category; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_subcategories_category ON public.subcategories USING btree (category);


--
-- Name: ix_subcategories_user_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_subcategories_user_id ON public.subcategories USING btree (user_id);


--
-- Name: uq_expense_recurring_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX uq_expense_recurring_date ON public.expenses USING btree (user_id, recurring_template_id, date) WHERE (recurring_template_id IS NOT NULL);


--
-- Name: uq_income_initial_balance_per_user; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX uq_income_initial_balance_per_user ON public.income USING btree (user_id) WHERE ((type)::text = 'Initial Balance'::text);


--
-- Name: budget_periods budget_periods_salary_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.budget_periods
    ADD CONSTRAINT budget_periods_salary_period_id_fkey FOREIGN KEY (salary_period_id) REFERENCES public.salary_periods(id);


--
-- Name: budget_periods budget_periods_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.budget_periods
    ADD CONSTRAINT budget_periods_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: credit_card_settings credit_card_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_card_settings
    ADD CONSTRAINT credit_card_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: debts debts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: expenses expenses_budget_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_budget_period_id_fkey FOREIGN KEY (budget_period_id) REFERENCES public.budget_periods(id);


--
-- Name: expenses expenses_recurring_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_recurring_template_id_fkey FOREIGN KEY (recurring_template_id) REFERENCES public.recurring_expenses(id);


--
-- Name: expenses expenses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: goals fk_goal_user; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT fk_goal_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subcategories fk_subcategory_user; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT fk_subcategory_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: goals goals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: income income_budget_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_budget_period_id_fkey FOREIGN KEY (budget_period_id) REFERENCES public.budget_periods(id);


--
-- Name: income income_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: period_suggestions period_suggestions_budget_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.period_suggestions
    ADD CONSTRAINT period_suggestions_budget_period_id_fkey FOREIGN KEY (budget_period_id) REFERENCES public.budget_periods(id);


--
-- Name: period_suggestions period_suggestions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.period_suggestions
    ADD CONSTRAINT period_suggestions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: recurring_expenses recurring_expenses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_expenses
    ADD CONSTRAINT recurring_expenses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: salary_periods salary_periods_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.salary_periods
    ADD CONSTRAINT salary_periods_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: subcategories subcategories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT subcategories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_defaults user_defaults_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_defaults
    ADD CONSTRAINT user_defaults_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

\unrestrict lvZZOXdpz0B0iXiqBxtbYFXCzhBeDagDdZOwZLfzQzt0BhrzuTb03SnEEilVi3r

