--
-- PostgreSQL database dump
--

\restrict Nz5z3cEZme5q1qnNKL6O9bkShgdS1Bbxb9oVeWLDAGunVzM9bd7jQykwEXpcWu3

-- Dumped from database version 17.7 (e429a59)
-- Dumped by pg_dump version 17.7 (Ubuntu 17.7-3.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO neondb_owner;

--
-- Name: budget_periods; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.budget_periods (
    id integer NOT NULL,
    user_id integer NOT NULL,
    salary_period_id integer,
    week_number integer,
    budget_amount integer,
    start_date date NOT NULL,
    end_date date NOT NULL,
    period_type character varying(50) NOT NULL,
    created_at timestamp without time zone,
    CONSTRAINT check_budget_period_date_order CHECK ((start_date <= end_date)),
    CONSTRAINT check_budget_period_date_range CHECK ((start_date <= end_date)),
    CONSTRAINT check_budget_period_week_number CHECK (((week_number IS NULL) OR (week_number >= 1)))
);


ALTER TABLE public.budget_periods OWNER TO neondb_owner;

--
-- Name: budget_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.budget_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_periods_id_seq OWNER TO neondb_owner;

--
-- Name: budget_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.budget_periods_id_seq OWNED BY public.budget_periods.id;


--
-- Name: credit_card_settings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.credit_card_settings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    credit_limit integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.credit_card_settings OWNER TO neondb_owner;

--
-- Name: credit_card_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.credit_card_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.credit_card_settings_id_seq OWNER TO neondb_owner;

--
-- Name: credit_card_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.credit_card_settings_id_seq OWNED BY public.credit_card_settings.id;


--
-- Name: debts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.debts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(200) NOT NULL,
    original_amount integer NOT NULL,
    current_balance integer NOT NULL,
    monthly_payment integer NOT NULL,
    archived boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    CONSTRAINT check_debt_positive_current CHECK ((current_balance >= 0)),
    CONSTRAINT check_debt_positive_original CHECK ((original_amount > 0)),
    CONSTRAINT check_debt_positive_payment CHECK ((monthly_payment > 0))
);


ALTER TABLE public.debts OWNER TO neondb_owner;

--
-- Name: debts_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.debts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.debts_id_seq OWNER TO neondb_owner;

--
-- Name: debts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.debts_id_seq OWNED BY public.debts.id;


--
-- Name: exchange_rates; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.exchange_rates (
    id integer NOT NULL,
    base_currency character varying(3) NOT NULL,
    target_currency character varying(3) NOT NULL,
    rate double precision NOT NULL,
    rate_date date NOT NULL,
    fetched_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT exchange_rates_rate_check CHECK ((rate > (0)::double precision))
);


ALTER TABLE public.exchange_rates OWNER TO neondb_owner;

--
-- Name: exchange_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.exchange_rates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.exchange_rates_id_seq OWNER TO neondb_owner;

--
-- Name: exchange_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.exchange_rates_id_seq OWNED BY public.exchange_rates.id;


--
-- Name: expense_name_mappings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.expense_name_mappings (
    id integer NOT NULL,
    expense_name character varying(200) NOT NULL,
    subcategory character varying(100) NOT NULL,
    confidence double precision,
    last_updated timestamp without time zone
);


ALTER TABLE public.expense_name_mappings OWNER TO neondb_owner;

--
-- Name: expense_name_mappings_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.expense_name_mappings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expense_name_mappings_id_seq OWNER TO neondb_owner;

--
-- Name: expense_name_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.expense_name_mappings_id_seq OWNED BY public.expense_name_mappings.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    user_id integer NOT NULL,
    budget_period_id integer,
    recurring_template_id integer,
    name character varying(200) NOT NULL,
    amount integer NOT NULL,
    category character varying(100) NOT NULL,
    subcategory character varying(100),
    date date NOT NULL,
    due_date character varying(50),
    payment_method character varying(20) NOT NULL,
    notes text,
    receipt_url character varying(500),
    is_fixed_bill boolean NOT NULL,
    created_at timestamp without time zone,
    currency character varying(3) DEFAULT 'EUR'::character varying NOT NULL,
    original_amount integer,
    exchange_rate_used double precision,
    deleted_at timestamp without time zone,
    updated_at timestamp without time zone,
    CONSTRAINT check_expense_positive_amount CHECK ((amount > 0))
);


ALTER TABLE public.expenses OWNER TO neondb_owner;

--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expenses_id_seq OWNER TO neondb_owner;

--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: goals; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.goals (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    target_amount integer NOT NULL,
    target_date date,
    subcategory_name character varying(100) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    initial_amount integer DEFAULT 0 NOT NULL,
    deleted_at timestamp without time zone,
    CONSTRAINT check_goal_positive_amount CHECK ((target_amount > 0))
);


ALTER TABLE public.goals OWNER TO neondb_owner;

--
-- Name: goals_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.goals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.goals_id_seq OWNER TO neondb_owner;

--
-- Name: goals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.goals_id_seq OWNED BY public.goals.id;


--
-- Name: income; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.income (
    id integer NOT NULL,
    user_id integer NOT NULL,
    budget_period_id integer,
    type character varying(50) NOT NULL,
    amount integer NOT NULL,
    scheduled_date date,
    actual_date date,
    created_at timestamp without time zone,
    currency character varying(3) DEFAULT 'EUR'::character varying NOT NULL,
    original_amount integer,
    exchange_rate_used double precision,
    deleted_at timestamp without time zone,
    updated_at timestamp without time zone,
    recurring_income_id integer,
    CONSTRAINT check_income_positive_amount CHECK ((amount > 0))
);


ALTER TABLE public.income OWNER TO neondb_owner;

--
-- Name: income_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.income_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.income_id_seq OWNER TO neondb_owner;

--
-- Name: income_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.income_id_seq OWNED BY public.income.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.password_reset_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    is_used boolean NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO neondb_owner;

--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.password_reset_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.password_reset_tokens_id_seq OWNER TO neondb_owner;

--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.password_reset_tokens_id_seq OWNED BY public.password_reset_tokens.id;


--
-- Name: period_suggestions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.period_suggestions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    budget_period_id integer NOT NULL,
    suggestion_type character varying(100) NOT NULL,
    amount integer NOT NULL,
    status character varying(20),
    created_at timestamp without time zone
);


ALTER TABLE public.period_suggestions OWNER TO neondb_owner;

--
-- Name: period_suggestions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.period_suggestions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.period_suggestions_id_seq OWNER TO neondb_owner;

--
-- Name: period_suggestions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.period_suggestions_id_seq OWNED BY public.period_suggestions.id;


--
-- Name: rate_limits; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.rate_limits (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    "timestamp" timestamp without time zone
);


ALTER TABLE public.rate_limits OWNER TO neondb_owner;

--
-- Name: rate_limits_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.rate_limits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rate_limits_id_seq OWNER TO neondb_owner;

--
-- Name: rate_limits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.rate_limits_id_seq OWNED BY public.rate_limits.id;


--
-- Name: recurring_expenses; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.recurring_expenses (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(200) NOT NULL,
    amount integer NOT NULL,
    category character varying(100) NOT NULL,
    subcategory character varying(100),
    payment_method character varying(20) NOT NULL,
    frequency character varying(20) NOT NULL,
    frequency_value integer,
    day_of_month integer,
    day_of_week integer,
    start_date date NOT NULL,
    end_date date,
    next_due_date date NOT NULL,
    is_active boolean NOT NULL,
    is_fixed_bill boolean NOT NULL,
    notes text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    CONSTRAINT check_recurring_expense_date_range CHECK (((end_date IS NULL) OR (start_date <= end_date))),
    CONSTRAINT check_recurring_positive_amount CHECK ((amount > 0))
);


ALTER TABLE public.recurring_expenses OWNER TO neondb_owner;

--
-- Name: recurring_expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.recurring_expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recurring_expenses_id_seq OWNER TO neondb_owner;

--
-- Name: recurring_expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.recurring_expenses_id_seq OWNED BY public.recurring_expenses.id;


--
-- Name: recurring_income; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.recurring_income (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(200) NOT NULL,
    amount integer NOT NULL,
    income_type character varying(50) DEFAULT 'Salary'::character varying NOT NULL,
    currency character varying(3) DEFAULT 'EUR'::character varying NOT NULL,
    frequency character varying(20) NOT NULL,
    frequency_value integer,
    day_of_month integer,
    day_of_week integer,
    start_date date NOT NULL,
    end_date date,
    next_due_date date NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    deleted_at timestamp without time zone,
    CONSTRAINT check_recurring_income_date_range CHECK (((end_date IS NULL) OR (start_date <= end_date))),
    CONSTRAINT check_recurring_income_day_of_month CHECK (((day_of_month IS NULL) OR ((day_of_month >= 1) AND (day_of_month <= 31)))),
    CONSTRAINT check_recurring_income_day_of_week CHECK (((day_of_week IS NULL) OR ((day_of_week >= 0) AND (day_of_week <= 6)))),
    CONSTRAINT check_recurring_income_frequency_value CHECK (((frequency_value IS NULL) OR (frequency_value > 0))),
    CONSTRAINT check_recurring_income_positive_amount CHECK ((amount > 0))
);


ALTER TABLE public.recurring_income OWNER TO neondb_owner;

--
-- Name: recurring_income_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.recurring_income_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recurring_income_id_seq OWNER TO neondb_owner;

--
-- Name: recurring_income_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.recurring_income_id_seq OWNED BY public.recurring_income.id;


--
-- Name: salary_periods; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.salary_periods (
    id integer NOT NULL,
    user_id integer NOT NULL,
    initial_debit_balance integer NOT NULL,
    initial_credit_balance integer NOT NULL,
    credit_limit integer NOT NULL,
    credit_budget_allowance integer NOT NULL,
    salary_amount integer,
    total_budget_amount integer NOT NULL,
    fixed_bills_total integer NOT NULL,
    remaining_amount integer NOT NULL,
    weekly_budget integer NOT NULL,
    weekly_debit_budget integer NOT NULL,
    weekly_credit_budget integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    num_sub_periods integer DEFAULT 4 NOT NULL,
    CONSTRAINT check_salary_period_date_order CHECK ((start_date <= end_date)),
    CONSTRAINT check_salary_period_positive_credit_limit CHECK ((credit_limit >= 0))
);


ALTER TABLE public.salary_periods OWNER TO neondb_owner;

--
-- Name: salary_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.salary_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.salary_periods_id_seq OWNER TO neondb_owner;

--
-- Name: salary_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.salary_periods_id_seq OWNED BY public.salary_periods.id;


--
-- Name: subcategories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.subcategories (
    id integer NOT NULL,
    user_id integer,
    category character varying(100) NOT NULL,
    name character varying(100) NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.subcategories OWNER TO neondb_owner;

--
-- Name: subcategories_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.subcategories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subcategories_id_seq OWNER TO neondb_owner;

--
-- Name: subcategories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.subcategories_id_seq OWNED BY public.subcategories.id;


--
-- Name: user_defaults; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.user_defaults (
    id integer NOT NULL,
    user_id integer NOT NULL,
    default_expense_name character varying(200),
    default_category character varying(100),
    default_subcategory character varying(100),
    default_payment_method character varying(20)
);


ALTER TABLE public.user_defaults OWNER TO neondb_owner;

--
-- Name: user_defaults_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.user_defaults_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_defaults_id_seq OWNER TO neondb_owner;

--
-- Name: user_defaults_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.user_defaults_id_seq OWNED BY public.user_defaults.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone,
    failed_login_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp without time zone,
    recurring_lookahead_days integer DEFAULT 14 NOT NULL,
    default_currency character varying(3) DEFAULT 'EUR'::character varying NOT NULL,
    balance_start_date date,
    user_initial_debit_balance integer DEFAULT 0 NOT NULL,
    user_initial_credit_limit integer DEFAULT 0 NOT NULL,
    balance_mode character varying(20) DEFAULT 'sync'::character varying NOT NULL,
    user_initial_credit_available integer DEFAULT 0 NOT NULL,
    payment_date_adjustment character varying(20) DEFAULT 'exact_date'::character varying NOT NULL,
    CONSTRAINT check_user_balance_mode_valid CHECK (((balance_mode)::text = ANY ((ARRAY['sync'::character varying, 'budget'::character varying])::text[]))),
    CONSTRAINT check_user_failed_attempts CHECK ((failed_login_attempts >= 0)),
    CONSTRAINT check_user_lookahead_range CHECK (((recurring_lookahead_days >= 7) AND (recurring_lookahead_days <= 90))),
    CONSTRAINT check_user_payment_date_adjustment_valid CHECK (((payment_date_adjustment)::text = ANY ((ARRAY['exact_date'::character varying, 'previous_workday'::character varying, 'next_workday'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: budget_periods id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.budget_periods ALTER COLUMN id SET DEFAULT nextval('public.budget_periods_id_seq'::regclass);


--
-- Name: credit_card_settings id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_card_settings ALTER COLUMN id SET DEFAULT nextval('public.credit_card_settings_id_seq'::regclass);


--
-- Name: debts id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.debts ALTER COLUMN id SET DEFAULT nextval('public.debts_id_seq'::regclass);


--
-- Name: exchange_rates id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.exchange_rates ALTER COLUMN id SET DEFAULT nextval('public.exchange_rates_id_seq'::regclass);


--
-- Name: expense_name_mappings id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expense_name_mappings ALTER COLUMN id SET DEFAULT nextval('public.expense_name_mappings_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: goals id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.goals ALTER COLUMN id SET DEFAULT nextval('public.goals_id_seq'::regclass);


--
-- Name: income id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income ALTER COLUMN id SET DEFAULT nextval('public.income_id_seq'::regclass);


--
-- Name: password_reset_tokens id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens ALTER COLUMN id SET DEFAULT nextval('public.password_reset_tokens_id_seq'::regclass);


--
-- Name: period_suggestions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.period_suggestions ALTER COLUMN id SET DEFAULT nextval('public.period_suggestions_id_seq'::regclass);


--
-- Name: rate_limits id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.rate_limits ALTER COLUMN id SET DEFAULT nextval('public.rate_limits_id_seq'::regclass);


--
-- Name: recurring_expenses id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_expenses ALTER COLUMN id SET DEFAULT nextval('public.recurring_expenses_id_seq'::regclass);


--
-- Name: recurring_income id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_income ALTER COLUMN id SET DEFAULT nextval('public.recurring_income_id_seq'::regclass);


--
-- Name: salary_periods id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.salary_periods ALTER COLUMN id SET DEFAULT nextval('public.salary_periods_id_seq'::regclass);


--
-- Name: subcategories id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories ALTER COLUMN id SET DEFAULT nextval('public.subcategories_id_seq'::regclass);


--
-- Name: user_defaults id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_defaults ALTER COLUMN id SET DEFAULT nextval('public.user_defaults_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.alembic_version (version_num) FROM stdin;
34eed8893f3a
\.


--
-- Data for Name: budget_periods; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.budget_periods (id, user_id, salary_period_id, week_number, budget_amount, start_date, end_date, period_type, created_at) FROM stdin;
1	1	1	1	18365	2025-11-20	2025-11-26	weekly	2025-12-04 16:06:13.903987
2	1	1	2	18365	2025-11-27	2025-12-03	weekly	2025-12-04 16:06:13.903989
3	1	1	3	18365	2025-12-04	2025-12-10	weekly	2025-12-04 16:06:13.90399
4	1	1	4	18365	2025-12-11	2025-12-19	weekly	2025-12-04 16:06:13.90399
5	1	2	1	20743	2025-12-20	2025-12-26	weekly	2025-12-17 10:14:43.949622
9	3	3	1	50000	2025-12-23	2025-12-29	weekly	2025-12-23 16:45:25.74918
10	3	3	2	50000	2025-12-30	2026-01-05	weekly	2025-12-23 16:45:25.749183
11	3	3	3	50000	2026-01-06	2026-01-12	weekly	2025-12-23 16:45:25.749184
12	3	3	4	50000	2026-01-13	2026-01-22	weekly	2025-12-23 16:45:25.749184
6	1	2	2	17389	2025-12-27	2026-01-02	weekly	2025-12-17 10:14:43.949624
7	1	2	3	17389	2026-01-03	2026-01-09	weekly	2025-12-17 10:14:43.949625
8	1	2	4	17389	2026-01-10	2026-01-19	weekly	2025-12-17 10:14:43.949625
\.


--
-- Data for Name: credit_card_settings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.credit_card_settings (id, user_id, credit_limit, created_at, updated_at) FROM stdin;
1	1	150000	2025-12-04 16:05:51.79458	2025-12-04 16:05:51.794584
2	2	150000	2025-12-05 22:12:33.70062	2025-12-05 22:12:33.700624
3	3	150000	2025-12-23 15:51:20.432803	2025-12-23 15:51:20.432808
\.


--
-- Data for Name: debts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.debts (id, user_id, name, original_amount, current_balance, monthly_payment, archived, created_at, updated_at, deleted_at) FROM stdin;
1	1	Klarna Turkish Airlines Old	205855	33645	10080	f	2025-12-04 16:06:13.692827	2026-01-19 18:34:06.502664	\N
3	1	Klarna Turkish Airlines Business	54422	43943	10479	f	2025-12-04 16:06:13.707428	2026-01-19 18:34:17.39287	\N
5	1	Elisa (Phone)	84840	63630	3535	f	2025-12-04 16:06:13.718028	2026-01-19 18:34:21.789283	\N
4	1	Klarna Gigantti	63773	53127	5323	f	2025-12-04 16:06:13.712809	2026-01-19 18:34:24.47247	\N
6	1	Telia Rahoitus	100000	75455	4546	f	2025-12-04 16:06:13.723429	2026-01-19 18:34:26.768981	\N
2	1	Klarna Turkish Airlines New	117469	76305	10291	f	2025-12-04 16:06:13.701772	2026-01-19 18:34:31.090823	\N
\.


--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.exchange_rates (id, base_currency, target_currency, rate, rate_date, fetched_at) FROM stdin;
232	BDT	AED	0.030051	2025-12-25	2025-12-25 14:48:04.663885
233	BDT	AFN	0.538188	2025-12-25	2025-12-25 14:48:05.374567
10	EUR	AWG	2.109255	2025-12-25	2025-12-25 14:00:47.26393
234	BDT	ALL	0.669419	2025-12-25	2025-12-25 14:48:05.97569
235	BDT	AMD	3.12223	2025-12-25	2025-12-25 14:48:06.464829
14	EUR	BBD	2.35671	2025-12-25	2025-12-25 14:00:50.964889
236	BDT	ANG	0.014647	2025-12-25	2025-12-25 14:48:06.782005
237	BDT	AOA	7.66021	2025-12-25	2025-12-25 14:48:07.276226
15	EUR	BDT	144.026155	2025-12-25	2025-12-25 14:00:52.265055
238	BDT	ARS	11.88323	2025-12-25	2025-12-25 14:48:07.878169
239	BDT	AUD	0.012204	2025-12-25	2025-12-25 14:48:08.474699
16	EUR	BGN	1.95583	2025-12-25	2025-12-25 14:00:53.664051
240	BDT	AWG	0.014647	2025-12-25	2025-12-25 14:48:08.964049
241	BDT	AZN	0.013917	2025-12-25	2025-12-25 14:48:09.381616
242	BDT	BAM	0.01358	2025-12-25	2025-12-25 14:48:09.963287
243	BDT	BBD	0.016365	2025-12-25	2025-12-25 14:48:10.377981
244	BDT	BGN	0.01358	2025-12-25	2025-12-25 14:48:10.763726
245	BDT	BHD	0.003077	2025-12-25	2025-12-25 14:48:10.983178
246	BDT	BIF	24.206115	2025-12-25	2025-12-25 14:48:11.364216
247	BDT	BMD	0.008183	2025-12-25	2025-12-25 14:48:11.679973
248	BDT	BND	0.010505	2025-12-25	2025-12-25 14:48:11.987781
249	BDT	BOB	0.056693	2025-12-25	2025-12-25 14:48:12.280273
250	BDT	BRL	0.045173	2025-12-25	2025-12-25 14:48:12.564442
251	BDT	BSD	0.008183	2025-12-25	2025-12-25 14:48:12.862953
252	BDT	BTN	0.733957	2025-12-25	2025-12-25 14:48:13.179484
253	BDT	BWP	0.111417	2025-12-25	2025-12-25 14:48:13.473548
254	BDT	BYN	0.023776	2025-12-25	2025-12-25 14:48:13.775082
255	BDT	BZD	0.016365	2025-12-25	2025-12-25 14:48:14.062902
256	BDT	CAD	0.011189	2025-12-25	2025-12-25 14:48:14.284857
257	BDT	CDF	18.636023	2025-12-25	2025-12-25 14:48:14.58798
258	BDT	CHF	0.006446	2025-12-25	2025-12-25 14:48:14.864486
259	BDT	CLF	0.000188	2025-12-25	2025-12-25 14:48:15.177006
260	BDT	CLP	7.431352	2025-12-25	2025-12-25 14:48:15.478888
261	BDT	CNH	0.057365	2025-12-25	2025-12-25 14:48:15.76291
262	BDT	CNY	0.057484	2025-12-25	2025-12-25 14:48:15.988099
263	BDT	COP	30.853449	2025-12-25	2025-12-25 14:48:16.290361
264	BDT	CRC	4.073267	2025-12-25	2025-12-25 14:48:16.581774
265	BDT	CUP	0.196383	2025-12-25	2025-12-25 14:48:16.789983
266	BDT	CVE	0.76559	2025-12-25	2025-12-25 14:48:17.163101
267	BDT	CZK	0.168565	2025-12-25	2025-12-25 14:48:17.383795
268	BDT	DJF	1.454226	2025-12-25	2025-12-25 14:48:17.686084
269	BDT	DKK	0.051799	2025-12-25	2025-12-25 14:48:17.882705
270	BDT	DOP	0.512705	2025-12-25	2025-12-25 14:48:18.184007
271	BDT	DZD	1.060646	2025-12-25	2025-12-25 14:48:18.386673
272	BDT	EGP	0.388718	2025-12-25	2025-12-25 14:48:18.689111
273	BDT	ERN	0.12274	2025-12-25	2025-12-25 14:48:18.98164
274	BDT	ETB	1.274565	2025-12-25	2025-12-25 14:48:19.290395
275	BDT	EUR	0.006943	2025-12-25	2025-12-25 14:48:19.588041
276	BDT	FJD	0.018606	2025-12-25	2025-12-25 14:48:19.97904
277	BDT	FKP	0.006059	2025-12-25	2025-12-25 14:48:20.278606
278	BDT	FOK	0.051799	2025-12-25	2025-12-25 14:48:20.58393
279	BDT	GBP	0.006059	2025-12-25	2025-12-25 14:48:20.878458
280	BDT	GEL	0.02206	2025-12-25	2025-12-25 14:48:21.086672
281	BDT	GGP	0.006059	2025-12-25	2025-12-25 14:48:21.386127
282	BDT	GHS	0.092629	2025-12-25	2025-12-25 14:48:21.67882
283	BDT	GIP	0.006059	2025-12-25	2025-12-25 14:48:21.888193
284	BDT	GMD	0.607194	2025-12-25	2025-12-25 14:48:22.187128
285	BDT	GNF	71.492839	2025-12-25	2025-12-25 14:48:22.488463
286	BDT	GTQ	0.06271	2025-12-25	2025-12-25 14:48:22.793983
287	BDT	GYD	1.712091	2025-12-25	2025-12-25 14:48:23.175583
288	BDT	HKD	0.06362	2025-12-25	2025-12-25 14:48:23.484727
289	BDT	HNL	0.215792	2025-12-25	2025-12-25 14:48:23.776428
290	BDT	HRK	0.052313	2025-12-25	2025-12-25 14:48:23.983625
291	BDT	HTG	1.071565	2025-12-25	2025-12-25 14:48:24.293145
292	BDT	HUF	2.706089	2025-12-25	2025-12-25 14:48:24.585658
293	BDT	IDR	137.217669	2025-12-25	2025-12-25 14:48:24.792356
294	BDT	ILS	0.026047	2025-12-25	2025-12-25 14:48:25.176924
295	BDT	IMP	0.006059	2025-12-25	2025-12-25 14:48:25.462967
296	BDT	INR	0.733957	2025-12-25	2025-12-25 14:48:25.691203
297	BDT	IQD	10.719963	2025-12-25	2025-12-25 14:48:25.992432
298	BDT	IRR	351.99914	2025-12-25	2025-12-25 14:48:26.284093
299	BDT	ISK	1.027335	2025-12-25	2025-12-25 14:48:26.580273
300	BDT	JEP	0.006059	2025-12-25	2025-12-25 14:48:26.875412
301	BDT	JMD	1.307392	2025-12-25	2025-12-25 14:48:27.089827
302	BDT	JOD	0.005801	2025-12-25	2025-12-25 14:48:27.390705
303	BDT	JPY	1.275715	2025-12-25	2025-12-25 14:48:27.681673
304	BDT	KES	1.055364	2025-12-25	2025-12-25 14:48:27.981569
305	BDT	KGS	0.715882	2025-12-25	2025-12-25 14:48:28.280634
306	BDT	KHR	32.840386	2025-12-25	2025-12-25 14:48:28.579849
307	BDT	KID	0.012204	2025-12-25	2025-12-25 14:48:28.887979
308	BDT	KMF	3.415822	2025-12-25	2025-12-25 14:48:29.173876
309	BDT	KRW	11.845218	2025-12-25	2025-12-25 14:48:29.463149
310	BDT	KWD	0.002499	2025-12-25	2025-12-25 14:48:29.764195
311	BDT	KYD	0.006819	2025-12-25	2025-12-25 14:48:29.989568
312	BDT	KZT	4.175405	2025-12-25	2025-12-25 14:48:30.262415
313	BDT	LAK	177.479347	2025-12-25	2025-12-25 14:48:30.483264
314	BDT	LBP	732.345753	2025-12-25	2025-12-25 14:48:31.073947
315	BDT	LKR	2.533017	2025-12-25	2025-12-25 14:48:31.777271
316	BDT	LRD	1.451775	2025-12-25	2025-12-25 14:48:32.664154
317	BDT	LSL	0.136367	2025-12-25	2025-12-25 14:48:33.462698
391	BDT	ZAR	0.136367	2025-12-25	2025-12-25 14:48:59.76412
392	BDT	ZMW	0.184122	2025-12-25	2025-12-25 14:49:00.262663
393	BDT	ZWL	0.212966	2025-12-25	2025-12-25 14:49:00.581205
394	EUR	AED	4.327508	2025-12-26	2025-12-26 00:52:37.835689
395	EUR	AFN	77.434793	2025-12-26	2025-12-26 00:52:38.137134
396	EUR	ALL	96.421234	2025-12-26	2025-12-26 00:52:38.536002
397	EUR	AMD	449.869768	2025-12-26	2025-12-26 00:52:38.920033
398	EUR	ANG	2.109255	2025-12-26	2025-12-26 00:52:39.533525
399	EUR	AOA	1108.346135	2025-12-26	2025-12-26 00:52:39.927923
400	EUR	ARS	1711.265744	2025-12-26	2025-12-26 00:52:40.319071
401	EUR	AUD	1.757653	2025-12-26	2025-12-26 00:52:40.828556
402	EUR	AWG	2.109255	2025-12-26	2025-12-26 00:52:41.03841
403	EUR	AZN	2.005254	2025-12-26	2025-12-26 00:52:41.242239
404	EUR	BAM	1.95583	2025-12-26	2025-12-26 00:52:41.520622
405	EUR	BBD	2.35671	2025-12-26	2025-12-26 00:52:41.739648
406	EUR	BDT	144.026155	2025-12-26	2025-12-26 00:52:42.036509
407	EUR	BGN	1.95583	2025-12-26	2025-12-26 00:52:42.242011
408	EUR	BHD	0.443061	2025-12-26	2025-12-26 00:52:42.532369
409	EUR	BIF	3499.394018	2025-12-26	2025-12-26 00:52:42.738579
410	EUR	BMD	1.178355	2025-12-26	2025-12-26 00:52:42.941744
411	EUR	BND	1.512756	2025-12-26	2025-12-26 00:52:43.143013
412	EUR	BOB	8.166893	2025-12-26	2025-12-26 00:52:43.435646
413	EUR	BRL	6.506005	2025-12-26	2025-12-26 00:52:43.63874
414	EUR	BSD	1.178355	2025-12-26	2025-12-26 00:52:43.937775
415	EUR	BTN	105.670888	2025-12-26	2025-12-26 00:52:44.140412
416	EUR	BWP	16.298807	2025-12-26	2025-12-26 00:52:44.343287
417	EUR	BYN	3.427656	2025-12-26	2025-12-26 00:52:44.539693
418	EUR	BZD	2.35671	2025-12-26	2025-12-26 00:52:44.740783
419	EUR	CAD	1.611689	2025-12-26	2025-12-26 00:52:45.036828
39	EUR	CZK	24.273338	2025-12-25	2025-12-25 14:01:21.265099
1	EUR	AED	4.327508	2025-12-25	2025-12-25 14:00:37.663632
65	EUR	HUF	389.227875	2025-12-25	2025-12-25 14:01:49.365006
3	EUR	AFN	77.434793	2025-12-25	2025-12-25 14:00:38.962435
40	EUR	DJF	209.418392	2025-12-25	2025-12-25 14:01:22.659798
4	EUR	ALL	96.421234	2025-12-25	2025-12-25 14:00:40.563029
5	EUR	AMD	449.869768	2025-12-25	2025-12-25 14:00:41.368354
41	EUR	DKK	7.461265	2025-12-25	2025-12-25 14:01:23.866539
6	EUR	ANG	2.109255	2025-12-25	2025-12-25 14:00:42.866322
318	BDT	LYD	0.044343	2025-12-25	2025-12-25 14:48:34.56457
42	EUR	DOP	73.957209	2025-12-25	2025-12-25 14:01:24.966777
7	EUR	AOA	1108.346135	2025-12-25	2025-12-25 14:00:44.363804
8	EUR	ARS	1711.265744	2025-12-25	2025-12-25 14:00:45.364136
43	EUR	DZD	152.823944	2025-12-25	2025-12-25 14:01:26.066524
9	EUR	AUD	1.757653	2025-12-25	2025-12-25 14:00:46.76436
66	EUR	IDR	19718.198961	2025-12-25	2025-12-25 14:01:50.565758
11	EUR	AZN	2.005254	2025-12-25	2025-12-25 14:00:48.264857
13	EUR	BAM	1.95583	2025-12-25	2025-12-25 14:00:49.564761
44	EUR	EGP	56.116859	2025-12-25	2025-12-25 14:01:27.765972
17	EUR	BHD	0.443061	2025-12-25	2025-12-25 14:00:54.764429
68	EUR	ILS	3.751828	2025-12-25	2025-12-25 14:01:51.365118
18	EUR	BIF	3499.394018	2025-12-25	2025-12-25 14:00:55.966388
45	EUR	ERN	17.675322	2025-12-25	2025-12-25 14:01:29.064496
19	EUR	BMD	1.178355	2025-12-25	2025-12-25 14:00:56.964917
70	EUR	IMP	0.872552	2025-12-25	2025-12-25 14:01:52.266334
20	EUR	BND	1.512756	2025-12-25	2025-12-25 14:00:58.563897
46	EUR	ETB	181.952086	2025-12-25	2025-12-25 14:01:30.06451
21	EUR	BOB	8.166893	2025-12-25	2025-12-25 14:00:59.065021
22	EUR	BRL	6.506005	2025-12-25	2025-12-25 14:01:00.360163
71	EUR	INR	105.671233	2025-12-25	2025-12-25 14:01:53.365128
47	EUR	FJD	2.679777	2025-12-25	2025-12-25 14:01:31.26775
23	EUR	BSD	1.178355	2025-12-25	2025-12-25 14:01:01.565125
24	EUR	BTN	105.670888	2025-12-25	2025-12-25 14:01:02.764742
81	EUR	KHR	4735.960526	2025-12-25	2025-12-25 14:02:05.067907
48	EUR	FKP	0.872552	2025-12-25	2025-12-25 14:01:32.564556
25	EUR	BWP	16.298807	2025-12-25	2025-12-25 14:01:03.96474
26	EUR	BYN	3.427656	2025-12-25	2025-12-25 14:01:05.264781
27	EUR	BZD	2.35671	2025-12-25	2025-12-25 14:01:06.564185
28	EUR	CAD	1.611689	2025-12-25	2025-12-25 14:01:07.967096
29	EUR	CDF	2686.067164	2025-12-25	2025-12-25 14:01:08.763636
30	EUR	CHF	0.928554	2025-12-25	2025-12-25 14:01:09.766506
72	EUR	IQD	1544.776824	2025-12-25	2025-12-25 14:01:54.465955
31	EUR	CLF	0.027101	2025-12-25	2025-12-25 14:01:11.366988
32	EUR	CLP	1071.185109	2025-12-25	2025-12-25 14:01:12.665736
49	EUR	FOK	7.461265	2025-12-25	2025-12-25 14:01:33.860301
33	EUR	CNH	8.259695	2025-12-25	2025-12-25 14:01:13.663921
34	EUR	CNY	8.27748	2025-12-25	2025-12-25 14:01:14.866058
103	EUR	MNT	4159.918972	2025-12-25	2025-12-25 14:02:23.764102
35	EUR	COP	4437.75716	2025-12-25	2025-12-25 14:01:16.364151
50	EUR	GBP	0.872552	2025-12-25	2025-12-25 14:01:35.065353
73	EUR	IRR	50055.669571	2025-12-25	2025-12-25 14:01:55.663785
36	EUR	CRC	587.930617	2025-12-25	2025-12-25 14:01:17.56315
51	EUR	GEL	3.179354	2025-12-25	2025-12-25 14:01:35.865316
37	EUR	CUP	28.280515	2025-12-25	2025-12-25 14:01:18.963609
52	EUR	GGP	0.872552	2025-12-25	2025-12-25 14:01:36.965869
38	EUR	CVE	110.265	2025-12-25	2025-12-25 14:01:20.664476
54	EUR	GHS	13.302211	2025-12-25	2025-12-25 14:01:38.263423
55	EUR	GIP	0.872552	2025-12-25	2025-12-25 14:01:38.964545
56	EUR	GMD	87.454612	2025-12-25	2025-12-25 14:01:40.866413
57	EUR	GNF	10295.45819	2025-12-25	2025-12-25 14:01:41.563699
58	EUR	GTQ	9.036739	2025-12-25	2025-12-25 14:01:42.66118
60	EUR	GYD	246.698424	2025-12-25	2025-12-25 14:01:43.764207
83	EUR	KID	1.757652	2025-12-25	2025-12-25 14:02:05.964072
61	EUR	HKD	9.161437	2025-12-25	2025-12-25 14:01:44.860306
62	EUR	HNL	31.097286	2025-12-25	2025-12-25 14:01:45.964701
74	EUR	ISK	148.015102	2025-12-25	2025-12-25 14:01:56.865677
63	EUR	HRK	7.5345	2025-12-25	2025-12-25 14:01:47.262535
98	EUR	MAD	10.745973	2025-12-25	2025-12-25 14:02:18.167937
64	EUR	HTG	154.411411	2025-12-25	2025-12-25 14:01:48.465102
84	EUR	KMF	491.96775	2025-12-25	2025-12-25 14:02:06.966129
85	EUR	KRW	1707.500739	2025-12-25	2025-12-25 14:02:07.660223
75	EUR	JEP	0.872552	2025-12-25	2025-12-25 14:01:58.264573
76	EUR	JMD	188.108472	2025-12-25	2025-12-25 14:01:59.26715
87	EUR	KWD	0.36144	2025-12-25	2025-12-25 14:02:08.964343
77	EUR	JOD	0.835454	2025-12-25	2025-12-25 14:02:00.464238
88	EUR	KYD	0.981962	2025-12-25	2025-12-25 14:02:09.774816
89	EUR	KZT	604.688772	2025-12-25	2025-12-25 14:02:10.766629
78	EUR	JPY	183.761551	2025-12-25	2025-12-25 14:02:01.559837
79	EUR	KES	152.084181	2025-12-25	2025-12-25 14:02:02.664555
91	EUR	LAK	25596.94192	2025-12-25	2025-12-25 14:02:12.064612
80	EUR	KGS	103.059665	2025-12-25	2025-12-25 14:02:03.762976
92	EUR	LBP	105462.753719	2025-12-25	2025-12-25 14:02:12.864716
93	EUR	LKR	364.95757	2025-12-25	2025-12-25 14:02:13.664966
94	EUR	LRD	209.399615	2025-12-25	2025-12-25 14:02:15.663207
95	EUR	LSL	19.626682	2025-12-25	2025-12-25 14:02:15.963336
97	EUR	LYD	6.38032	2025-12-25	2025-12-25 14:02:16.865448
99	EUR	MDL	19.814089	2025-12-25	2025-12-25 14:02:19.065989
110	EUR	MWK	2055.851882	2025-12-25	2025-12-25 14:02:28.164094
100	EUR	MGA	5307.255534	2025-12-25	2025-12-25 14:02:20.163873
104	EUR	MOP	9.437042	2025-12-25	2025-12-25 14:02:25.064061
101	EUR	MKD	61.4843	2025-12-25	2025-12-25 14:02:21.660231
102	EUR	MMK	2479.74508	2025-12-25	2025-12-25 14:02:22.865264
111	EUR	MXN	21.121538	2025-12-25	2025-12-25 14:02:28.96394
105	EUR	MRU	46.994777	2025-12-25	2025-12-25 14:02:26.364924
109	EUR	MVR	18.237276	2025-12-25	2025-12-25 14:02:27.274293
107	EUR	MUR	54.199771	2025-12-25	2025-12-25 14:02:27.365284
112	EUR	MYR	4.771733	2025-12-25	2025-12-25 14:02:29.764237
113	EUR	MZN	75.349015	2025-12-25	2025-12-25 14:02:31.264308
116	EUR	NGN	1707.140579	2025-12-25	2025-12-25 14:02:33.465819
115	EUR	NAD	19.626682	2025-12-25	2025-12-25 14:02:32.766362
117	EUR	NIO	43.404423	2025-12-25	2025-12-25 14:02:34.464009
119	EUR	NOK	11.791112	2025-12-25	2025-12-25 14:02:35.164829
120	EUR	NPR	169.073422	2025-12-25	2025-12-25 14:02:35.764956
121	EUR	NZD	2.018995	2025-12-25	2025-12-25 14:02:36.274832
122	EUR	OMR	0.453074	2025-12-25	2025-12-25 14:02:36.863554
123	EUR	PAB	1.178355	2025-12-25	2025-12-25 14:02:37.367402
124	EUR	PEN	3.965922	2025-12-25	2025-12-25 14:02:37.963539
126	EUR	PGK	5.094031	2025-12-25	2025-12-25 14:02:38.185927
127	EUR	PHP	69.242381	2025-12-25	2025-12-25 14:02:38.463986
128	EUR	PKR	330.39864	2025-12-25	2025-12-25 14:02:38.685347
129	EUR	PLN	4.214352	2025-12-25	2025-12-25 14:02:38.888412
130	EUR	PYG	7986.800269	2025-12-25	2025-12-25 14:02:39.179194
131	EUR	QAR	4.289211	2025-12-25	2025-12-25 14:02:39.384317
132	EUR	RON	5.090097	2025-12-25	2025-12-25 14:02:39.665169
133	EUR	RSD	117.36913	2025-12-25	2025-12-25 14:02:39.877329
134	EUR	RUB	92.841887	2025-12-25	2025-12-25 14:02:40.082791
135	EUR	RWF	1721.600633	2025-12-25	2025-12-25 14:02:40.364019
136	EUR	SAR	4.41883	2025-12-25	2025-12-25 14:02:40.585125
137	EUR	SBD	9.532682	2025-12-25	2025-12-25 14:02:40.875762
138	EUR	SCR	17.199192	2025-12-25	2025-12-25 14:02:41.085484
139	EUR	SDG	526.988287	2025-12-25	2025-12-25 14:02:41.382449
140	EUR	SEK	10.802992	2025-12-25	2025-12-25 14:02:41.591396
141	EUR	SGD	1.512756	2025-12-25	2025-12-25 14:02:41.889753
142	EUR	SHP	0.872552	2025-12-25	2025-12-25 14:02:42.179215
143	EUR	SLE	28.414724	2025-12-25	2025-12-25 14:02:42.48051
144	EUR	SOS	672.771963	2025-12-25	2025-12-25 14:02:42.790179
145	EUR	SRD	45.246135	2025-12-25	2025-12-25 14:02:43.08802
146	EUR	SSP	5566.917231	2025-12-25	2025-12-25 14:02:43.386334
147	EUR	STN	24.5	2025-12-25	2025-12-25 14:02:43.679741
148	EUR	SYP	12980.000305	2025-12-25	2025-12-25 14:02:43.884506
149	EUR	SZL	19.626682	2025-12-25	2025-12-25 14:02:44.186331
150	EUR	THB	36.62098	2025-12-25	2025-12-25 14:02:44.38846
151	EUR	TJS	10.892974	2025-12-25	2025-12-25 14:02:44.678934
152	EUR	TMT	4.127584	2025-12-25	2025-12-25 14:02:44.982901
153	EUR	TND	3.407744	2025-12-25	2025-12-25 14:02:45.27758
154	EUR	TOP	2.83195	2025-12-25	2025-12-25 14:02:45.484839
155	EUR	TRY	50.520792	2025-12-25	2025-12-25 14:02:45.774965
156	EUR	TTD	8.670925	2025-12-25	2025-12-25 14:02:45.9853
157	EUR	TVD	1.757652	2025-12-25	2025-12-25 14:02:46.185773
319	BDT	MAD	0.074642	2025-12-25	2025-12-25 14:48:35.566111
158	EUR	TWD	37.038321	2025-12-25	2025-12-25 14:10:44.390149
320	BDT	MDL	0.137559	2025-12-25	2025-12-25 14:48:36.075582
321	BDT	MGA	37.3122	2025-12-25	2025-12-25 14:48:36.382856
161	EUR	TZS	2898.306324	2025-12-25	2025-12-25 14:10:45.687145
322	BDT	MKD	0.427623	2025-12-25	2025-12-25 14:48:36.68124
323	BDT	MMK	17.205044	2025-12-25	2025-12-25 14:48:36.884177
165	EUR	UAH	49.625692	2025-12-25	2025-12-25 14:10:46.786241
324	BDT	MNT	28.91163	2025-12-25	2025-12-25 14:48:37.18578
325	BDT	MOP	0.065529	2025-12-25	2025-12-25 14:48:37.477071
169	EUR	UGX	4231.607935	2025-12-25	2025-12-25 14:10:47.789093
326	BDT	MRU	0.326326	2025-12-25	2025-12-25 14:48:37.764493
327	BDT	MUR	0.376576	2025-12-25	2025-12-25 14:48:37.987821
173	EUR	USD	1.178355	2025-12-25	2025-12-25 14:10:49.187211
328	BDT	MVR	0.12655	2025-12-25	2025-12-25 14:48:38.375502
329	BDT	MWK	14.249909	2025-12-25	2025-12-25 14:48:38.588551
177	EUR	UYU	46.067809	2025-12-25	2025-12-25 14:10:50.587387
330	BDT	MXN	0.146506	2025-12-25	2025-12-25 14:48:38.884256
180	EUR	UZS	14278.457713	2025-12-25	2025-12-25 14:10:50.988556
331	BDT	MYR	0.03313	2025-12-25	2025-12-25 14:48:39.090007
332	BDT	MZN	0.523055	2025-12-25	2025-12-25 14:48:39.463855
184	EUR	VES	342.936342	2025-12-25	2025-12-25 14:10:52.086561
333	BDT	NAD	0.136367	2025-12-25	2025-12-25 14:48:39.690585
334	BDT	NGN	11.891306	2025-12-25	2025-12-25 14:48:39.989283
188	EUR	VND	30876.727797	2025-12-25	2025-12-25 14:10:53.187519
335	BDT	NIO	0.301201	2025-12-25	2025-12-25 14:48:40.283318
336	BDT	NOK	0.081843	2025-12-25	2025-12-25 14:48:40.491187
192	EUR	VUV	142.491814	2025-12-25	2025-12-25 14:10:54.288378
337	BDT	NPR	1.174331	2025-12-25	2025-12-25 14:48:40.785362
338	BDT	NZD	0.01402	2025-12-25	2025-12-25 14:48:41.077246
196	EUR	WST	3.261647	2025-12-25	2025-12-25 14:10:55.686876
339	BDT	OMR	0.003146	2025-12-25	2025-12-25 14:48:41.286685
340	BDT	PAB	0.008183	2025-12-25	2025-12-25 14:48:41.563583
200	EUR	XAF	655.957	2025-12-25	2025-12-25 14:10:56.889456
203	EUR	XCD	3.181558	2025-12-25	2025-12-25 14:10:57.48638
341	BDT	PEN	0.027545	2025-12-25	2025-12-25 14:48:41.7869
342	BDT	PGK	0.035347	2025-12-25	2025-12-25 14:48:42.07994
206	EUR	XDR	0.85636	2025-12-25	2025-12-25 14:10:58.487889
343	BDT	PHP	0.480582	2025-12-25	2025-12-25 14:48:42.38138
344	BDT	PKR	2.294097	2025-12-25	2025-12-25 14:48:42.679177
210	EUR	XOF	655.957	2025-12-25	2025-12-25 14:10:59.787348
345	BDT	PLN	0.029269	2025-12-25	2025-12-25 14:48:42.98513
213	EUR	XPF	119.332	2025-12-25	2025-12-25 14:11:00.686539
346	BDT	PYG	55.485938	2025-12-25	2025-12-25 14:48:43.264351
217	EUR	YER	281.237368	2025-12-25	2025-12-25 14:11:01.387009
347	BDT	QAR	0.029785	2025-12-25	2025-12-25 14:48:43.577905
348	BDT	RON	0.03533	2025-12-25	2025-12-25 14:48:43.886386
220	EUR	ZAR	19.624667	2025-12-25	2025-12-25 14:11:02.18606
349	BDT	RSD	0.815368	2025-12-25	2025-12-25 14:48:44.188508
350	BDT	RUB	0.63927	2025-12-25	2025-12-25 14:48:44.488018
224	EUR	ZMW	26.520207	2025-12-25	2025-12-25 14:11:03.088139
351	BDT	RWF	11.932685	2025-12-25	2025-12-25 14:48:45.163716
352	BDT	SAR	0.030685	2025-12-25	2025-12-25 14:48:45.787716
228	EUR	ZWL	30.6958	2025-12-25	2025-12-25 14:11:04.08865
353	BDT	SBD	0.066296	2025-12-25	2025-12-25 14:48:46.081509
354	BDT	SCR	0.118299	2025-12-25	2025-12-25 14:48:46.378988
355	BDT	SDG	4.187704	2025-12-25	2025-12-25 14:48:46.681882
356	BDT	SEK	0.07499	2025-12-25	2025-12-25 14:48:46.974487
357	BDT	SGD	0.010505	2025-12-25	2025-12-25 14:48:47.275006
358	BDT	SHP	0.006059	2025-12-25	2025-12-25 14:48:47.577754
359	BDT	SLE	0.197564	2025-12-25	2025-12-25 14:48:47.873062
360	BDT	SOS	4.669046	2025-12-25	2025-12-25 14:48:48.163822
361	BDT	SRD	0.314576	2025-12-25	2025-12-25 14:48:48.488372
362	BDT	SSP	38.129934	2025-12-25	2025-12-25 14:48:48.789448
363	BDT	STN	0.170108	2025-12-25	2025-12-25 14:48:49.083785
364	BDT	SYP	90.190389	2025-12-25	2025-12-25 14:48:49.388088
365	BDT	SZL	0.136367	2025-12-25	2025-12-25 14:48:49.687312
366	BDT	THB	0.254203	2025-12-25	2025-12-25 14:48:50.075002
367	BDT	TJS	0.075568	2025-12-25	2025-12-25 14:48:50.373086
368	BDT	TMT	0.028648	2025-12-25	2025-12-25 14:48:50.679058
369	BDT	TND	0.023635	2025-12-25	2025-12-25 14:48:51.179716
370	BDT	TOP	0.019675	2025-12-25	2025-12-25 14:48:51.582302
371	BDT	TRY	0.350592	2025-12-25	2025-12-25 14:48:52.079689
372	BDT	TTD	0.05567	2025-12-25	2025-12-25 14:48:52.565136
373	BDT	TVD	0.012204	2025-12-25	2025-12-25 14:48:52.981837
374	BDT	TWD	0.257315	2025-12-25	2025-12-25 14:48:53.463697
375	BDT	TZS	20.268654	2025-12-25	2025-12-25 14:48:53.875707
376	BDT	UAH	0.3439	2025-12-25	2025-12-25 14:48:54.276935
377	BDT	UGX	29.507974	2025-12-25	2025-12-25 14:48:54.683243
378	BDT	USD	0.008183	2025-12-25	2025-12-25 14:48:55.074775
379	BDT	UYU	0.319729	2025-12-25	2025-12-25 14:48:55.285504
380	BDT	UZS	99.325623	2025-12-25	2025-12-25 14:48:55.582304
381	BDT	VES	2.38403	2025-12-25	2025-12-25 14:48:55.885582
382	BDT	VND	215.083175	2025-12-25	2025-12-25 14:48:56.264719
383	BDT	VUV	0.986867	2025-12-25	2025-12-25 14:48:56.562599
384	BDT	WST	0.022683	2025-12-25	2025-12-25 14:48:56.785518
385	BDT	XAF	4.55443	2025-12-25	2025-12-25 14:48:57.078609
386	BDT	XCD	0.022093	2025-12-25	2025-12-25 14:48:57.366223
387	BDT	XDR	0.005941	2025-12-25	2025-12-25 14:48:57.69383
388	BDT	XOF	4.55443	2025-12-25	2025-12-25 14:48:58.079791
389	BDT	XPF	0.828544	2025-12-25	2025-12-25 14:48:58.474982
390	BDT	YER	1.951447	2025-12-25	2025-12-25 14:48:59.181709
420	EUR	CDF	2686.067164	2025-12-26	2025-12-26 00:52:45.237445
421	EUR	CHF	0.928554	2025-12-26	2025-12-26 00:52:45.445625
422	EUR	CLF	0.027101	2025-12-26	2025-12-26 00:52:45.728554
423	EUR	CLP	1071.185109	2025-12-26	2025-12-26 00:52:45.941709
424	EUR	CNH	8.259695	2025-12-26	2025-12-26 00:52:46.237521
425	EUR	CNY	8.27748	2025-12-26	2025-12-26 00:52:46.520122
426	EUR	COP	4437.75716	2025-12-26	2025-12-26 00:52:46.744649
427	EUR	CRC	587.930617	2025-12-26	2025-12-26 00:52:47.118802
428	EUR	CUP	28.280515	2025-12-26	2025-12-26 00:52:47.335664
429	EUR	CVE	110.265	2025-12-26	2025-12-26 00:52:47.535606
430	EUR	CZK	24.273338	2025-12-26	2025-12-26 00:52:47.739815
431	EUR	DJF	209.418392	2025-12-26	2025-12-26 00:52:48.018783
432	EUR	DKK	7.461265	2025-12-26	2025-12-26 00:52:48.241665
433	EUR	DOP	73.957209	2025-12-26	2025-12-26 00:52:48.54326
434	EUR	DZD	152.823944	2025-12-26	2025-12-26 00:52:48.819715
435	EUR	EGP	56.116859	2025-12-26	2025-12-26 00:52:49.041098
436	EUR	ERN	17.675322	2025-12-26	2025-12-26 00:52:49.341907
437	EUR	ETB	181.952086	2025-12-26	2025-12-26 00:52:49.63981
438	EUR	FJD	2.679777	2025-12-26	2025-12-26 00:52:49.932842
439	EUR	FKP	0.872552	2025-12-26	2025-12-26 00:52:50.138766
440	EUR	FOK	7.461265	2025-12-26	2025-12-26 00:52:50.437036
441	EUR	GBP	0.872552	2025-12-26	2025-12-26 00:52:50.64376
442	EUR	GEL	3.179354	2025-12-26	2025-12-26 00:52:50.943489
443	EUR	GGP	0.872552	2025-12-26	2025-12-26 00:52:51.244729
444	EUR	GHS	13.302211	2025-12-26	2025-12-26 00:52:51.519853
445	EUR	GIP	0.872552	2025-12-26	2025-12-26 00:52:51.750792
446	EUR	GMD	87.454612	2025-12-26	2025-12-26 00:52:51.942276
447	EUR	GNF	10295.45819	2025-12-26	2025-12-26 00:52:52.219924
448	EUR	GTQ	9.036739	2025-12-26	2025-12-26 00:52:52.427969
449	EUR	GYD	246.335846	2025-12-26	2025-12-26 00:52:52.805569
450	EUR	HKD	9.161038	2025-12-26	2025-12-26 00:52:52.941409
451	EUR	HNL	31.052379	2025-12-26	2025-12-26 00:52:53.327452
452	EUR	HRK	7.5345	2025-12-26	2025-12-26 00:52:53.819042
453	EUR	HTG	154.18447	2025-12-26	2025-12-26 00:52:54.418634
454	EUR	HUF	389.359462	2025-12-26	2025-12-26 00:52:55.120514
455	EUR	IDR	19734.933824	2025-12-26	2025-12-26 00:52:55.519727
456	EUR	ILS	3.754583	2025-12-26	2025-12-26 00:52:55.821033
457	EUR	IMP	0.872056	2025-12-26	2025-12-26 00:52:56.040544
458	EUR	INR	105.718536	2025-12-26	2025-12-26 00:52:56.34027
459	EUR	IQD	1542.506438	2025-12-26	2025-12-26 00:52:56.54184
460	EUR	IRR	50021.725081	2025-12-26	2025-12-26 00:52:56.844629
461	EUR	ISK	148.014024	2025-12-26	2025-12-26 00:52:57.218735
462	EUR	JEP	0.872056	2025-12-26	2025-12-26 00:52:57.44425
463	EUR	JMD	187.757152	2025-12-26	2025-12-26 00:52:57.733492
464	EUR	JOD	0.835764	2025-12-26	2025-12-26 00:52:57.946993
465	EUR	JPY	183.762937	2025-12-26	2025-12-26 00:52:58.248942
466	EUR	KES	151.942762	2025-12-26	2025-12-26 00:52:58.544592
467	EUR	KGS	103.000823	2025-12-26	2025-12-26 00:52:58.842306
468	EUR	KHR	4729	2025-12-26	2025-12-26 00:52:59.139607
469	EUR	KID	1.757297	2025-12-26	2025-12-26 00:52:59.437213
470	EUR	KMF	491.96775	2025-12-26	2025-12-26 00:52:59.655782
471	EUR	KRW	1704.784388	2025-12-26	2025-12-26 00:52:59.934001
472	EUR	KWD	0.360894	2025-12-26	2025-12-26 00:53:00.145664
473	EUR	KYD	0.982326	2025-12-26	2025-12-26 00:53:00.442725
474	EUR	KZT	601.898534	2025-12-26	2025-12-26 00:53:00.730639
475	EUR	LAK	25511.81021	2025-12-26	2025-12-26 00:53:00.950381
476	EUR	LBP	105501.886944	2025-12-26	2025-12-26 00:53:01.233168
477	EUR	LKR	364.53462	2025-12-26	2025-12-26 00:53:01.447551
478	EUR	LRD	209.369867	2025-12-26	2025-12-26 00:53:01.641093
479	EUR	LSL	19.620184	2025-12-26	2025-12-26 00:53:01.94109
480	EUR	LYD	6.372976	2025-12-26	2025-12-26 00:53:02.137311
481	EUR	MAD	10.736311	2025-12-26	2025-12-26 00:53:02.33494
482	EUR	MDL	19.745623	2025-12-26	2025-12-26 00:53:02.629787
483	EUR	MGA	5322.554329	2025-12-26	2025-12-26 00:53:02.828991
484	EUR	MKD	61.4887	2025-12-26	2025-12-26 00:53:03.035922
485	EUR	MMK	2476.029464	2025-12-26	2025-12-26 00:53:03.248537
486	EUR	MNT	4168.698668	2025-12-26	2025-12-26 00:53:03.542972
487	EUR	MOP	9.43502	2025-12-26	2025-12-26 00:53:03.936202
488	EUR	MRU	46.888976	2025-12-26	2025-12-26 00:53:04.427724
489	EUR	MUR	54.150559	2025-12-26	2025-12-26 00:53:04.920241
490	EUR	MVR	18.214329	2025-12-26	2025-12-26 00:53:05.328568
491	EUR	MWK	2052.481162	2025-12-26	2025-12-26 00:53:05.718685
492	EUR	MXN	21.130693	2025-12-26	2025-12-26 00:53:05.937805
493	EUR	MYR	4.768235	2025-12-26	2025-12-26 00:53:06.14239
494	EUR	MZN	75.279302	2025-12-26	2025-12-26 00:53:06.341474
495	EUR	NAD	19.620184	2025-12-26	2025-12-26 00:53:06.541309
496	EUR	NGN	1706.711685	2025-12-26	2025-12-26 00:53:06.842769
497	EUR	NIO	43.359618	2025-12-26	2025-12-26 00:53:07.138917
498	EUR	NOK	11.796106	2025-12-26	2025-12-26 00:53:07.438896
499	EUR	NPR	169.129649	2025-12-26	2025-12-26 00:53:07.732879
500	EUR	AED	4.32401	2025-12-29	2025-12-29 12:00:39.215135
501	EUR	AFN	77.399773	2025-12-29	2025-12-29 12:00:39.508196
502	EUR	ALL	96.293063	2025-12-29	2025-12-29 12:00:39.797518
503	EUR	AMD	449.102486	2025-12-29	2025-12-29 12:00:40.08896
504	EUR	ANG	2.10755	2025-12-29	2025-12-29 12:00:40.314136
505	EUR	AOA	1085.839956	2025-12-29	2025-12-29 12:00:40.611358
506	EUR	ARS	1709.882347	2025-12-29	2025-12-29 12:00:40.906762
507	EUR	AUD	1.754666	2025-12-29	2025-12-29 12:00:41.111465
508	EUR	AWG	2.10755	2025-12-29	2025-12-29 12:00:41.411069
509	EUR	AZN	2.001181	2025-12-29	2025-12-29 12:00:41.705645
510	EUR	BAM	1.95583	2025-12-29	2025-12-29 12:00:41.987422
511	EUR	BBD	2.354804	2025-12-29	2025-12-29 12:00:42.212136
512	EUR	BDT	143.947084	2025-12-29	2025-12-29 12:00:42.488492
513	EUR	BGN	1.95583	2025-12-29	2025-12-29 12:00:42.70518
514	EUR	BHD	0.442703	2025-12-29	2025-12-29 12:00:42.914866
515	EUR	BIF	3489.988593	2025-12-29	2025-12-29 12:00:43.216532
516	EUR	BMD	1.177402	2025-12-29	2025-12-29 12:00:43.509761
517	EUR	BND	1.512581	2025-12-29	2025-12-29 12:00:43.802008
518	EUR	BOB	8.147883	2025-12-29	2025-12-29 12:00:44.016976
519	EUR	BRL	6.52672	2025-12-29	2025-12-29 12:00:44.297862
520	EUR	BSD	1.177402	2025-12-29	2025-12-29 12:00:44.598877
521	EUR	BTN	105.722091	2025-12-29	2025-12-29 12:00:44.888967
522	EUR	BWP	16.033031	2025-12-29	2025-12-29 12:00:45.189142
523	EUR	BYN	3.430432	2025-12-29	2025-12-29 12:00:45.496675
524	EUR	BZD	2.354804	2025-12-29	2025-12-29 12:00:45.788149
525	EUR	CAD	1.609342	2025-12-29	2025-12-29 12:00:46.01028
526	EUR	CDF	2701.481203	2025-12-29	2025-12-29 12:00:46.306217
527	EUR	CHF	0.929046	2025-12-29	2025-12-29 12:00:46.597921
528	EUR	CLF	0.026945	2025-12-29	2025-12-29 12:00:46.890064
529	EUR	CLP	1065.050875	2025-12-29	2025-12-29 12:00:47.206185
530	EUR	CNH	8.248027	2025-12-29	2025-12-29 12:00:47.504822
531	EUR	CNY	8.257927	2025-12-29	2025-12-29 12:00:47.81284
532	EUR	COP	4367.276616	2025-12-29	2025-12-29 12:00:48.104886
533	EUR	CRC	582.887343	2025-12-29	2025-12-29 12:00:48.407399
534	EUR	CUP	28.257653	2025-12-29	2025-12-29 12:00:48.711122
535	EUR	CVE	110.265	2025-12-29	2025-12-29 12:00:49.007585
536	EUR	CZK	24.261925	2025-12-29	2025-12-29 12:00:49.306567
537	EUR	DJF	209.249097	2025-12-29	2025-12-29 12:00:49.608498
538	EUR	DKK	7.46045	2025-12-29	2025-12-29 12:00:49.906367
539	EUR	DOP	73.847073	2025-12-29	2025-12-29 12:00:50.187221
540	EUR	DZD	152.452995	2025-12-29	2025-12-29 12:00:50.408164
541	EUR	EGP	56.004069	2025-12-29	2025-12-29 12:00:50.615767
542	EUR	ERN	17.661033	2025-12-29	2025-12-29 12:00:50.901777
543	EUR	ETB	182.279229	2025-12-29	2025-12-29 12:00:51.113787
544	EUR	FJD	2.6704	2025-12-29	2025-12-29 12:00:51.312839
545	EUR	FKP	0.872418	2025-12-29	2025-12-29 12:00:51.688251
546	EUR	FOK	7.46045	2025-12-29	2025-12-29 12:00:51.91056
547	EUR	GBP	0.872419	2025-12-29	2025-12-29 12:00:52.209083
548	EUR	GEL	3.172044	2025-12-29	2025-12-29 12:00:52.514847
549	EUR	GGP	0.872418	2025-12-29	2025-12-29 12:00:52.80233
550	EUR	GHS	13.020714	2025-12-29	2025-12-29 12:00:53.091918
551	EUR	GIP	0.872418	2025-12-29	2025-12-29 12:00:53.408655
552	EUR	GMD	87.234308	2025-12-29	2025-12-29 12:00:53.812875
553	EUR	GNF	10267.636869	2025-12-29	2025-12-29 12:00:54.189846
554	EUR	GTQ	9.016493	2025-12-29	2025-12-29 12:00:54.41241
555	EUR	GYD	246.262509	2025-12-29	2025-12-29 12:00:54.707742
556	EUR	HKD	9.149235	2025-12-29	2025-12-29 12:00:54.997327
557	EUR	HNL	31.027207	2025-12-29	2025-12-29 12:00:55.215456
558	EUR	HRK	7.5345	2025-12-29	2025-12-29 12:00:55.513436
559	EUR	HTG	154.204721	2025-12-29	2025-12-29 12:00:55.886901
560	EUR	HUF	387.098124	2025-12-29	2025-12-29 12:00:56.113768
561	EUR	IDR	19731.998832	2025-12-29	2025-12-29 12:00:56.414821
562	EUR	ILS	3.756927	2025-12-29	2025-12-29 12:00:56.706438
563	EUR	IMP	0.872418	2025-12-29	2025-12-29 12:00:56.987099
564	EUR	INR	105.722102	2025-12-29	2025-12-29 12:00:57.205304
565	EUR	IQD	1542.04721	2025-12-29	2025-12-29 12:00:57.505998
566	EUR	IRR	50830.476173	2025-12-29	2025-12-29 12:00:57.798884
567	EUR	ISK	147.983593	2025-12-29	2025-12-29 12:00:58.08735
568	EUR	JEP	0.872418	2025-12-29	2025-12-29 12:00:58.314766
569	EUR	JMD	187.655895	2025-12-29	2025-12-29 12:00:58.687196
570	EUR	JOD	0.834778	2025-12-29	2025-12-29 12:00:58.912207
571	EUR	JPY	184.245489	2025-12-29	2025-12-29 12:00:59.212077
572	EUR	KES	151.776425	2025-12-29	2025-12-29 12:00:59.414668
573	EUR	KGS	102.94942	2025-12-29	2025-12-29 12:00:59.708503
574	EUR	KHR	4727.592105	2025-12-29	2025-12-29 12:01:00.003534
575	EUR	KID	1.754665	2025-12-29	2025-12-29 12:01:00.308032
576	EUR	KMF	491.96775	2025-12-29	2025-12-29 12:01:00.512276
577	EUR	KRW	1696.405265	2025-12-29	2025-12-29 12:01:00.711797
578	EUR	KWD	0.360809	2025-12-29	2025-12-29 12:01:01.003085
579	EUR	KYD	0.981168	2025-12-29	2025-12-29 12:01:01.213002
580	EUR	KZT	593.06877	2025-12-29	2025-12-29 12:01:01.517514
581	EUR	LAK	25532.459614	2025-12-29	2025-12-29 12:01:01.811216
582	EUR	LBP	105377.497009	2025-12-29	2025-12-29 12:01:02.087989
583	EUR	LKR	364.009075	2025-12-29	2025-12-29 12:01:02.307038
584	EUR	LRD	209.019222	2025-12-29	2025-12-29 12:01:02.588231
585	EUR	LSL	19.622429	2025-12-29	2025-12-29 12:01:02.904319
586	EUR	LYD	6.371079	2025-12-29	2025-12-29 12:01:03.12312
587	EUR	MAD	10.732058	2025-12-29	2025-12-29 12:01:03.403465
588	EUR	MDL	19.702079	2025-12-29	2025-12-29 12:01:03.688334
589	EUR	MGA	5354.115465	2025-12-29	2025-12-29 12:01:03.912884
590	EUR	MKD	61.495	2025-12-29	2025-12-29 12:01:04.203817
591	EUR	MMK	2474.214231	2025-12-29	2025-12-29 12:01:04.487718
592	EUR	MNT	4153.077948	2025-12-29	2025-12-29 12:01:04.706806
593	EUR	MOP	9.424202	2025-12-29	2025-12-29 12:01:04.999106
594	EUR	MRU	46.807843	2025-12-29	2025-12-29 12:01:05.213304
595	EUR	MUR	54.077408	2025-12-29	2025-12-29 12:01:05.588975
596	EUR	MVR	18.198443	2025-12-29	2025-12-29 12:01:05.904213
597	EUR	MWK	2042.776724	2025-12-29	2025-12-29 12:01:06.38844
598	EUR	MXN	21.079979	2025-12-29	2025-12-29 12:01:07.000875
599	EUR	MYR	4.766868	2025-12-29	2025-12-29 12:01:07.789113
600	EUR	AED	4.314173	2026-01-02	2026-01-02 14:49:06.557987
601	EUR	AFN	77.034792	2026-01-02	2026-01-02 14:49:06.626258
602	EUR	ALL	96.745395	2026-01-02	2026-01-02 14:49:06.662445
603	EUR	AMD	447.935075	2026-01-02	2026-01-02 14:49:06.737365
604	EUR	ANG	2.102756	2026-01-02	2026-01-02 14:49:06.820447
605	EUR	AOA	1106.682112	2026-01-02	2026-01-02 14:49:06.909584
606	EUR	ARS	1705.992632	2026-01-02	2026-01-02 14:49:06.955837
607	EUR	AUD	1.758889	2026-01-02	2026-01-02 14:49:07.022477
608	EUR	AWG	2.102756	2026-01-02	2026-01-02 14:49:07.109044
609	EUR	AZN	1.996365	2026-01-02	2026-01-02 14:49:07.148236
610	EUR	BAM	1.95583	2026-01-02	2026-01-02 14:49:07.227558
611	EUR	BBD	2.349448	2026-01-02	2026-01-02 14:49:07.320128
612	EUR	BDT	143.679099	2026-01-02	2026-01-02 14:49:07.360791
613	EUR	BGN	1.95583	2026-01-02	2026-01-02 14:49:07.442118
614	EUR	BHD	0.441696	2026-01-02	2026-01-02 14:49:07.528722
615	EUR	BIF	3483.208756	2026-01-02	2026-01-02 14:49:07.56506
616	EUR	BMD	1.174724	2026-01-02	2026-01-02 14:49:07.635361
617	EUR	BND	1.510143	2026-01-02	2026-01-02 14:49:07.716641
618	EUR	BOB	8.132899	2026-01-02	2026-01-02 14:49:07.757001
619	EUR	BRL	6.433197	2026-01-02	2026-01-02 14:49:07.833986
620	EUR	BSD	1.174724	2026-01-02	2026-01-02 14:49:07.913238
621	EUR	BTN	105.480048	2026-01-02	2026-01-02 14:49:07.952513
622	EUR	BWP	15.991235	2026-01-02	2026-01-02 14:49:08.018535
623	EUR	BYN	3.439295	2026-01-02	2026-01-02 14:49:08.05883
624	EUR	BZD	2.349448	2026-01-02	2026-01-02 14:49:08.138789
625	EUR	CAD	1.611095	2026-01-02	2026-01-02 14:49:08.219628
626	EUR	CDF	2675.552239	2026-01-02	2026-01-02 14:49:08.264406
627	EUR	CHF	0.930896	2026-01-02	2026-01-02 14:49:08.343681
628	EUR	CLF	0.026751	2026-01-02	2026-01-02 14:49:08.414757
629	EUR	CLP	1057.377519	2026-01-02	2026-01-02 14:49:08.452476
630	EUR	CNH	8.199923	2026-01-02	2026-01-02 14:49:08.539201
631	EUR	CNY	8.213562	2026-01-02	2026-01-02 14:49:08.630903
632	EUR	COP	4424.19588	2026-01-02	2026-01-02 14:49:08.716619
633	EUR	CRC	584.07313	2026-01-02	2026-01-02 14:49:08.760691
634	EUR	CUP	28.193371	2026-01-02	2026-01-02 14:49:08.820642
635	EUR	CVE	110.265	2026-01-02	2026-01-02 14:49:08.909404
636	EUR	CZK	24.179955	2026-01-02	2026-01-02 14:49:08.948702
637	EUR	DJF	208.773088	2026-01-02	2026-01-02 14:49:09.028232
638	EUR	DKK	7.460713	2026-01-02	2026-01-02 14:49:09.111067
639	EUR	DOP	74.081805	2026-01-02	2026-01-02 14:49:09.15442
640	EUR	DZD	152.164288	2026-01-02	2026-01-02 14:49:09.229559
641	EUR	EGP	56.024236	2026-01-02	2026-01-02 14:49:09.309446
642	EUR	ERN	17.620857	2026-01-02	2026-01-02 14:49:09.343816
643	EUR	ETB	181.235265	2026-01-02	2026-01-02 14:49:09.430837
644	EUR	FJD	2.668895	2026-01-02	2026-01-02 14:49:09.512173
645	EUR	FKP	0.872503	2026-01-02	2026-01-02 14:49:09.553024
646	EUR	FOK	7.460713	2026-01-02	2026-01-02 14:49:09.618577
647	EUR	GBP	0.872503	2026-01-02	2026-01-02 14:49:09.690237
648	EUR	GEL	3.165141	2026-01-02	2026-01-02 14:49:09.737008
649	EUR	GGP	0.872503	2026-01-02	2026-01-02 14:49:09.813647
650	EUR	GHS	12.28968	2026-01-02	2026-01-02 14:49:09.851737
651	EUR	GIP	0.872503	2026-01-02	2026-01-02 14:49:09.920037
652	EUR	GMD	86.563736	2026-01-02	2026-01-02 14:49:09.954698
653	EUR	GNF	10276.902195	2026-01-02	2026-01-02 14:49:10.030106
654	EUR	GTQ	9.006371	2026-01-02	2026-01-02 14:49:10.117179
655	EUR	GYD	245.564384	2026-01-02	2026-01-02 14:49:10.155684
656	EUR	HKD	9.143167	2026-01-02	2026-01-02 14:49:10.239988
657	EUR	HNL	30.962125	2026-01-02	2026-01-02 14:49:10.318296
658	EUR	HRK	7.5345	2026-01-02	2026-01-02 14:49:10.356649
659	EUR	HTG	153.675096	2026-01-02	2026-01-02 14:49:10.435205
660	EUR	HUF	384.449714	2026-01-02	2026-01-02 14:49:10.509037
661	EUR	IDR	19597.886665	2026-01-02	2026-01-02 14:49:10.563808
662	EUR	ILS	3.741684	2026-01-02	2026-01-02 14:49:10.61226
663	EUR	IMP	0.872503	2026-01-02	2026-01-02 14:49:10.653732
664	EUR	INR	105.480187	2026-01-02	2026-01-02 14:49:10.732288
665	EUR	IQD	1538.729614	2026-01-02	2026-01-02 14:49:10.809917
666	EUR	IRR	50088.895443	2026-01-02	2026-01-02 14:49:10.847659
667	EUR	ISK	147.199584	2026-01-02	2026-01-02 14:49:10.926942
668	EUR	JEP	0.872503	2026-01-02	2026-01-02 14:49:10.972334
669	EUR	JMD	186.622754	2026-01-02	2026-01-02 14:49:11.036286
670	EUR	JOD	0.832879	2026-01-02	2026-01-02 14:49:11.12061
671	EUR	JPY	184.087544	2026-01-02	2026-01-02 14:49:11.198992
672	EUR	KES	151.485135	2026-01-02	2026-01-02 14:49:11.237761
673	EUR	KGS	102.645153	2026-01-02	2026-01-02 14:49:11.314627
674	EUR	KHR	4717.421053	2026-01-02	2026-01-02 14:49:11.349587
675	EUR	KID	1.758887	2026-01-02	2026-01-02 14:49:11.421385
676	EUR	KMF	491.96775	2026-01-02	2026-01-02 14:49:11.460113
677	EUR	KRW	1696.485874	2026-01-02	2026-01-02 14:49:11.533431
678	EUR	KWD	0.360613	2026-01-02	2026-01-02 14:49:11.613465
679	EUR	KYD	0.978936	2026-01-02	2026-01-02 14:49:11.652093
680	EUR	KZT	596.12461	2026-01-02	2026-01-02 14:49:11.734098
681	EUR	LAK	25430.26951	2026-01-02	2026-01-02 14:49:11.811992
682	EUR	LBP	105137.779723	2026-01-02	2026-01-02 14:49:11.854017
683	EUR	LKR	363.342275	2026-01-02	2026-01-02 14:49:11.936217
684	EUR	LRD	209.795219	2026-01-02	2026-01-02 14:49:12.032377
685	EUR	LSL	19.45585	2026-01-02	2026-01-02 14:49:12.112164
686	EUR	LYD	6.347243	2026-01-02	2026-01-02 14:49:12.149483
687	EUR	MAD	10.703163	2026-01-02	2026-01-02 14:49:12.220847
688	EUR	MDL	19.721445	2026-01-02	2026-01-02 14:49:12.309285
689	EUR	MGA	5321.099503	2026-01-02	2026-01-02 14:49:12.343254
690	EUR	MKD	61.495	2026-01-02	2026-01-02 14:49:12.412289
691	EUR	MMK	2466.716593	2026-01-02	2026-01-02 14:49:12.447111
692	EUR	MNT	4148.121308	2026-01-02	2026-01-02 14:49:12.521
693	EUR	MOP	9.417457	2026-01-02	2026-01-02 14:49:12.598463
694	EUR	MRU	46.768067	2026-01-02	2026-01-02 14:49:12.635914
695	EUR	MUR	54.103437	2026-01-02	2026-01-02 14:49:12.721578
696	EUR	MVR	18.156906	2026-01-02	2026-01-02 14:49:12.798392
697	EUR	MWK	2049.679274	2026-01-02	2026-01-02 14:49:12.843376
698	EUR	MXN	21.142146	2026-01-02	2026-01-02 14:49:12.931243
699	EUR	MYR	4.763833	2026-01-02	2026-01-02 14:49:13.009811
700	EUR	MZN	75.018466	2026-01-02	2026-01-02 14:49:13.044998
701	EUR	NAD	19.45585	2026-01-02	2026-01-02 14:49:13.124404
702	EUR	NGN	1693.564847	2026-01-02	2026-01-02 14:49:13.211424
703	EUR	NIO	43.222775	2026-01-02	2026-01-02 14:49:13.250563
704	EUR	NOK	11.839115	2026-01-02	2026-01-02 14:49:13.316112
705	EUR	NPR	168.768077	2026-01-02	2026-01-02 14:49:13.357415
706	EUR	NZD	2.040867	2026-01-02	2026-01-02 14:49:13.447711
707	EUR	OMR	0.451678	2026-01-02	2026-01-02 14:49:13.519872
708	EUR	PAB	1.174724	2026-01-02	2026-01-02 14:49:13.55653
709	EUR	PEN	3.947004	2026-01-02	2026-01-02 14:49:13.620069
710	EUR	PGK	5.004358	2026-01-02	2026-01-02 14:49:13.655559
711	EUR	PHP	69.211243	2026-01-02	2026-01-02 14:49:13.731983
712	EUR	PKR	328.986017	2026-01-02	2026-01-02 14:49:13.808336
713	EUR	PLN	4.217109	2026-01-02	2026-01-02 14:49:13.849586
714	EUR	PYG	7904.891802	2026-01-02	2026-01-02 14:49:13.910818
715	EUR	QAR	4.275995	2026-01-02	2026-01-02 14:49:13.945625
716	EUR	RON	5.096269	2026-01-02	2026-01-02 14:49:14.033589
717	EUR	RSD	117.321191	2026-01-02	2026-01-02 14:49:14.069145
718	EUR	RUB	92.616059	2026-01-02	2026-01-02 14:49:14.135522
719	EUR	RWF	1714.263569	2026-01-02	2026-01-02 14:49:14.172557
720	EUR	SAR	4.405214	2026-01-02	2026-01-02 14:49:14.236255
721	EUR	SBD	9.525549	2026-01-02	2026-01-02 14:49:14.307807
722	EUR	SCR	17.732772	2026-01-02	2026-01-02 14:49:14.343934
723	EUR	SDG	524.925329	2026-01-02	2026-01-02 14:49:14.411066
724	EUR	SEK	10.812769	2026-01-02	2026-01-02 14:49:14.444722
725	EUR	SGD	1.510144	2026-01-02	2026-01-02 14:49:14.508486
726	EUR	SHP	0.872503	2026-01-02	2026-01-02 14:49:14.54919
727	EUR	SLE	28.184721	2026-01-02	2026-01-02 14:49:14.619113
728	EUR	SOS	670.138318	2026-01-02	2026-01-02 14:49:14.655311
729	EUR	SRD	44.681456	2026-01-02	2026-01-02 14:49:14.716727
730	EUR	SSP	5542.449238	2026-01-02	2026-01-02 14:49:14.753232
731	EUR	STN	24.5	2026-01-02	2026-01-02 14:49:14.82171
732	EUR	SYP	12952.40238	2026-01-02	2026-01-02 14:49:14.861818
733	EUR	SZL	19.45585	2026-01-02	2026-01-02 14:49:14.926932
734	EUR	THB	37.018988	2026-01-02	2026-01-02 14:49:14.963139
735	EUR	TJS	10.864555	2026-01-02	2026-01-02 14:49:15.042131
736	EUR	TMT	4.107383	2026-01-02	2026-01-02 14:49:15.11049
737	EUR	TND	3.395964	2026-01-02	2026-01-02 14:49:15.1451
738	EUR	TOP	2.803864	2026-01-02	2026-01-02 14:49:15.222894
739	EUR	TRY	50.463633	2026-01-02	2026-01-02 14:49:15.314741
740	EUR	TTD	8.175187	2026-01-02	2026-01-02 14:49:15.354947
741	EUR	TVD	1.758887	2026-01-02	2026-01-02 14:49:15.430846
742	EUR	TWD	36.799092	2026-01-02	2026-01-02 14:49:15.467172
743	EUR	TZS	2889.5249	2026-01-02	2026-01-02 14:49:15.534531
744	EUR	UAH	49.655211	2026-01-02	2026-01-02 14:49:15.614577
745	EUR	UGX	4231.100336	2026-01-02	2026-01-02 14:49:15.676553
746	EUR	USD	1.174725	2026-01-02	2026-01-02 14:49:15.729095
747	EUR	UYU	45.880403	2026-01-02	2026-01-02 14:49:15.809001
748	EUR	UZS	14214.882631	2026-01-02	2026-01-02 14:49:15.852682
749	EUR	VES	354.493549	2026-01-02	2026-01-02 14:49:15.927809
750	EUR	VND	30801.022172	2026-01-02	2026-01-02 14:49:15.998516
751	EUR	VUV	141.916283	2026-01-02	2026-01-02 14:49:16.033853
752	EUR	WST	3.218198	2026-01-02	2026-01-02 14:49:16.113135
753	EUR	XAF	655.957	2026-01-02	2026-01-02 14:49:16.146346
754	EUR	XCD	3.171754	2026-01-02	2026-01-02 14:49:16.217292
755	EUR	XDR	0.852068	2026-01-02	2026-01-02 14:49:16.255153
756	EUR	XOF	655.957	2026-01-02	2026-01-02 14:49:16.333327
757	EUR	XPF	119.332	2026-01-02	2026-01-02 14:49:16.399152
758	EUR	YER	280.012066	2026-01-02	2026-01-02 14:49:16.43836
759	EUR	ZAR	19.471063	2026-01-02	2026-01-02 14:49:16.510056
760	EUR	ZMW	25.981608	2026-01-02	2026-01-02 14:49:16.546379
761	EUR	ZWL	30.4936	2026-01-02	2026-01-02 14:49:16.624787
762	EUR	AED	4.32009738	2026-01-03	2026-01-03 12:53:20.950553
763	EUR	AFN	77.12603514	2026-01-03	2026-01-03 12:53:21.421613
764	EUR	ALL	96.87110731	2026-01-03	2026-01-03 12:53:21.643152
765	EUR	AMD	448.5850353	2026-01-03	2026-01-03 12:53:21.841261
766	EUR	ANG	2.1192242	2026-01-03	2026-01-03 12:53:21.937863
767	EUR	AOA	1083.61579716	2026-01-03	2026-01-03 12:53:22.039248
768	EUR	ARS	1705.99959924	2026-01-03	2026-01-03 12:53:22.152294
769	EUR	AUD	1.7573137	2026-01-03	2026-01-03 12:53:22.258869
770	EUR	AWG	2.10564311	2026-01-03	2026-01-03 12:53:22.346071
771	EUR	AZN	1.99973648	2026-01-03	2026-01-03 12:53:22.418567
772	EUR	BAM	1.95583	2026-01-03	2026-01-03 12:53:22.460081
773	EUR	BBD	2.35267386	2026-01-03	2026-01-03 12:53:22.542973
774	EUR	BDT	143.89926302	2026-01-03	2026-01-03 12:53:22.595869
775	EUR	BGN	1.95583	2026-01-03	2026-01-03 12:53:22.646207
776	EUR	BHD	0.44230269	2026-01-03	2026-01-03 12:53:22.720119
777	EUR	BIF	3483.725035	2026-01-03	2026-01-03 12:53:22.767631
778	EUR	BMD	1.17633693	2026-01-03	2026-01-03 12:53:22.844544
779	EUR	BND	1.5104025	2026-01-03	2026-01-03 12:53:22.936711
780	EUR	BOB	8.15033644	2026-01-03	2026-01-03 12:53:23.019118
781	EUR	BRL	6.46972043	2026-01-03	2026-01-03 12:53:23.060635
782	EUR	BSD	1.17633693	2026-01-03	2026-01-03 12:53:23.166706
783	EUR	BTN	105.79297592	2026-01-03	2026-01-03 12:53:23.211659
784	EUR	BWP	16.09899454	2026-01-03	2026-01-03 12:53:23.265357
785	EUR	BYN	3.45255277	2026-01-03	2026-01-03 12:53:23.348131
786	EUR	BZD	2.36924511	2026-01-03	2026-01-03 12:53:23.435024
787	EUR	CAD	1.61232712	2026-01-03	2026-01-03 12:53:23.474297
788	EUR	CDF	2668.99595686	2026-01-03	2026-01-03 12:53:23.556354
789	EUR	CHF	0.93056352	2026-01-03	2026-01-03 12:53:23.631414
790	EUR	CLP	1058.79105615	2026-01-03	2026-01-03 12:53:23.742366
791	EUR	CNH	8.19918871	2026-01-03	2026-01-03 12:53:23.819668
792	EUR	CNY	8.23035756	2026-01-03	2026-01-03 12:53:23.878789
793	EUR	COP	4437.43601492	2026-01-03	2026-01-03 12:53:23.952779
794	EUR	CRC	585.40182557	2026-01-03	2026-01-03 12:53:24.018594
795	EUR	CUP	28.23154507	2026-01-03	2026-01-03 12:53:24.062237
796	EUR	CVE	110.27	2026-01-03	2026-01-03 12:53:24.154634
797	EUR	CZK	24.15621468	2026-01-03	2026-01-03 12:53:24.219993
798	EUR	DJF	209.35719319	2026-01-03	2026-01-03 12:53:24.266105
799	EUR	DKK	7.46885109	2026-01-03	2026-01-03 12:53:24.352996
800	EUR	DOP	74.20371356	2026-01-03	2026-01-03 12:53:24.432619
801	EUR	DZD	152.35270744	2026-01-03	2026-01-03 12:53:24.487619
802	EUR	EGP	56.06744546	2026-01-03	2026-01-03 12:53:24.589534
803	EUR	ERN	17.64505398	2026-01-03	2026-01-03 12:53:24.628247
804	EUR	ETB	182.67749938	2026-01-03	2026-01-03 12:53:24.685012
805	EUR	FJD	2.67540696	2026-01-03	2026-01-03 12:53:24.740525
806	EUR	FKP	0.87201128	2026-01-03	2026-01-03 12:53:24.78104
807	EUR	GBP	0.87201128	2026-01-03	2026-01-03 12:53:24.878406
808	EUR	GEL	3.16632756	2026-01-03	2026-01-03 12:53:24.96739
809	EUR	GGP	0.87201128	2026-01-03	2026-01-03 12:53:25.044923
810	EUR	GHS	12.30994017	2026-01-03	2026-01-03 12:53:25.086386
811	EUR	GIP	0.87201128	2026-01-03	2026-01-03 12:53:25.154604
812	EUR	GMD	87.00264666	2026-01-03	2026-01-03 12:53:25.248173
813	EUR	GNF	10300.14622922	2026-01-03	2026-01-03 12:53:25.289901
814	EUR	GTQ	9.02009331	2026-01-03	2026-01-03 12:53:25.358559
815	EUR	GYD	246.13153058	2026-01-03	2026-01-03 12:53:25.432757
816	EUR	HKD	9.16377317	2026-01-03	2026-01-03 12:53:25.472688
817	EUR	HNL	31.02591015	2026-01-03	2026-01-03 12:53:25.544886
818	EUR	HRK	7.5345	2026-01-03	2026-01-03 12:53:25.627782
819	EUR	HTG	154.62080942	2026-01-03	2026-01-03 12:53:25.667208
820	EUR	HUF	384.45679313	2026-01-03	2026-01-03 12:53:25.740294
821	EUR	IDR	19642.13797577	2026-01-03	2026-01-03 12:53:25.818669
822	EUR	ILS	3.73292553	2026-01-03	2026-01-03 12:53:25.868397
823	EUR	IMP	0.87201128	2026-01-03	2026-01-03 12:53:25.954449
824	EUR	INR	105.79297592	2026-01-03	2026-01-03 12:53:26.040776
825	EUR	IQD	1541.7605533	2026-01-03	2026-01-03 12:53:26.077922
826	EUR	IRR	49373.81958984	2026-01-03	2026-01-03 12:53:26.140877
827	EUR	ISK	147.23897691	2026-01-03	2026-01-03 12:53:26.180159
828	EUR	JEP	0.87201128	2026-01-03	2026-01-03 12:53:26.259832
829	EUR	JMD	186.99626358	2026-01-03	2026-01-03 12:53:26.351938
830	EUR	JOD	0.83402288	2026-01-03	2026-01-03 12:53:26.399003
831	EUR	JPY	184.22223035	2026-01-03	2026-01-03 12:53:26.462314
832	EUR	KES	151.77266649	2026-01-03	2026-01-03 12:53:26.54124
833	EUR	KGS	102.82710125	2026-01-03	2026-01-03 12:53:26.635647
834	EUR	KHR	4718.09607562	2026-01-03	2026-01-03 12:53:26.675057
835	EUR	KMF	491.96775	2026-01-03	2026-01-03 12:53:26.769854
836	EUR	KRW	1696.24933868	2026-01-03	2026-01-03 12:53:26.837951
837	EUR	KWD	0.36201067	2026-01-03	2026-01-03 12:53:26.919484
838	EUR	KYD	0.9757798	2026-01-03	2026-01-03 12:53:26.964213
839	EUR	KZT	596.68974729	2026-01-03	2026-01-03 12:53:27.044603
840	EUR	LAK	25441.88603587	2026-01-03	2026-01-03 12:53:27.087151
841	EUR	LBP	105848.88930285	2026-01-03	2026-01-03 12:53:27.173121
842	EUR	LKR	364.2398434	2026-01-03	2026-01-03 12:53:27.244266
843	EUR	LRD	209.89771025	2026-01-03	2026-01-03 12:53:27.284687
844	EUR	LSL	19.46107697	2026-01-03	2026-01-03 12:53:27.371366
845	EUR	LYD	6.37431657	2026-01-03	2026-01-03 12:53:27.435654
846	EUR	MAD	10.71721049	2026-01-03	2026-01-03 12:53:27.489918
847	EUR	MDL	19.76919325	2026-01-03	2026-01-03 12:53:27.54898
848	EUR	MGA	5400.81393132	2026-01-03	2026-01-03 12:53:27.619045
849	EUR	MKD	61.63439792	2026-01-03	2026-01-03 12:53:27.656821
850	EUR	MMK	2469.89330039	2026-01-03	2026-01-03 12:53:27.757454
851	EUR	MNT	4187.36797145	2026-01-03	2026-01-03 12:53:27.801243
852	EUR	MOP	9.43868637	2026-01-03	2026-01-03 12:53:27.846627
853	EUR	MRU	46.86842863	2026-01-03	2026-01-03 12:53:27.938047
854	EUR	MUR	54.33135054	2026-01-03	2026-01-03 12:53:27.979922
855	EUR	MVR	18.1849573	2026-01-03	2026-01-03 12:53:28.049745
856	EUR	MWK	2040.60137853	2026-01-03	2026-01-03 12:53:28.136123
857	EUR	MXN	21.14244815	2026-01-03	2026-01-03 12:53:28.183512
858	EUR	MYR	4.77246358	2026-01-03	2026-01-03 12:53:28.255349
859	EUR	MZN	75.11155413	2026-01-03	2026-01-03 12:53:28.35449
860	EUR	NAD	19.46107697	2026-01-03	2026-01-03 12:53:28.395531
861	EUR	NGN	1699.87111041	2026-01-03	2026-01-03 12:53:28.460568
862	EUR	NIO	43.28159407	2026-01-03	2026-01-03 12:53:28.54401
863	EUR	NOK	11.8328731	2026-01-03	2026-01-03 12:53:28.588959
864	EUR	NPR	169.34810621	2026-01-03	2026-01-03 12:53:28.644439
865	EUR	NZD	2.03876021	2026-01-03	2026-01-03 12:53:28.740597
866	EUR	OMR	0.45281591	2026-01-03	2026-01-03 12:53:28.789962
867	EUR	PAB	1.17633693	2026-01-03	2026-01-03 12:53:28.861009
868	EUR	PEN	3.95341111	2026-01-03	2026-01-03 12:53:28.932544
869	EUR	PGK	5.07432082	2026-01-03	2026-01-03 12:53:28.977231
870	EUR	PHP	69.27894536	2026-01-03	2026-01-03 12:53:29.063344
871	EUR	PKR	329.48850844	2026-01-03	2026-01-03 12:53:29.119945
872	EUR	PLN	4.21704549	2026-01-03	2026-01-03 12:53:29.168486
873	EUR	PYG	7833.52306123	2026-01-03	2026-01-03 12:53:29.242752
874	EUR	QAR	4.28186643	2026-01-03	2026-01-03 12:53:29.292168
875	EUR	RON	5.09601922	2026-01-03	2026-01-03 12:53:29.364045
876	EUR	RSD	117.31758554	2026-01-03	2026-01-03 12:53:29.435513
877	EUR	RUB	92.75229834	2026-01-03	2026-01-03 12:53:29.476839
878	EUR	RWF	1713.11688188	2026-01-03	2026-01-03 12:53:29.540418
879	EUR	SAR	4.4112635	2026-01-03	2026-01-03 12:53:29.579199
880	EUR	SBD	9.53283408	2026-01-03	2026-01-03 12:53:29.663722
881	EUR	SCR	17.83917369	2026-01-03	2026-01-03 12:53:29.73833
882	EUR	SDG	705.36265247	2026-01-03	2026-01-03 12:53:29.778467
883	EUR	SEK	10.82482853	2026-01-03	2026-01-03 12:53:29.860465
884	EUR	SGD	1.5104025	2026-01-03	2026-01-03 12:53:29.945532
885	EUR	SHP	0.87201128	2026-01-03	2026-01-03 12:53:30.019878
886	EUR	SLE	26.8497713	2026-01-03	2026-01-03 12:53:30.069472
887	EUR	SOS	669.62223026	2026-01-03	2026-01-03 12:53:30.148709
888	EUR	SRD	44.80049888	2026-01-03	2026-01-03 12:53:30.218985
889	EUR	SSP	5353.88542079	2026-01-03	2026-01-03 12:53:30.260946
890	EUR	STN	24.65530007	2026-01-03	2026-01-03 12:53:30.34219
891	EUR	SYP	13006.49559186	2026-01-03	2026-01-03 12:53:30.419665
892	EUR	SZL	19.46107697	2026-01-03	2026-01-03 12:53:30.463644
893	EUR	THB	37.09095029	2026-01-03	2026-01-03 12:53:30.554597
894	EUR	TJS	10.86153013	2026-01-03	2026-01-03 12:53:30.673658
895	EUR	TMT	4.11640524	2026-01-03	2026-01-03 12:53:30.719553
896	EUR	TND	3.39200084	2026-01-03	2026-01-03 12:53:30.785492
897	EUR	TOP	2.81686827	2026-01-03	2026-01-03 12:53:30.838835
898	EUR	TRY	50.60720742	2026-01-03	2026-01-03 12:53:30.883859
899	EUR	TTD	7.98714227	2026-01-03	2026-01-03 12:53:30.975479
900	EUR	TVD	1.7573137	2026-01-03	2026-01-03 12:53:31.028851
901	EUR	TWD	36.95275036	2026-01-03	2026-01-03 12:53:31.070078
902	EUR	TZS	2905.12650054	2026-01-03	2026-01-03 12:53:31.139089
903	EUR	UAH	49.70107478	2026-01-03	2026-01-03 12:53:31.176857
904	EUR	UGX	4258.38875177	2026-01-03	2026-01-03 12:53:31.253492
905	EUR	USD	1.17633693	2026-01-03	2026-01-03 12:53:31.319919
906	EUR	UYU	45.95006898	2026-01-03	2026-01-03 12:53:31.359108
907	EUR	UZS	14137.61661196	2026-01-03	2026-01-03 12:53:31.442049
908	EUR	VES	352.33228681	2026-01-03	2026-01-03 12:53:31.480801
909	EUR	VND	30965.60589445	2026-01-03	2026-01-03 12:53:31.559901
910	EUR	VUV	142.38432273	2026-01-03	2026-01-03 12:53:31.634027
911	EUR	WST	3.24690163	2026-01-03	2026-01-03 12:53:31.674392
912	EUR	XAF	655.957	2026-01-03	2026-01-03 12:53:31.747974
913	EUR	XCD	3.18320422	2026-01-03	2026-01-03 12:53:31.792711
914	EUR	XDR	0.85875903	2026-01-03	2026-01-03 12:53:31.862406
915	EUR	XOF	655.957	2026-01-03	2026-01-03 12:53:31.937299
916	EUR	XPF	119.33174224	2026-01-03	2026-01-03 12:53:31.9761
917	EUR	YER	280.43227205	2026-01-03	2026-01-03 12:53:32.042744
918	EUR	ZAR	19.46107697	2026-01-03	2026-01-03 12:53:32.119932
919	EUR	ZMW	26.17461111	2026-01-03	2026-01-03 12:53:32.319325
920	EUR	ZWL	76382.33887792	2026-01-03	2026-01-03 12:53:32.436722
921	EUR	AED	4.30786935	2026-01-04	2026-01-04 22:23:18.051089
922	EUR	AFN	77.50047076	2026-01-04	2026-01-04 22:23:18.122938
923	EUR	ALL	96.67006045	2026-01-04	2026-01-04 22:23:18.162828
924	EUR	AMD	450.85752849	2026-01-04	2026-01-04 22:23:18.22389
925	EUR	ANG	2.10800486	2026-01-04	2026-01-04 22:23:18.263701
926	EUR	AOA	1078.97552976	2026-01-04	2026-01-04 22:23:18.315894
927	EUR	ARS	1730.55629109	2026-01-04	2026-01-04 22:23:18.348098
928	EUR	AUD	1.75255685	2026-01-04	2026-01-04 22:23:18.415191
929	EUR	AWG	2.09968309	2026-01-04	2026-01-04 22:23:18.447748
930	EUR	AZN	1.99612579	2026-01-04	2026-01-04 22:23:18.509353
931	EUR	BAM	1.95583	2026-01-04	2026-01-04 22:23:18.543276
932	EUR	BBD	2.34601462	2026-01-04	2026-01-04 22:23:18.617919
933	EUR	BDT	143.41074494	2026-01-04	2026-01-04 22:23:18.652383
934	EUR	BGN	1.95583	2026-01-04	2026-01-04 22:23:18.706574
935	EUR	BHD	0.44105075	2026-01-04	2026-01-04 22:23:18.784108
936	EUR	BIF	3472.32825748	2026-01-04	2026-01-04 22:23:18.818571
937	EUR	BMD	1.17300731	2026-01-04	2026-01-04 22:23:18.85778
938	EUR	BND	1.50812715	2026-01-04	2026-01-04 22:23:18.916076
939	EUR	BOB	8.11842341	2026-01-04	2026-01-04 22:23:18.984168
940	EUR	BRL	6.36184678	2026-01-04	2026-01-04 22:23:19.024044
941	EUR	BSD	1.17300731	2026-01-04	2026-01-04 22:23:19.115089
942	EUR	BTN	105.57056091	2026-01-04	2026-01-04 22:23:19.156845
943	EUR	BWP	15.8066228	2026-01-04	2026-01-04 22:23:19.212026
944	EUR	BYN	3.44216532	2026-01-04	2026-01-04 22:23:19.244393
945	EUR	BZD	2.36006518	2026-01-04	2026-01-04 22:23:19.324322
946	EUR	CAD	1.61094949	2026-01-04	2026-01-04 22:23:19.382912
947	EUR	CDF	2577.20867415	2026-01-04	2026-01-04 22:23:19.417903
948	EUR	CHF	0.92856212	2026-01-04	2026-01-04 22:23:19.501529
949	EUR	CLP	1062.9499386	2026-01-04	2026-01-04 22:23:19.607262
950	EUR	CNH	8.17855926	2026-01-04	2026-01-04 22:23:19.706995
951	EUR	CNY	8.20327076	2026-01-04	2026-01-04 22:23:19.747876
952	EUR	COP	4436.75671848	2026-01-04	2026-01-04 22:23:19.803172
953	EUR	CRC	585.39554868	2026-01-04	2026-01-04 22:23:19.847783
954	EUR	CUP	28.01647031	2026-01-04	2026-01-04 22:23:19.90459
955	EUR	CVE	110.26999999	2026-01-04	2026-01-04 22:23:19.984076
956	EUR	CZK	24.16428559	2026-01-04	2026-01-04 22:23:20.016599
957	EUR	DJF	209.37983565	2026-01-04	2026-01-04 22:23:20.097164
958	EUR	DKK	7.47259136	2026-01-04	2026-01-04 22:23:20.143997
959	EUR	DOP	74.13022754	2026-01-04	2026-01-04 22:23:20.221176
960	EUR	DZD	152.1392767	2026-01-04	2026-01-04 22:23:20.283335
961	EUR	EGP	55.95317262	2026-01-04	2026-01-04 22:23:20.328076
962	EUR	ERN	17.59510965	2026-01-04	2026-01-04 22:23:20.382935
963	EUR	ETB	182.04846073	2026-01-04	2026-01-04 22:23:20.424218
964	EUR	FJD	2.67306284	2026-01-04	2026-01-04 22:23:20.462932
965	EUR	FKP	0.87124635	2026-01-04	2026-01-04 22:23:20.516978
966	EUR	GBP	0.87124635	2026-01-04	2026-01-04 22:23:20.596821
967	EUR	GEL	3.15604444	2026-01-04	2026-01-04 22:23:20.65472
968	EUR	GGP	0.87124635	2026-01-04	2026-01-04 22:23:20.701214
969	EUR	GHS	12.29878323	2026-01-04	2026-01-04 22:23:20.740835
970	EUR	GIP	0.87124635	2026-01-04	2026-01-04 22:23:20.783706
971	EUR	GMD	86.85281307	2026-01-04	2026-01-04 22:23:20.81932
972	EUR	GNF	10258.80086249	2026-01-04	2026-01-04 22:23:20.866661
973	EUR	GTQ	8.99188902	2026-01-04	2026-01-04 22:23:20.91322
974	EUR	GYD	245.46554225	2026-01-04	2026-01-04 22:23:20.949207
975	EUR	HKD	9.13907478	2026-01-04	2026-01-04 22:23:21.006587
976	EUR	HNL	30.95872572	2026-01-04	2026-01-04 22:23:21.053867
977	EUR	HRK	7.5345	2026-01-04	2026-01-04 22:23:21.106464
978	EUR	HTG	153.92353612	2026-01-04	2026-01-04 22:23:21.183457
979	EUR	HUF	383.48967939	2026-01-04	2026-01-04 22:23:21.219727
980	EUR	IDR	19603.70139105	2026-01-04	2026-01-04 22:23:21.255058
981	EUR	ILS	3.73678156	2026-01-04	2026-01-04 22:23:21.320162
982	EUR	IMP	0.87124635	2026-01-04	2026-01-04 22:23:21.358028
983	EUR	INR	105.57056091	2026-01-04	2026-01-04 22:23:21.418227
984	EUR	IQD	1537.07846665	2026-01-04	2026-01-04 22:23:21.461219
985	EUR	IRR	49366.24538237	2026-01-04	2026-01-04 22:23:21.519184
986	EUR	ISK	147.52794529	2026-01-04	2026-01-04 22:23:21.557612
987	EUR	JEP	0.87124635	2026-01-04	2026-01-04 22:23:21.620254
988	EUR	JMD	187.17588615	2026-01-04	2026-01-04 22:23:21.68387
989	EUR	JOD	0.83166218	2026-01-04	2026-01-04 22:23:21.72321
990	EUR	JPY	183.90311243	2026-01-04	2026-01-04 22:23:21.799782
991	EUR	KES	151.33854862	2026-01-04	2026-01-04 22:23:21.834814
992	EUR	KGS	102.58138064	2026-01-04	2026-01-04 22:23:21.90625
993	EUR	KHR	4706.23521082	2026-01-04	2026-01-04 22:23:21.942307
994	EUR	KMF	491.96774997	2026-01-04	2026-01-04 22:23:22.028137
995	EUR	KRW	1693.01829769	2026-01-04	2026-01-04 22:23:22.083994
996	EUR	KWD	0.36066488	2026-01-04	2026-01-04 22:23:22.148328
997	EUR	KYD	0.96250268	2026-01-04	2026-01-04 22:23:22.20395
998	EUR	KZT	593.58028919	2026-01-04	2026-01-04 22:23:22.243635
999	EUR	LAK	25345.1962307	2026-01-04	2026-01-04 22:23:22.315295
1000	EUR	LBP	105211.86095075	2026-01-04	2026-01-04 22:23:22.353265
1001	EUR	LKR	362.63739184	2026-01-04	2026-01-04 22:23:22.405501
1002	EUR	LRD	208.92429715	2026-01-04	2026-01-04 22:23:22.443844
1003	EUR	LSL	19.33528132	2026-01-04	2026-01-04 22:23:22.495391
1004	EUR	LYD	6.36021777	2026-01-04	2026-01-04 22:23:22.538049
1005	EUR	MAD	10.71484804	2026-01-04	2026-01-04 22:23:22.600826
1006	EUR	MDL	19.72798393	2026-01-04	2026-01-04 22:23:22.640311
1007	EUR	MGA	5376.99100551	2026-01-04	2026-01-04 22:23:22.673871
1008	EUR	MKD	61.54515451	2026-01-04	2026-01-04 22:23:22.716201
1009	EUR	MMK	2463.40699333	2026-01-04	2026-01-04 22:23:22.755983
1010	EUR	MNT	4172.42149859	2026-01-04	2026-01-04 22:23:22.810272
1011	EUR	MOP	9.41324702	2026-01-04	2026-01-04 22:23:22.848398
1012	EUR	MRU	46.75011085	2026-01-04	2026-01-04 22:23:22.901572
1013	EUR	MUR	54.17122814	2026-01-04	2026-01-04 22:23:22.942313
1014	EUR	MVR	18.13412203	2026-01-04	2026-01-04 22:23:23.012533
1015	EUR	MWK	2036.97317482	2026-01-04	2026-01-04 22:23:23.049137
1016	EUR	MXN	21.00327493	2026-01-04	2026-01-04 22:23:23.106453
1017	EUR	MYR	4.75640638	2026-01-04	2026-01-04 22:23:23.143031
1018	EUR	MZN	74.92697366	2026-01-04	2026-01-04 22:23:23.202617
1019	EUR	NAD	19.33528132	2026-01-04	2026-01-04 22:23:23.235871
1020	EUR	NGN	1687.46530765	2026-01-04	2026-01-04 22:23:23.31427
1021	EUR	NIO	43.04292266	2026-01-04	2026-01-04 22:23:23.350864
1022	EUR	NOK	11.80431893	2026-01-04	2026-01-04 22:23:23.418492
1023	EUR	NPR	168.99207538	2026-01-04	2026-01-04 22:23:23.458642
1024	EUR	NZD	2.03342513	2026-01-04	2026-01-04 22:23:23.515409
1025	EUR	OMR	0.45154414	2026-01-04	2026-01-04 22:23:23.549217
1026	EUR	PAB	1.17300731	2026-01-04	2026-01-04 22:23:23.60864
1027	EUR	PEN	3.94254462	2026-01-04	2026-01-04 22:23:23.645786
1028	EUR	PGK	4.98770873	2026-01-04	2026-01-04 22:23:23.709746
1029	EUR	PHP	69.04358687	2026-01-04	2026-01-04 22:23:23.783744
1030	EUR	PKR	328.53335555	2026-01-04	2026-01-04 22:23:23.819606
1031	EUR	PLN	4.21274255	2026-01-04	2026-01-04 22:23:23.904842
1032	EUR	PYG	7719.86584837	2026-01-04	2026-01-04 22:23:23.950447
1033	EUR	QAR	4.26974661	2026-01-04	2026-01-04 22:23:24.024991
1034	EUR	RON	5.09168566	2026-01-04	2026-01-04 22:23:24.10187
1035	EUR	RSD	117.395025	2026-01-04	2026-01-04 22:23:24.136761
1036	EUR	RUB	94.16853969	2026-01-04	2026-01-04 22:23:24.201529
1037	EUR	RWF	1706.98739917	2026-01-04	2026-01-04 22:23:24.23834
1038	EUR	SAR	4.39877741	2026-01-04	2026-01-04 22:23:24.301287
1039	EUR	SBD	9.55254273	2026-01-04	2026-01-04 22:23:24.335632
1040	EUR	SCR	17.61115061	2026-01-04	2026-01-04 22:23:24.404007
1041	EUR	SDG	703.56358658	2026-01-04	2026-01-04 22:23:24.439235
1042	EUR	SEK	10.8128903	2026-01-04	2026-01-04 22:23:24.514276
1043	EUR	SGD	1.50812715	2026-01-04	2026-01-04 22:23:24.55257
1044	EUR	SHP	0.87124635	2026-01-04	2026-01-04 22:23:24.631205
1045	EUR	SLE	26.7797596	2026-01-04	2026-01-04 22:23:24.665974
1046	EUR	SOS	670.00248723	2026-01-04	2026-01-04 22:23:24.713443
1047	EUR	SRD	44.83148349	2026-01-04	2026-01-04 22:23:24.754295
1048	EUR	SSP	5343.95153208	2026-01-04	2026-01-04 22:23:24.803265
1049	EUR	STN	24.69241129	2026-01-04	2026-01-04 22:23:24.840564
1050	EUR	SYP	12969.6662986	2026-01-04	2026-01-04 22:23:24.899619
1051	EUR	SZL	19.33528132	2026-01-04	2026-01-04 22:23:24.93598
1052	EUR	THB	36.92906417	2026-01-04	2026-01-04 22:23:25.002377
1053	EUR	TJS	10.83797445	2026-01-04	2026-01-04 22:23:25.039286
1054	EUR	TMT	4.10539445	2026-01-04	2026-01-04 22:23:25.112714
1055	EUR	TND	3.3909886	2026-01-04	2026-01-04 22:23:25.1506
1056	EUR	TOP	2.80661143	2026-01-04	2026-01-04 22:23:25.219743
1057	EUR	TRY	50.48438489	2026-01-04	2026-01-04 22:23:25.259123
1058	EUR	TTD	7.94225034	2026-01-04	2026-01-04 22:23:25.318143
1059	EUR	TVD	1.75255685	2026-01-04	2026-01-04 22:23:25.382919
1060	EUR	TWD	36.81256853	2026-01-04	2026-01-04 22:23:25.41927
1061	EUR	TZS	2889.9159859	2026-01-04	2026-01-04 22:23:25.462563
1062	EUR	UAH	49.55172174	2026-01-04	2026-01-04 22:23:25.509353
1063	EUR	UGX	4250.54076363	2026-01-04	2026-01-04 22:23:25.546228
1064	EUR	USD	1.17300731	2026-01-04	2026-01-04 22:23:25.602799
1065	EUR	UYU	45.67873016	2026-01-04	2026-01-04 22:23:25.64142
1066	EUR	UZS	14083.0439986	2026-01-04	2026-01-04 22:23:25.695841
1067	EUR	VES	352.63177967	2026-01-04	2026-01-04 22:23:25.731488
1068	EUR	VND	30878.29289635	2026-01-04	2026-01-04 22:23:25.800931
1069	EUR	VUV	141.72680651	2026-01-04	2026-01-04 22:23:25.833333
1070	EUR	WST	3.2466395	2026-01-04	2026-01-04 22:23:25.903752
1071	EUR	XAF	655.95699996	2026-01-04	2026-01-04 22:23:25.937614
1072	EUR	XCD	3.16821862	2026-01-04	2026-01-04 22:23:26.001311
1073	EUR	XDR	0.8571857	2026-01-04	2026-01-04 22:23:26.037617
1074	EUR	XOF	655.95699996	2026-01-04	2026-01-04 22:23:26.106735
1075	EUR	XPF	119.33174224	2026-01-04	2026-01-04 22:23:26.143777
1076	EUR	YER	279.61099673	2026-01-04	2026-01-04 22:23:26.226475
1077	EUR	ZAR	19.33528132	2026-01-04	2026-01-04 22:23:26.303015
1078	EUR	ZMW	25.92483679	2026-01-04	2026-01-04 22:23:26.338043
1079	EUR	ZWL	76017.33470016	2026-01-04	2026-01-04 22:23:26.403181
1080	EUR	AED	4.30786935	2026-01-05	2026-01-05 12:32:33.390901
1081	EUR	AFN	77.50047076	2026-01-05	2026-01-05 12:32:33.476876
1082	EUR	ALL	96.67006045	2026-01-05	2026-01-05 12:32:33.519648
1083	EUR	AMD	450.85752849	2026-01-05	2026-01-05 12:32:33.597598
1084	EUR	ANG	2.10800486	2026-01-05	2026-01-05 12:32:33.687054
1085	EUR	AOA	1078.97552976	2026-01-05	2026-01-05 12:32:33.728321
1086	EUR	ARS	1730.55629109	2026-01-05	2026-01-05 12:32:33.781868
1087	EUR	AUD	1.75255685	2026-01-05	2026-01-05 12:32:33.823675
1088	EUR	AWG	2.09968309	2026-01-05	2026-01-05 12:32:33.914976
1089	EUR	AZN	1.99612579	2026-01-05	2026-01-05 12:32:33.97899
1090	EUR	BAM	1.95583	2026-01-05	2026-01-05 12:32:34.01546
1091	EUR	BBD	2.34601462	2026-01-05	2026-01-05 12:32:34.094284
1092	EUR	BDT	143.41074494	2026-01-05	2026-01-05 12:32:34.162802
1093	EUR	BGN	1.95583	2026-01-05	2026-01-05 12:32:34.202904
1094	EUR	BHD	0.44105075	2026-01-05	2026-01-05 12:32:34.283904
1095	EUR	BIF	3472.32825748	2026-01-05	2026-01-05 12:32:34.325398
1096	EUR	BMD	1.17300731	2026-01-05	2026-01-05 12:32:34.393748
1097	EUR	BND	1.50812715	2026-01-05	2026-01-05 12:32:34.435969
1098	EUR	BOB	8.11842341	2026-01-05	2026-01-05 12:32:34.5066
1099	EUR	BRL	6.36184678	2026-01-05	2026-01-05 12:32:34.577005
1100	EUR	BSD	1.17300731	2026-01-05	2026-01-05 12:32:34.614037
1101	EUR	BTN	105.57056091	2026-01-05	2026-01-05 12:32:34.686719
1102	EUR	BWP	15.8066228	2026-01-05	2026-01-05 12:32:34.732951
1103	EUR	BYN	3.44216532	2026-01-05	2026-01-05 12:32:34.818679
1104	EUR	BZD	2.36006518	2026-01-05	2026-01-05 12:32:34.880633
1105	EUR	CAD	1.61094949	2026-01-05	2026-01-05 12:32:34.921857
1106	EUR	CDF	2577.20867415	2026-01-05	2026-01-05 12:32:35.001237
1107	EUR	CHF	0.92856212	2026-01-05	2026-01-05 12:32:35.088773
1108	EUR	CLP	1062.9499386	2026-01-05	2026-01-05 12:32:35.186296
1109	EUR	CNH	8.17855926	2026-01-05	2026-01-05 12:32:35.226636
1110	EUR	CNY	8.20327076	2026-01-05	2026-01-05 12:32:35.285313
1111	EUR	COP	4436.75671848	2026-01-05	2026-01-05 12:32:35.380551
1112	EUR	CRC	585.39554868	2026-01-05	2026-01-05 12:32:35.461135
1113	EUR	CUP	28.01647031	2026-01-05	2026-01-05 12:32:35.497423
1114	EUR	CVE	110.26999999	2026-01-05	2026-01-05 12:32:35.563381
1115	EUR	CZK	24.16428559	2026-01-05	2026-01-05 12:32:35.601372
1116	EUR	DJF	209.37983565	2026-01-05	2026-01-05 12:32:35.685107
1117	EUR	DKK	7.47259136	2026-01-05	2026-01-05 12:32:35.723762
1118	EUR	DOP	74.13022754	2026-01-05	2026-01-05 12:32:35.789849
1119	EUR	DZD	152.1392767	2026-01-05	2026-01-05 12:32:35.863295
1120	EUR	EGP	55.95317262	2026-01-05	2026-01-05 12:32:35.901502
1121	EUR	ERN	17.59510965	2026-01-05	2026-01-05 12:32:35.991194
1122	EUR	ETB	182.04846073	2026-01-05	2026-01-05 12:32:36.065778
1123	EUR	FJD	2.67306284	2026-01-05	2026-01-05 12:32:36.133404
1124	EUR	FKP	0.87124635	2026-01-05	2026-01-05 12:32:36.192216
1125	EUR	GBP	0.87124635	2026-01-05	2026-01-05 12:32:36.288129
1126	EUR	GEL	3.15604444	2026-01-05	2026-01-05 12:32:36.384192
1127	EUR	GGP	0.87124635	2026-01-05	2026-01-05 12:32:36.423822
1128	EUR	GHS	12.29878323	2026-01-05	2026-01-05 12:32:36.504859
1129	EUR	GIP	0.87124635	2026-01-05	2026-01-05 12:32:36.579443
1130	EUR	GMD	86.85281307	2026-01-05	2026-01-05 12:32:36.621768
1131	EUR	GNF	10258.80086249	2026-01-05	2026-01-05 12:32:36.690217
1132	EUR	GTQ	8.99188902	2026-01-05	2026-01-05 12:32:36.77736
1133	EUR	GYD	245.46554225	2026-01-05	2026-01-05 12:32:36.835052
1134	EUR	HKD	9.13907478	2026-01-05	2026-01-05 12:32:36.91747
1135	EUR	HNL	30.95872572	2026-01-05	2026-01-05 12:32:36.999678
1136	EUR	HRK	7.5345	2026-01-05	2026-01-05 12:32:37.06217
1137	EUR	HTG	153.92353612	2026-01-05	2026-01-05 12:32:37.102774
1138	EUR	HUF	383.48967939	2026-01-05	2026-01-05 12:32:37.18403
1139	EUR	IDR	19603.70139105	2026-01-05	2026-01-05 12:32:37.230689
1140	EUR	ILS	3.73678156	2026-01-05	2026-01-05 12:32:37.304398
1141	EUR	IMP	0.87124635	2026-01-05	2026-01-05 12:32:37.385823
1142	EUR	INR	105.57056091	2026-01-05	2026-01-05 12:32:37.462878
1143	EUR	IQD	1537.07846665	2026-01-05	2026-01-05 12:32:37.516987
1144	EUR	IRR	49366.24538237	2026-01-05	2026-01-05 12:32:37.598109
1145	EUR	ISK	147.52794529	2026-01-05	2026-01-05 12:32:37.679971
1146	EUR	JEP	0.87124635	2026-01-05	2026-01-05 12:32:37.720592
1147	EUR	JMD	187.17588615	2026-01-05	2026-01-05 12:32:37.803837
1148	EUR	JOD	0.83166218	2026-01-05	2026-01-05 12:32:37.890156
1149	EUR	JPY	183.90311243	2026-01-05	2026-01-05 12:32:37.931764
1150	EUR	KES	151.33854862	2026-01-05	2026-01-05 12:32:38.021603
1151	EUR	KGS	102.58138064	2026-01-05	2026-01-05 12:32:38.098663
1152	EUR	KHR	4706.23521082	2026-01-05	2026-01-05 12:32:38.162461
1153	EUR	KMF	491.96774997	2026-01-05	2026-01-05 12:32:38.277835
1154	EUR	KRW	1693.01829769	2026-01-05	2026-01-05 12:32:38.322858
1155	EUR	KWD	0.36066488	2026-01-05	2026-01-05 12:32:38.403354
1156	EUR	KYD	0.96250268	2026-01-05	2026-01-05 12:32:38.482639
1157	EUR	KZT	593.58028919	2026-01-05	2026-01-05 12:32:38.518133
1158	EUR	LAK	25345.1962307	2026-01-05	2026-01-05 12:32:38.583765
1159	EUR	LBP	105211.86095075	2026-01-05	2026-01-05 12:32:38.662469
1160	EUR	LKR	362.63739184	2026-01-05	2026-01-05 12:32:38.701297
1161	EUR	LRD	208.92429715	2026-01-05	2026-01-05 12:32:38.776583
1162	EUR	LSL	19.33528132	2026-01-05	2026-01-05 12:32:38.815956
1163	EUR	LYD	6.36021777	2026-01-05	2026-01-05 12:32:38.900847
1164	EUR	MAD	10.71484804	2026-01-05	2026-01-05 12:32:38.996614
1165	EUR	MDL	19.72798393	2026-01-05	2026-01-05 12:32:39.06286
1166	EUR	MGA	5376.99100551	2026-01-05	2026-01-05 12:32:39.101444
1167	EUR	MKD	61.54515451	2026-01-05	2026-01-05 12:32:39.185265
1168	EUR	MMK	2463.40699333	2026-01-05	2026-01-05 12:32:39.223537
1169	EUR	MNT	4172.42149859	2026-01-05	2026-01-05 12:32:39.301031
1170	EUR	MOP	9.41324702	2026-01-05	2026-01-05 12:32:39.379574
1171	EUR	MRU	46.75011085	2026-01-05	2026-01-05 12:32:39.421636
1172	EUR	MUR	54.17122814	2026-01-05	2026-01-05 12:32:39.500938
1173	EUR	MVR	18.13412203	2026-01-05	2026-01-05 12:32:39.563811
1174	EUR	MWK	2036.97317482	2026-01-05	2026-01-05 12:32:39.605331
1175	EUR	MXN	21.00327493	2026-01-05	2026-01-05 12:32:39.692398
1176	EUR	MYR	4.75640638	2026-01-05	2026-01-05 12:32:39.72896
1177	EUR	MZN	74.92697366	2026-01-05	2026-01-05 12:32:39.804639
1178	EUR	NAD	19.33528132	2026-01-05	2026-01-05 12:32:39.862809
1179	EUR	NGN	1687.46530765	2026-01-05	2026-01-05 12:32:39.906799
1180	EUR	NIO	43.04292266	2026-01-05	2026-01-05 12:32:39.999424
1181	EUR	NOK	11.80431893	2026-01-05	2026-01-05 12:32:40.04458
1182	EUR	NPR	168.99207538	2026-01-05	2026-01-05 12:32:40.165706
1183	EUR	NZD	2.03342513	2026-01-05	2026-01-05 12:32:40.277374
1184	EUR	OMR	0.45154414	2026-01-05	2026-01-05 12:32:40.320523
1185	EUR	PAB	1.17300731	2026-01-05	2026-01-05 12:32:40.383148
1186	EUR	PEN	3.94254462	2026-01-05	2026-01-05 12:32:40.431823
1187	EUR	PGK	4.98770873	2026-01-05	2026-01-05 12:32:40.48537
1188	EUR	PHP	69.04358687	2026-01-05	2026-01-05 12:32:40.563675
1189	EUR	PKR	328.53335555	2026-01-05	2026-01-05 12:32:40.60715
1190	EUR	PLN	4.21274255	2026-01-05	2026-01-05 12:32:40.679021
1191	EUR	PYG	7719.86584837	2026-01-05	2026-01-05 12:32:40.730964
1192	EUR	QAR	4.26974661	2026-01-05	2026-01-05 12:32:40.786094
1193	EUR	RON	5.09168566	2026-01-05	2026-01-05 12:32:40.862165
1194	EUR	RSD	117.395025	2026-01-05	2026-01-05 12:32:40.900245
1195	EUR	RUB	94.16853969	2026-01-05	2026-01-05 12:32:40.978862
1196	EUR	RWF	1706.98739917	2026-01-05	2026-01-05 12:32:41.020813
1197	EUR	SAR	4.39877741	2026-01-05	2026-01-05 12:32:41.093527
1198	EUR	SBD	9.55254273	2026-01-05	2026-01-05 12:32:41.162627
1199	EUR	SCR	17.61115061	2026-01-05	2026-01-05 12:32:41.20226
1200	EUR	SDG	703.56358658	2026-01-05	2026-01-05 12:32:41.276671
1201	EUR	SEK	10.8128903	2026-01-05	2026-01-05 12:32:41.315935
1202	EUR	SGD	1.50812715	2026-01-05	2026-01-05 12:32:41.400603
1203	EUR	SHP	0.87124635	2026-01-05	2026-01-05 12:32:41.49623
1204	EUR	SLE	26.7797596	2026-01-05	2026-01-05 12:32:41.538186
1205	EUR	SOS	670.00248723	2026-01-05	2026-01-05 12:32:41.597606
1206	EUR	SRD	44.83148349	2026-01-05	2026-01-05 12:32:41.676146
1207	EUR	SSP	5343.95153208	2026-01-05	2026-01-05 12:32:41.720368
1208	EUR	STN	24.69241129	2026-01-05	2026-01-05 12:32:41.795552
1209	EUR	SYP	12969.6662986	2026-01-05	2026-01-05 12:32:41.879956
1210	EUR	SZL	19.33528132	2026-01-05	2026-01-05 12:32:41.919376
1211	EUR	THB	36.92906417	2026-01-05	2026-01-05 12:32:41.985928
1212	EUR	TJS	10.83797445	2026-01-05	2026-01-05 12:32:42.035007
1213	EUR	TMT	4.10539445	2026-01-05	2026-01-05 12:32:42.112216
1214	EUR	TND	3.3909886	2026-01-05	2026-01-05 12:32:42.203308
1215	EUR	TOP	2.80661143	2026-01-05	2026-01-05 12:32:42.281644
1216	EUR	TRY	50.48438489	2026-01-05	2026-01-05 12:32:42.320465
1217	EUR	TTD	7.94225034	2026-01-05	2026-01-05 12:32:42.387716
1218	EUR	TVD	1.75255685	2026-01-05	2026-01-05 12:32:42.462405
1219	EUR	TWD	36.81256853	2026-01-05	2026-01-05 12:32:42.506655
1220	EUR	TZS	2889.9159859	2026-01-05	2026-01-05 12:32:42.597583
1221	EUR	UAH	49.55172174	2026-01-05	2026-01-05 12:32:42.663633
1222	EUR	UGX	4250.54076363	2026-01-05	2026-01-05 12:32:42.715306
1223	EUR	USD	1.17300731	2026-01-05	2026-01-05 12:32:42.78416
1224	EUR	UYU	45.67873016	2026-01-05	2026-01-05 12:32:42.819488
1225	EUR	UZS	14083.0439986	2026-01-05	2026-01-05 12:32:42.897416
1226	EUR	VES	352.63177967	2026-01-05	2026-01-05 12:32:42.978862
1227	EUR	VND	30878.29289635	2026-01-05	2026-01-05 12:32:43.018273
1228	EUR	VUV	141.72680651	2026-01-05	2026-01-05 12:32:43.087039
1229	EUR	WST	3.2466395	2026-01-05	2026-01-05 12:32:43.137212
1230	EUR	XAF	655.95699996	2026-01-05	2026-01-05 12:32:43.200333
1231	EUR	XCD	3.16821862	2026-01-05	2026-01-05 12:32:43.262324
1232	EUR	XDR	0.8571857	2026-01-05	2026-01-05 12:32:43.304925
1233	EUR	XOF	655.95699996	2026-01-05	2026-01-05 12:32:43.363487
1234	EUR	XPF	119.33174224	2026-01-05	2026-01-05 12:32:43.41022
1235	EUR	YER	279.61099673	2026-01-05	2026-01-05 12:32:43.483869
1236	EUR	ZAR	19.33528132	2026-01-05	2026-01-05 12:32:43.562434
1237	EUR	ZMW	25.92483679	2026-01-05	2026-01-05 12:32:43.599281
1238	EUR	ZWL	76017.33470016	2026-01-05	2026-01-05 12:32:43.684273
1239	EUR	AED	4.30567661	2026-01-06	2026-01-06 18:12:12.488145
1240	EUR	AFN	77.27368662	2026-01-06	2026-01-06 18:12:12.557113
1241	EUR	ALL	96.72192353	2026-01-06	2026-01-06 18:12:12.61995
1242	EUR	AMD	447.0751654	2026-01-06	2026-01-06 18:12:12.686819
1243	EUR	ANG	2.10911362	2026-01-06	2026-01-06 18:12:12.730839
1244	EUR	AOA	1075.89724568	2026-01-06	2026-01-06 18:12:12.816726
1245	EUR	ARS	1723.27941219	2026-01-06	2026-01-06 18:12:12.860738
1246	EUR	AUD	1.74614501	2026-01-06	2026-01-06 18:12:12.92894
1247	EUR	AWG	2.09861433	2026-01-06	2026-01-06 18:12:13.006436
1248	EUR	AZN	1.99309741	2026-01-06	2026-01-06 18:12:13.060751
1249	EUR	BAM	1.95583	2026-01-06	2026-01-06 18:12:13.135237
1250	EUR	BBD	2.34482048	2026-01-06	2026-01-06 18:12:13.209793
1251	EUR	BDT	143.10086113	2026-01-06	2026-01-06 18:12:13.255239
1252	EUR	BGN	1.95583	2026-01-06	2026-01-06 18:12:13.326292
1253	EUR	BHD	0.44082625	2026-01-06	2026-01-06 18:12:13.387332
1254	EUR	BIF	3463.31366579	2026-01-06	2026-01-06 18:12:13.436518
1255	EUR	BMD	1.17241024	2026-01-06	2026-01-06 18:12:13.518523
1256	EUR	BND	1.50311467	2026-01-06	2026-01-06 18:12:13.588025
1257	EUR	BOB	8.10562871	2026-01-06	2026-01-06 18:12:13.639338
1258	EUR	BRL	6.34116683	2026-01-06	2026-01-06 18:12:13.717614
1259	EUR	BSD	1.17241024	2026-01-06	2026-01-06 18:12:13.765782
1260	EUR	BTN	105.76510867	2026-01-06	2026-01-06 18:12:13.839095
1261	EUR	BWP	16.19858829	2026-01-06	2026-01-06 18:12:13.905062
1262	EUR	BYN	3.47475299	2026-01-06	2026-01-06 18:12:13.952681
1263	EUR	BZD	2.35225389	2026-01-06	2026-01-06 18:12:14.020481
1264	EUR	CAD	1.6141842	2026-01-06	2026-01-06 18:12:14.07339
1265	EUR	CDF	2667.2305113	2026-01-06	2026-01-06 18:12:14.131144
1266	EUR	CHF	0.92793691	2026-01-06	2026-01-06 18:12:14.20106
1267	EUR	CLP	1059.85592832	2026-01-06	2026-01-06 18:12:14.269589
1268	EUR	CNH	8.18506954	2026-01-06	2026-01-06 18:12:14.348108
1269	EUR	CNY	8.18932007	2026-01-06	2026-01-06 18:12:14.437092
1270	EUR	COP	4392.83131078	2026-01-06	2026-01-06 18:12:14.489053
1271	EUR	CRC	582.36604394	2026-01-06	2026-01-06 18:12:14.583738
1272	EUR	CUP	28.07278196	2026-01-06	2026-01-06 18:12:14.668086
1273	EUR	CVE	110.27	2026-01-06	2026-01-06 18:12:14.732885
1274	EUR	CZK	24.19598057	2026-01-06	2026-01-06 18:12:14.7876
1275	EUR	DJF	208.65769801	2026-01-06	2026-01-06 18:12:14.836948
1276	EUR	DKK	7.47087328	2026-01-06	2026-01-06 18:12:14.900792
1277	EUR	DOP	73.86533755	2026-01-06	2026-01-06 18:12:14.979389
1278	EUR	DZD	152.35168767	2026-01-06	2026-01-06 18:12:15.030941
1279	EUR	EGP	55.48349485	2026-01-06	2026-01-06 18:12:15.080571
1280	EUR	ERN	17.58615362	2026-01-06	2026-01-06 18:12:15.131984
1281	EUR	ETB	181.96657499	2026-01-06	2026-01-06 18:12:15.222154
1282	EUR	FJD	2.66822968	2026-01-06	2026-01-06 18:12:15.264746
1283	EUR	FKP	0.86568462	2026-01-06	2026-01-06 18:12:15.311823
1284	EUR	GBP	0.86568462	2026-01-06	2026-01-06 18:12:15.422203
1285	EUR	GEL	3.15909478	2026-01-06	2026-01-06 18:12:15.465544
1286	EUR	GGP	0.86568462	2026-01-06	2026-01-06 18:12:15.51891
1287	EUR	GHS	12.27369681	2026-01-06	2026-01-06 18:12:15.612648
1288	EUR	GIP	0.86568462	2026-01-06	2026-01-06 18:12:15.652543
1289	EUR	GMD	86.64831595	2026-01-06	2026-01-06 18:12:15.711073
1290	EUR	GNF	10256.99370869	2026-01-06	2026-01-06 18:12:15.760487
1291	EUR	GTQ	8.98200484	2026-01-06	2026-01-06 18:12:15.835386
1292	EUR	GYD	244.36586807	2026-01-06	2026-01-06 18:12:15.898776
1293	EUR	HKD	9.12733595	2026-01-06	2026-01-06 18:12:15.938485
1294	EUR	HNL	30.92165511	2026-01-06	2026-01-06 18:12:16.018604
1295	EUR	HRK	7.5345	2026-01-06	2026-01-06 18:12:16.063126
1296	EUR	HTG	153.18389805	2026-01-06	2026-01-06 18:12:16.126073
1297	EUR	HUF	384.105517	2026-01-06	2026-01-06 18:12:16.210118
1298	EUR	IDR	19621.20772159	2026-01-06	2026-01-06 18:12:16.252865
1299	EUR	ILS	3.69654076	2026-01-06	2026-01-06 18:12:16.317838
1300	EUR	IMP	0.86568462	2026-01-06	2026-01-06 18:12:16.387011
1301	EUR	INR	105.76510867	2026-01-06	2026-01-06 18:12:16.440073
1302	EUR	IQD	1533.4191917	2026-01-06	2026-01-06 18:12:16.515538
1303	EUR	IRR	49337.3601353	2026-01-06	2026-01-06 18:12:16.586178
1304	EUR	ISK	147.40390099	2026-01-06	2026-01-06 18:12:16.628806
1305	EUR	JEP	0.86568462	2026-01-06	2026-01-06 18:12:16.718527
1306	EUR	JMD	186.05240635	2026-01-06	2026-01-06 18:12:16.760445
1307	EUR	JOD	0.83123886	2026-01-06	2026-01-06 18:12:16.808557
1308	EUR	JPY	183.47138103	2026-01-06	2026-01-06 18:12:16.853907
1309	EUR	KES	150.91124428	2026-01-06	2026-01-06 18:12:16.917055
1310	EUR	KGS	102.5274165	2026-01-06	2026-01-06 18:12:16.961439
1311	EUR	KHR	4706.28551089	2026-01-06	2026-01-06 18:12:17.037681
1312	EUR	KMF	491.96774999	2026-01-06	2026-01-06 18:12:17.156086
1313	EUR	KRW	1695.76755672	2026-01-06	2026-01-06 18:12:17.210921
1314	EUR	KWD	0.36012124	2026-01-06	2026-01-06 18:12:17.255647
1315	EUR	KYD	0.97187468	2026-01-06	2026-01-06 18:12:17.309293
1316	EUR	KZT	601.22862083	2026-01-06	2026-01-06 18:12:17.351439
1317	EUR	LAK	25326.54469619	2026-01-06	2026-01-06 18:12:17.430202
1318	EUR	LBP	105142.70023081	2026-01-06	2026-01-06 18:12:17.468762
1319	EUR	LKR	363.04779899	2026-01-06	2026-01-06 18:12:17.519061
1320	EUR	LRD	208.3731237	2026-01-06	2026-01-06 18:12:17.605782
1321	EUR	LSL	19.16544576	2026-01-06	2026-01-06 18:12:17.651945
1322	EUR	LYD	6.34454618	2026-01-06	2026-01-06 18:12:17.72982
1323	EUR	MAD	10.73848233	2026-01-06	2026-01-06 18:12:17.786679
1324	EUR	MDL	19.71983219	2026-01-06	2026-01-06 18:12:17.830947
1325	EUR	MGA	5399.32618649	2026-01-06	2026-01-06 18:12:17.905478
1326	EUR	MKD	61.55219578	2026-01-06	2026-01-06 18:12:17.947605
1327	EUR	MMK	2461.92580706	2026-01-06	2026-01-06 18:12:18.019891
1328	EUR	MNT	4173.73229212	2026-01-06	2026-01-06 18:12:18.10694
1329	EUR	MOP	9.40115603	2026-01-06	2026-01-06 18:12:18.152526
1330	EUR	MRU	46.83842857	2026-01-06	2026-01-06 18:12:18.209782
1331	EUR	MUR	54.49791092	2026-01-06	2026-01-06 18:12:18.257341
1332	EUR	MVR	18.12470523	2026-01-06	2026-01-06 18:12:18.314704
1333	EUR	MWK	2029.39121438	2026-01-06	2026-01-06 18:12:18.357253
1334	EUR	MXN	20.99959692	2026-01-06	2026-01-06 18:12:18.422393
1335	EUR	MYR	4.75719573	2026-01-06	2026-01-06 18:12:18.486236
1336	EUR	MZN	74.9138124	2026-01-06	2026-01-06 18:12:18.530901
1337	EUR	NAD	19.16544576	2026-01-06	2026-01-06 18:12:18.587542
1338	EUR	NGN	1678.3511691	2026-01-06	2026-01-06 18:12:18.631629
1339	EUR	NIO	43.08588413	2026-01-06	2026-01-06 18:12:18.720537
1340	EUR	NOK	11.75543606	2026-01-06	2026-01-06 18:12:18.76152
1341	EUR	NPR	169.3034977	2026-01-06	2026-01-06 18:12:18.830035
1342	EUR	NZD	2.02345008	2026-01-06	2026-01-06 18:12:18.888004
1343	EUR	OMR	0.45125602	2026-01-06	2026-01-06 18:12:18.93553
1344	EUR	PAB	1.17241024	2026-01-06	2026-01-06 18:12:19.034655
1345	EUR	PEN	3.9373852	2026-01-06	2026-01-06 18:12:19.076959
1346	EUR	PGK	5.06135224	2026-01-06	2026-01-06 18:12:19.120802
1347	EUR	PHP	69.24919156	2026-01-06	2026-01-06 18:12:19.164336
1348	EUR	PKR	327.65582632	2026-01-06	2026-01-06 18:12:19.21869
1349	EUR	PLN	4.21267962	2026-01-06	2026-01-06 18:12:19.287047
1350	EUR	PYG	7712.78118104	2026-01-06	2026-01-06 18:12:19.328388
1351	EUR	QAR	4.26757328	2026-01-06	2026-01-06 18:12:19.420679
1352	EUR	RON	5.08880232	2026-01-06	2026-01-06 18:12:19.460752
1353	EUR	RSD	117.33427672	2026-01-06	2026-01-06 18:12:19.546554
1354	EUR	RUB	94.84093407	2026-01-06	2026-01-06 18:12:19.591396
1355	EUR	RWF	1704.45147968	2026-01-06	2026-01-06 18:12:19.628177
1356	EUR	SAR	4.3965384	2026-01-06	2026-01-06 18:12:19.687738
1357	EUR	SBD	9.54038718	2026-01-06	2026-01-06 18:12:19.731761
1358	EUR	SCR	17.05951989	2026-01-06	2026-01-06 18:12:19.812248
1359	EUR	SDG	703.47165287	2026-01-06	2026-01-06 18:12:19.901062
1360	EUR	SEK	10.74806189	2026-01-06	2026-01-06 18:12:19.962778
1361	EUR	SGD	1.50311467	2026-01-06	2026-01-06 18:12:20.00813
1362	EUR	SHP	0.86568462	2026-01-06	2026-01-06 18:12:20.076245
1363	EUR	SLE	26.79542549	2026-01-06	2026-01-06 18:12:20.141553
1364	EUR	SOS	669.30140052	2026-01-06	2026-01-06 18:12:20.210493
1365	EUR	SRD	44.85087188	2026-01-06	2026-01-06 18:12:20.269089
1366	EUR	SSP	5334.35762553	2026-01-06	2026-01-06 18:12:20.313067
1367	EUR	STN	24.72365455	2026-01-06	2026-01-06 18:12:20.362365
1368	EUR	SYP	12963.08294652	2026-01-06	2026-01-06 18:12:20.431984
1369	EUR	SZL	19.16544576	2026-01-06	2026-01-06 18:12:20.503001
1370	EUR	THB	36.61201197	2026-01-06	2026-01-06 18:12:20.551933
1371	EUR	TJS	10.81791746	2026-01-06	2026-01-06 18:12:20.643647
1372	EUR	TMT	4.11411889	2026-01-06	2026-01-06 18:12:20.68723
1373	EUR	TND	3.38775609	2026-01-06	2026-01-06 18:12:20.734507
1374	EUR	TOP	2.82364264	2026-01-06	2026-01-06 18:12:20.809933
1375	EUR	TRY	50.46777105	2026-01-06	2026-01-06 18:12:20.854467
1376	EUR	TTD	7.95298289	2026-01-06	2026-01-06 18:12:20.923928
1377	EUR	TVD	1.74614501	2026-01-06	2026-01-06 18:12:20.999001
1378	EUR	TWD	36.92860077	2026-01-06	2026-01-06 18:12:21.046111
1379	EUR	TZS	2907.21246863	2026-01-06	2026-01-06 18:12:21.116245
1380	EUR	UAH	49.72892647	2026-01-06	2026-01-06 18:12:21.159064
1381	EUR	UGX	4244.47045355	2026-01-06	2026-01-06 18:12:21.211182
1382	EUR	USD	1.17241024	2026-01-06	2026-01-06 18:12:21.269979
1383	EUR	UYU	45.61350931	2026-01-06	2026-01-06 18:12:21.337198
1384	EUR	UZS	14031.39741709	2026-01-06	2026-01-06 18:12:21.387316
1385	EUR	VES	355.93375457	2026-01-06	2026-01-06 18:12:21.434062
1386	EUR	VND	30806.50329867	2026-01-06	2026-01-06 18:12:21.516333
1387	EUR	VUV	141.77256792	2026-01-06	2026-01-06 18:12:21.557963
1388	EUR	WST	3.25940862	2026-01-06	2026-01-06 18:12:21.629513
1389	EUR	XAF	655.95699998	2026-01-06	2026-01-06 18:12:21.678403
1390	EUR	XCD	3.17271193	2026-01-06	2026-01-06 18:12:21.737211
1391	EUR	XDR	0.85758892	2026-01-06	2026-01-06 18:12:21.808364
1392	EUR	XOF	655.95699998	2026-01-06	2026-01-06 18:12:21.887495
1393	EUR	XPF	119.33174224	2026-01-06	2026-01-06 18:12:21.931462
1394	EUR	YER	279.58838251	2026-01-06	2026-01-06 18:12:22.003629
1395	EUR	ZAR	19.16544576	2026-01-06	2026-01-06 18:12:22.044758
1396	EUR	ZMW	24.77765198	2026-01-06	2026-01-06 18:12:22.128778
1397	EUR	ZWL	75706.75578906	2026-01-06	2026-01-06 18:12:22.171903
1398	EUR	AED	4.29723906	2026-01-08	2026-01-08 10:02:46.841046
1399	EUR	AFN	77.41516413	2026-01-08	2026-01-08 10:02:46.924163
1400	EUR	ALL	96.64958812	2026-01-08	2026-01-08 10:02:46.969205
1401	EUR	AMD	445.06029185	2026-01-08	2026-01-08 10:02:47.010703
1402	EUR	ANG	2.10974439	2026-01-08	2026-01-08 10:02:47.067772
1403	EUR	AOA	1073.82471858	2026-01-08	2026-01-08 10:02:47.11337
1404	EUR	ARS	1716.84098368	2026-01-08	2026-01-08 10:02:47.147235
1405	EUR	AUD	1.73350261	2026-01-08	2026-01-08 10:02:47.199525
1406	EUR	AWG	2.09450181	2026-01-08	2026-01-08 10:02:47.235272
1407	EUR	AZN	1.98919714	2026-01-08	2026-01-08 10:02:47.305052
1408	EUR	BAM	1.95583	2026-01-08	2026-01-08 10:02:47.34271
1409	EUR	BBD	2.34022549	2026-01-08	2026-01-08 10:02:47.403069
1410	EUR	BDT	143.08006303	2026-01-08	2026-01-08 10:02:47.441103
1411	EUR	BGN	1.95583	2026-01-08	2026-01-08 10:02:47.50445
1412	EUR	BHD	0.43996239	2026-01-08	2026-01-08 10:02:47.539837
1413	EUR	BIF	3463.96467527	2026-01-08	2026-01-08 10:02:47.601559
1414	EUR	BMD	1.17011274	2026-01-08	2026-01-08 10:02:47.643763
1415	EUR	BND	1.49902873	2026-01-08	2026-01-08 10:02:47.707771
1416	EUR	BOB	8.10376193	2026-01-08	2026-01-08 10:02:47.787428
1417	EUR	BRL	6.28690407	2026-01-08	2026-01-08 10:02:47.860445
1418	EUR	BSD	1.17011274	2026-01-08	2026-01-08 10:02:47.910631
1419	EUR	BTN	105.4932686	2026-01-08	2026-01-08 10:02:47.984601
1420	EUR	BWP	16.27274187	2026-01-08	2026-01-08 10:02:48.02111
1421	EUR	BYN	3.44099631	2026-01-08	2026-01-08 10:02:48.097739
1422	EUR	BZD	2.35599236	2026-01-08	2026-01-08 10:02:48.142633
1423	EUR	CAD	1.61681	2026-01-08	2026-01-08 10:02:48.209291
1424	EUR	CDF	2686.85245485	2026-01-08	2026-01-08 10:02:48.244488
1425	EUR	CHF	0.92989085	2026-01-08	2026-01-08 10:02:48.295789
1426	EUR	CLP	1046.07717405	2026-01-08	2026-01-08 10:02:48.391216
1427	EUR	CNH	8.17426437	2026-01-08	2026-01-08 10:02:48.47461
1428	EUR	CNY	8.17739186	2026-01-08	2026-01-08 10:02:48.514423
1429	EUR	COP	4348.35750907	2026-01-08	2026-01-08 10:02:48.55139
1430	EUR	CRC	581.83698176	2026-01-08	2026-01-08 10:02:48.591899
1431	EUR	CUP	28.06717565	2026-01-08	2026-01-08 10:02:48.64763
1432	EUR	CVE	110.27	2026-01-08	2026-01-08 10:02:48.722598
1433	EUR	CZK	24.17109527	2026-01-08	2026-01-08 10:02:48.754865
1434	EUR	DJF	208.36335624	2026-01-08	2026-01-08 10:02:48.795304
1435	EUR	DKK	7.47206215	2026-01-08	2026-01-08 10:02:48.836562
1436	EUR	DOP	74.17433476	2026-01-08	2026-01-08 10:02:48.894201
1437	EUR	DZD	151.95655902	2026-01-08	2026-01-08 10:02:48.935168
1438	EUR	EGP	55.29661798	2026-01-08	2026-01-08 10:02:48.989898
1439	EUR	ERN	17.55169117	2026-01-08	2026-01-08 10:02:49.025473
1440	EUR	ETB	181.47270768	2026-01-08	2026-01-08 10:02:49.084741
1441	EUR	FJD	2.65691913	2026-01-08	2026-01-08 10:02:49.121417
1442	EUR	FKP	0.86601139	2026-01-08	2026-01-08 10:02:49.166902
1443	EUR	GBP	0.86601139	2026-01-08	2026-01-08 10:02:49.243465
1444	EUR	GEL	3.15284775	2026-01-08	2026-01-08 10:02:49.291929
1445	EUR	GGP	0.86601139	2026-01-08	2026-01-08 10:02:49.372154
1446	EUR	GHS	12.44216931	2026-01-08	2026-01-08 10:02:49.406202
1447	EUR	GIP	0.86601139	2026-01-08	2026-01-08 10:02:49.451608
1448	EUR	GMD	86.3761454	2026-01-08	2026-01-08 10:02:49.50172
1449	EUR	GNF	10240.33499265	2026-01-08	2026-01-08 10:02:49.570236
1450	EUR	GTQ	8.97029605	2026-01-08	2026-01-08 10:02:49.611953
1451	EUR	GYD	245.01144851	2026-01-08	2026-01-08 10:02:49.650511
1452	EUR	HKD	9.11455848	2026-01-08	2026-01-08 10:02:49.692175
1453	EUR	HNL	30.88962643	2026-01-08	2026-01-08 10:02:49.754275
1454	EUR	HRK	7.5345	2026-01-08	2026-01-08 10:02:49.793941
1455	EUR	HTG	153.25386344	2026-01-08	2026-01-08 10:02:49.824765
1456	EUR	HUF	384.55559871	2026-01-08	2026-01-08 10:02:49.891367
1457	EUR	IDR	19621.58271332	2026-01-08	2026-01-08 10:02:49.930198
1458	EUR	ILS	3.70585853	2026-01-08	2026-01-08 10:02:49.985896
1459	EUR	IMP	0.86601139	2026-01-08	2026-01-08 10:02:50.02613
1460	EUR	INR	105.4932686	2026-01-08	2026-01-08 10:02:50.080297
1461	EUR	IQD	1533.4974818	2026-01-08	2026-01-08 10:02:50.117088
1462	EUR	IRR	49180.17982884	2026-01-08	2026-01-08 10:02:50.169503
1463	EUR	ISK	147.2083667	2026-01-08	2026-01-08 10:02:50.21522
1464	EUR	JEP	0.86601139	2026-01-08	2026-01-08 10:02:50.288404
1465	EUR	JMD	185.94248393	2026-01-08	2026-01-08 10:02:50.321655
1466	EUR	JOD	0.82960994	2026-01-08	2026-01-08 10:02:50.391282
1467	EUR	JPY	183.34284279	2026-01-08	2026-01-08 10:02:50.444232
1468	EUR	KES	151.07404846	2026-01-08	2026-01-08 10:02:50.482325
1469	EUR	KGS	102.32815756	2026-01-08	2026-01-08 10:02:50.526017
1470	EUR	KHR	4702.32285175	2026-01-08	2026-01-08 10:02:50.599801
1471	EUR	KMF	491.96774999	2026-01-08	2026-01-08 10:02:50.667719
1472	EUR	KRW	1695.35639663	2026-01-08	2026-01-08 10:02:50.703141
1473	EUR	KWD	0.35939784	2026-01-08	2026-01-08 10:02:50.750415
1474	EUR	KYD	0.97073893	2026-01-08	2026-01-08 10:02:50.80609
1475	EUR	KZT	596.21202839	2026-01-08	2026-01-08 10:02:50.844811
1476	EUR	LAK	25318.18589151	2026-01-08	2026-01-08 10:02:50.903552
1477	EUR	LBP	104808.76756293	2026-01-08	2026-01-08 10:02:50.94984
1478	EUR	LKR	363.02771116	2026-01-08	2026-01-08 10:02:50.991906
1479	EUR	LRD	208.49660942	2026-01-08	2026-01-08 10:02:51.027423
1480	EUR	LSL	19.13524257	2026-01-08	2026-01-08 10:02:51.092544
1481	EUR	LYD	6.33854873	2026-01-08	2026-01-08 10:02:51.152092
1482	EUR	MAD	10.74713958	2026-01-08	2026-01-08 10:02:51.190085
1483	EUR	MDL	19.75346347	2026-01-08	2026-01-08 10:02:51.232299
1484	EUR	MGA	5398.08291524	2026-01-08	2026-01-08 10:02:51.266841
1485	EUR	MKD	61.5980377	2026-01-08	2026-01-08 10:02:51.302624
1486	EUR	MMK	2456.78112597	2026-01-08	2026-01-08 10:02:51.354358
1487	EUR	MNT	4167.22146752	2026-01-08	2026-01-08 10:02:51.40458
1488	EUR	MOP	9.38799523	2026-01-08	2026-01-08 10:02:51.442825
1489	EUR	MRU	46.34200805	2026-01-08	2026-01-08 10:02:51.495361
1490	EUR	MUR	54.16051339	2026-01-08	2026-01-08 10:02:51.536123
1491	EUR	MVR	18.08985891	2026-01-08	2026-01-08 10:02:51.576034
1492	EUR	MWK	2030.2119612	2026-01-08	2026-01-08 10:02:51.618849
1493	EUR	MXN	21.03167427	2026-01-08	2026-01-08 10:02:51.652315
1494	EUR	MYR	4.73888698	2026-01-08	2026-01-08 10:02:51.692027
1495	EUR	MZN	74.76795051	2026-01-08	2026-01-08 10:02:51.726834
1496	EUR	NAD	19.13524257	2026-01-08	2026-01-08 10:02:51.760808
1497	EUR	NGN	1672.7850231	2026-01-08	2026-01-08 10:02:51.857224
1498	EUR	NIO	43.01397788	2026-01-08	2026-01-08 10:02:51.89368
1499	EUR	NOK	11.7494241	2026-01-08	2026-01-08 10:02:51.932274
1500	EUR	NPR	168.86834972	2026-01-08	2026-01-08 10:02:51.997534
1501	EUR	NZD	2.02113689	2026-01-08	2026-01-08 10:02:52.040422
1502	EUR	OMR	0.45024877	2026-01-08	2026-01-08 10:02:52.083888
1503	EUR	PAB	1.17011274	2026-01-08	2026-01-08 10:02:52.118715
1504	EUR	PEN	3.93606017	2026-01-08	2026-01-08 10:02:52.156637
1505	EUR	PGK	5.00131499	2026-01-08	2026-01-08 10:02:52.200343
1506	EUR	PHP	69.33397957	2026-01-08	2026-01-08 10:02:52.23285
1507	EUR	PKR	329.0466782	2026-01-08	2026-01-08 10:02:52.287853
1508	EUR	PLN	4.2109697	2026-01-08	2026-01-08 10:02:52.336173
1509	EUR	PYG	7690.19922061	2026-01-08	2026-01-08 10:02:52.387635
1510	EUR	QAR	4.25921039	2026-01-08	2026-01-08 10:02:52.424821
1511	EUR	RON	5.08923658	2026-01-08	2026-01-08 10:02:52.486557
1512	EUR	RSD	117.33285813	2026-01-08	2026-01-08 10:02:52.527103
1513	EUR	RUB	94.19546444	2026-01-08	2026-01-08 10:02:52.587851
1514	EUR	RWF	1704.61357553	2026-01-08	2026-01-08 10:02:52.620864
1515	EUR	SAR	4.38792279	2026-01-08	2026-01-08 10:02:52.692914
1516	EUR	SBD	9.48848146	2026-01-08	2026-01-08 10:02:52.731531
1517	EUR	SCR	16.40556149	2026-01-08	2026-01-08 10:02:52.804791
1518	EUR	SDG	701.97097214	2026-01-08	2026-01-08 10:02:52.88796
1519	EUR	SEK	10.75561256	2026-01-08	2026-01-08 10:02:52.92093
1520	EUR	SGD	1.49902873	2026-01-08	2026-01-08 10:02:52.991155
1521	EUR	SHP	0.86601139	2026-01-08	2026-01-08 10:02:53.035829
1522	EUR	SLE	26.73785147	2026-01-08	2026-01-08 10:02:53.114151
1523	EUR	SOS	658.85377241	2026-01-08	2026-01-08 10:02:53.155929
1524	EUR	SRD	44.844871	2026-01-08	2026-01-08 10:02:53.197205
1525	EUR	SSP	5326.78069758	2026-01-08	2026-01-08 10:02:53.23752
1526	EUR	STN	24.68632257	2026-01-08	2026-01-08 10:02:53.314775
1527	EUR	SYP	12940.9495385	2026-01-08	2026-01-08 10:02:53.36742
1528	EUR	SZL	19.13524257	2026-01-08	2026-01-08 10:02:53.408168
1529	EUR	THB	36.5713639	2026-01-08	2026-01-08 10:02:53.484264
1530	EUR	TJS	10.82686212	2026-01-08	2026-01-08 10:02:53.540316
1531	EUR	TMT	4.09088012	2026-01-08	2026-01-08 10:02:53.580177
1532	EUR	TND	3.38009689	2026-01-08	2026-01-08 10:02:53.62524
1533	EUR	TOP	2.79847214	2026-01-08	2026-01-08 10:02:53.668915
1534	EUR	TRY	50.38457248	2026-01-08	2026-01-08 10:02:53.704445
1535	EUR	TTD	7.94231278	2026-01-08	2026-01-08 10:02:53.742718
1536	EUR	TVD	1.73350261	2026-01-08	2026-01-08 10:02:53.801528
1537	EUR	TWD	36.85157762	2026-01-08	2026-01-08 10:02:53.83889
1538	EUR	TZS	2897.57590203	2026-01-08	2026-01-08 10:02:53.907484
1539	EUR	UAH	49.77773922	2026-01-08	2026-01-08 10:02:53.940148
1540	EUR	UGX	4239.48785208	2026-01-08	2026-01-08 10:02:53.99381
1541	EUR	USD	1.17011274	2026-01-08	2026-01-08 10:02:54.03
1542	EUR	UYU	45.56196677	2026-01-08	2026-01-08 10:02:54.09404
1543	EUR	UZS	14014.82028033	2026-01-08	2026-01-08 10:02:54.131339
1544	EUR	VES	361.43649445	2026-01-08	2026-01-08 10:02:54.1915
1545	EUR	VND	30797.95267265	2026-01-08	2026-01-08 10:02:54.23103
1546	EUR	VUV	141.22772651	2026-01-08	2026-01-08 10:02:54.286222
1547	EUR	WST	3.22101415	2026-01-08	2026-01-08 10:02:54.334272
1548	EUR	XAF	655.95699999	2026-01-08	2026-01-08 10:02:54.378756
1549	EUR	XCD	3.1666124	2026-01-08	2026-01-08 10:02:54.417118
1550	EUR	XDR	0.85492161	2026-01-08	2026-01-08 10:02:54.467582
1551	EUR	XOF	655.95699999	2026-01-08	2026-01-08 10:02:54.524302
1552	EUR	XPF	119.33174224	2026-01-08	2026-01-08 10:02:54.559526
1553	EUR	YER	278.94760325	2026-01-08	2026-01-08 10:02:54.623224
1554	EUR	ZAR	19.13524257	2026-01-08	2026-01-08 10:02:54.666191
1555	EUR	ZMW	24.55441555	2026-01-08	2026-01-08 10:02:54.707077
1556	EUR	ZWL	75675.98869827	2026-01-08	2026-01-08 10:02:54.774694
1557	EUR	AED	4.27818692	2026-01-10	2026-01-10 00:21:32.227829
1558	EUR	AFN	76.87927603	2026-01-10	2026-01-10 00:21:32.321264
1559	EUR	ALL	96.51202035	2026-01-10	2026-01-10 00:21:32.351144
1560	EUR	AMD	442.99000401	2026-01-10	2026-01-10 00:21:32.41812
1561	EUR	ANG	2.10213149	2026-01-10	2026-01-10 00:21:32.449267
1562	EUR	AOA	1069.33689548	2026-01-10	2026-01-10 00:21:32.520877
1563	EUR	ARS	1703.92780215	2026-01-10	2026-01-10 00:21:32.554093
1564	EUR	AUD	1.73984178	2026-01-10	2026-01-10 00:21:32.622836
1565	EUR	AWG	2.08521568	2026-01-10	2026-01-10 00:21:32.654856
1566	EUR	AZN	1.98037241	2026-01-10	2026-01-10 00:21:32.713021
1567	EUR	BAM	1.95583	2026-01-10	2026-01-10 00:21:32.755937
1568	EUR	BBD	2.32984992	2026-01-10	2026-01-10 00:21:32.830715
1569	EUR	BDT	142.55554031	2026-01-10	2026-01-10 00:21:32.874797
1570	EUR	BGN	1.95583	2026-01-10	2026-01-10 00:21:32.950075
1571	EUR	BHD	0.43801179	2026-01-10	2026-01-10 00:21:33.026532
1572	EUR	BIF	3455.42211695	2026-01-10	2026-01-10 00:21:33.103462
1573	EUR	BMD	1.16492496	2026-01-10	2026-01-10 00:21:33.145875
1574	EUR	BND	1.49812164	2026-01-10	2026-01-10 00:21:33.218626
1575	EUR	BOB	8.08237045	2026-01-10	2026-01-10 00:21:33.257948
1576	EUR	BRL	6.27684	2026-01-10	2026-01-10 00:21:33.333691
1577	EUR	BSD	1.16492496	2026-01-10	2026-01-10 00:21:33.376136
1578	EUR	BTN	104.70706556	2026-01-10	2026-01-10 00:21:33.442867
1579	EUR	BWP	15.92873604	2026-01-10	2026-01-10 00:21:33.518541
1580	EUR	BYN	3.4430241	2026-01-10	2026-01-10 00:21:33.553866
1581	EUR	BZD	2.34662245	2026-01-10	2026-01-10 00:21:33.620105
1582	EUR	CAD	1.61591516	2026-01-10	2026-01-10 00:21:33.65238
1583	EUR	CDF	2683.68210495	2026-01-10	2026-01-10 00:21:33.716629
1584	EUR	CHF	0.93188839	2026-01-10	2026-01-10 00:21:33.754797
1585	EUR	CLP	1045.1423807	2026-01-10	2026-01-10 00:21:33.870988
1586	EUR	CNH	8.13020529	2026-01-10	2026-01-10 00:21:33.941828
1587	EUR	CNY	8.13404439	2026-01-10	2026-01-10 00:21:33.970905
1588	EUR	COP	4327.62641734	2026-01-10	2026-01-10 00:21:34.028197
1589	EUR	CRC	579.59364168	2026-01-10	2026-01-10 00:21:34.08847
1590	EUR	CUP	27.99140766	2026-01-10	2026-01-10 00:21:34.181405
1591	EUR	CVE	110.27	2026-01-10	2026-01-10 00:21:34.232036
1592	EUR	CZK	24.27897956	2026-01-10	2026-01-10 00:21:34.264027
1593	EUR	DJF	207.51183697	2026-01-10	2026-01-10 00:21:34.311197
1594	EUR	DKK	7.47255105	2026-01-10	2026-01-10 00:21:34.345986
1595	EUR	DOP	74.05828284	2026-01-10	2026-01-10 00:21:34.416471
1596	EUR	DZD	151.47612195	2026-01-10	2026-01-10 00:21:34.455662
1597	EUR	EGP	55.03079109	2026-01-10	2026-01-10 00:21:34.50191
1598	EUR	ERN	17.47387443	2026-01-10	2026-01-10 00:21:34.534855
1599	EUR	ETB	181.62053112	2026-01-10	2026-01-10 00:21:34.595005
1600	EUR	FJD	2.65077312	2026-01-10	2026-01-10 00:21:34.631236
1601	EUR	FKP	0.86754	2026-01-10	2026-01-10 00:21:34.659644
1602	EUR	GBP	0.86754	2026-01-10	2026-01-10 00:21:34.764322
1603	EUR	GEL	3.1386158	2026-01-10	2026-01-10 00:21:34.820166
1604	EUR	GGP	0.86754	2026-01-10	2026-01-10 00:21:34.852097
1605	EUR	GHS	12.4904655	2026-01-10	2026-01-10 00:21:34.916673
1606	EUR	GIP	0.86754	2026-01-10	2026-01-10 00:21:34.951927
1607	EUR	GMD	86.04342057	2026-01-10	2026-01-10 00:21:35.019053
1608	EUR	GNF	10198.21777538	2026-01-10	2026-01-10 00:21:35.050349
1609	EUR	GTQ	8.93543089	2026-01-10	2026-01-10 00:21:35.124273
1610	EUR	GYD	243.99646963	2026-01-10	2026-01-10 00:21:35.155246
1611	EUR	HKD	9.07923314	2026-01-10	2026-01-10 00:21:35.222222
1612	EUR	HNL	30.73052666	2026-01-10	2026-01-10 00:21:35.252133
1613	EUR	HRK	7.5345	2026-01-10	2026-01-10 00:21:35.31993
1614	EUR	HTG	152.75495928	2026-01-10	2026-01-10 00:21:35.35288
1615	EUR	HUF	385.17718155	2026-01-10	2026-01-10 00:21:35.41217
1616	EUR	IDR	19603.77222404	2026-01-10	2026-01-10 00:21:35.447082
1617	EUR	ILS	3.69238055	2026-01-10	2026-01-10 00:21:35.515112
1618	EUR	IMP	0.86754	2026-01-10	2026-01-10 00:21:35.552837
1619	EUR	INR	104.70706556	2026-01-10	2026-01-10 00:21:35.62867
1620	EUR	IQD	1529.89228271	2026-01-10	2026-01-10 00:21:35.658493
1621	EUR	IRR	49070.04136882	2026-01-10	2026-01-10 00:21:35.720457
1622	EUR	ISK	147.19721498	2026-01-10	2026-01-10 00:21:35.754317
1623	EUR	JEP	0.86754	2026-01-10	2026-01-10 00:21:35.825014
1624	EUR	JMD	184.89351709	2026-01-10	2026-01-10 00:21:35.858374
1625	EUR	JOD	0.8259318	2026-01-10	2026-01-10 00:21:35.941836
1626	EUR	JPY	183.12608326	2026-01-10	2026-01-10 00:21:36.01429
1627	EUR	KES	150.57531628	2026-01-10	2026-01-10 00:21:36.048536
1628	EUR	KGS	101.8525802	2026-01-10	2026-01-10 00:21:36.113191
1629	EUR	KHR	4684.60110841	2026-01-10	2026-01-10 00:21:36.147718
1630	EUR	KMF	491.96775002	2026-01-10	2026-01-10 00:21:36.245488
1631	EUR	KRW	1694.53287815	2026-01-10	2026-01-10 00:21:36.322672
1632	EUR	KWD	0.35801217	2026-01-10	2026-01-10 00:21:36.354554
1633	EUR	KYD	0.96921511	2026-01-10	2026-01-10 00:21:36.413549
1634	EUR	KZT	594.68414578	2026-01-10	2026-01-10 00:21:36.456561
1635	EUR	LAK	25175.08373625	2026-01-10	2026-01-10 00:21:36.520122
1636	EUR	LBP	104761.40015358	2026-01-10	2026-01-10 00:21:36.550308
1637	EUR	LKR	360.87210352	2026-01-10	2026-01-10 00:21:36.612634
1638	EUR	LRD	208.97007221	2026-01-10	2026-01-10 00:21:36.644469
1639	EUR	LSL	19.25250175	2026-01-10	2026-01-10 00:21:36.711873
1640	EUR	LYD	6.32400617	2026-01-10	2026-01-10 00:21:36.740538
1641	EUR	MAD	10.75787858	2026-01-10	2026-01-10 00:21:36.812691
1642	EUR	MDL	19.54032476	2026-01-10	2026-01-10 00:21:36.847209
1643	EUR	MGA	5390.68696992	2026-01-10	2026-01-10 00:21:36.913217
1644	EUR	MKD	61.53540196	2026-01-10	2026-01-10 00:21:36.949072
1645	EUR	MMK	2445.97193043	2026-01-10	2026-01-10 00:21:37.01453
1646	EUR	MNT	4147.98685888	2026-01-10	2026-01-10 00:21:37.045408
1647	EUR	MOP	9.35161013	2026-01-10	2026-01-10 00:21:37.119173
1648	EUR	MRU	46.22804954	2026-01-10	2026-01-10 00:21:37.162824
1649	EUR	MUR	54.22304059	2026-01-10	2026-01-10 00:21:37.222659
1650	EUR	MVR	18.00481212	2026-01-10	2026-01-10 00:21:37.254506
1651	EUR	MWK	2023.24972653	2026-01-10	2026-01-10 00:21:37.322459
1652	EUR	MXN	20.95810357	2026-01-10	2026-01-10 00:21:37.360748
1653	EUR	MYR	4.73372252	2026-01-10	2026-01-10 00:21:37.431673
1654	EUR	MZN	74.43044718	2026-01-10	2026-01-10 00:21:37.468282
1655	EUR	NAD	19.25250175	2026-01-10	2026-01-10 00:21:37.518409
1656	EUR	NGN	1660.99992228	2026-01-10	2026-01-10 00:21:37.548866
1657	EUR	NIO	42.89510226	2026-01-10	2026-01-10 00:21:37.6349
1658	EUR	NOK	11.75949605	2026-01-10	2026-01-10 00:21:37.671522
1659	EUR	NPR	167.60983519	2026-01-10	2026-01-10 00:21:37.720762
1660	EUR	NZD	2.02839034	2026-01-10	2026-01-10 00:21:37.750246
1661	EUR	OMR	0.44836312	2026-01-10	2026-01-10 00:21:37.812202
1662	EUR	PAB	1.16492496	2026-01-10	2026-01-10 00:21:37.842121
1663	EUR	PEN	3.92048211	2026-01-10	2026-01-10 00:21:37.914789
1664	EUR	PGK	4.97776599	2026-01-10	2026-01-10 00:21:37.950548
1665	EUR	PHP	68.86712576	2026-01-10	2026-01-10 00:21:38.013973
1666	EUR	PKR	328.45775697	2026-01-10	2026-01-10 00:21:38.04291
1667	EUR	PLN	4.21258194	2026-01-10	2026-01-10 00:21:38.101136
1668	EUR	PYG	7651.17597133	2026-01-10	2026-01-10 00:21:38.13486
1669	EUR	QAR	4.24032686	2026-01-10	2026-01-10 00:21:38.201198
1670	EUR	RON	5.08747556	2026-01-10	2026-01-10 00:21:38.239082
1671	EUR	RSD	117.32091292	2026-01-10	2026-01-10 00:21:38.324367
1672	EUR	RUB	93.6230552	2026-01-10	2026-01-10 00:21:38.401433
1673	EUR	RWF	1698.49266158	2026-01-10	2026-01-10 00:21:38.435189
1674	EUR	SAR	4.36846861	2026-01-10	2026-01-10 00:21:38.467392
1675	EUR	SBD	9.47663853	2026-01-10	2026-01-10 00:21:38.545316
1676	EUR	SCR	14.73144475	2026-01-10	2026-01-10 00:21:38.601991
1677	EUR	SDG	698.88532164	2026-01-10	2026-01-10 00:21:38.636315
1678	EUR	SEK	10.7548927	2026-01-10	2026-01-10 00:21:38.664518
1679	EUR	SGD	1.49812164	2026-01-10	2026-01-10 00:21:38.734063
1680	EUR	SHP	0.86754	2026-01-10	2026-01-10 00:21:38.801525
1681	EUR	SLE	26.62441917	2026-01-10	2026-01-10 00:21:38.833542
1682	EUR	SOS	661.94689036	2026-01-10	2026-01-10 00:21:38.913633
1683	EUR	SRD	44.62284455	2026-01-10	2026-01-10 00:21:38.94921
1684	EUR	SSP	5305.85610864	2026-01-10	2026-01-10 00:21:39.02003
1685	EUR	STN	24.66542774	2026-01-10	2026-01-10 00:21:39.054459
1686	EUR	SYP	128.81940586	2026-01-10	2026-01-10 00:21:39.116663
1687	EUR	SZL	19.25250175	2026-01-10	2026-01-10 00:21:39.148298
1688	EUR	THB	36.64254341	2026-01-10	2026-01-10 00:21:39.200919
1689	EUR	TJS	10.84618795	2026-01-10	2026-01-10 00:21:39.231532
1690	EUR	TMT	4.08426224	2026-01-10	2026-01-10 00:21:39.264621
1691	EUR	TND	3.37924295	2026-01-10	2026-01-10 00:21:39.332268
1692	EUR	TOP	2.80569225	2026-01-10	2026-01-10 00:21:39.368186
1693	EUR	TRY	50.27283039	2026-01-10	2026-01-10 00:21:39.433943
1694	EUR	TTD	7.9132003	2026-01-10	2026-01-10 00:21:39.501776
1695	EUR	TVD	1.73984178	2026-01-10	2026-01-10 00:21:39.534131
1696	EUR	TWD	36.84353337	2026-01-10	2026-01-10 00:21:39.566383
1697	EUR	TZS	2903.034812	2026-01-10	2026-01-10 00:21:39.639497
1698	EUR	UAH	50.14491249	2026-01-10	2026-01-10 00:21:39.720837
1699	EUR	UGX	4192.2729871	2026-01-10	2026-01-10 00:21:39.754895
1700	EUR	USD	1.16492496	2026-01-10	2026-01-10 00:21:39.821739
1701	EUR	UYU	45.47877173	2026-01-10	2026-01-10 00:21:39.856948
1702	EUR	UZS	14061.0921689	2026-01-10	2026-01-10 00:21:39.923393
1703	EUR	VES	370.44797319	2026-01-10	2026-01-10 00:21:39.955855
1704	EUR	VND	30672.12059167	2026-01-10	2026-01-10 00:21:40.028616
1705	EUR	VUV	140.77397725	2026-01-10	2026-01-10 00:21:40.102226
1706	EUR	WST	3.23322893	2026-01-10	2026-01-10 00:21:40.137927
1707	EUR	XAF	655.95700002	2026-01-10	2026-01-10 00:21:40.214575
1708	EUR	XCD	3.15329197	2026-01-10	2026-01-10 00:21:40.24897
1709	EUR	XDR	0.85239491	2026-01-10	2026-01-10 00:21:40.313048
1710	EUR	XOF	655.95700002	2026-01-10	2026-01-10 00:21:40.347407
1711	EUR	XPF	119.33174225	2026-01-10	2026-01-10 00:21:40.415726
1712	EUR	YER	277.76590852	2026-01-10	2026-01-10 00:21:40.445496
1713	EUR	ZAR	19.25250175	2026-01-10	2026-01-10 00:21:40.517866
1714	EUR	ZMW	23.09316588	2026-01-10	2026-01-10 00:21:40.546324
1715	EUR	ZWL	74877.55311768	2026-01-10	2026-01-10 00:21:40.633221
1716	EUR	AED	4.2819269	2026-01-12	2026-01-12 16:02:23.397838
1717	EUR	AFN	76.95724479	2026-01-12	2026-01-12 16:02:23.487927
1718	EUR	ALL	96.65134173	2026-01-12	2026-01-12 16:02:23.533345
1719	EUR	AMD	444.14009074	2026-01-12	2026-01-12 16:02:23.609438
1720	EUR	ANG	2.09996113	2026-01-12	2026-01-12 16:02:23.696032
1721	EUR	AOA	1063.32629795	2026-01-12	2026-01-12 16:02:23.737319
1722	EUR	ARS	1704.40769921	2026-01-12	2026-01-12 16:02:23.8206
1723	EUR	AUD	1.74093168	2026-01-12	2026-01-12 16:02:23.894505
1724	EUR	AWG	2.08703857	2026-01-12	2026-01-12 16:02:23.931645
1725	EUR	AZN	1.98210367	2026-01-12	2026-01-12 16:02:24.015147
1726	EUR	BAM	1.95583	2026-01-12	2026-01-12 16:02:24.079841
1727	EUR	BBD	2.33188667	2026-01-12	2026-01-12 16:02:24.120625
1728	EUR	BDT	142.41236552	2026-01-12	2026-01-12 16:02:24.186375
1729	EUR	BGN	1.95583	2026-01-12	2026-01-12 16:02:24.229235
1730	EUR	BHD	0.43839469	2026-01-12	2026-01-12 16:02:24.331112
1731	EUR	BIF	3450.1568829	2026-01-12	2026-01-12 16:02:24.401984
1732	EUR	BMD	1.16594333	2026-01-12	2026-01-12 16:02:24.443475
1733	EUR	BND	1.49915243	2026-01-12	2026-01-12 16:02:24.505125
1734	EUR	BOB	8.06831568	2026-01-12	2026-01-12 16:02:24.554601
1735	EUR	BRL	6.28870806	2026-01-12	2026-01-12 16:02:24.602675
1736	EUR	BSD	1.16594333	2026-01-12	2026-01-12 16:02:24.676362
1737	EUR	BTN	105.23253946	2026-01-12	2026-01-12 16:02:24.720639
1738	EUR	BWP	16.05776753	2026-01-12	2026-01-12 16:02:24.801157
1739	EUR	BYN	3.4106848	2026-01-12	2026-01-12 16:02:24.886022
1740	EUR	BZD	2.34749525	2026-01-12	2026-01-12 16:02:24.928465
1741	EUR	CAD	1.61979719	2026-01-12	2026-01-12 16:02:24.978943
1742	EUR	CDF	2502.21042238	2026-01-12	2026-01-12 16:02:25.02127
1743	EUR	CHF	0.93099669	2026-01-12	2026-01-12 16:02:25.098444
1744	EUR	CLP	1044.06346092	2026-01-12	2026-01-12 16:02:25.190963
1745	EUR	CNH	8.13034478	2026-01-12	2026-01-12 16:02:25.286504
1746	EUR	CNY	8.13429272	2026-01-12	2026-01-12 16:02:25.324547
1747	EUR	COP	4330.54716242	2026-01-12	2026-01-12 16:02:25.403412
1748	EUR	CRC	579.66628775	2026-01-12	2026-01-12 16:02:25.486309
1749	EUR	CUP	27.95657001	2026-01-12	2026-01-12 16:02:25.530726
1750	EUR	CVE	110.27	2026-01-12	2026-01-12 16:02:25.604098
1751	EUR	CZK	24.25949313	2026-01-12	2026-01-12 16:02:25.698071
1752	EUR	DJF	207.5759168	2026-01-12	2026-01-12 16:02:25.752779
1753	EUR	DKK	7.47222388	2026-01-12	2026-01-12 16:02:25.805629
1754	EUR	DOP	73.98573473	2026-01-12	2026-01-12 16:02:25.888535
1755	EUR	DZD	151.80787215	2026-01-12	2026-01-12 16:02:25.930137
1756	EUR	EGP	55.15294243	2026-01-12	2026-01-12 16:02:25.99571
1757	EUR	ERN	17.48915002	2026-01-12	2026-01-12 16:02:26.081042
1758	EUR	ETB	181.20140322	2026-01-12	2026-01-12 16:02:26.125987
1759	EUR	FJD	2.65639903	2026-01-12	2026-01-12 16:02:26.195198
1760	EUR	FKP	0.86830971	2026-01-12	2026-01-12 16:02:26.2346
1761	EUR	GBP	0.86830971	2026-01-12	2026-01-12 16:02:26.320431
1762	EUR	GEL	3.14204594	2026-01-12	2026-01-12 16:02:26.407977
1763	EUR	GGP	0.86830971	2026-01-12	2026-01-12 16:02:26.480149
1764	EUR	GHS	12.50117716	2026-01-12	2026-01-12 16:02:26.51563
1765	EUR	GIP	0.86830971	2026-01-12	2026-01-12 16:02:26.603178
1766	EUR	GMD	86.11843254	2026-01-12	2026-01-12 16:02:26.645574
1767	EUR	GNF	10206.63457176	2026-01-12	2026-01-12 16:02:26.704812
1768	EUR	GTQ	8.93799095	2026-01-12	2026-01-12 16:02:26.786024
1769	EUR	GYD	243.67508049	2026-01-12	2026-01-12 16:02:26.824839
1770	EUR	HKD	9.08859723	2026-01-12	2026-01-12 16:02:26.892298
1771	EUR	HNL	30.81011884	2026-01-12	2026-01-12 16:02:26.929145
1772	EUR	HRK	7.5345	2026-01-12	2026-01-12 16:02:26.988539
1773	EUR	HTG	152.68638233	2026-01-12	2026-01-12 16:02:27.042051
1774	EUR	HUF	386.05816759	2026-01-12	2026-01-12 16:02:27.100537
1775	EUR	IDR	19645.87932972	2026-01-12	2026-01-12 16:02:27.180196
1776	EUR	ILS	3.66928129	2026-01-12	2026-01-12 16:02:27.229485
1777	EUR	IMP	0.86830971	2026-01-12	2026-01-12 16:02:27.305679
1778	EUR	INR	105.23253946	2026-01-12	2026-01-12 16:02:27.383149
1779	EUR	IQD	1526.98135072	2026-01-12	2026-01-12 16:02:27.425349
1780	EUR	IRR	1163270.86292144	2026-01-12	2026-01-12 16:02:27.490341
1781	EUR	ISK	147.2041025	2026-01-12	2026-01-12 16:02:27.564634
1782	EUR	JEP	0.86830971	2026-01-12	2026-01-12 16:02:27.60568
1783	EUR	JMD	184.54908417	2026-01-12	2026-01-12 16:02:27.681159
1784	EUR	JOD	0.82665382	2026-01-12	2026-01-12 16:02:27.721552
1785	EUR	JPY	183.97105551	2026-01-12	2026-01-12 16:02:27.78913
1786	EUR	KES	150.27778177	2026-01-12	2026-01-12 16:02:27.829403
1787	EUR	KGS	101.93466016	2026-01-12	2026-01-12 16:02:27.900768
1788	EUR	KHR	4687.23164201	2026-01-12	2026-01-12 16:02:27.94642
1789	EUR	KMF	491.96775001	2026-01-12	2026-01-12 16:02:28.06487
1790	EUR	KRW	1705.28861459	2026-01-12	2026-01-12 16:02:28.109305
1791	EUR	KWD	0.3578565	2026-01-12	2026-01-12 16:02:28.165564
1792	EUR	KYD	0.96884178	2026-01-12	2026-01-12 16:02:28.206427
1793	EUR	KZT	595.32419702	2026-01-12	2026-01-12 16:02:28.276903
1794	EUR	LAK	25171.71381721	2026-01-12	2026-01-12 16:02:28.3172
1795	EUR	LBP	104459.34757372	2026-01-12	2026-01-12 16:02:28.368293
1796	EUR	LKR	360.22204597	2026-01-12	2026-01-12 16:02:28.419491
1797	EUR	LRD	209.22117582	2026-01-12	2026-01-12 16:02:28.522812
1798	EUR	LSL	19.1994233	2026-01-12	2026-01-12 16:02:28.564923
1799	EUR	LYD	6.32145734	2026-01-12	2026-01-12 16:02:28.60757
1800	EUR	MAD	10.77643163	2026-01-12	2026-01-12 16:02:28.685542
1801	EUR	MDL	19.55668377	2026-01-12	2026-01-12 16:02:28.728147
1802	EUR	MGA	5371.64718465	2026-01-12	2026-01-12 16:02:28.803876
1803	EUR	MKD	61.59547032	2026-01-12	2026-01-12 16:02:28.842654
1804	EUR	MMK	2448.30305798	2026-01-12	2026-01-12 16:02:28.90846
1805	EUR	MNT	4152.20330066	2026-01-12	2026-01-12 16:02:28.966092
1806	EUR	MOP	9.36125515	2026-01-12	2026-01-12 16:02:29.006907
1807	EUR	MRU	46.30702478	2026-01-12	2026-01-12 16:02:29.092822
1808	EUR	MUR	54.45256425	2026-01-12	2026-01-12 16:02:29.132311
1809	EUR	MVR	18.02535339	2026-01-12	2026-01-12 16:02:29.200822
1810	EUR	MWK	2020.53388786	2026-01-12	2026-01-12 16:02:29.258377
1811	EUR	MXN	20.92026945	2026-01-12	2026-01-12 16:02:29.313069
1812	EUR	MYR	4.74365959	2026-01-12	2026-01-12 16:02:29.364574
1813	EUR	MZN	74.50839813	2026-01-12	2026-01-12 16:02:29.443592
1814	EUR	NAD	19.1994233	2026-01-12	2026-01-12 16:02:29.480798
1815	EUR	NGN	1661.0187077	2026-01-12	2026-01-12 16:02:29.519929
1816	EUR	NIO	42.88505474	2026-01-12	2026-01-12 16:02:29.59385
1817	EUR	NOK	11.75634043	2026-01-12	2026-01-12 16:02:29.637423
1818	EUR	NPR	168.45098755	2026-01-12	2026-01-12 16:02:29.689371
1819	EUR	NZD	2.02939769	2026-01-12	2026-01-12 16:02:29.730974
1820	EUR	OMR	0.44895396	2026-01-12	2026-01-12 16:02:29.799241
1821	EUR	PAB	1.16594333	2026-01-12	2026-01-12 16:02:29.891717
1822	EUR	PEN	3.91808701	2026-01-12	2026-01-12 16:02:29.941674
1823	EUR	PGK	4.97259101	2026-01-12	2026-01-12 16:02:29.998627
1824	EUR	PHP	69.07371351	2026-01-12	2026-01-12 16:02:30.065401
1825	EUR	PKR	326.18429874	2026-01-12	2026-01-12 16:02:30.105723
1826	EUR	PLN	4.2122504	2026-01-12	2026-01-12 16:02:30.185661
1827	EUR	PYG	7706.8829768	2026-01-12	2026-01-12 16:02:30.231394
1828	EUR	QAR	4.24403374	2026-01-12	2026-01-12 16:02:30.291582
1829	EUR	RON	5.09061927	2026-01-12	2026-01-12 16:02:30.344941
1830	EUR	RSD	117.35942675	2026-01-12	2026-01-12 16:02:30.401871
1831	EUR	RUB	92.55378855	2026-01-12	2026-01-12 16:02:30.477015
1832	EUR	RWF	1698.5115687	2026-01-12	2026-01-12 16:02:30.525395
1833	EUR	SAR	4.37228751	2026-01-12	2026-01-12 16:02:30.5773
1834	EUR	SBD	9.45317256	2026-01-12	2026-01-12 16:02:30.628405
1835	EUR	SCR	16.28808536	2026-01-12	2026-01-12 16:02:30.685701
1836	EUR	SDG	699.63793594	2026-01-12	2026-01-12 16:02:30.733512
1837	EUR	SEK	10.71467091	2026-01-12	2026-01-12 16:02:30.798144
1838	EUR	SGD	1.49915243	2026-01-12	2026-01-12 16:02:30.852142
1839	EUR	SHP	0.86830971	2026-01-12	2026-01-12 16:02:30.898034
1840	EUR	SLE	26.59519105	2026-01-12	2026-01-12 16:02:30.93633
1841	EUR	SOS	663.61376195	2026-01-12	2026-01-12 16:02:31.011307
1842	EUR	SRD	44.39255016	2026-01-12	2026-01-12 16:02:31.085715
1843	EUR	SSP	5314.41798451	2026-01-12	2026-01-12 16:02:31.12848
1844	EUR	STN	24.67614062	2026-01-12	2026-01-12 16:02:31.195375
1845	EUR	SYP	128.92644533	2026-01-12	2026-01-12 16:02:31.248108
1846	EUR	SZL	19.1994233	2026-01-12	2026-01-12 16:02:31.296919
1847	EUR	THB	36.4926279	2026-01-12	2026-01-12 16:02:31.337016
1848	EUR	TJS	10.85690446	2026-01-12	2026-01-12 16:02:31.400567
1849	EUR	TMT	4.07888447	2026-01-12	2026-01-12 16:02:31.435626
1850	EUR	TND	3.41642583	2026-01-12	2026-01-12 16:02:31.503707
1851	EUR	TOP	2.79445651	2026-01-12	2026-01-12 16:02:31.586281
1852	EUR	TRY	50.30213222	2026-01-12	2026-01-12 16:02:31.622063
1853	EUR	TTD	7.91448238	2026-01-12	2026-01-12 16:02:31.705232
1854	EUR	TVD	1.74093168	2026-01-12	2026-01-12 16:02:31.765981
1855	EUR	TWD	36.89177787	2026-01-12	2026-01-12 16:02:31.809072
1856	EUR	TZS	2910.77325896	2026-01-12	2026-01-12 16:02:31.893074
1857	EUR	UAH	50.30436463	2026-01-12	2026-01-12 16:02:31.935223
1858	EUR	UGX	4196.85647349	2026-01-12	2026-01-12 16:02:31.999925
1859	EUR	USD	1.16594333	2026-01-12	2026-01-12 16:02:32.08662
1860	EUR	UYU	45.3551315	2026-01-12	2026-01-12 16:02:32.15891
1861	EUR	UZS	14115.10255874	2026-01-12	2026-01-12 16:02:32.201085
1862	EUR	VES	381.8832179	2026-01-12	2026-01-12 16:02:32.268062
1863	EUR	VND	30615.64364642	2026-01-12	2026-01-12 16:02:32.309073
1864	EUR	VUV	140.08031104	2026-01-12	2026-01-12 16:02:32.370941
1865	EUR	WST	3.22659692	2026-01-12	2026-01-12 16:02:32.425011
1866	EUR	XAF	655.95700002	2026-01-12	2026-01-12 16:02:32.465688
1867	EUR	XCD	3.1563281	2026-01-12	2026-01-12 16:02:32.505758
1868	EUR	XDR	0.85430651	2026-01-12	2026-01-12 16:02:32.598219
1869	EUR	XOF	655.95700002	2026-01-12	2026-01-12 16:02:32.632386
1870	EUR	XPF	119.33174225	2026-01-12	2026-01-12 16:02:32.701268
1871	EUR	YER	277.9591195	2026-01-12	2026-01-12 16:02:32.742547
1872	EUR	ZAR	19.1994233	2026-01-12	2026-01-12 16:02:32.815694
1873	EUR	ZMW	22.67625164	2026-01-12	2026-01-12 16:02:32.878507
1874	EUR	ZWL	75059.54941587	2026-01-12	2026-01-12 16:02:32.919815
1875	EUR	AED	4.2819269	2026-01-13	2026-01-13 00:26:14.743102
1876	EUR	AFN	76.95724479	2026-01-13	2026-01-13 00:26:14.786873
1877	EUR	ALL	96.65134173	2026-01-13	2026-01-13 00:26:14.868951
1878	EUR	AMD	444.14009074	2026-01-13	2026-01-13 00:26:14.946482
1879	EUR	ANG	2.09996113	2026-01-13	2026-01-13 00:26:14.973818
1880	EUR	AOA	1063.32629795	2026-01-13	2026-01-13 00:26:15.072806
1881	EUR	ARS	1704.40769921	2026-01-13	2026-01-13 00:26:15.142345
1882	EUR	AUD	1.74093168	2026-01-13	2026-01-13 00:26:15.165227
1883	EUR	AWG	2.08703857	2026-01-13	2026-01-13 00:26:15.19475
1884	EUR	AZN	1.98210367	2026-01-13	2026-01-13 00:26:15.265914
1885	EUR	BAM	1.95583	2026-01-13	2026-01-13 00:26:15.352067
1886	EUR	BBD	2.33188667	2026-01-13	2026-01-13 00:26:15.378022
1887	EUR	BDT	142.41236552	2026-01-13	2026-01-13 00:26:15.464457
1888	EUR	BGN	1.95583	2026-01-13	2026-01-13 00:26:15.486148
1889	EUR	BHD	0.43839469	2026-01-13	2026-01-13 00:26:15.565127
1890	EUR	BIF	3450.1568829	2026-01-13	2026-01-13 00:26:15.587494
1891	EUR	BMD	1.16594333	2026-01-13	2026-01-13 00:26:15.652006
1892	EUR	BND	1.49915243	2026-01-13	2026-01-13 00:26:15.675155
1893	EUR	BOB	8.06831568	2026-01-13	2026-01-13 00:26:15.754068
1894	EUR	BRL	6.28870806	2026-01-13	2026-01-13 00:26:15.775882
1895	EUR	BSD	1.16594333	2026-01-13	2026-01-13 00:26:15.859736
1896	EUR	BTN	105.23253946	2026-01-13	2026-01-13 00:26:15.945358
1897	EUR	BWP	16.05776753	2026-01-13	2026-01-13 00:26:15.967638
1898	EUR	BYN	3.4106848	2026-01-13	2026-01-13 00:26:16.044097
1899	EUR	BZD	2.34749525	2026-01-13	2026-01-13 00:26:16.06817
1900	EUR	CAD	1.61979719	2026-01-13	2026-01-13 00:26:16.150602
1901	EUR	CDF	2502.21042238	2026-01-13	2026-01-13 00:26:16.175235
1902	EUR	CHF	0.93099669	2026-01-13	2026-01-13 00:26:16.262981
1903	EUR	CLP	1044.06346092	2026-01-13	2026-01-13 00:26:16.358666
1904	EUR	CNH	8.13034478	2026-01-13	2026-01-13 00:26:16.379916
1905	EUR	CNY	8.13429272	2026-01-13	2026-01-13 00:26:16.464698
1906	EUR	COP	4330.54716242	2026-01-13	2026-01-13 00:26:16.545877
1907	EUR	CRC	579.66628775	2026-01-13	2026-01-13 00:26:16.579064
1908	EUR	CUP	27.95657001	2026-01-13	2026-01-13 00:26:16.659681
1909	EUR	CVE	110.27	2026-01-13	2026-01-13 00:26:16.684658
1910	EUR	CZK	24.25949313	2026-01-13	2026-01-13 00:26:16.759548
1911	EUR	DJF	207.5759168	2026-01-13	2026-01-13 00:26:16.8464
1912	EUR	DKK	7.47222388	2026-01-13	2026-01-13 00:26:16.872273
1913	EUR	DOP	73.98573473	2026-01-13	2026-01-13 00:26:16.953673
1914	EUR	DZD	151.80787215	2026-01-13	2026-01-13 00:26:16.978475
1915	EUR	EGP	55.15294243	2026-01-13	2026-01-13 00:26:17.06493
1916	EUR	ERN	17.48915002	2026-01-13	2026-01-13 00:26:17.148322
1917	EUR	ETB	181.20140322	2026-01-13	2026-01-13 00:26:17.170983
1918	EUR	FJD	2.65639903	2026-01-13	2026-01-13 00:26:17.246837
1919	EUR	FKP	0.86830971	2026-01-13	2026-01-13 00:26:17.270963
1920	EUR	GBP	0.86830971	2026-01-13	2026-01-13 00:26:17.451887
1921	EUR	GEL	3.14204594	2026-01-13	2026-01-13 00:26:17.475498
1922	EUR	GGP	0.86830971	2026-01-13	2026-01-13 00:26:17.554725
1923	EUR	GHS	12.50117716	2026-01-13	2026-01-13 00:26:17.643921
1924	EUR	GIP	0.86830971	2026-01-13	2026-01-13 00:26:17.667805
1925	EUR	GMD	86.11843254	2026-01-13	2026-01-13 00:26:17.751719
1926	EUR	GNF	10206.63457176	2026-01-13	2026-01-13 00:26:17.777737
1927	EUR	GTQ	8.93799095	2026-01-13	2026-01-13 00:26:17.864708
1928	EUR	GYD	243.67508049	2026-01-13	2026-01-13 00:26:17.946602
1929	EUR	HKD	9.08859723	2026-01-13	2026-01-13 00:26:17.973627
1930	EUR	HNL	30.81011884	2026-01-13	2026-01-13 00:26:18.058121
1931	EUR	HRK	7.5345	2026-01-13	2026-01-13 00:26:18.145477
1932	EUR	HTG	152.68638233	2026-01-13	2026-01-13 00:26:18.183305
1933	EUR	HUF	386.05816759	2026-01-13	2026-01-13 00:26:18.250437
1934	EUR	IDR	19645.87932972	2026-01-13	2026-01-13 00:26:18.277171
1935	EUR	ILS	3.66928129	2026-01-13	2026-01-13 00:26:18.357314
1936	EUR	IMP	0.86830971	2026-01-13	2026-01-13 00:26:18.442753
1937	EUR	INR	105.23253946	2026-01-13	2026-01-13 00:26:18.467493
1938	EUR	IQD	1526.98135072	2026-01-13	2026-01-13 00:26:18.552217
1939	EUR	IRR	1163270.86292144	2026-01-13	2026-01-13 00:26:18.580245
1940	EUR	ISK	147.2041025	2026-01-13	2026-01-13 00:26:18.650996
1941	EUR	JEP	0.86830971	2026-01-13	2026-01-13 00:26:18.748046
1942	EUR	JMD	184.54908417	2026-01-13	2026-01-13 00:26:18.772696
1943	EUR	JOD	0.82665382	2026-01-13	2026-01-13 00:26:18.856081
1944	EUR	JPY	183.97105551	2026-01-13	2026-01-13 00:26:18.881262
1945	EUR	KES	150.27778177	2026-01-13	2026-01-13 00:26:18.961075
1946	EUR	KGS	101.93466016	2026-01-13	2026-01-13 00:26:19.041927
1947	EUR	KHR	4687.23164201	2026-01-13	2026-01-13 00:26:19.073099
1948	EUR	KMF	491.96775001	2026-01-13	2026-01-13 00:26:19.171099
1949	EUR	KRW	1705.28861459	2026-01-13	2026-01-13 00:26:19.26228
1950	EUR	KWD	0.3578565	2026-01-13	2026-01-13 00:26:19.35122
1951	EUR	KYD	0.96884178	2026-01-13	2026-01-13 00:26:19.376771
1952	EUR	KZT	595.32419702	2026-01-13	2026-01-13 00:26:19.453492
1953	EUR	LAK	25171.71381721	2026-01-13	2026-01-13 00:26:19.477131
1954	EUR	LBP	104459.34757372	2026-01-13	2026-01-13 00:26:19.565254
1955	EUR	LKR	360.22204597	2026-01-13	2026-01-13 00:26:19.645175
1956	EUR	LRD	209.22117582	2026-01-13	2026-01-13 00:26:19.668959
1957	EUR	LSL	19.1994233	2026-01-13	2026-01-13 00:26:19.754773
1958	EUR	LYD	6.32145734	2026-01-13	2026-01-13 00:26:19.778651
1959	EUR	MAD	10.77643163	2026-01-13	2026-01-13 00:26:19.866095
1960	EUR	MDL	19.55668377	2026-01-13	2026-01-13 00:26:19.953902
1961	EUR	MGA	5371.64718465	2026-01-13	2026-01-13 00:26:19.979472
1962	EUR	MKD	61.59547032	2026-01-13	2026-01-13 00:26:20.060459
1963	EUR	MMK	2448.30305798	2026-01-13	2026-01-13 00:26:20.142804
1964	EUR	MNT	4152.20330066	2026-01-13	2026-01-13 00:26:20.168883
1965	EUR	MOP	9.36125515	2026-01-13	2026-01-13 00:26:20.247132
1966	EUR	MRU	46.30702478	2026-01-13	2026-01-13 00:26:20.269409
1967	EUR	MUR	54.45256425	2026-01-13	2026-01-13 00:26:20.352417
1968	EUR	MVR	18.02535339	2026-01-13	2026-01-13 00:26:20.376055
1969	EUR	MWK	2020.53388786	2026-01-13	2026-01-13 00:26:20.453069
1970	EUR	MXN	20.92026945	2026-01-13	2026-01-13 00:26:20.542225
1971	EUR	MYR	4.74365959	2026-01-13	2026-01-13 00:26:20.570635
1972	EUR	MZN	74.50839813	2026-01-13	2026-01-13 00:26:20.654018
1973	EUR	NAD	19.1994233	2026-01-13	2026-01-13 00:26:20.679962
1974	EUR	NGN	1661.0187077	2026-01-13	2026-01-13 00:26:20.761091
1975	EUR	NIO	42.88505474	2026-01-13	2026-01-13 00:26:20.781117
1976	EUR	NOK	11.75634043	2026-01-13	2026-01-13 00:26:20.864255
1977	EUR	NPR	168.45098755	2026-01-13	2026-01-13 00:26:20.944862
1978	EUR	NZD	2.02939769	2026-01-13	2026-01-13 00:26:20.968696
1979	EUR	OMR	0.44895396	2026-01-13	2026-01-13 00:26:21.050307
1980	EUR	PAB	1.16594333	2026-01-13	2026-01-13 00:26:21.071217
1981	EUR	PEN	3.91808701	2026-01-13	2026-01-13 00:26:21.093414
1982	EUR	PGK	4.97259101	2026-01-13	2026-01-13 00:26:21.242934
1983	EUR	PHP	69.07371351	2026-01-13	2026-01-13 00:26:21.265655
1984	EUR	PKR	326.18429874	2026-01-13	2026-01-13 00:26:21.444395
1985	EUR	PLN	4.2122504	2026-01-13	2026-01-13 00:26:21.646005
1986	EUR	PYG	7706.8829768	2026-01-13	2026-01-13 00:26:22.053196
1987	EUR	QAR	4.24403374	2026-01-13	2026-01-13 00:26:22.168842
1988	EUR	RON	5.09061927	2026-01-13	2026-01-13 00:26:22.343119
1989	EUR	RSD	117.35942675	2026-01-13	2026-01-13 00:26:22.4706
1990	EUR	RUB	92.55378855	2026-01-13	2026-01-13 00:26:22.653332
1991	EUR	RWF	1698.5115687	2026-01-13	2026-01-13 00:26:22.75268
1992	EUR	SAR	4.37228751	2026-01-13	2026-01-13 00:26:22.856939
1993	EUR	SBD	9.45317256	2026-01-13	2026-01-13 00:26:22.961486
1994	EUR	SCR	16.28808536	2026-01-13	2026-01-13 00:26:23.069959
1995	EUR	SDG	699.63793594	2026-01-13	2026-01-13 00:26:23.242111
1996	EUR	SEK	10.71467091	2026-01-13	2026-01-13 00:26:23.36368
1998	EUR	SGD	1.49915243	2026-01-13	2026-01-13 00:26:23.566454
2000	EUR	SHP	0.86830971	2026-01-13	2026-01-13 00:26:23.643193
2001	EUR	SLE	26.59519105	2026-01-13	2026-01-13 00:26:23.943769
2003	EUR	SOS	663.61376195	2026-01-13	2026-01-13 00:26:24.158584
2005	EUR	SRD	44.39255016	2026-01-13	2026-01-13 00:26:24.442444
2007	EUR	SSP	5314.41798451	2026-01-13	2026-01-13 00:26:24.543127
2009	EUR	STN	24.67614062	2026-01-13	2026-01-13 00:26:24.743472
2011	EUR	SYP	128.92644533	2026-01-13	2026-01-13 00:26:25.042093
2013	EUR	SZL	19.1994233	2026-01-13	2026-01-13 00:26:25.342091
2015	EUR	THB	36.4926279	2026-01-13	2026-01-13 00:26:25.641982
2017	EUR	TJS	10.85690446	2026-01-13	2026-01-13 00:26:25.857752
2019	EUR	TMT	4.07888447	2026-01-13	2026-01-13 00:26:26.241967
2021	EUR	TND	3.41642583	2026-01-13	2026-01-13 00:26:26.555571
2023	EUR	TOP	2.79445651	2026-01-13	2026-01-13 00:26:27.042906
2025	EUR	TRY	50.30213222	2026-01-13	2026-01-13 00:26:27.162729
2027	EUR	TTD	7.91448238	2026-01-13	2026-01-13 00:26:27.742765
2029	EUR	TVD	1.74093168	2026-01-13	2026-01-13 00:26:27.942153
2031	EUR	TWD	36.89177787	2026-01-13	2026-01-13 00:26:28.155192
2033	EUR	TZS	2910.77325896	2026-01-13	2026-01-13 00:26:28.34198
2035	EUR	UAH	50.30436463	2026-01-13	2026-01-13 00:26:28.542156
2037	EUR	UGX	4196.85647349	2026-01-13	2026-01-13 00:26:28.767269
2039	EUR	USD	1.16594333	2026-01-13	2026-01-13 00:26:28.769852
2040	EUR	UYU	45.3551315	2026-01-13	2026-01-13 00:26:29.043198
2042	EUR	UZS	14115.10255874	2026-01-13	2026-01-13 00:26:29.156612
2044	EUR	VES	381.8832179	2026-01-13	2026-01-13 00:26:29.273766
2046	EUR	VND	30615.64364642	2026-01-13	2026-01-13 00:26:29.443263
2048	EUR	VUV	140.08031104	2026-01-13	2026-01-13 00:26:29.654501
2050	EUR	WST	3.22659692	2026-01-13	2026-01-13 00:26:29.763245
2052	EUR	XAF	655.95700002	2026-01-13	2026-01-13 00:26:29.865338
2054	EUR	XCD	3.1563281	2026-01-13	2026-01-13 00:26:30.061843
2056	EUR	XDR	0.85430651	2026-01-13	2026-01-13 00:26:30.161175
2058	EUR	XOF	655.95700002	2026-01-13	2026-01-13 00:26:30.262883
2060	EUR	XPF	119.33174225	2026-01-13	2026-01-13 00:26:30.441981
2062	EUR	YER	277.9591195	2026-01-13	2026-01-13 00:26:30.37171
2063	EUR	ZAR	19.1994233	2026-01-13	2026-01-13 00:26:30.542863
2065	EUR	ZMW	22.67625164	2026-01-13	2026-01-13 00:26:30.641946
2067	EUR	ZWL	75059.54941587	2026-01-13	2026-01-13 00:26:30.761629
2069	EUR	AED	4.27423046	2026-01-15	2026-01-15 23:45:16.601257
2070	EUR	AFN	76.10589477	2026-01-15	2026-01-15 23:45:16.887935
2071	EUR	ALL	96.48596338	2026-01-15	2026-01-15 23:45:17.094536
2072	EUR	AMD	440.38163558	2026-01-15	2026-01-15 23:45:17.384981
2073	EUR	ANG	2.09836231	2026-01-15	2026-01-15 23:45:17.601
2074	EUR	AOA	1067.76736776	2026-01-15	2026-01-15 23:45:17.796248
2075	EUR	ARS	1691.74769523	2026-01-15	2026-01-15 23:45:18.092283
2076	EUR	AUD	1.74257908	2026-01-15	2026-01-15 23:45:18.297222
2077	EUR	AWG	2.08328727	2026-01-15	2026-01-15 23:45:18.588993
2078	EUR	AZN	1.9785409	2026-01-15	2026-01-15 23:45:19.069623
2079	EUR	BAM	1.95583	2026-01-15	2026-01-15 23:45:19.682576
2080	EUR	BBD	2.32769528	2026-01-15	2026-01-15 23:45:20.269438
2082	EUR	BDT	142.3069019	2026-01-15	2026-01-15 23:45:21.170481
2084	EUR	BGN	1.95583	2026-01-15	2026-01-15 23:45:22.070576
2087	EUR	BIF	3447.68678264	2026-01-15	2026-01-15 23:45:23.869012
2086	EUR	BHD	0.43760671	2026-01-15	2026-01-15 23:45:23.87083
2172	EUR	FKP	0.86642818	2026-01-15	2026-01-15 23:45:52.96801
2089	EUR	BMD	1.16384764	2026-01-15	2026-01-15 23:45:26.369959
2091	EUR	BND	1.49867438	2026-01-15	2026-01-15 23:45:26.46895
2123	EUR	CLP	1026.35062798	2026-01-15	2026-01-15 23:45:37.668416
2094	EUR	BOB	8.05522871	2026-01-15	2026-01-15 23:45:27.468633
2097	EUR	BRL	6.2816148	2026-01-15	2026-01-15 23:45:28.570739
2144	EUR	CZK	24.25042572	2026-01-15	2026-01-15 23:45:44.269471
2100	EUR	BSD	1.16384764	2026-01-15	2026-01-15 23:45:29.770567
2102	EUR	BTN	105.04315024	2026-01-15	2026-01-15 23:45:30.270095
2126	EUR	CNH	8.10614146	2026-01-15	2026-01-15 23:45:38.568516
2105	EUR	BWP	16.00378171	2026-01-15	2026-01-15 23:45:31.269249
2108	EUR	BYN	3.38140386	2026-01-15	2026-01-15 23:45:32.169543
2111	EUR	BZD	2.34374121	2026-01-15	2026-01-15 23:45:33.170441
2129	EUR	CNY	8.11002929	2026-01-15	2026-01-15 23:45:39.169834
2114	EUR	CAD	1.61656414	2026-01-15	2026-01-15 23:45:34.068933
2117	EUR	CDF	2652.02032736	2026-01-15	2026-01-15 23:45:35.070186
2160	EUR	DZD	151.34314487	2026-01-15	2026-01-15 23:45:48.567748
2120	EUR	CHF	0.93082887	2026-01-15	2026-01-15 23:45:35.970658
2132	EUR	COP	4276.88581497	2026-01-15	2026-01-15 23:45:40.170234
2135	EUR	CRC	576.88690149	2026-01-15	2026-01-15 23:45:41.068207
2149	EUR	DJF	207.28582544	2026-01-15	2026-01-15 23:45:45.070187
2138	EUR	CUP	27.95100973	2026-01-15	2026-01-15 23:45:42.16898
2163	EUR	EGP	55.05954484	2026-01-15	2026-01-15 23:45:49.570896
2141	EUR	CVE	110.27	2026-01-15	2026-01-15 23:45:43.270221
2165	EUR	ERN	17.45771459	2026-01-15	2026-01-15 23:45:50.568998
2153	EUR	DKK	7.47201841	2026-01-15	2026-01-15 23:45:46.069873
2157	EUR	DOP	74.15282693	2026-01-15	2026-01-15 23:45:47.167817
2167	EUR	ETB	181.25772081	2026-01-15	2026-01-15 23:45:51.468301
2169	EUR	FJD	2.65246786	2026-01-15	2026-01-15 23:45:52.270472
2173	EUR	GBP	0.86642818	2026-01-15	2026-01-15 23:45:54.08748
2174	EUR	GEL	3.13524782	2026-01-15	2026-01-15 23:45:54.288148
2175	EUR	GGP	0.86642818	2026-01-15	2026-01-15 23:45:54.48919
2176	EUR	GHS	12.55063505	2026-01-15	2026-01-15 23:45:54.790511
2177	EUR	GIP	0.86642818	2026-01-15	2026-01-15 23:45:54.994144
2178	EUR	GMD	85.65998795	2026-01-15	2026-01-15 23:45:55.190491
2179	EUR	GNF	10190.39967813	2026-01-15	2026-01-15 23:45:55.389079
2180	EUR	GTQ	8.92483739	2026-01-15	2026-01-15 23:45:55.591131
2181	EUR	GYD	243.61424006	2026-01-15	2026-01-15 23:45:55.795865
2182	EUR	HKD	9.07360556	2026-01-15	2026-01-15 23:45:55.99363
2183	EUR	HNL	30.77841095	2026-01-15	2026-01-15 23:45:56.191184
2184	EUR	HRK	7.5345	2026-01-15	2026-01-15 23:45:56.393124
2185	EUR	HTG	152.61134513	2026-01-15	2026-01-15 23:45:56.667868
2186	EUR	HUF	386.43395593	2026-01-15	2026-01-15 23:45:56.885734
2187	EUR	IDR	19621.43847312	2026-01-15	2026-01-15 23:45:57.087078
2188	EUR	ILS	3.67245006	2026-01-15	2026-01-15 23:45:57.288476
2189	EUR	IMP	0.86642818	2026-01-15	2026-01-15 23:45:57.488967
2190	EUR	INR	105.04315024	2026-01-15	2026-01-15 23:45:57.786173
2191	EUR	IQD	1525.43328243	2026-01-15	2026-01-15 23:45:58.071205
2192	EUR	IRR	1241319.90434728	2026-01-15	2026-01-15 23:45:58.370406
2193	EUR	ISK	146.00035552	2026-01-15	2026-01-15 23:45:58.593005
2194	EUR	JEP	0.86642818	2026-01-15	2026-01-15 23:45:58.797092
2195	EUR	JMD	183.92377286	2026-01-15	2026-01-15 23:45:58.985055
2196	EUR	JOD	0.82516798	2026-01-15	2026-01-15 23:45:59.187813
2197	EUR	JPY	184.29976917	2026-01-15	2026-01-15 23:45:59.388258
2198	EUR	KES	150.20365218	2026-01-15	2026-01-15 23:45:59.593864
2199	EUR	KGS	101.77510639	2026-01-15	2026-01-15 23:45:59.790074
2200	EUR	KHR	4692.83571803	2026-01-15	2026-01-15 23:46:00.092557
2201	EUR	KMF	491.96774999	2026-01-15	2026-01-15 23:46:00.486455
2202	EUR	KRW	1710.32083798	2026-01-15	2026-01-15 23:46:00.688793
2203	EUR	KWD	0.35795623	2026-01-15	2026-01-15 23:46:00.900326
2204	EUR	KYD	0.96803189	2026-01-15	2026-01-15 23:46:01.092459
2205	EUR	KZT	594.49670828	2026-01-15	2026-01-15 23:46:01.303799
2206	EUR	LAK	25147.386215	2026-01-15	2026-01-15 23:46:01.592815
2207	EUR	LBP	104614.58584786	2026-01-15	2026-01-15 23:46:01.80291
2208	EUR	LKR	360.36833712	2026-01-15	2026-01-15 23:46:02.003551
2209	EUR	LRD	209.76583082	2026-01-15	2026-01-15 23:46:02.280458
2210	EUR	LSL	19.09171267	2026-01-15	2026-01-15 23:46:02.492128
2211	EUR	LYD	6.32593617	2026-01-15	2026-01-15 23:46:02.693114
2212	EUR	MAD	10.7249292	2026-01-15	2026-01-15 23:46:02.996407
2213	EUR	MDL	19.85896614	2026-01-15	2026-01-15 23:46:03.268971
2214	EUR	MGA	5397.69727374	2026-01-15	2026-01-15 23:46:03.481306
2215	EUR	MKD	61.52663593	2026-01-15	2026-01-15 23:46:03.695179
2216	EUR	MMK	2443.86079403	2026-01-15	2026-01-15 23:46:03.990773
2217	EUR	MNT	4147.8136955	2026-01-15	2026-01-15 23:46:04.188402
2218	EUR	MOP	9.34581373	2026-01-15	2026-01-15 23:46:04.482779
2219	EUR	MRU	46.43789784	2026-01-15	2026-01-15 23:46:04.68919
2220	EUR	MUR	53.70760461	2026-01-15	2026-01-15 23:46:04.880766
2221	EUR	MVR	17.9916806	2026-01-15	2026-01-15 23:46:05.082769
2222	EUR	MWK	2018.87937232	2026-01-15	2026-01-15 23:46:05.282814
2223	EUR	MXN	20.71283221	2026-01-15	2026-01-15 23:46:05.484579
2224	EUR	MYR	4.71263536	2026-01-15	2026-01-15 23:46:05.702724
2225	EUR	MZN	74.36604591	2026-01-15	2026-01-15 23:46:05.901536
2226	EUR	NAD	19.09171267	2026-01-15	2026-01-15 23:46:06.095763
2227	EUR	NGN	1655.98879956	2026-01-15	2026-01-15 23:46:06.293654
2228	EUR	NIO	42.8402173	2026-01-15	2026-01-15 23:46:06.56811
2229	EUR	NOK	11.71377686	2026-01-15	2026-01-15 23:46:06.788747
2230	EUR	NPR	168.14782274	2026-01-15	2026-01-15 23:46:06.992719
2231	EUR	NZD	2.02846047	2026-01-15	2026-01-15 23:46:07.189326
2232	EUR	OMR	0.44788004	2026-01-15	2026-01-15 23:46:07.387418
2233	EUR	PAB	1.16384764	2026-01-15	2026-01-15 23:46:07.596175
2234	EUR	PEN	3.91158547	2026-01-15	2026-01-15 23:46:07.793456
2235	EUR	PGK	4.96873981	2026-01-15	2026-01-15 23:46:07.997609
2236	EUR	PHP	69.16524936	2026-01-15	2026-01-15 23:46:08.381242
2237	EUR	PKR	325.95994353	2026-01-15	2026-01-15 23:46:08.668459
2238	EUR	PLN	4.21118509	2026-01-15	2026-01-15 23:46:08.885393
2239	EUR	PYG	7709.81515782	2026-01-15	2026-01-15 23:46:09.170133
2240	EUR	QAR	4.23640541	2026-01-15	2026-01-15 23:46:09.396018
2241	EUR	RON	5.08829437	2026-01-15	2026-01-15 23:46:09.699307
2242	EUR	RSD	117.35019859	2026-01-15	2026-01-15 23:46:09.995417
2243	EUR	RUB	91.36000354	2026-01-15	2026-01-15 23:48:57.572041
2244	EUR	RWF	1697.54063751	2026-01-15	2026-01-15 23:48:57.776824
2245	EUR	SAR	4.36442865	2026-01-15	2026-01-15 23:48:57.978932
2246	EUR	SBD	9.45159057	2026-01-15	2026-01-15 23:48:58.182219
2247	EUR	SCR	16.65371965	2026-01-15	2026-01-15 23:48:58.477849
2248	EUR	SDG	698.11762519	2026-01-15	2026-01-15 23:48:58.688062
2249	EUR	SEK	10.70736616	2026-01-15	2026-01-15 23:48:58.96899
2250	EUR	SGD	1.49867438	2026-01-15	2026-01-15 23:48:59.1874
2251	EUR	SHP	0.86642818	2026-01-15	2026-01-15 23:48:59.481985
2252	EUR	SLE	26.72787843	2026-01-15	2026-01-15 23:48:59.780617
2253	EUR	SOS	660.8008188	2026-01-15	2026-01-15 23:49:00.07325
2254	EUR	SRD	44.60625197	2026-01-15	2026-01-15 23:49:00.281893
2255	EUR	SSP	5293.07892932	2026-01-15	2026-01-15 23:49:00.481436
2256	EUR	STN	24.66952623	2026-01-15	2026-01-15 23:49:00.683397
2257	EUR	SYP	128.73476434	2026-01-15	2026-01-15 23:49:00.969601
2258	EUR	SZL	19.09171267	2026-01-15	2026-01-15 23:49:01.17798
2259	EUR	THB	36.64930113	2026-01-15	2026-01-15 23:49:01.382601
2260	EUR	TJS	10.83020916	2026-01-15	2026-01-15 23:49:01.588508
2261	EUR	TMT	4.08092692	2026-01-15	2026-01-15 23:49:01.879503
2262	EUR	TND	3.36504987	2026-01-15	2026-01-15 23:49:02.079863
2263	EUR	TOP	2.79252556	2026-01-15	2026-01-15 23:49:02.282073
2264	EUR	TRY	50.25748126	2026-01-15	2026-01-15 23:49:02.487656
2265	EUR	TTD	7.90311928	2026-01-15	2026-01-15 23:49:02.768652
2266	EUR	TVD	1.74257908	2026-01-15	2026-01-15 23:49:02.976996
2267	EUR	TWD	36.72716938	2026-01-15	2026-01-15 23:49:03.185178
2268	EUR	TZS	2917.37260505	2026-01-15	2026-01-15 23:49:03.569146
2269	EUR	UAH	50.44682232	2026-01-15	2026-01-15 23:49:03.776628
2270	EUR	UGX	4143.51493058	2026-01-15	2026-01-15 23:49:03.977152
2271	EUR	USD	1.16384764	2026-01-15	2026-01-15 23:49:04.176154
2272	EUR	UYU	45.1019236	2026-01-15	2026-01-15 23:49:04.380798
2273	EUR	UZS	13996.32886923	2026-01-15	2026-01-15 23:49:04.581675
2274	EUR	VES	393.78529449	2026-01-15	2026-01-15 23:49:04.779434
2275	EUR	VND	30634.67886302	2026-01-15	2026-01-15 23:49:04.980092
2276	EUR	VUV	140.9211507	2026-01-15	2026-01-15 23:49:05.178505
2277	EUR	WST	3.22366478	2026-01-15	2026-01-15 23:49:05.380102
2278	EUR	XAF	655.95699999	2026-01-15	2026-01-15 23:49:05.590289
2279	EUR	XCD	3.14938427	2026-01-15	2026-01-15 23:49:05.78542
2280	EUR	XDR	0.85271827	2026-01-15	2026-01-15 23:49:06.077373
2281	EUR	XOF	655.95699999	2026-01-15	2026-01-15 23:49:06.276911
2282	EUR	XPF	119.33174224	2026-01-15	2026-01-15 23:49:06.469884
2283	EUR	YER	277.48725254	2026-01-15	2026-01-15 23:49:06.775817
2284	EUR	ZAR	19.09171267	2026-01-15	2026-01-15 23:49:06.983913
2285	EUR	ZMW	22.98343558	2026-01-15	2026-01-15 23:49:07.184929
2286	EUR	ZWL	74745.27400061	2026-01-15	2026-01-15 23:49:07.476418
2287	EUR	AED	4.27423046	2026-01-16	2026-01-16 09:06:11.86812
2288	EUR	AFN	76.10589477	2026-01-16	2026-01-16 09:06:12.087907
2289	EUR	ALL	96.48596338	2026-01-16	2026-01-16 09:06:12.369528
2290	EUR	AMD	440.38163558	2026-01-16	2026-01-16 09:06:12.589472
2291	EUR	ANG	2.09836231	2026-01-16	2026-01-16 09:06:12.792957
2292	EUR	AOA	1067.76736776	2026-01-16	2026-01-16 09:06:13.068195
2293	EUR	ARS	1691.74769523	2026-01-16	2026-01-16 09:06:13.268119
2294	EUR	AUD	1.74257908	2026-01-16	2026-01-16 09:06:13.469444
2295	EUR	AWG	2.08328727	2026-01-16	2026-01-16 09:06:13.688918
2296	EUR	AZN	1.9785409	2026-01-16	2026-01-16 09:06:13.892646
2297	EUR	BAM	1.95583	2026-01-16	2026-01-16 09:06:14.167875
2298	EUR	BBD	2.32769528	2026-01-16	2026-01-16 09:06:14.395236
2299	EUR	BDT	142.3069019	2026-01-16	2026-01-16 09:06:14.692883
2300	EUR	BGN	1.95583	2026-01-16	2026-01-16 09:06:14.894539
2301	EUR	BHD	0.43760671	2026-01-16	2026-01-16 09:06:15.193559
2302	EUR	BIF	3447.68678264	2026-01-16	2026-01-16 09:06:15.469322
2303	EUR	BMD	1.16384764	2026-01-16	2026-01-16 09:06:15.702784
2304	EUR	BND	1.49867438	2026-01-16	2026-01-16 09:06:15.995217
2305	EUR	BOB	8.05522871	2026-01-16	2026-01-16 09:06:16.293539
2306	EUR	BRL	6.2816148	2026-01-16	2026-01-16 09:06:16.592433
2307	EUR	BSD	1.16384764	2026-01-16	2026-01-16 09:06:16.871186
2308	EUR	BTN	105.04315024	2026-01-16	2026-01-16 09:06:17.17201
2309	EUR	BWP	16.00378171	2026-01-16	2026-01-16 09:06:17.489546
2310	EUR	BYN	3.38140386	2026-01-16	2026-01-16 09:06:17.787528
2311	EUR	BZD	2.34374121	2026-01-16	2026-01-16 09:06:18.069724
2312	EUR	CAD	1.61656414	2026-01-16	2026-01-16 09:06:18.368985
2313	EUR	CDF	2652.02032736	2026-01-16	2026-01-16 09:06:18.599345
2314	EUR	CHF	0.93082887	2026-01-16	2026-01-16 09:06:18.884179
2315	EUR	CLP	1026.35062798	2026-01-16	2026-01-16 09:06:19.395295
2316	EUR	CNH	8.10614146	2026-01-16	2026-01-16 09:06:19.679079
2317	EUR	CNY	8.11002929	2026-01-16	2026-01-16 09:06:19.885491
2318	EUR	COP	4276.88581497	2026-01-16	2026-01-16 09:06:20.179754
2319	EUR	CRC	576.88690149	2026-01-16	2026-01-16 09:06:20.469764
2320	EUR	CUP	27.95100973	2026-01-16	2026-01-16 09:06:20.695541
2321	EUR	CVE	110.27	2026-01-16	2026-01-16 09:06:20.983192
2322	EUR	CZK	24.25042572	2026-01-16	2026-01-16 09:06:21.195658
2323	EUR	DJF	207.28582544	2026-01-16	2026-01-16 09:06:21.492002
2324	EUR	DKK	7.47201841	2026-01-16	2026-01-16 09:06:21.784485
2325	EUR	DOP	74.15282693	2026-01-16	2026-01-16 09:06:22.069512
2326	EUR	DZD	151.34314487	2026-01-16	2026-01-16 09:06:22.296192
2327	EUR	EGP	55.05954484	2026-01-16	2026-01-16 09:06:22.593174
2328	EUR	ERN	17.45771459	2026-01-16	2026-01-16 09:06:22.789848
2329	EUR	ETB	181.25772081	2026-01-16	2026-01-16 09:06:23.094188
2330	EUR	FJD	2.65246786	2026-01-16	2026-01-16 09:06:23.299872
2331	EUR	FKP	0.86642818	2026-01-16	2026-01-16 09:06:23.58668
2332	EUR	GBP	0.86642818	2026-01-16	2026-01-16 09:06:24.069821
2333	EUR	GEL	3.13524782	2026-01-16	2026-01-16 09:06:24.302496
2334	EUR	GGP	0.86642818	2026-01-16	2026-01-16 09:06:24.582997
2335	EUR	GHS	12.55063505	2026-01-16	2026-01-16 09:06:24.78777
2336	EUR	GIP	0.86642818	2026-01-16	2026-01-16 09:06:25.069399
2337	EUR	GMD	85.65998795	2026-01-16	2026-01-16 09:06:25.291374
2338	EUR	GNF	10190.39967813	2026-01-16	2026-01-16 09:06:25.592566
2339	EUR	GTQ	8.92483739	2026-01-16	2026-01-16 09:06:25.870103
2340	EUR	GYD	243.61424006	2026-01-16	2026-01-16 09:06:26.182745
2341	EUR	HKD	9.07360556	2026-01-16	2026-01-16 09:06:26.390928
2342	EUR	HNL	30.77841095	2026-01-16	2026-01-16 09:06:26.667798
2343	EUR	HRK	7.5345	2026-01-16	2026-01-16 09:06:26.86948
2344	EUR	HTG	152.61134513	2026-01-16	2026-01-16 09:06:27.091233
2345	EUR	HUF	386.43395593	2026-01-16	2026-01-16 09:06:27.291604
2346	EUR	IDR	19621.43847312	2026-01-16	2026-01-16 09:06:28.171689
2347	EUR	ILS	3.67245006	2026-01-16	2026-01-16 09:06:28.486652
2348	EUR	IMP	0.86642818	2026-01-16	2026-01-16 09:06:28.971325
2349	EUR	INR	105.04315024	2026-01-16	2026-01-16 09:06:29.467537
2350	EUR	IQD	1525.43328243	2026-01-16	2026-01-16 09:06:29.977598
2352	EUR	ISK	146.00035552	2026-01-16	2026-01-16 09:06:31.469917
2351	EUR	IRR	1241319.90434728	2026-01-16	2026-01-16 09:06:31.669333
2354	EUR	JEP	0.86642818	2026-01-16	2026-01-16 09:06:32.670281
2356	EUR	JMD	183.92377286	2026-01-16	2026-01-16 09:06:33.86925
2358	EUR	JOD	0.82516798	2026-01-16	2026-01-16 09:06:34.770876
2360	EUR	JPY	184.29976917	2026-01-16	2026-01-16 09:06:35.769569
2362	EUR	KES	150.20365218	2026-01-16	2026-01-16 09:06:36.570764
2364	EUR	KGS	101.77510639	2026-01-16	2026-01-16 09:06:37.571667
2366	EUR	KHR	4692.83571803	2026-01-16	2026-01-16 09:06:38.269388
2368	EUR	KMF	491.96774999	2026-01-16	2026-01-16 09:06:39.870335
2370	EUR	KRW	1710.32083798	2026-01-16	2026-01-16 09:06:40.669258
2372	EUR	KWD	0.35795623	2026-01-16	2026-01-16 09:06:41.368892
2374	EUR	KYD	0.96803189	2026-01-16	2026-01-16 09:06:41.782544
2376	EUR	KZT	594.49670828	2026-01-16	2026-01-16 09:06:42.368876
2378	EUR	LAK	25147.386215	2026-01-16	2026-01-16 09:06:42.869285
2379	EUR	LBP	104614.58584786	2026-01-16	2026-01-16 09:06:43.47949
2380	EUR	LKR	360.36833712	2026-01-16	2026-01-16 09:06:43.698156
2381	EUR	LRD	209.76583082	2026-01-16	2026-01-16 09:06:43.893653
2382	EUR	LSL	19.09171267	2026-01-16	2026-01-16 09:06:44.18427
2383	EUR	LYD	6.32593617	2026-01-16	2026-01-16 09:06:44.398409
2384	EUR	MAD	10.7249292	2026-01-16	2026-01-16 09:06:44.669651
2385	EUR	MDL	19.85896614	2026-01-16	2026-01-16 09:06:44.885175
2386	EUR	MGA	5397.69727374	2026-01-16	2026-01-16 09:06:45.094866
2387	EUR	MKD	61.52663593	2026-01-16	2026-01-16 09:06:45.38389
2388	EUR	MMK	2443.86079403	2026-01-16	2026-01-16 09:06:45.667907
2389	EUR	MNT	4147.8136955	2026-01-16	2026-01-16 09:06:45.888932
2390	EUR	MOP	9.34581373	2026-01-16	2026-01-16 09:06:46.182723
2391	EUR	MRU	46.43789784	2026-01-16	2026-01-16 09:06:46.384991
2392	EUR	MUR	53.70760461	2026-01-16	2026-01-16 09:06:46.587958
2393	EUR	MVR	17.9916806	2026-01-16	2026-01-16 09:06:46.794149
2394	EUR	MWK	2018.87937232	2026-01-16	2026-01-16 09:06:47.000483
2395	EUR	MXN	20.71283221	2026-01-16	2026-01-16 09:06:47.202944
2396	EUR	MYR	4.71263536	2026-01-16	2026-01-16 09:06:47.479658
2397	EUR	MZN	74.36604591	2026-01-16	2026-01-16 09:06:47.690817
2398	EUR	NAD	19.09171267	2026-01-16	2026-01-16 09:06:47.892838
2399	EUR	NGN	1655.98879956	2026-01-16	2026-01-16 09:06:48.189325
2400	EUR	NIO	42.8402173	2026-01-16	2026-01-16 09:06:48.389643
2401	EUR	NOK	11.71377686	2026-01-16	2026-01-16 09:06:48.668199
2402	EUR	NPR	168.14782274	2026-01-16	2026-01-16 09:06:48.969828
2403	EUR	NZD	2.02846047	2026-01-16	2026-01-16 09:06:49.18963
2404	EUR	OMR	0.44788004	2026-01-16	2026-01-16 09:06:49.485369
2405	EUR	PAB	1.16384764	2026-01-16	2026-01-16 09:06:49.768847
2406	EUR	PEN	3.91158547	2026-01-16	2026-01-16 09:06:50.00015
2407	EUR	PGK	4.96873981	2026-01-16	2026-01-16 09:06:50.293896
2408	EUR	PHP	69.16524936	2026-01-16	2026-01-16 09:06:50.668272
2409	EUR	PKR	325.95994353	2026-01-16	2026-01-16 09:06:50.891424
2410	EUR	PLN	4.21118509	2026-01-16	2026-01-16 09:06:51.18705
2411	EUR	PYG	7709.81515782	2026-01-16	2026-01-16 09:06:51.389132
2412	EUR	QAR	4.23640541	2026-01-16	2026-01-16 09:06:51.596736
2413	EUR	RON	5.08829437	2026-01-16	2026-01-16 09:06:51.895818
2414	EUR	RSD	117.35019859	2026-01-16	2026-01-16 09:06:52.096322
2415	EUR	RUB	91.36000354	2026-01-16	2026-01-16 09:06:52.370204
2416	EUR	RWF	1697.54063751	2026-01-16	2026-01-16 09:06:52.679931
2417	EUR	SAR	4.36442865	2026-01-16	2026-01-16 09:06:52.890234
2418	EUR	SBD	9.45159057	2026-01-16	2026-01-16 09:06:53.181954
2419	EUR	SCR	16.65371965	2026-01-16	2026-01-16 09:06:53.469283
2420	EUR	SDG	698.11762519	2026-01-16	2026-01-16 09:06:53.688586
2421	EUR	SEK	10.70736616	2026-01-16	2026-01-16 09:06:53.970417
2422	EUR	SGD	1.49867438	2026-01-16	2026-01-16 09:06:54.195118
2423	EUR	SHP	0.86642818	2026-01-16	2026-01-16 09:06:54.482806
2424	EUR	SLE	26.72787843	2026-01-16	2026-01-16 09:06:54.68584
2425	EUR	SOS	660.8008188	2026-01-16	2026-01-16 09:06:54.97902
2426	EUR	SRD	44.60625197	2026-01-16	2026-01-16 09:06:55.268047
2427	EUR	SSP	5293.07892932	2026-01-16	2026-01-16 09:06:55.487987
2428	EUR	STN	24.66952623	2026-01-16	2026-01-16 09:06:55.688626
2429	EUR	SYP	128.73476434	2026-01-16	2026-01-16 09:06:55.88786
2430	EUR	SZL	19.09171267	2026-01-16	2026-01-16 09:06:56.167766
2431	EUR	THB	36.64930113	2026-01-16	2026-01-16 09:06:56.379139
2432	EUR	TJS	10.83020916	2026-01-16	2026-01-16 09:06:56.580004
2433	EUR	TMT	4.08092692	2026-01-16	2026-01-16 09:06:56.794665
2434	EUR	TND	3.36504987	2026-01-16	2026-01-16 09:06:57.086773
2435	EUR	TOP	2.79252556	2026-01-16	2026-01-16 09:06:57.286854
2436	EUR	TRY	50.25748126	2026-01-16	2026-01-16 09:06:57.494083
2437	EUR	TTD	7.90311928	2026-01-16	2026-01-16 09:06:57.691653
2438	EUR	TVD	1.74257908	2026-01-16	2026-01-16 09:06:57.893754
2439	EUR	TWD	36.72716938	2026-01-16	2026-01-16 09:06:58.194909
2441	EUR	TZS	2917.37260505	2026-01-16	2026-01-16 09:11:45.979702
2442	EUR	UAH	50.44682232	2026-01-16	2026-01-16 09:11:46.279402
2443	EUR	UGX	4143.51493058	2026-01-16	2026-01-16 09:11:46.60429
2444	EUR	USD	1.16384764	2026-01-16	2026-01-16 09:11:46.882557
2445	EUR	UYU	45.1019236	2026-01-16	2026-01-16 09:11:47.179346
2446	EUR	UZS	13996.32886923	2026-01-16	2026-01-16 09:11:47.477633
2447	EUR	VES	393.78529449	2026-01-16	2026-01-16 09:11:47.693571
2448	EUR	VND	30484.3456163	2026-01-16	2026-01-16 09:11:47.887212
2449	EUR	VUV	140.9211507	2026-01-16	2026-01-16 09:11:48.183675
2450	EUR	WST	3.22366478	2026-01-16	2026-01-16 09:11:48.476898
2451	EUR	XAF	655.95699999	2026-01-16	2026-01-16 09:11:48.684262
2452	EUR	XCD	3.14938427	2026-01-16	2026-01-16 09:11:48.976153
2453	EUR	XDR	0.85271827	2026-01-16	2026-01-16 09:11:49.183396
2454	EUR	XOF	655.95699999	2026-01-16	2026-01-16 09:11:49.482861
2455	EUR	XPF	119.33174224	2026-01-16	2026-01-16 09:11:49.683764
2456	EUR	YER	277.48725254	2026-01-16	2026-01-16 09:11:49.979565
2457	EUR	ZAR	19.09171267	2026-01-16	2026-01-16 09:11:50.269738
2458	EUR	ZMW	22.98343558	2026-01-16	2026-01-16 09:11:50.484741
2459	EUR	ZWL	74745.27400061	2026-01-16	2026-01-16 09:11:50.789779
2460	EUR	AED	4.26223585	2026-01-18	2026-01-18 21:24:03.86405
2461	AED	EUR	0.2346186450475283	2026-01-18	2026-01-18 21:24:03.885413
2462	EUR	AFN	77.17038231	2026-01-18	2026-01-18 21:24:03.896844
2463	AFN	EUR	0.012958339327423763	2026-01-18	2026-01-18 21:24:03.907444
2464	EUR	ALL	96.52939277	2026-01-18	2026-01-18 21:24:03.916668
2465	ALL	EUR	0.010359538906275874	2026-01-18	2026-01-18 21:24:03.92637
2466	EUR	AMD	441.01184201	2026-01-18	2026-01-18 21:24:03.970082
2467	AMD	EUR	0.0022675128074618116	2026-01-18	2026-01-18 21:24:03.980043
2468	EUR	ANG	2.08565071	2026-01-18	2026-01-18 21:24:03.989715
2469	ANG	EUR	0.47946666966109586	2026-01-18	2026-01-18 21:24:03.998815
2470	EUR	AOA	1059.17667626	2026-01-18	2026-01-18 21:24:04.008238
2471	AOA	EUR	0.0009441295512010748	2026-01-18	2026-01-18 21:24:04.062274
2472	EUR	ARS	1657.86773317	2026-01-18	2026-01-18 21:24:04.071649
2473	ARS	EUR	0.0006031844277998615	2026-01-18	2026-01-18 21:24:04.080596
2474	EUR	AUD	1.73666053	2026-01-18	2026-01-18 21:24:04.097899
2475	AUD	EUR	0.5758177736670275	2026-01-18	2026-01-18 21:24:04.106705
2476	EUR	AWG	2.07744103	2026-01-18	2026-01-18 21:24:04.115559
2477	AWG	EUR	0.4813614372485942	2026-01-18	2026-01-18 21:24:04.12422
2478	EUR	AZN	1.97496345	2026-01-18	2026-01-18 21:24:04.132707
2479	AZN	EUR	0.5063384843906859	2026-01-18	2026-01-18 21:24:04.141585
2480	EUR	BAM	1.95583	2026-01-18	2026-01-18 21:24:04.169254
2481	BAM	EUR	0.5112918811962185	2026-01-18	2026-01-18 21:24:04.178199
2482	EUR	BBD	2.32116316	2026-01-18	2026-01-18 21:24:04.187818
2483	BBD	EUR	0.43081848671077483	2026-01-18	2026-01-18 21:24:04.196539
2484	EUR	BDT	141.91142557	2026-01-18	2026-01-18 21:24:04.205427
2485	BDT	EUR	0.007046648964193053	2026-01-18	2026-01-18 21:24:04.214618
2486	EUR	BGN	1.95583	2026-01-18	2026-01-18 21:24:04.223305
2487	BGN	EUR	0.5112918811962185	2026-01-18	2026-01-18 21:24:04.232273
2488	EUR	BHD	0.43637867	2026-01-18	2026-01-18 21:24:04.241009
2489	BHD	EUR	2.2915877166956853	2026-01-18	2026-01-18 21:24:04.269336
2490	EUR	BIF	3433.00097112	2026-01-18	2026-01-18 21:24:04.278557
2491	BIF	EUR	0.0002912903341456833	2026-01-18	2026-01-18 21:24:04.288082
2492	EUR	BMD	1.16058158	2026-01-18	2026-01-18 21:24:04.297376
2493	BMD	EUR	0.8616369734215497	2026-01-18	2026-01-18 21:24:04.307919
2494	EUR	BND	1.49562678	2026-01-18	2026-01-18 21:24:04.317291
2495	BND	EUR	0.6686160032518272	2026-01-18	2026-01-18 21:24:04.365176
2496	EUR	BOB	8.03389743	2026-01-18	2026-01-18 21:24:04.374493
2497	BOB	EUR	0.12447258739772087	2026-01-18	2026-01-18 21:24:04.384165
2498	EUR	BRL	6.23310699	2026-01-18	2026-01-18 21:24:04.393911
2499	BRL	EUR	0.1604336331149676	2026-01-18	2026-01-18 21:24:04.402942
2500	EUR	BSD	1.16058158	2026-01-18	2026-01-18 21:24:04.411857
2501	BSD	EUR	0.8616369734215497	2026-01-18	2026-01-18 21:24:04.421068
2502	EUR	BTN	105.25432603	2026-01-18	2026-01-18 21:24:04.430181
2503	BTN	EUR	0.009500797142674934	2026-01-18	2026-01-18 21:24:04.467658
2504	EUR	BWP	15.51076049	2026-01-18	2026-01-18 21:24:04.476615
2505	BWP	EUR	0.06447137138406037	2026-01-18	2026-01-18 21:24:04.488038
2506	EUR	BYN	3.34749091	2026-01-18	2026-01-18 21:24:04.496666
2507	BYN	EUR	0.29873120701020817	2026-01-18	2026-01-18 21:24:04.505542
2508	EUR	BZD	2.3342758	2026-01-18	2026-01-18 21:24:04.514809
2509	BZD	EUR	0.42839839234078514	2026-01-18	2026-01-18 21:24:04.523808
2510	EUR	CAD	1.61515025	2026-01-18	2026-01-18 21:24:04.538776
2511	CAD	EUR	0.6191374455720141	2026-01-18	2026-01-18 21:24:04.565145
2512	EUR	CDF	2504.77299162	2026-01-18	2026-01-18 21:24:04.574056
2513	CDF	EUR	0.0003992377765752076	2026-01-18	2026-01-18 21:24:04.583283
2514	EUR	CHF	0.9318239	2026-01-18	2026-01-18 21:24:04.592373
2515	CHF	EUR	1.0731641461439227	2026-01-18	2026-01-18 21:24:04.601288
2516	EUR	CLP	1028.8295575	2026-01-18	2026-01-18 21:24:04.610664
2517	CLP	EUR	0.0009719782958315718	2026-01-18	2026-01-18 21:24:04.620453
2518	EUR	CNH	8.09215537	2026-01-18	2026-01-18 21:24:04.629395
2519	CNH	EUR	0.12357647057881439	2026-01-18	2026-01-18 21:24:04.665035
2520	EUR	CNY	8.08821992	2026-01-18	2026-01-18 21:24:04.674562
2521	CNY	EUR	0.12363659864481033	2026-01-18	2026-01-18 21:24:04.684601
2522	EUR	COP	4285.68296463	2026-01-18	2026-01-18 21:24:04.693767
2523	COP	EUR	0.0002333350386048292	2026-01-18	2026-01-18 21:24:04.703285
2524	EUR	CRC	565.73254967	2026-01-18	2026-01-18 21:24:04.712047
2525	CRC	EUR	0.001767619700480933	2026-01-18	2026-01-18 21:24:04.720822
2526	EUR	CUP	27.84989409	2026-01-18	2026-01-18 21:24:04.729952
2527	CUP	EUR	0.035906779277809456	2026-01-18	2026-01-18 21:24:04.774899
2528	EUR	CVE	110.27	2026-01-18	2026-01-18 21:24:04.785668
2529	CVE	EUR	0.009068649678062937	2026-01-18	2026-01-18 21:24:04.794761
2530	EUR	CZK	24.27351067	2026-01-18	2026-01-18 21:24:04.803897
2531	CZK	EUR	0.04119717224241136	2026-01-18	2026-01-18 21:24:04.813355
2532	EUR	DJF	206.89955422	2026-01-18	2026-01-18 21:24:04.822502
2533	DJF	EUR	0.0048332631927117745	2026-01-18	2026-01-18 21:24:04.831774
2534	EUR	DKK	7.47589716	2026-01-18	2026-01-18 21:24:04.867344
2535	DKK	EUR	0.13376320976571593	2026-01-18	2026-01-18 21:24:04.876565
2536	EUR	DOP	73.55862486	2026-01-18	2026-01-18 21:24:04.885777
2537	DOP	EUR	0.013594598891744428	2026-01-18	2026-01-18 21:24:04.894883
2538	EUR	DZD	151.2278417	2026-01-18	2026-01-18 21:24:04.904106
2539	DZD	EUR	0.006612538992547164	2026-01-18	2026-01-18 21:24:04.913424
2540	EUR	EGP	54.79076851	2026-01-18	2026-01-18 21:24:04.969771
2541	EGP	EUR	0.018251249748714286	2026-01-18	2026-01-18 21:24:04.979831
2542	EUR	ERN	17.40872368	2026-01-18	2026-01-18 21:24:04.989259
2543	ERN	EUR	0.057442464960762704	2026-01-18	2026-01-18 21:24:04.998382
2544	EUR	ETB	180.60402174	2026-01-18	2026-01-18 21:24:05.007824
2545	ETB	EUR	0.005536975258721611	2026-01-18	2026-01-18 21:24:05.018751
2546	EUR	EUR	1	2026-01-18	2026-01-18 21:24:05.069566
2548	EUR	FJD	2.64580451	2026-01-18	2026-01-18 21:24:05.080146
2549	FJD	EUR	0.377956873314121	2026-01-18	2026-01-18 21:24:05.090485
2550	EUR	FKP	0.86737936	2026-01-18	2026-01-18 21:24:05.100883
2551	FKP	EUR	1.1528980814115752	2026-01-18	2026-01-18 21:24:05.111636
2552	EUR	GBP	0.86737936	2026-01-18	2026-01-18 21:24:05.121062
2553	GBP	EUR	1.1528980814115752	2026-01-18	2026-01-18 21:24:05.133014
2554	EUR	GEL	3.12335319	2026-01-18	2026-01-18 21:24:05.167492
2555	GEL	EUR	0.32016872225712006	2026-01-18	2026-01-18 21:24:05.177212
2556	EUR	GGP	0.86737936	2026-01-18	2026-01-18 21:24:05.186275
2557	GGP	EUR	1.1528980814115752	2026-01-18	2026-01-18 21:24:05.195099
2558	EUR	GHS	12.55065971	2026-01-18	2026-01-18 21:24:05.205681
2559	GHS	EUR	0.07967708655212993	2026-01-18	2026-01-18 21:24:05.216093
2560	EUR	GIP	0.86737936	2026-01-18	2026-01-18 21:24:05.225148
2561	GIP	EUR	1.1528980814115752	2026-01-18	2026-01-18 21:24:05.2336
2562	EUR	GMD	85.857055	2026-01-18	2026-01-18 21:24:05.241871
2563	GMD	EUR	0.011647266494291004	2026-01-18	2026-01-18 21:24:05.269363
2564	EUR	GNF	10162.12578709	2026-01-18	2026-01-18 21:24:05.277741
2565	GNF	EUR	9.84046075546913e-05	2026-01-18	2026-01-18 21:24:05.286273
2566	EUR	GTQ	8.89493291	2026-01-18	2026-01-18 21:24:05.294458
2567	GTQ	EUR	0.112423557335184	2026-01-18	2026-01-18 21:24:05.302607
2568	EUR	GYD	242.89206128	2026-01-18	2026-01-18 21:24:05.311107
2569	GYD	EUR	0.00411705510147252	2026-01-18	2026-01-18 21:24:05.320725
2570	EUR	HKD	9.04983878	2026-01-18	2026-01-18 21:24:05.329101
2571	HKD	EUR	0.11049920604220974	2026-01-18	2026-01-18 21:24:05.337415
2572	EUR	HNL	30.69629692	2026-01-18	2026-01-18 21:24:05.345703
2573	HNL	EUR	0.03257721941529877	2026-01-18	2026-01-18 21:24:05.354099
2574	EUR	HRK	7.5345	2026-01-18	2026-01-18 21:24:05.368817
2575	HRK	EUR	0.13272280841462605	2026-01-18	2026-01-18 21:24:05.377561
2576	EUR	HTG	153.06334558	2026-01-18	2026-01-18 21:24:05.386193
2577	HTG	EUR	0.006533242797030989	2026-01-18	2026-01-18 21:24:05.394682
2578	EUR	HUF	385.3942112	2026-01-18	2026-01-18 21:24:05.403359
2579	HUF	EUR	0.002594745771832704	2026-01-18	2026-01-18 21:24:05.41199
2580	EUR	IDR	19596.56642726	2026-01-18	2026-01-18 21:24:05.422021
2581	IDR	EUR	5.102934760086032e-05	2026-01-18	2026-01-18 21:24:05.43144
2582	EUR	ILS	3.64564106	2026-01-18	2026-01-18 21:24:05.44046
2583	ILS	EUR	0.2743001802815991	2026-01-18	2026-01-18 21:24:05.44954
2584	EUR	IMP	0.86737936	2026-01-18	2026-01-18 21:24:05.468565
2585	IMP	EUR	1.1528980814115752	2026-01-18	2026-01-18 21:24:05.478461
2586	EUR	INR	105.25432603	2026-01-18	2026-01-18 21:24:05.487187
2587	INR	EUR	0.009500797142674934	2026-01-18	2026-01-18 21:24:05.496042
2588	EUR	IQD	1520.70655292	2026-01-18	2026-01-18 21:24:05.504527
2589	IQD	EUR	0.0006575890648197971	2026-01-18	2026-01-18 21:24:05.512934
2590	EUR	IRR	1235842.96794875	2026-01-18	2026-01-18 21:24:05.522109
2591	IRR	EUR	8.091642918515759e-07	2026-01-18	2026-01-18 21:24:05.531481
2592	EUR	ISK	146.29310004	2026-01-18	2026-01-18 21:24:05.540161
2593	ISK	EUR	0.006835592380820259	2026-01-18	2026-01-18 21:24:05.548844
2594	EUR	JEP	0.86737936	2026-01-18	2026-01-18 21:24:05.567118
2595	JEP	EUR	1.1528980814115752	2026-01-18	2026-01-18 21:24:05.57641
2596	EUR	JMD	183.1333665	2026-01-18	2026-01-18 21:24:05.585385
2597	JMD	EUR	0.005460501377284516	2026-01-18	2026-01-18 21:24:05.595405
2598	EUR	JOD	0.82285234	2026-01-18	2026-01-18 21:24:05.604557
2599	JOD	EUR	1.2152848711592654	2026-01-18	2026-01-18 21:24:05.613906
2600	EUR	JPY	183.59916423	2026-01-18	2026-01-18 21:24:05.62354
2601	JPY	EUR	0.005446647887499482	2026-01-18	2026-01-18 21:24:05.63315
2602	EUR	KES	149.74256144	2026-01-18	2026-01-18 21:24:05.642563
2603	KES	EUR	0.006678128051126517	2026-01-18	2026-01-18 21:24:05.652054
2604	EUR	KGS	101.4904924	2026-01-18	2026-01-18 21:24:05.664768
2605	KGS	EUR	0.009853139701586472	2026-01-18	2026-01-18 21:24:05.675183
2606	EUR	KHR	4668.39162707	2026-01-18	2026-01-18 21:24:05.684243
2607	KHR	EUR	0.00021420653618720183	2026-01-18	2026-01-18 21:24:05.693141
2608	EUR	KMF	491.96775001	2026-01-18	2026-01-18 21:24:05.702155
2609	KMF	EUR	0.002032653563124155	2026-01-18	2026-01-18 21:24:05.710904
2610	EUR	KRW	1709.34590334	2026-01-18	2026-01-18 21:24:05.720068
2611	KRW	EUR	0.0005850190988529802	2026-01-18	2026-01-18 21:24:05.728894
2612	EUR	KWD	0.35703014	2026-01-18	2026-01-18 21:24:05.73755
2613	KWD	EUR	2.800883981391599	2026-01-18	2026-01-18 21:24:05.746016
2614	EUR	KYD	0.95542252	2026-01-18	2026-01-18 21:24:05.754595
2615	KYD	EUR	1.0466573469505407	2026-01-18	2026-01-18 21:24:05.769681
2616	EUR	KZT	593.98883162	2026-01-18	2026-01-18 21:24:05.778354
2617	KZT	EUR	0.001683533337272817	2026-01-18	2026-01-18 21:24:05.787039
2618	EUR	LAK	25092.09943977	2026-01-18	2026-01-18 21:24:05.796052
2619	LAK	EUR	3.9853181771431965e-05	2026-01-18	2026-01-18 21:24:05.805572
2620	EUR	LBP	104600.46569906	2026-01-18	2026-01-18 21:24:05.814298
2621	LBP	EUR	9.560186881739538e-06	2026-01-18	2026-01-18 21:24:05.822989
2622	EUR	LKR	359.40090742	2026-01-18	2026-01-18 21:24:05.832017
2623	LKR	EUR	0.0027824081112610786	2026-01-18	2026-01-18 21:24:05.840716
2624	EUR	LRD	210.16484613	2026-01-18	2026-01-18 21:24:05.849065
2625	LRD	EUR	0.0047581696863872175	2026-01-18	2026-01-18 21:24:05.857507
2626	EUR	LSL	19.04573007	2026-01-18	2026-01-18 21:24:05.868534
2627	LSL	EUR	0.05250520701094867	2026-01-18	2026-01-18 21:24:05.878885
2628	EUR	LYD	6.30166377	2026-01-18	2026-01-18 21:24:05.887441
2629	LYD	EUR	0.15868825067447226	2026-01-18	2026-01-18 21:24:05.896076
2630	EUR	MAD	10.70133405	2026-01-18	2026-01-18 21:24:05.905032
2631	MAD	EUR	0.09344629326845469	2026-01-18	2026-01-18 21:24:05.913805
2632	EUR	MDL	19.81827107	2026-01-18	2026-01-18 21:24:05.923043
2633	MDL	EUR	0.05045848835490774	2026-01-18	2026-01-18 21:24:05.932182
2634	EUR	MGA	5320.53356367	2026-01-18	2026-01-18 21:24:05.941017
2635	MGA	EUR	0.00018795107446145298	2026-01-18	2026-01-18 21:24:05.950218
2636	EUR	MKD	61.50831096	2026-01-18	2026-01-18 21:24:05.966922
2637	MKD	EUR	0.016257965539816538	2026-01-18	2026-01-18 21:24:05.976032
2638	EUR	MMK	2437.36630323	2026-01-18	2026-01-18 21:24:05.984492
2639	MMK	EUR	0.0004102789140371716	2026-01-18	2026-01-18 21:24:05.992912
2640	EUR	MNT	4134.86586093	2026-01-18	2026-01-18 21:24:06.00114
2641	MNT	EUR	0.00024184581401997003	2026-01-18	2026-01-18 21:24:06.00968
2642	EUR	MOP	9.32133395	2026-01-18	2026-01-18 21:24:06.018016
2643	MOP	EUR	0.10728078248929168	2026-01-18	2026-01-18 21:24:06.026653
2644	EUR	MRU	46.3768438	2026-01-18	2026-01-18 21:24:06.034848
2645	MRU	EUR	0.021562485026201804	2026-01-18	2026-01-18 21:24:06.043515
2646	EUR	MUR	53.73160043	2026-01-18	2026-01-18 21:24:06.069043
2647	MUR	EUR	0.0186110220428437	2026-01-18	2026-01-18 21:24:06.077613
2648	EUR	MVR	17.94222801	2026-01-18	2026-01-18 21:24:06.086476
2649	MVR	EUR	0.055734438300675676	2026-01-18	2026-01-18 21:24:06.094936
2650	EUR	MWK	2011.04180942	2026-01-18	2026-01-18 21:24:06.103545
2651	MWK	EUR	0.0004972547041617239	2026-01-18	2026-01-18 21:24:06.11316
2652	EUR	MXN	20.45594585	2026-01-18	2026-01-18 21:24:06.121518
2653	MXN	EUR	0.048885542000004854	2026-01-18	2026-01-18 21:24:06.130719
2654	EUR	MYR	4.70924981	2026-01-18	2026-01-18 21:24:06.140373
2655	MYR	EUR	0.21234804700241627	2026-01-18	2026-01-18 21:24:06.169698
2656	EUR	MZN	74.12820765	2026-01-18	2026-01-18 21:24:06.179614
2657	MZN	EUR	0.013490141360513524	2026-01-18	2026-01-18 21:24:06.188665
2658	EUR	NAD	19.04573007	2026-01-18	2026-01-18 21:24:06.200847
2659	NAD	EUR	0.05250520701094867	2026-01-18	2026-01-18 21:24:06.210103
2660	EUR	NGN	1648.4868198	2026-01-18	2026-01-18 21:24:06.219337
2661	NGN	EUR	0.0006066169216453447	2026-01-18	2026-01-18 21:24:06.228248
2662	EUR	NIO	42.66766329	2026-01-18	2026-01-18 21:24:06.262242
2663	NIO	EUR	0.02343695255123965	2026-01-18	2026-01-18 21:24:06.271532
2664	EUR	NOK	11.71737517	2026-01-18	2026-01-18 21:24:06.280375
2665	NOK	EUR	0.08534334571451636	2026-01-18	2026-01-18 21:24:06.288584
2666	EUR	NPR	168.48586239	2026-01-18	2026-01-18 21:24:06.297013
2667	NPR	EUR	0.005935216081722428	2026-01-18	2026-01-18 21:24:06.305042
2668	EUR	NZD	2.01813143	2026-01-18	2026-01-18 21:24:06.313495
2669	NZD	EUR	0.49550786689844084	2026-01-18	2026-01-18 21:24:06.321806
2670	EUR	OMR	0.44661114	2026-01-18	2026-01-18 21:24:06.330058
2671	OMR	EUR	2.2390843184072837	2026-01-18	2026-01-18 21:24:06.338589
2672	EUR	PAB	1.16058158	2026-01-18	2026-01-18 21:24:06.346944
2673	PAB	EUR	0.8616369734215497	2026-01-18	2026-01-18 21:24:06.355194
2674	EUR	PEN	3.90068165	2026-01-18	2026-01-18 21:24:06.363065
2675	PEN	EUR	0.2563654483313192	2026-01-18	2026-01-18 21:24:06.371127
2676	EUR	PGK	4.94712584	2026-01-18	2026-01-18 21:24:06.379003
2677	PGK	EUR	0.20213757085265494	2026-01-18	2026-01-18 21:24:06.386892
2678	EUR	PHP	68.93625575	2026-01-18	2026-01-18 21:24:06.395335
2679	PHP	EUR	0.014506154840009569	2026-01-18	2026-01-18 21:24:06.403489
2680	EUR	PKR	324.97600138	2026-01-18	2026-01-18 21:24:06.411763
2681	PKR	EUR	0.003077150299571453	2026-01-18	2026-01-18 21:24:06.419671
2682	EUR	PLN	4.2221594	2026-01-18	2026-01-18 21:24:06.427466
2683	PLN	EUR	0.23684562927681035	2026-01-18	2026-01-18 21:24:06.436694
2684	EUR	PYG	7851.7287999	2026-01-18	2026-01-18 21:24:06.444841
2685	PYG	EUR	0.0001273604865227561	2026-01-18	2026-01-18 21:24:06.453292
2686	EUR	QAR	4.22451695	2026-01-18	2026-01-18 21:24:06.46132
2687	QAR	EUR	0.23671345430392934	2026-01-18	2026-01-18 21:24:06.469747
2688	EUR	RON	5.09116096	2026-01-18	2026-01-18 21:24:06.477848
2689	RON	EUR	0.19641885374608153	2026-01-18	2026-01-18 21:24:06.486235
2690	EUR	RSD	117.42850695	2026-01-18	2026-01-18 21:24:06.494382
2691	RSD	EUR	0.008515819761089111	2026-01-18	2026-01-18 21:24:06.502523
2692	EUR	RUB	90.40957349	2026-01-18	2026-01-18 21:24:06.510767
2693	RUB	EUR	0.011060775550618074	2026-01-18	2026-01-18 21:24:06.51866
2694	EUR	RWF	1689.46565862	2026-01-18	2026-01-18 21:24:06.526745
2695	RWF	EUR	0.0005919031232732048	2026-01-18	2026-01-18 21:24:06.535102
2696	EUR	SAR	4.35218092	2026-01-18	2026-01-18 21:24:06.543593
2697	SAR	EUR	0.22976985984305082	2026-01-18	2026-01-18 21:24:06.552196
2698	EUR	SBD	9.42858224	2026-01-18	2026-01-18 21:24:06.560697
2699	SBD	EUR	0.1060604844445839	2026-01-18	2026-01-18 21:24:06.568815
2700	EUR	SCR	17.21581269	2026-01-18	2026-01-18 21:24:06.577163
2701	SCR	EUR	0.05808613383560227	2026-01-18	2026-01-18 21:24:06.585167
2702	EUR	SDG	695.95154707	2026-01-18	2026-01-18 21:24:06.593628
2703	SDG	EUR	0.0014368816395481313	2026-01-18	2026-01-18 21:24:06.602153
2704	EUR	SEK	10.70265316	2026-01-18	2026-01-18 21:24:06.61092
2705	SEK	EUR	0.09343477594297749	2026-01-18	2026-01-18 21:24:06.61916
2706	EUR	SGD	1.49562678	2026-01-18	2026-01-18 21:24:06.627476
2707	SGD	EUR	0.6686160032518272	2026-01-18	2026-01-18 21:24:06.636064
2708	EUR	SHP	0.86737936	2026-01-18	2026-01-18 21:24:06.644626
2709	SHP	EUR	1.1528980814115752	2026-01-18	2026-01-18 21:24:06.652927
2710	EUR	SLE	26.50200208	2026-01-18	2026-01-18 21:24:06.661594
2711	SLE	EUR	0.03773299832146115	2026-01-18	2026-01-18 21:24:06.669961
2712	EUR	SOS	662.8558282	2026-01-18	2026-01-18 21:24:06.678158
2713	SOS	EUR	0.0015086236817371322	2026-01-18	2026-01-18 21:24:06.686739
2714	EUR	SRD	44.41721826	2026-01-18	2026-01-18 21:24:06.69554
2715	SRD	EUR	0.022513791704523552	2026-01-18	2026-01-18 21:24:06.703729
2716	EUR	SSP	5280.71316996	2026-01-18	2026-01-18 21:24:06.712008
2717	SSP	EUR	0.00018936836139645408	2026-01-18	2026-01-18 21:24:06.720522
2718	EUR	STN	24.65656319	2026-01-18	2026-01-18 21:24:06.729105
2719	STN	EUR	0.040557152766755894	2026-01-18	2026-01-18 21:24:06.738867
2720	EUR	SYP	128.33837496	2026-01-18	2026-01-18 21:24:06.747254
2721	SYP	EUR	0.0077919016842131275	2026-01-18	2026-01-18 21:24:06.755291
2722	EUR	SZL	19.04573007	2026-01-18	2026-01-18 21:24:06.763191
2723	SZL	EUR	0.05250520701094867	2026-01-18	2026-01-18 21:24:06.771516
2724	EUR	THB	36.46539799	2026-01-18	2026-01-18 21:24:06.779932
2725	THB	EUR	0.027423257529623907	2026-01-18	2026-01-18 21:24:06.788219
2726	EUR	TJS	10.82171536	2026-01-18	2026-01-18 21:24:06.796392
2727	TJS	EUR	0.09240679196722099	2026-01-18	2026-01-18 21:24:06.804482
2728	EUR	TMT	4.06596414	2026-01-18	2026-01-18 21:24:06.812714
2729	TMT	EUR	0.2459441267969471	2026-01-18	2026-01-18 21:24:06.821154
2730	EUR	TND	3.36389225	2026-01-18	2026-01-18 21:24:06.829741
2731	TND	EUR	0.29727468232670057	2026-01-18	2026-01-18 21:24:06.837932
2732	EUR	TOP	2.77607749	2026-01-18	2026-01-18 21:24:06.846371
2733	TOP	EUR	0.36022049226010616	2026-01-18	2026-01-18 21:24:06.85475
2734	EUR	TRY	50.16628458	2026-01-18	2026-01-18 21:24:06.862758
2735	TRY	EUR	0.019933706639272904	2026-01-18	2026-01-18 21:24:06.871303
2736	EUR	TTD	7.84791307	2026-01-18	2026-01-18 21:24:06.879342
2737	TTD	EUR	0.12742241040139352	2026-01-18	2026-01-18 21:24:06.88752
2738	EUR	TVD	1.73666053	2026-01-18	2026-01-18 21:24:06.895624
2739	TVD	EUR	0.5758177736670275	2026-01-18	2026-01-18 21:24:06.903586
2740	EUR	TWD	36.71102736	2026-01-18	2026-01-18 21:24:06.911633
2741	TWD	EUR	0.027239771586713774	2026-01-18	2026-01-18 21:24:06.920934
2742	EUR	TZS	2880.53668794	2026-01-18	2026-01-18 21:24:06.92899
2743	TZS	EUR	0.00034715752942384657	2026-01-18	2026-01-18 21:24:06.937238
2744	EUR	UAH	50.39321939	2026-01-18	2026-01-18 21:24:06.945221
2745	UAH	EUR	0.01984393956379059	2026-01-18	2026-01-18 21:24:06.954818
2746	EUR	UGX	4110.39832023	2026-01-18	2026-01-18 21:24:06.962919
2747	UGX	EUR	0.00024328542445104065	2026-01-18	2026-01-18 21:24:06.971063
2748	EUR	USD	1.16058158	2026-01-18	2026-01-18 21:24:06.979826
2749	USD	EUR	0.8616369734215497	2026-01-18	2026-01-18 21:24:06.988104
2750	EUR	UYU	44.66880756	2026-01-18	2026-01-18 21:24:06.99671
2751	UYU	EUR	0.02238698668319679	2026-01-18	2026-01-18 21:24:07.005078
2752	EUR	UZS	13883.88207324	2026-01-18	2026-01-18 21:24:07.013306
2753	UZS	EUR	7.202596469235466e-05	2026-01-18	2026-01-18 21:24:07.021592
2754	EUR	VES	395.98834632	2026-01-18	2026-01-18 21:24:07.029791
2755	VES	EUR	0.0025253268417952265	2026-01-18	2026-01-18 21:24:07.03807
2756	EUR	VND	30515.91384222	2026-01-18	2026-01-18 21:24:07.046248
2757	VND	EUR	3.2769787107488146e-05	2026-01-18	2026-01-18 21:24:07.055286
2758	EUR	VUV	139.68441887	2026-01-18	2026-01-18 21:24:07.063464
2759	VUV	EUR	0.007158994597176005	2026-01-18	2026-01-18 21:24:07.071725
2760	EUR	WST	3.2382415	2026-01-18	2026-01-18 21:24:07.080429
2761	WST	EUR	0.30880958075548104	2026-01-18	2026-01-18 21:24:07.089036
2762	EUR	XAF	655.95700001	2026-01-18	2026-01-18 21:24:07.098193
2763	XAF	EUR	0.001524490172350863	2026-01-18	2026-01-18 21:24:07.106319
2764	EUR	XCD	3.13418175	2026-01-18	2026-01-18 21:24:07.114657
2765	XCD	EUR	0.31906254319807714	2026-01-18	2026-01-18 21:24:07.122792
2766	EUR	XDR	0.85096607	2026-01-18	2026-01-18 21:24:07.131194
2767	XDR	EUR	1.1751349851116861	2026-01-18	2026-01-18 21:24:07.140093
2768	EUR	XOF	655.95700001	2026-01-18	2026-01-18 21:24:07.148185
2769	XOF	EUR	0.001524490172350863	2026-01-18	2026-01-18 21:24:07.156266
2770	EUR	XPF	119.33174225	2026-01-18	2026-01-18 21:24:07.164647
2771	XPF	EUR	0.0083799999995391	2026-01-18	2026-01-18 21:24:07.173069
2772	EUR	YER	276.63737502	2026-01-18	2026-01-18 21:24:07.181299
2773	YER	EUR	0.00361484054686285	2026-01-18	2026-01-18 21:24:07.189457
2774	EUR	ZAR	19.04573007	2026-01-18	2026-01-18 21:24:07.197555
2775	ZAR	EUR	0.05250520701094867	2026-01-18	2026-01-18 21:24:07.205939
2776	EUR	ZMW	23.41449815	2026-01-18	2026-01-18 21:24:07.214339
2777	ZMW	EUR	0.04270858139233704	2026-01-18	2026-01-18 21:24:07.222832
2778	EUR	ZWL	74464.58460879	2026-01-18	2026-01-18 21:24:07.231375
2779	ZWL	EUR	1.3429202690831331e-05	2026-01-18	2026-01-18 21:24:07.239368
2786	EUR	AMD	440.0434776	2026-01-19	2026-01-20 00:25:48.872979
2787	AMD	EUR	0.002272502720535722	2026-01-19	2026-01-20 00:25:48.881088
2788	EUR	ANG	2.09253149	2026-01-19	2026-01-20 00:25:48.891689
2789	ANG	EUR	0.477890060330705	2026-01-19	2026-01-20 00:25:48.899225
2790	EUR	AOA	1065.9781702	2026-01-19	2026-01-20 00:25:48.907944
2791	AOA	EUR	0.0009381055146864582	2026-01-19	2026-01-20 00:25:48.94393
2792	EUR	ARS	1656.87312191	2026-01-19	2026-01-20 00:25:48.954508
2793	ARS	EUR	0.0006035465158896573	2026-01-19	2026-01-20 00:25:48.962761
2794	EUR	AUD	1.73899129	2026-01-19	2026-01-20 00:25:48.970463
2795	AUD	EUR	0.5750460084248036	2026-01-19	2026-01-20 00:25:48.978001
2796	EUR	AWG	2.08000092	2026-01-19	2026-01-20 00:25:48.985343
2797	AWG	EUR	0.4807690181213959	2026-01-19	2026-01-20 00:25:48.992256
2798	EUR	AZN	1.97541631	2026-01-19	2026-01-20 00:25:48.999323
2799	AZN	EUR	0.5062224073668805	2026-01-19	2026-01-20 00:25:49.006289
2800	EUR	BAM	1.95583	2026-01-19	2026-01-20 00:25:49.045242
2801	BAM	EUR	0.5112918811962185	2026-01-19	2026-01-20 00:25:49.05288
2803	BBD	EUR	0.43028827201509595	2026-01-19	2026-01-20 00:25:49.067428
2783	AFN	EUR	0.013111258679784358	2026-01-19	2026-01-20 00:25:48.847426
2784	EUR	ALL	96.67381347	2026-01-19	2026-01-20 00:25:48.856115
2866	EUR	EUR	1	2026-01-19	2026-01-20 00:25:49.602167
2807	BGN	EUR	0.5112918811962185	2026-01-19	2026-01-20 00:25:49.096166
2808	EUR	BHD	0.43691639	2026-01-19	2026-01-20 00:25:49.103294
2809	BHD	EUR	2.288767422984521	2026-01-19	2026-01-20 00:25:49.11029
2810	EUR	BIF	3438.33946671	2026-01-19	2026-01-20 00:25:49.117706
2811	BIF	EUR	0.0002908380657820437	2026-01-19	2026-01-20 00:25:49.12505
2812	EUR	BMD	1.16201168	2026-01-19	2026-01-20 00:25:49.145213
2813	BMD	EUR	0.8605765477331518	2026-01-19	2026-01-20 00:25:49.152883
2814	EUR	BND	1.49532015	2026-01-19	2026-01-20 00:25:49.160204
2815	BND	EUR	0.6687531094929738	2026-01-19	2026-01-20 00:25:49.167356
2816	EUR	BOB	8.02753509	2026-01-19	2026-01-20 00:25:49.174753
2817	BOB	EUR	0.12457123996202923	2026-01-19	2026-01-20 00:25:49.182391
2818	EUR	BRL	6.23908162	2026-01-19	2026-01-20 00:25:49.189865
2819	BRL	EUR	0.160279999670849	2026-01-19	2026-01-20 00:25:49.197401
2820	EUR	BSD	1.16201168	2026-01-19	2026-01-20 00:25:49.204916
2821	BSD	EUR	0.8605765477331518	2026-01-19	2026-01-20 00:25:49.212871
2822	EUR	BTN	105.37185215	2026-01-19	2026-01-20 00:25:49.220346
2824	EUR	BWP	16.02253635	2026-01-19	2026-01-20 00:25:49.24511
2825	BWP	EUR	0.06241209120427429	2026-01-19	2026-01-20 00:25:49.252283
2826	EUR	BYN	3.34756491	2026-01-19	2026-01-20 00:25:49.259208
2827	BYN	EUR	0.2987246033714698	2026-01-19	2026-01-20 00:25:49.266882
2828	EUR	BZD	2.34032054	2026-01-19	2026-01-20 00:25:49.275753
2829	BZD	EUR	0.42729189566485626	2026-01-19	2026-01-20 00:25:49.283315
2830	EUR	CAD	1.61511546	2026-01-19	2026-01-20 00:25:49.290975
2831	CAD	EUR	0.6191507819509078	2026-01-19	2026-01-20 00:25:49.298501
2832	EUR	CDF	2641.63747805	2026-01-19	2026-01-20 00:25:49.306313
2833	CDF	EUR	0.0003785530786526312	2026-01-19	2026-01-20 00:25:49.314132
2834	EUR	CHF	0.92904042	2026-01-19	2026-01-20 00:25:49.321856
2835	CHF	EUR	1.0763794324470835	2026-01-19	2026-01-20 00:25:49.329466
2836	EUR	CLP	1030.25140997	2026-01-19	2026-01-20 00:25:49.346744
2837	CLP	EUR	0.0009706368662277484	2026-01-19	2026-01-20 00:25:49.354979
2838	EUR	CNH	8.08848343	2026-01-19	2026-01-20 00:25:49.36294
2839	CNH	EUR	0.12363257075993045	2026-01-19	2026-01-20 00:25:49.370527
2841	CNY	EUR	0.12356469215185888	2026-01-19	2026-01-20 00:25:49.385875
2842	EUR	COP	4288.7269792	2026-01-19	2026-01-20 00:25:49.393139
2843	COP	EUR	0.00023316942413213155	2026-01-19	2026-01-20 00:25:49.400431
2844	EUR	CRC	568.22112954	2026-01-19	2026-01-20 00:25:49.408135
2845	CRC	EUR	0.0017598782375613945	2026-01-19	2026-01-20 00:25:49.415674
2846	EUR	CUP	27.86555168	2026-01-19	2026-01-20 00:25:49.423176
2847	CUP	EUR	0.035886603340343416	2026-01-19	2026-01-20 00:25:49.430352
2848	EUR	CVE	110.26999999	2026-01-19	2026-01-20 00:25:49.445785
2849	CVE	EUR	0.00906864967888534	2026-01-19	2026-01-20 00:25:49.45333
2850	EUR	CZK	24.26981774	2026-01-19	2026-01-20 00:25:49.460758
2851	CZK	EUR	0.04120344086275779	2026-01-19	2026-01-20 00:25:49.468102
2852	EUR	DJF	206.86787838	2026-01-19	2026-01-20 00:25:49.475562
2853	DJF	EUR	0.004834003267356369	2026-01-19	2026-01-20 00:25:49.48363
2854	EUR	DKK	7.4719387	2026-01-19	2026-01-20 00:25:49.491743
2855	DKK	EUR	0.13383407441498416	2026-01-19	2026-01-20 00:25:49.499212
2856	EUR	DOP	73.97987634	2026-01-19	2026-01-20 00:25:49.506822
2858	EUR	DZD	150.95479059	2026-01-19	2026-01-20 00:25:49.522564
2859	DZD	EUR	0.0066244999320097435	2026-01-19	2026-01-20 00:25:49.541192
2860	EUR	EGP	54.7040646	2026-01-19	2026-01-20 00:25:49.548769
2861	EGP	EUR	0.018280177301487024	2026-01-19	2026-01-20 00:25:49.556663
2862	EUR	ERN	17.43017527	2026-01-19	2026-01-20 00:25:49.564173
2863	ERN	EUR	0.057371769618470396	2026-01-19	2026-01-20 00:25:49.571118
2864	EUR	ETB	181.26529788	2026-01-19	2026-01-20 00:25:49.579237
2865	ETB	EUR	0.005516775751870682	2026-01-19	2026-01-20 00:25:49.586944
2868	EUR	FJD	2.64920752	2026-01-19	2026-01-20 00:25:49.609512
2869	FJD	EUR	0.3774713730240355	2026-01-19	2026-01-20 00:25:49.616946
2870	EUR	FKP	0.86808364	2026-01-19	2026-01-20 00:25:49.624378
2871	FKP	EUR	1.1519627302272393	2026-01-19	2026-01-20 00:25:49.64324
2872	EUR	GBP	0.86808364	2026-01-19	2026-01-20 00:25:49.65062
2873	GBP	EUR	1.1519627302272393	2026-01-19	2026-01-20 00:25:49.658401
2874	EUR	GEL	3.12607497	2026-01-19	2026-01-20 00:25:49.665566
2875	GEL	EUR	0.31988996092438565	2026-01-19	2026-01-20 00:25:49.672465
2877	GGP	EUR	1.1519627302272393	2026-01-19	2026-01-20 00:25:49.686204
2878	EUR	GHS	12.57373638	2026-01-19	2026-01-20 00:25:49.703937
2879	GHS	EUR	0.0795308546145931	2026-01-19	2026-01-20 00:25:49.711173
2880	EUR	GIP	0.86808364	2026-01-19	2026-01-20 00:25:49.718921
2881	GIP	EUR	1.1519627302272393	2026-01-19	2026-01-20 00:25:49.726228
2882	EUR	GMD	85.75194915	2026-01-19	2026-01-20 00:25:49.733543
2883	GMD	EUR	0.011661542506174042	2026-01-19	2026-01-20 00:25:49.74139
2884	EUR	GNF	10177.48380814	2026-01-19	2026-01-20 00:25:49.749009
2885	GNF	EUR	9.825611308761752e-05	2026-01-19	2026-01-20 00:25:49.757462
2886	EUR	GTQ	8.9072365	2026-01-19	2026-01-20 00:25:49.765522
2887	GTQ	EUR	0.11226826636970962	2026-01-19	2026-01-20 00:25:49.77344
2888	EUR	GYD	242.95595434	2026-01-19	2026-01-20 00:25:49.780332
2889	GYD	EUR	0.004115972389796092	2026-01-19	2026-01-20 00:25:49.787777
2890	EUR	HKD	9.05885534	2026-01-19	2026-01-20 00:25:49.795375
2891	HKD	EUR	0.11038922275140339	2026-01-19	2026-01-20 00:25:49.802899
2892	EUR	HNL	30.64238072	2026-01-19	2026-01-20 00:25:49.809679
2894	EUR	HRK	7.5345	2026-01-19	2026-01-20 00:25:49.824292
2895	HRK	EUR	0.13272280841462605	2026-01-19	2026-01-20 00:25:49.831152
2896	EUR	HTG	152.46705463	2026-01-19	2026-01-20 00:25:49.838384
2897	HTG	EUR	0.006558793979635494	2026-01-19	2026-01-20 00:25:49.854313
2898	EUR	HUF	385.12278046	2026-01-19	2026-01-20 00:25:49.862194
2899	HUF	EUR	0.0025965745230795635	2026-01-19	2026-01-20 00:25:49.869796
2900	EUR	IDR	19656.82168084	2026-01-19	2026-01-20 00:25:49.878299
2901	IDR	EUR	5.087292423142472e-05	2026-01-19	2026-01-20 00:25:49.885804
2902	EUR	ILS	3.65897703	2026-01-19	2026-01-20 00:25:49.894164
2903	ILS	EUR	0.2733004311863636	2026-01-19	2026-01-20 00:25:49.902159
2904	EUR	IMP	0.86808364	2026-01-19	2026-01-20 00:25:49.90931
2905	IMP	EUR	1.1519627302272393	2026-01-19	2026-01-20 00:25:49.917645
2906	EUR	INR	105.37185215	2026-01-19	2026-01-20 00:25:49.925386
2907	INR	EUR	0.009490200462420172	2026-01-19	2026-01-20 00:25:49.933552
2908	EUR	IQD	1522.16527887	2026-01-19	2026-01-20 00:25:49.940887
2909	IQD	EUR	0.0006569588821145386	2026-01-19	2026-01-20 00:25:49.948246
2911	IRR	EUR	8.076695725939645e-07	2026-01-19	2026-01-20 00:25:49.964293
2912	EUR	ISK	146.21004911	2026-01-19	2026-01-20 00:25:49.9717
2913	ISK	EUR	0.006839475166632751	2026-01-19	2026-01-20 00:25:49.978648
2914	EUR	JEP	0.86808364	2026-01-19	2026-01-20 00:25:49.986973
2915	JEP	EUR	1.1519627302272393	2026-01-19	2026-01-20 00:25:49.994693
2916	EUR	JMD	183.2353672	2026-01-19	2026-01-20 00:25:50.002023
2917	JMD	EUR	0.005457461707752672	2026-01-19	2026-01-20 00:25:50.009347
2918	EUR	JOD	0.82386628	2026-01-19	2026-01-20 00:25:50.017025
2919	JOD	EUR	1.2137892086079796	2026-01-19	2026-01-20 00:25:50.024822
2920	EUR	JPY	183.36720509	2026-01-19	2026-01-20 00:25:50.045392
2921	JPY	EUR	0.005453537885955024	2026-01-19	2026-01-20 00:25:50.052717
2922	EUR	KES	149.88458238	2026-01-19	2026-01-20 00:25:50.059852
2923	KES	EUR	0.006671800288736275	2026-01-19	2026-01-20 00:25:50.06796
2804	EUR	BDT	142.10088236	2026-01-19	2026-01-20 00:25:49.074527
2805	BDT	EUR	0.007037253980355931	2026-01-19	2026-01-20 00:25:49.081512
2928	EUR	KMF	491.96774997	2026-01-19	2026-01-20 00:25:50.105699
2929	KMF	EUR	0.002032653563289422	2026-01-19	2026-01-20 00:25:50.113561
2930	EUR	KRW	1713.96637702	2026-01-19	2026-01-20 00:25:50.120786
2931	KRW	EUR	0.0005834420169540649	2026-01-19	2026-01-20 00:25:50.128067
2932	EUR	KWD	0.35748074	2026-01-19	2026-01-20 00:25:50.135704
2933	KWD	EUR	2.797353502177488	2026-01-19	2026-01-20 00:25:50.144552
2934	EUR	KYD	0.96566741	2026-01-19	2026-01-20 00:25:50.152307
2935	KYD	EUR	1.0355532242721124	2026-01-19	2026-01-20 00:25:50.159442
2936	EUR	KZT	594.05610665	2026-01-19	2026-01-20 00:25:50.166768
2937	KZT	EUR	0.001683342682291742	2026-01-19	2026-01-20 00:25:50.17484
2938	EUR	LAK	25107.80735698	2026-01-19	2026-01-20 00:25:50.182241
2939	LAK	EUR	3.982824887024628e-05	2026-01-19	2026-01-20 00:25:50.189301
2940	EUR	LBP	104116.50593745	2026-01-19	2026-01-20 00:25:50.19697
2941	LBP	EUR	9.604625039960227e-06	2026-01-19	2026-01-20 00:25:50.205049
2942	EUR	LKR	359.86618357	2026-01-19	2026-01-20 00:25:50.212297
2943	LKR	EUR	0.0027788106959082564	2026-01-19	2026-01-20 00:25:50.219325
2945	LRD	EUR	0.004766044561146981	2026-01-19	2026-01-20 00:25:50.251669
2946	EUR	LSL	19.07102957	2026-01-19	2026-01-20 00:25:50.259462
2947	LSL	EUR	0.05243555395525507	2026-01-19	2026-01-20 00:25:50.268288
2948	EUR	LYD	6.31232479	2026-01-19	2026-01-20 00:25:50.276198
2949	LYD	EUR	0.1584202387025779	2026-01-19	2026-01-20 00:25:50.285582
2950	EUR	MAD	10.72252218	2026-01-19	2026-01-20 00:25:50.296722
2951	MAD	EUR	0.09326163967888383	2026-01-19	2026-01-20 00:25:50.305112
2952	EUR	MDL	19.90269531	2026-01-19	2026-01-20 00:25:50.314077
2953	MDL	EUR	0.05024445103661691	2026-01-19	2026-01-20 00:25:50.340862
2954	EUR	MGA	5386.33196711	2026-01-19	2026-01-20 00:25:50.349493
2955	MGA	EUR	0.00018565510000241283	2026-01-19	2026-01-20 00:25:50.358091
2956	EUR	MKD	61.53134188	2026-01-19	2026-01-20 00:25:50.366656
2957	MKD	EUR	0.01625188025234726	2026-01-19	2026-01-20 00:25:50.375025
2958	EUR	MMK	2440.46608292	2026-01-19	2026-01-20 00:25:50.382443
2959	MMK	EUR	0.00040975779462728987	2026-01-19	2026-01-20 00:25:50.389722
2960	EUR	MNT	4143.96573026	2026-01-19	2026-01-20 00:25:50.397978
2962	EUR	MOP	9.330621	2026-01-19	2026-01-20 00:25:50.44377
2963	MOP	EUR	0.10717400267356267	2026-01-19	2026-01-20 00:25:50.451724
2964	EUR	MRU	46.52550276	2026-01-19	2026-01-20 00:25:50.459569
2965	MRU	EUR	0.02149358826187137	2026-01-19	2026-01-20 00:25:50.467353
2966	EUR	MUR	53.79890038	2026-01-19	2026-01-20 00:25:50.474829
2967	MUR	EUR	0.018587740510245723	2026-01-19	2026-01-20 00:25:50.482447
2968	EUR	MVR	17.96420465	2026-01-19	2026-01-20 00:25:50.490565
2969	MVR	EUR	0.05566625517150296	2026-01-19	2026-01-20 00:25:50.498191
2970	EUR	MWK	2013.87583888	2026-01-19	2026-01-20 00:25:50.506308
2971	MWK	EUR	0.0004965549418161458	2026-01-19	2026-01-20 00:25:50.514412
2972	EUR	MXN	20.48397324	2026-01-19	2026-01-20 00:25:50.522821
2973	MXN	EUR	0.04881865389509755	2026-01-19	2026-01-20 00:25:50.531372
2974	EUR	MYR	4.71438109	2026-01-19	2026-01-20 00:25:50.538222
2975	MYR	EUR	0.21211692073879415	2026-01-19	2026-01-20 00:25:50.546083
2976	EUR	MZN	74.24480539	2026-01-19	2026-01-20 00:25:50.553988
2977	MZN	EUR	0.013468955770671191	2026-01-19	2026-01-20 00:25:50.561245
2979	NAD	EUR	0.05243555395525507	2026-01-19	2026-01-20 00:25:50.576348
2980	EUR	NGN	1650.04836015	2026-01-19	2026-01-20 00:25:50.584333
2981	NGN	EUR	0.0006060428434407181	2026-01-19	2026-01-20 00:25:50.592141
2982	EUR	NIO	42.74736858	2026-01-19	2026-01-20 00:25:50.599048
2983	NIO	EUR	0.023393252806392976	2026-01-19	2026-01-20 00:25:50.607701
2984	EUR	NOK	11.71047703	2026-01-19	2026-01-20 00:25:50.616273
2985	NOK	EUR	0.08539361782087881	2026-01-19	2026-01-20 00:25:50.623753
2986	EUR	NPR	168.67399232	2026-01-19	2026-01-20 00:25:50.630945
2987	NPR	EUR	0.005928596259836248	2026-01-19	2026-01-20 00:25:50.643391
2988	EUR	NZD	2.01631792	2026-01-19	2026-01-20 00:25:50.650763
2989	NZD	EUR	0.4959535349465128	2026-01-19	2026-01-20 00:25:50.658748
2990	EUR	OMR	0.44728437	2026-01-19	2026-01-20 00:25:50.667503
2991	OMR	EUR	2.2357141609933744	2026-01-19	2026-01-20 00:25:50.675403
2992	EUR	PAB	1.16201168	2026-01-19	2026-01-20 00:25:50.682833
2993	PAB	EUR	0.8605765477331518	2026-01-19	2026-01-20 00:25:50.690725
2994	EUR	PEN	3.90250283	2026-01-19	2026-01-20 00:25:50.698862
2996	EUR	PGK	4.96242791	2026-01-19	2026-01-20 00:25:50.715574
2997	PGK	EUR	0.2015142624006401	2026-01-19	2026-01-20 00:25:50.723158
2998	EUR	PHP	69.01349237	2026-01-19	2026-01-20 00:25:50.730734
2999	PHP	EUR	0.014489920241084593	2026-01-19	2026-01-20 00:25:50.738734
3000	EUR	PKR	325.1187535	2026-01-19	2026-01-20 00:25:50.746764
3001	PKR	EUR	0.0030757991940935513	2026-01-19	2026-01-20 00:25:50.75473
3002	EUR	PLN	4.22376676	2026-01-19	2026-01-20 00:25:50.762585
3003	PLN	EUR	0.23675549736084384	2026-01-19	2026-01-20 00:25:50.770916
3004	EUR	PYG	7927.54061198	2026-01-19	2026-01-20 00:25:50.779394
3005	PYG	EUR	0.00012614252628221324	2026-01-19	2026-01-20 00:25:50.788024
3006	EUR	QAR	4.22972253	2026-01-19	2026-01-20 00:25:50.796014
3007	QAR	EUR	0.2364221276708664	2026-01-19	2026-01-20 00:25:50.803849
3008	EUR	RON	5.0895281	2026-01-19	2026-01-20 00:25:50.8113
3009	RON	EUR	0.19648187029363293	2026-01-19	2026-01-20 00:25:50.819179
3010	EUR	RSD	117.33878959	2026-01-19	2026-01-20 00:25:50.82644
3011	RSD	EUR	0.008522330965694769	2026-01-19	2026-01-20 00:25:50.834185
3013	RUB	EUR	0.011058123172469458	2026-01-19	2026-01-20 00:25:50.850559
3014	EUR	RWF	1691.76690703	2026-01-19	2026-01-20 00:25:50.857762
3015	RWF	EUR	0.0005910979791864832	2026-01-19	2026-01-20 00:25:50.866071
3016	EUR	SAR	4.35754382	2026-01-19	2026-01-20 00:25:50.87368
3017	SAR	EUR	0.22948707834222076	2026-01-19	2026-01-20 00:25:50.880523
3018	EUR	SBD	9.43445122	2026-01-19	2026-01-20 00:25:50.888108
3019	SBD	EUR	0.10599450637681075	2026-01-19	2026-01-20 00:25:50.895961
3020	EUR	SCR	17.72791132	2026-01-19	2026-01-20 00:25:50.903493
3021	SCR	EUR	0.056408224406664056	2026-01-19	2026-01-20 00:25:50.910778
3022	EUR	SDG	696.99895865	2026-01-19	2026-01-20 00:25:50.918352
3023	SDG	EUR	0.0014347223730963319	2026-01-19	2026-01-20 00:25:50.926749
3024	EUR	SEK	10.70673948	2026-01-19	2026-01-20 00:25:50.935385
3025	SEK	EUR	0.09339911575022278	2026-01-19	2026-01-20 00:25:50.945191
3026	EUR	SGD	1.49532015	2026-01-19	2026-01-20 00:25:50.953011
3027	SGD	EUR	0.6687531094929738	2026-01-19	2026-01-20 00:25:50.960444
3028	EUR	SHP	0.86808364	2026-01-19	2026-01-20 00:25:50.967478
3030	EUR	SLE	26.53539333	2026-01-19	2026-01-20 00:25:50.98258
3031	SLE	EUR	0.03768551638047266	2026-01-19	2026-01-20 00:25:50.989437
3032	EUR	SOS	662.33714182	2026-01-19	2026-01-20 00:25:50.996536
3033	SOS	EUR	0.0015098051080936737	2026-01-19	2026-01-20 00:25:51.004007
3034	EUR	SRD	44.60525352	2026-01-19	2026-01-20 00:25:51.01103
3035	SRD	EUR	0.0224188839001133	2026-01-19	2026-01-20 00:25:51.018726
3036	EUR	SSP	5287.27449358	2026-01-19	2026-01-20 00:25:51.02641
3037	SSP	EUR	0.00018913336185103237	2026-01-19	2026-01-20 00:25:51.045258
3038	EUR	STN	24.69450207	2026-01-19	2026-01-20 00:25:51.053505
3039	STN	EUR	0.04049484363626207	2026-01-19	2026-01-20 00:25:51.061674
3040	EUR	SYP	128.61998615	2026-01-19	2026-01-20 00:25:51.069537
3041	SYP	EUR	0.007774841452974298	2026-01-19	2026-01-20 00:25:51.077319
3042	EUR	SZL	19.07102957	2026-01-19	2026-01-20 00:25:51.084528
3043	SZL	EUR	0.05243555395525507	2026-01-19	2026-01-20 00:25:51.091963
2925	KGS	EUR	0.009841333281315982	2026-01-19	2026-01-20 00:25:50.08291
2926	EUR	KHR	4676.48832216	2026-01-19	2026-01-20 00:25:50.089841
3069	USD	EUR	0.8605765477331518	2026-01-19	2026-01-20 00:25:51.312687
3070	EUR	UYU	44.95347323	2026-01-19	2026-01-20 00:25:51.319504
3071	UYU	EUR	0.022245222185249155	2026-01-19	2026-01-20 00:25:51.327575
3072	EUR	UZS	13882.02593455	2026-01-19	2026-01-20 00:25:51.34631
3073	UZS	EUR	7.203559514401786e-05	2026-01-19	2026-01-20 00:25:51.354051
3074	EUR	VES	398.31738671	2026-01-19	2026-01-20 00:25:51.361644
3075	VES	EUR	0.002510560757238706	2026-01-19	2026-01-20 00:25:51.368849
3076	EUR	VND	30599.07220798	2026-01-19	2026-01-20 00:25:51.376334
3097	ZMW	EUR	0.04262016456204714	2026-01-19	2026-01-20 00:25:51.549782
3098	EUR	ZWL	74556.34229988	2026-01-19	2026-01-20 00:25:51.557406
3099	ZWL	EUR	1.3412675154821933e-05	2026-01-19	2026-01-20 00:25:51.56477
2780	EUR	AED	4.26748791	2026-01-19	2026-01-20 00:25:48.742668
2781	AED	EUR	0.23432989643783197	2026-01-19	2026-01-20 00:25:48.748331
2782	EUR	AFN	76.270328	2026-01-19	2026-01-20 00:25:48.755543
2785	ALL	EUR	0.010344062824317176	2026-01-19	2026-01-20 00:25:48.865212
2802	EUR	BBD	2.32402337	2026-01-19	2026-01-20 00:25:49.060355
2806	EUR	BGN	1.95583	2026-01-19	2026-01-20 00:25:49.088418
2823	BTN	EUR	0.009490200462420172	2026-01-19	2026-01-20 00:25:49.227949
2840	EUR	CNY	8.09292673	2026-01-19	2026-01-20 00:25:49.378299
2857	DOP	EUR	0.013517189396264406	2026-01-19	2026-01-20 00:25:49.515118
2876	EUR	GGP	0.86808364	2026-01-19	2026-01-20 00:25:49.679046
2893	HNL	EUR	0.032634540022776666	2026-01-19	2026-01-20 00:25:49.817341
2910	EUR	IRR	1238130.08924966	2026-01-19	2026-01-20 00:25:49.956098
2924	EUR	KGS	101.6122482	2026-01-19	2026-01-20 00:25:50.075494
2927	KHR	EUR	0.00021383566708835805	2026-01-19	2026-01-20 00:25:50.097739
2944	EUR	LRD	209.81759343	2026-01-19	2026-01-20 00:25:50.243653
2961	MNT	EUR	0.00024131473691923078	2026-01-19	2026-01-20 00:25:50.405995
2978	EUR	NAD	19.07102957	2026-01-19	2026-01-20 00:25:50.568428
2995	PEN	EUR	0.25624581033295496	2026-01-19	2026-01-20 00:25:50.707281
3012	EUR	RUB	90.43125894	2026-01-19	2026-01-20 00:25:50.84298
3029	SHP	EUR	1.1519627302272393	2026-01-19	2026-01-20 00:25:50.975444
3044	EUR	THB	36.38716008	2026-01-19	2026-01-20 00:25:51.098951
3045	THB	EUR	0.02748222169032764	2026-01-19	2026-01-20 00:25:51.106735
3046	EUR	TJS	10.82957312	2026-01-19	2026-01-20 00:25:51.114921
3047	TJS	EUR	0.09233974311999475	2026-01-19	2026-01-20 00:25:51.13902
3048	EUR	TMT	4.07471084	2026-01-19	2026-01-20 00:25:51.148052
3049	TMT	EUR	0.2454161876183587	2026-01-19	2026-01-20 00:25:51.155285
3050	EUR	TND	3.40917418	2026-01-19	2026-01-20 00:25:51.162917
3051	TND	EUR	0.29332616850923116	2026-01-19	2026-01-20 00:25:51.169764
3052	EUR	TOP	2.78468941	2026-01-19	2026-01-20 00:25:51.177018
3053	TOP	EUR	0.35910647572003374	2026-01-19	2026-01-20 00:25:51.185181
3054	EUR	TRY	50.2817567	2026-01-19	2026-01-20 00:25:51.192622
3055	TRY	EUR	0.019887928855914453	2026-01-19	2026-01-20 00:25:51.199935
3056	EUR	TTD	7.88375304	2026-01-19	2026-01-20 00:25:51.20727
3057	TTD	EUR	0.1268431411950976	2026-01-19	2026-01-20 00:25:51.215362
3058	EUR	TVD	1.73899129	2026-01-19	2026-01-20 00:25:51.222761
3059	TVD	EUR	0.5750460084248036	2026-01-19	2026-01-20 00:25:51.229903
3060	EUR	TWD	36.64154903	2026-01-19	2026-01-20 00:25:51.243054
3061	TWD	EUR	0.027291422619203608	2026-01-19	2026-01-20 00:25:51.251128
3062	EUR	TZS	2925.43748558	2026-01-19	2026-01-20 00:25:51.259126
3063	TZS	EUR	0.00034182921526410226	2026-01-19	2026-01-20 00:25:51.267585
3064	EUR	UAH	50.46725334	2026-01-19	2026-01-20 00:25:51.275263
3065	UAH	EUR	0.019814829098444453	2026-01-19	2026-01-20 00:25:51.283288
3066	EUR	UGX	4121.19936863	2026-01-19	2026-01-20 00:25:51.290509
3067	UGX	EUR	0.00024264780966722012	2026-01-19	2026-01-20 00:25:51.298223
3068	EUR	USD	1.16201168	2026-01-19	2026-01-20 00:25:51.305671
3077	VND	EUR	3.268072944182954e-05	2026-01-19	2026-01-20 00:25:51.383723
3078	EUR	VUV	140.84647471	2026-01-19	2026-01-20 00:25:51.391003
3079	VUV	EUR	0.007099929210574702	2026-01-19	2026-01-20 00:25:51.398161
3080	EUR	WST	3.22137484	2026-01-19	2026-01-20 00:25:51.405704
3081	WST	EUR	0.31042646375173155	2026-01-19	2026-01-20 00:25:51.413711
3082	EUR	XAF	655.95699996	2026-01-19	2026-01-20 00:25:51.421334
3083	XAF	EUR	0.0015244901724670668	2026-01-19	2026-01-20 00:25:51.443645
3084	EUR	XCD	3.14566365	2026-01-19	2026-01-20 00:25:51.451701
3085	XCD	EUR	0.31789794182222886	2026-01-19	2026-01-20 00:25:51.458466
3086	EUR	XDR	0.85197889	2026-01-19	2026-01-20 00:25:51.465661
3087	XDR	EUR	1.1737380018887558	2026-01-19	2026-01-20 00:25:51.472879
3088	EUR	XOF	655.95699996	2026-01-19	2026-01-20 00:25:51.479559
3089	XOF	EUR	0.0015244901724670668	2026-01-19	2026-01-20 00:25:51.487403
3090	EUR	XPF	119.33174224	2026-01-19	2026-01-20 00:25:51.495416
3091	XPF	EUR	0.008380000000241344	2026-01-19	2026-01-20 00:25:51.50295
3092	EUR	YER	277.08772006	2026-01-19	2026-01-20 00:25:51.510725
3093	YER	EUR	0.0036089654199885227	2026-01-19	2026-01-20 00:25:51.518874
3094	EUR	ZAR	19.07102957	2026-01-19	2026-01-20 00:25:51.526435
3095	ZAR	EUR	0.05243555395525507	2026-01-19	2026-01-20 00:25:51.533934
3096	EUR	ZMW	23.46307224	2026-01-19	2026-01-20 00:25:51.54285
\.


--
-- Data for Name: expense_name_mappings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.expense_name_mappings (id, expense_name, subcategory, confidence, last_updated) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.expenses (id, user_id, budget_period_id, recurring_template_id, name, amount, category, subcategory, date, due_date, payment_method, notes, receipt_url, is_fixed_bill, created_at, currency, original_amount, exchange_rate_used, deleted_at, updated_at) FROM stdin;
174	1	\N	\N	Wolt	3542	Flexible Expenses	Food	2025-12-31	N/A	Credit card	\N	\N	f	2026-01-01 12:39:24.380325	EUR	\N	\N	\N	\N
175	1	\N	\N	Wolt	1999	Flexible Expenses	Food	2025-12-31	N/A	Credit card	\N	\N	f	2026-01-01 12:39:36.191134	EUR	\N	\N	\N	\N
176	1	\N	\N	Nordea Credit Interest	466	Flexible Expenses	Other	2026-01-01	N/A	Credit card	\N	\N	f	2026-01-01 12:40:22.722058	EUR	\N	\N	\N	\N
182	1	\N	\N	Groceries	3814	Flexible Expenses	Food	2026-01-04	N/A	Credit card	\N	\N	f	2026-01-05 12:33:19.680494	EUR	\N	\N	\N	2026-01-06 18:13:35.298588
183	1	\N	\N	Wolt	1426	Flexible Expenses	Food	2026-01-04	N/A	Credit card	\N	\N	f	2026-01-05 12:33:32.53605	EUR	\N	\N	\N	2026-01-06 18:13:42.974698
184	1	\N	\N	Wolt	2534	Flexible Expenses	Food	2026-01-05	N/A	Debit card	\N	\N	f	2026-01-06 18:14:38.39144	EUR	\N	\N	\N	2026-01-06 18:14:38.391444
185	1	\N	\N	Groceries	2395	Flexible Expenses	Food	2026-01-05	N/A	Debit card	\N	\N	f	2026-01-06 18:15:00.953954	EUR	\N	\N	\N	2026-01-06 18:15:00.953961
186	1	\N	\N	Wolt	603	Flexible Expenses	Food	2026-01-06	N/A	Debit card	\N	\N	f	2026-01-06 18:15:20.494311	EUR	\N	\N	\N	2026-01-06 18:15:20.494314
187	1	\N	\N	Wolt	3062	Flexible Expenses	Food	2026-01-07	N/A	Credit card	\N	\N	f	2026-01-08 10:03:26.62518	EUR	\N	\N	\N	2026-01-08 10:03:26.625184
188	1	\N	\N	Wolt	1468	Flexible Expenses	Food	2026-01-07	N/A	Credit card	\N	\N	f	2026-01-08 10:03:39.434257	EUR	\N	\N	\N	2026-01-08 10:03:47.99694
189	1	\N	\N	Wolt	2274	Flexible Expenses	Food	2026-01-09	N/A	Debit card	\N	\N	f	2026-01-10 00:25:14.806832	EUR	\N	\N	\N	2026-01-10 00:25:14.806835
190	1	\N	\N	Wolt	1858	Flexible Expenses	Food	2026-01-09	N/A	Debit card	\N	\N	f	2026-01-10 00:25:26.691559	EUR	\N	\N	\N	2026-01-10 00:25:26.691564
191	1	\N	\N	Nordea Bank Abp	465	Fixed Expenses	Other	2026-01-12	N/A	Debit card	\N	\N	f	2026-01-12 16:05:53.696254	EUR	\N	\N	\N	2026-01-12 16:05:53.696257
196	1	\N	\N	Wolt	2239	Flexible Expenses	Food	2026-01-13	N/A	Credit card	\N	\N	f	2026-01-15 23:47:08.590161	EUR	\N	\N	\N	2026-01-15 23:47:08.590165
198	1	\N	\N	Wolt	2524	Flexible Expenses	Food	2026-01-14	N/A	Credit card	\N	\N	f	2026-01-15 23:47:56.423906	EUR	\N	\N	\N	2026-01-15 23:47:56.423912
216	1	\N	30	Credit repayment	50000	Debt Payments	Credit Card	2026-01-20	N/A	Debit card	\N	\N	t	2026-01-19 18:58:20.325585	EUR	\N	\N	\N	2026-01-19 18:58:20.32559
203	1	\N	16	Discord	999	Fixed Expenses	Subscriptions	2026-02-16	N/A	Credit card	\N	\N	t	2026-01-18 21:27:25.190712	EUR	\N	\N	\N	2026-01-19 18:33:57.806246
177	1	\N	12	YouTube	1499	Flexible Expenses	Entertainment	2026-01-28	N/A	Debit card	\N	\N	t	2026-01-02 14:41:43.623428	EUR	\N	\N	\N	2026-01-19 18:34:04.698256
148	1	\N	5	Klarna Turkish Airlines Old	10080	Debt Payments	Klarna Turkish Airlines Old	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.243697	EUR	\N	\N	\N	2026-01-19 18:34:06.504585
205	1	\N	15	Telia Dot	810	Fixed Expenses	Subscriptions	2026-02-15	N/A	Debit card	\N	\N	t	2026-01-18 21:27:25.273633	EUR	\N	\N	\N	2026-01-19 18:34:08.409446
178	1	\N	21	GH Copilot	3000	Fixed Expenses	Subscriptions	2026-01-26	N/A	Debit card	\N	\N	t	2026-01-02 14:41:43.653203	EUR	\N	\N	\N	2026-01-19 18:34:10.046004
202	1	\N	\N	Zooplus	6895	Flexible Expenses	Cat Stuff	2026-01-20	N/A	Debit card	\N	\N	f	2026-01-16 09:14:28.773466	EUR	\N	\N	\N	2026-01-19 18:34:11.559462
204	1	\N	11	Insinööriliitto	3525	Fixed Expenses	Insurance	2026-02-15	N/A	Debit card	\N	\N	t	2026-01-18 21:27:25.265677	EUR	\N	\N	\N	2026-01-19 18:34:15.857654
209	1	\N	28	Klarna Turkish Airlines Business Payment	10479	Debt Payments	Klarna Turkish Airlines Business	2026-01-20	N/A	Debit card	\N	\N	t	2026-01-19 17:54:42.936954	EUR	\N	\N	\N	2026-01-19 18:34:17.394832
195	1	\N	24	LähiTapiola Keskinäinen Vakuutus	5515	Fixed Expenses	Insurance	2026-01-20	N/A	Debit card	\N	\N	t	2026-01-12 16:10:35.397464	EUR	\N	\N	\N	2026-01-19 18:34:18.322653
2	1	2	1	Telia	4546	Debt Payments	Telia Rahoitus	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:13.991189	EUR	\N	\N	\N	2025-12-04 16:06:13.991189
208	1	\N	27	Credit payment	25000	Debt Payments	Credit Card	2026-01-20	N/A	Debit card	\N	\N	t	2026-01-19 17:51:34.176947	EUR	\N	\N	2026-01-19 18:56:49.480241	2026-01-19 18:56:49.480671
179	1	\N	\N	Groceries	1070	Flexible Expenses	Food	2026-01-01	N/A	Credit card	\N	\N	f	2026-01-02 14:42:24.505144	EUR	\N	\N	\N	2026-01-02 14:42:24.505147
192	1	\N	\N	Twitch Sub	998	Flexible Expenses	Entertainment	2026-01-09	N/A	Credit card	\N	\N	f	2026-01-12 16:06:58.770509	EUR	\N	\N	\N	2026-01-12 16:06:58.770514
197	1	\N	\N	Groceries 	3548	Flexible Expenses	Food	2026-01-13	N/A	Credit card	\N	\N	f	2026-01-15 23:47:29.784812	EUR	\N	\N	\N	2026-01-15 23:47:29.784816
200	1	\N	\N	Wolt	1478	Flexible Expenses	Food	2026-01-15	N/A	Debit card	\N	\N	f	2026-01-15 23:48:32.804414	EUR	\N	\N	\N	2026-01-15 23:48:32.80442
153	1	\N	15	Telia Dot	810	Fixed Expenses	Subscriptions	2026-01-16	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.320684	EUR	\N	\N	\N	2026-01-16 09:21:46.719367
210	1	\N	29	Emergency Fund Contribution	5000	Savings & Investments	Emergency Fund	2026-01-19	N/A	Debit card	\N	\N	f	2026-01-19 17:56:15.496308	EUR	\N	\N	\N	2026-01-19 17:56:15.496313
211	1	\N	\N	Wolt	2321	Flexible Expenses	Food	2026-01-17	N/A	Credit card	\N	\N	f	2026-01-19 17:57:27.172715	EUR	\N	\N	\N	2026-01-19 17:57:27.172718
212	1	\N	\N	Wolt	4009	Flexible Expenses	Food	2026-01-17	N/A	Credit card	\N	\N	f	2026-01-19 17:57:38.748356	EUR	\N	\N	\N	2026-01-19 17:57:38.74836
180	1	\N	23	Agria Eläinvakuutus	9456	Fixed Expenses	Insurance	2026-01-20	N/A	Debit card	\N	\N	t	2026-01-02 14:45:32.487023	EUR	\N	\N	\N	2026-01-19 18:34:20.78897
150	1	\N	2	Elisa	3535	Debt Payments	Elisa (Phone)	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.255682	EUR	\N	\N	\N	2026-01-19 18:34:21.792012
181	1	\N	\N	Credit Card Payment	24750	Debt Payments	Credit Card	2026-01-20	N/A	Debit card	\N	\N	f	2026-01-02 14:45:59.655067	EUR	\N	\N	2026-01-19 18:56:25.116789	2026-01-19 18:56:25.117159
206	1	\N	25	Credit card repayment	50000	Debt Payments	Credit Card	2026-01-20	N/A	Debit card	\N	\N	t	2026-01-18 21:34:01.969055	EUR	\N	\N	2026-01-19 18:56:37.612526	2026-01-19 18:56:37.612912
49	1	2	\N	Wolt	5004	Flexible Expenses	Food	2025-11-30	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.686852	EUR	\N	\N	\N	2025-12-04 16:06:14.686852
51	1	2	\N	Snapchat	99	Flexible Expenses	Entertainment	2025-11-30	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.707763	EUR	\N	\N	\N	2025-12-04 16:06:14.707763
52	1	2	\N	YouTube	1499	Flexible Expenses	Entertainment	2025-11-30	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.716167	EUR	\N	\N	\N	2025-12-04 16:06:14.716167
53	1	2	\N	Wolt	1478	Flexible Expenses	Food	2025-12-02	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.724467	EUR	\N	\N	\N	2025-12-04 16:06:14.724467
54	1	2	\N	Wolt	3356	Flexible Expenses	Food	2025-12-03	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.73294	EUR	\N	\N	\N	2025-12-04 16:06:14.73294
9	1	2	\N	Fortum	2651	Fixed Expenses	Utilities	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.056033	EUR	\N	\N	\N	2025-12-04 16:06:14.056033
193	1	\N	\N	Wolt	3757	Flexible Expenses	Food	2026-01-11	N/A	Credit card	\N	\N	f	2026-01-12 16:07:15.866414	EUR	\N	\N	\N	2026-01-12 16:07:15.866433
199	1	\N	\N	Groceries 	4719	Flexible Expenses	Food	2026-01-14	N/A	Credit card	\N	\N	f	2026-01-15 23:48:14.777834	EUR	\N	\N	\N	2026-01-15 23:48:14.777839
201	1	\N	\N	Wolt	2081	Flexible Expenses	Food	2026-01-15	N/A	Credit card	\N	\N	f	2026-01-15 23:48:51.326053	EUR	\N	\N	\N	2026-01-15 23:48:51.326059
213	1	\N	\N	Wolt	3041	Flexible Expenses	Food	2026-01-19	N/A	Credit card	\N	\N	f	2026-01-19 17:57:52.589001	EUR	\N	\N	\N	2026-01-19 17:57:52.589007
215	1	\N	12	YouTube	1499	Flexible Expenses	Entertainment	2026-01-30	N/A	Debit card	\N	\N	t	2026-01-19 18:33:06.698707	EUR	\N	\N	\N	2026-01-19 18:33:06.69871
207	1	\N	26	Credit card repayment	50000	Debt Payments	Credit Card	2026-01-20	N/A	Debit card	\N	\N	t	2026-01-18 21:37:30.876504	EUR	\N	\N	2026-01-19 18:35:20.060431	2026-01-19 18:35:20.060733
1	1	\N	\N	Pre-existing Credit Card Debt	141058	Debt	Credit Card	2025-11-19	N/A	Credit card	Existing credit card balance at budget period start	\N	f	2025-12-04 16:06:13.914645	EUR	\N	\N	\N	2025-12-04 16:06:13.914645
3	1	2	2	Elisa	3535	Debt Payments	Elisa (Phone)	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.001089	EUR	\N	\N	\N	2025-12-04 16:06:14.001089
4	1	2	3	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.009865	EUR	\N	\N	\N	2025-12-04 16:06:14.009865
5	1	2	4	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.018561	EUR	\N	\N	\N	2025-12-04 16:06:14.018561
6	1	2	5	Klarna Turkish Airlines Old	10080	Debt Payments	Klarna Turkish Airlines Old	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.030294	EUR	\N	\N	\N	2025-12-04 16:06:14.030294
7	1	2	\N	Rent	94718	Fixed Expenses	Rent	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.039037	EUR	\N	\N	\N	2025-12-04 16:06:14.039037
8	1	2	\N	DNA	3490	Fixed Expenses	Subscriptions	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.047386	EUR	\N	\N	\N	2025-12-04 16:06:14.047386
11	1	1	\N	Wise Europe SA	4233	Flexible Expenses	Shopping	2025-11-22	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.102966	EUR	\N	\N	\N	2025-12-04 16:06:14.102966
12	1	1	\N	Wise	3888	Flexible Expenses	Shopping	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.116186	EUR	\N	\N	\N	2025-12-04 16:06:14.116186
13	1	1	\N	UBER   *TRIP	18	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.125584	EUR	\N	\N	\N	2025-12-04 16:06:14.125584
14	1	1	\N	Nordea Responsible Global	5000	Flexible Expenses	Shopping	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.134744	EUR	\N	\N	\N	2025-12-04 16:06:14.134744
15	1	1	\N	UBER   *TRIP	37	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.143014	EUR	\N	\N	\N	2025-12-04 16:06:14.143014
16	1	1	\N	UBR* PENDING.UBER.COM	366	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.191232	EUR	\N	\N	\N	2025-12-04 16:06:14.191232
17	1	1	\N	UBR* PENDING.UBER.COM	277	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.2	EUR	\N	\N	\N	2025-12-04 16:06:14.2
18	1	1	\N	UBER   *TRIP	243	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.209241	EUR	\N	\N	\N	2025-12-04 16:06:14.209241
19	1	1	\N	UBER   *TRIP	73	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.217657	EUR	\N	\N	\N	2025-12-04 16:06:14.217657
20	1	1	\N	UBR* PENDING.UBER.COM	118	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.225929	EUR	\N	\N	\N	2025-12-04 16:06:14.225929
21	1	2	\N	PAYPAL *DISNEYPLUS	1099	Fixed Expenses	Subscriptions	2025-11-28	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.234435	EUR	\N	\N	\N	2025-12-04 16:06:14.234435
22	1	2	\N	Retail NLD Amsterdam UBER *TRIP HELP.UBER.C	2059	Flexible Expenses	Transportation	2025-11-27	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.287782	EUR	\N	\N	\N	2025-12-04 16:06:14.287782
23	1	1	\N	Retail FIN Finland Wolt Oy	2614	Flexible Expenses	Food	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.297088	EUR	\N	\N	\N	2025-12-04 16:06:14.297088
24	1	1	\N	Retail FIN HELSINKI VFI*Armina Oy ITIS	6767	Flexible Expenses	Shopping	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.30562	EUR	\N	\N	\N	2025-12-04 16:06:14.30562
25	1	1	\N	Retail NLD HELP.UBER.COM UBER *TRIP	1969	Flexible Expenses	Transportation	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.313831	EUR	\N	\N	\N	2025-12-04 16:06:14.313831
26	1	1	\N	Retail NLD Amsterdam UBER *TRIP HELP.UBER.C	1939	Flexible Expenses	Transportation	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.322517	EUR	\N	\N	\N	2025-12-04 16:06:14.322517
27	1	1	\N	Retail FIN Helsinki BIBI Bistro	1619	Flexible Expenses	Shopping	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.33067	EUR	\N	\N	\N	2025-12-04 16:06:14.33067
28	1	1	\N	Retail NLD Amsterdam UBER *TRIP HELP.UBER.C	1854	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.33925	EUR	\N	\N	\N	2025-12-04 16:06:14.33925
29	1	1	\N	Retail FIN Finland Wolt Oy	543	Flexible Expenses	Food	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.347687	EUR	\N	\N	\N	2025-12-04 16:06:14.347687
30	1	1	\N	Retail FIN Espoo KFC Iso Omena	1175	Flexible Expenses	Shopping	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.393561	EUR	\N	\N	\N	2025-12-04 16:06:14.393561
31	1	1	\N	Retail NLD HELP.UBER.COM UBER *TRIP	1697	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.401544	EUR	\N	\N	\N	2025-12-04 16:06:14.401544
32	1	1	\N	TRY 1182.18 Retail TUR ISTANBUL F17 OBICA MOZ	2487	Flexible Expenses	Shopping	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.409402	EUR	\N	\N	\N	2025-12-04 16:06:14.409402
33	1	1	\N	TRY 40.00 Retail NLD HELP.UBER.COM UBER *	84	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.417416	EUR	\N	\N	\N	2025-12-04 16:06:14.417416
34	1	1	\N	TRY 655.00 Retail NLD HELP.UBER.COM UBER *	1378	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.425739	EUR	\N	\N	\N	2025-12-04 16:06:14.425739
35	1	1	\N	TRY 1221.00 Retail TUR ISTANBUL TAKSI YONETIM	2577	Flexible Expenses	Shopping	2025-11-24	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.433975	EUR	\N	\N	\N	2025-12-04 16:06:14.433975
36	1	1	\N	Retail TUR ISTANBUL GNC AIRPORT HOTEL	100	Flexible Expenses	Shopping	2025-11-24	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.442823	EUR	\N	\N	\N	2025-12-04 16:06:14.442823
37	1	1	\N	Retail TUR ISTANBUL GNC AIRPORT HOTEL	3000	Flexible Expenses	Shopping	2025-11-24	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.493253	EUR	\N	\N	\N	2025-12-04 16:06:14.493253
38	1	1	\N	TRY 1650.00 Retail TUR ISTANBUL GNC AIRPORT H	3483	Flexible Expenses	Shopping	2025-11-24	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.502175	EUR	\N	\N	\N	2025-12-04 16:06:14.502175
39	1	1	\N	USD 67.95 Retail TUR ANKARA E-VISA TURKEY	6048	Flexible Expenses	Shopping	2025-11-23	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.510495	EUR	\N	\N	\N	2025-12-04 16:06:14.510495
40	1	1	\N	BDT 560.00 Retail BGD Shantinagar T FRESH &	405	Flexible Expenses	Shopping	2025-11-21	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.518961	EUR	\N	\N	\N	2025-12-04 16:06:14.518961
41	1	1	\N	BDT 400.00 Retail BGD Shantinagar T HAKKA EX	290	Flexible Expenses	Shopping	2025-11-21	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.527468	EUR	\N	\N	\N	2025-12-04 16:06:14.527468
42	1	1	\N	BDT 1680.00 Retail BGD Gulshan Model KIVAHAN	1223	Flexible Expenses	Shopping	2025-11-20	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.535601	EUR	\N	\N	\N	2025-12-04 16:06:14.535601
43	1	1	\N	BDT 470.00 Retail BGD Gulshan Model ALFRESCO	343	Flexible Expenses	Shopping	2025-11-20	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.587727	EUR	\N	\N	\N	2025-12-04 16:06:14.587727
44	1	1	\N	Payment to Klarna Turkish Airlines Old	4112	Debt Payments	Klarna Turkish Airlines Old	2025-11-26	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.597124	EUR	\N	\N	\N	2025-12-04 16:06:14.597124
45	1	2	11	Insinööriliitto	3525	Fixed Expenses	Insurance	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.605679	EUR	\N	\N	\N	2025-12-04 16:06:14.605679
46	1	2	\N	Mee6	4203	Flexible Expenses	Entertainment	2025-11-29	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.614016	EUR	\N	\N	\N	2025-12-04 16:06:14.614016
47	1	2	\N	ImageGPT	2241	Flexible Expenses	Entertainment	2025-11-29	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.622792	EUR	\N	\N	\N	2025-12-04 16:06:14.622792
48	1	2	\N	Namecheap	637	Flexible Expenses	Entertainment	2025-11-29	N/A	Credit card	\N	\N	f	2025-12-04 16:06:14.631742	EUR	\N	\N	\N	2025-12-04 16:06:14.631742
10	1	1	\N	Credit card repayment	99104	Debt Payments	Credit Card	2025-11-20	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.094241	EUR	\N	\N	\N	2025-12-04 16:06:14.094241
55	1	3	\N	Wolt	6212	Flexible Expenses	Food	2025-12-04	N/A	Debit card	\N	\N	f	2025-12-04 16:07:50.508079	EUR	\N	\N	\N	2025-12-04 16:07:50.508079
56	1	3	\N	Wolt	3294	Flexible Expenses	Food	2025-12-04	N/A	Debit card	\N	\N	f	2025-12-04 16:09:32.892452	EUR	\N	\N	\N	2025-12-04 16:09:32.892452
57	1	3	\N	Wolt	1027	Flexible Expenses	Food	2025-12-05	N/A	Debit card	\N	\N	f	2025-12-05 11:18:41.340793	EUR	\N	\N	\N	2025-12-05 11:18:41.340793
58	1	3	\N	Wolt	2424	Flexible Expenses	Food	2025-12-05	N/A	Debit card	\N	\N	f	2025-12-05 11:18:55.891369	EUR	\N	\N	\N	2025-12-05 11:18:55.891369
59	1	3	\N	Wolt	3271	Flexible Expenses	Food	2025-12-06	N/A	Credit card	\N	\N	f	2025-12-06 10:25:51.052266	EUR	\N	\N	\N	2025-12-06 10:25:51.052266
60	1	3	\N	Wolt	2101	Flexible Expenses	Food	2025-12-05	N/A	Debit card	\N	\N	f	2025-12-06 14:11:36.395363	EUR	\N	\N	\N	2025-12-06 14:11:36.395363
61	1	\N	\N	Uber	1304	Flexible Expenses	Transportation	2025-12-07	N/A	Debit card	\N	\N	f	2025-12-07 17:29:07.343085	EUR	\N	\N	\N	2025-12-07 17:29:07.343085
62	1	\N	\N	Uber	1251	Flexible Expenses	Transportation	2025-12-07	N/A	Debit card	\N	\N	f	2025-12-07 17:29:33.885755	EUR	\N	\N	\N	2025-12-07 17:29:33.885755
63	1	\N	\N	Wolt	2840	Flexible Expenses	Food	2025-12-07	N/A	Debit card	\N	\N	f	2025-12-07 17:29:44.937947	EUR	\N	\N	\N	2025-12-07 17:29:44.937947
64	1	\N	\N	Nordea	465	Fixed Expenses	Subscriptions	2025-12-10	N/A	Debit card	\N	\N	f	2025-12-10 08:14:21.791929	EUR	\N	\N	\N	2025-12-10 08:14:21.791929
65	1	\N	\N	Wolt	1351	Flexible Expenses	Food	2025-12-10	N/A	Debit card	\N	\N	f	2025-12-10 10:55:44.808684	EUR	\N	\N	\N	2025-12-10 10:55:44.808684
66	1	\N	\N	Wolt	3054	Flexible Expenses	Food	2025-12-10	N/A	Debit card	\N	\N	f	2025-12-10 10:55:55.959342	EUR	\N	\N	\N	2025-12-10 10:55:55.959342
67	1	\N	\N	Uber	912	Flexible Expenses	Transportation	2025-12-11	N/A	Debit card	\N	\N	f	2025-12-11 10:47:24.381581	EUR	\N	\N	\N	2025-12-11 10:47:24.381581
68	1	\N	\N	Sodexo Nokia	860	Flexible Expenses	Food	2025-12-11	N/A	Debit card	\N	\N	f	2025-12-11 10:47:48.478915	EUR	\N	\N	\N	2025-12-11 10:47:48.478915
69	1	\N	\N	Settlement Survivors	692	Flexible Expenses	Entertainment	2025-12-11	N/A	Credit card	\N	\N	f	2025-12-11 10:48:29.418718	EUR	\N	\N	\N	2025-12-11 10:48:29.418718
70	1	\N	\N	Nordea Credit	99	Fixed Expenses	Subscriptions	2025-12-11	N/A	Credit card	\N	\N	f	2025-12-11 10:48:52.431043	EUR	\N	\N	\N	2025-12-11 10:48:52.431043
71	1	\N	\N	HSL	320	Flexible Expenses	Transportation	2025-12-11	N/A	Debit card	\N	\N	f	2025-12-11 21:22:50.721342	EUR	\N	\N	\N	2025-12-11 21:22:50.721342
72	1	\N	\N	Uber	1378	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	\N	\N	f	2025-12-11 21:24:18.577382	EUR	\N	\N	\N	2025-12-11 21:24:18.577382
73	1	\N	\N	Wolt	1626	Flexible Expenses	Food	2025-12-12	N/A	Debit card	\N	\N	f	2025-12-12 12:39:14.744577	EUR	\N	\N	\N	2025-12-12 12:39:14.744577
85	1	\N	\N	Wolt	1999	Flexible Expenses	Food	2025-12-12	N/A	Credit card	\N	\N	f	2025-12-12 23:57:15.117517	EUR	\N	\N	\N	2025-12-12 23:57:15.117517
86	1	\N	\N	Wolt	5129	Flexible Expenses	Food	2025-12-12	N/A	Credit card	\N	\N	f	2025-12-12 23:57:24.640442	EUR	\N	\N	\N	2025-12-12 23:57:24.640442
87	1	\N	\N	Verkkokauppa (OnePlus Buds Pro 4)	8590	Flexible Expenses	Shopping	2025-12-12	N/A	Debit card	\N	\N	f	2025-12-12 23:58:13.154874	EUR	\N	\N	\N	2025-12-12 23:58:13.154874
88	1	\N	\N	Adjusting credit	10	Fixed Expenses	Utilities	2025-12-12	N/A	Credit card	\N	\N	f	2025-12-12 23:58:48.067889	EUR	\N	\N	\N	2025-12-12 23:58:48.067889
78	1	\N	5	Klarna Turkish Airlines Old	10080	Debt Payments	Klarna Turkish Airlines Old	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.26532	EUR	\N	\N	\N	2025-12-12 12:42:47.26532
74	1	\N	1	Telia	4546	Debt Payments	Telia Rahoitus	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.226641	EUR	\N	\N	\N	2025-12-12 12:42:47.226641
75	1	\N	2	Elisa	3535	Debt Payments	Elisa (Phone)	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.237049	EUR	\N	\N	\N	2025-12-12 12:42:47.237049
76	1	\N	3	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.246338	EUR	\N	\N	\N	2025-12-12 12:42:47.246338
77	1	\N	4	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.255959	EUR	\N	\N	\N	2025-12-12 12:42:47.255959
82	1	\N	10	DNA	3490	Fixed Expenses	Subscriptions	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.33003	EUR	\N	\N	\N	2025-12-12 12:42:47.33003
80	1	\N	8	Rent	94718	Fixed Expenses	Rent	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.284605	EUR	\N	\N	\N	2025-12-12 12:42:47.284605
100	1	\N	\N	Caruna	4583	Fixed Expenses	Utilities	2025-12-19	N/A	Debit card	\N	\N	f	2025-12-13 00:01:33.115932	EUR	\N	\N	\N	2025-12-13 00:01:33.115932
114	1	\N	\N	Canva Subscription	600	Flexible Expenses	Shopping	2025-12-15	N/A	Debit card	\N	\N	f	2025-12-15 15:40:41.915651	EUR	\N	\N	\N	2025-12-15 15:40:41.915651
113	1	\N	15	Telia Dot	810	Fixed Expenses	Subscriptions	2025-12-15	N/A	Debit card	\N	\N	f	2025-12-15 15:08:07.937896	EUR	\N	\N	\N	2025-12-15 15:08:07.937896
115	1	\N	\N	Prime Video	699	Flexible Expenses	Entertainment	2025-12-15	N/A	Debit card	\N	\N	f	2025-12-15 15:41:37.334051	EUR	\N	\N	\N	2025-12-15 15:41:37.334051
118	1	\N	16	Discord	999	Fixed Expenses	Subscriptions	2025-12-16	N/A	Credit card	\N	\N	f	2025-12-16 14:24:00.304481	EUR	\N	\N	\N	2025-12-16 14:24:00.304481
121	1	\N	\N	Wolt	1711	Flexible Expenses	Food	2025-12-16	N/A	Debit card	\N	\N	f	2025-12-16 14:26:21.878437	EUR	\N	\N	\N	2025-12-16 14:26:21.878437
122	1	\N	\N	Wolt	2672	Flexible Expenses	Food	2025-12-16	N/A	Debit card	\N	\N	f	2025-12-16 14:26:27.815188	EUR	\N	\N	\N	2025-12-16 14:26:27.815188
128	1	\N	\N	Temu	6045	Flexible Expenses	Shopping	2025-12-17	N/A	Debit card	\N	\N	f	2025-12-17 09:38:16.68101	EUR	\N	\N	\N	2025-12-17 09:38:16.68101
130	1	\N	\N	Wolt	1487	Flexible Expenses	Food	2025-12-17	N/A	Credit card	\N	\N	f	2025-12-17 16:07:58.844461	EUR	\N	\N	\N	2025-12-17 16:07:58.844461
131	1	\N	\N	Wolt	2270	Flexible Expenses	Food	2025-12-17	N/A	Credit card	\N	\N	f	2025-12-17 16:08:11.427218	EUR	\N	\N	\N	2025-12-17 16:08:11.427218
132	1	\N	\N	Wolt	2365	Flexible Expenses	Food	2025-12-18	N/A	Debit card	\N	\N	f	2025-12-18 22:23:55.164613	EUR	\N	\N	\N	2025-12-18 22:23:55.164613
133	1	\N	\N	Netflix	949	Flexible Expenses	Entertainment	2025-12-18	N/A	Credit card	\N	\N	f	2025-12-18 22:24:50.576909	EUR	\N	\N	\N	2025-12-18 22:24:50.576909
134	1	\N	\N	Temu	4215	Flexible Expenses	Shopping	2025-12-19	N/A	Debit card	\N	\N	f	2025-12-19 07:53:36.408135	EUR	\N	\N	\N	2025-12-19 07:53:36.408135
81	1	\N	9	Fortum	1788	Fixed Expenses	Utilities	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.293648	EUR	\N	\N	\N	2025-12-12 12:42:47.293648
135	1	\N	\N	Savings	5000	Savings & Investments	Emergency Fund	2025-12-19	N/A	Debit card	\N	\N	f	2025-12-20 16:55:12.277545	EUR	\N	\N	\N	2025-12-20 16:55:12.277545
137	1	\N	\N	Klarna Turkish Airlines Business Payment	10479	Debt Payments	Klarna Turkish Airlines Business	2025-12-19	N/A	Debit card	\N	\N	f	2025-12-21 13:24:38.400549	EUR	\N	\N	\N	2025-12-21 13:24:38.400549
138	1	\N	\N	Wolt	2796	Flexible Expenses	Food	2025-12-21	N/A	Debit card	\N	\N	f	2025-12-21 13:25:10.284668	EUR	\N	\N	\N	2025-12-21 13:25:10.284668
140	1	\N	\N	Wolt	4549	Flexible Expenses	Food	2025-12-21	N/A	Debit card	\N	\N	f	2025-12-21 15:45:20.225022	EUR	\N	\N	\N	2025-12-21 15:45:20.225022
127	1	\N	\N	Zooplus	4946	Flexible Expenses	Cat Stuff	2025-12-17	N/A	Debit card	\N	\N	f	2025-12-16 23:57:32.64	EUR	\N	\N	\N	2025-12-16 23:57:32.64
125	1	\N	\N	Credit repayment	80000	Debt Payments	Credit Card	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-16 23:56:34.555753	EUR	\N	\N	\N	2025-12-16 23:56:34.555753
141	1	\N	12	YouTube	1499	Flexible Expenses	Entertainment	2025-12-30	N/A	Debit card	\N	\N	t	2025-12-22 23:54:35.07162	EUR	\N	\N	\N	2025-12-22 23:54:35.07162
142	1	\N	16	Discord	999	Fixed Expenses	Subscriptions	2026-01-16	N/A	Credit card	\N	\N	t	2025-12-23 00:25:02.137551	EUR	\N	\N	\N	2025-12-23 00:25:02.137551
149	1	\N	18	Investment (Nordea) Contribution	5000	Savings & Investments	Investment (Nordea)	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-23 00:25:02.249619	EUR	\N	\N	\N	2025-12-23 00:25:02.249619
152	1	\N	11	Insinööriliitto	3525	Fixed Expenses	Insurance	2026-01-15	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.314166	EUR	\N	\N	\N	2025-12-23 00:25:02.314166
154	3	\N	\N	Emergency	55000	Savings & Investments	Emergency Fund	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-23 16:46:44.230719	EUR	\N	\N	\N	2025-12-23 16:46:44.230719
155	3	\N	\N	Wolt	2400	Fixed Expenses	Insurance	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-23 16:48:17.557856	EUR	\N	\N	\N	2025-12-23 16:48:17.557856
156	1	\N	\N	Proton vpn	999	Flexible Expenses	Entertainment	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-23 18:44:26.114863	EUR	\N	\N	\N	2025-12-23 18:44:26.114863
157	1	\N	\N	Wolt	3311	Flexible Expenses	Food	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-24 01:18:34.460833	EUR	\N	\N	\N	2025-12-24 01:18:34.460833
158	1	\N	\N	Wolt	1520	Flexible Expenses	Food	2025-12-23	N/A	Credit card	\N	\N	f	2025-12-24 01:19:10.006105	EUR	\N	\N	\N	2025-12-24 01:19:10.006105
159	1	\N	\N	Wolt	1478	Flexible Expenses	Food	2025-12-24	N/A	Credit card	\N	\N	f	2025-12-24 22:52:06.079252	EUR	\N	\N	\N	2025-12-24 22:52:06.079252
163	1	\N	\N	Wolt	3131	Flexible Expenses	Food	2025-12-26	N/A	Credit card	\N	\N	f	2025-12-26 00:53:58.440674	EUR	\N	\N	\N	2025-12-26 00:53:58.440674
144	1	\N	10	DNA	3490	Fixed Expenses	Subscriptions	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.219266	EUR	\N	\N	\N	2026-01-19 18:34:23.493855
146	1	\N	3	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.231736	EUR	\N	\N	\N	2026-01-19 18:34:24.474393
145	1	\N	1	Telia	4546	Debt Payments	Telia Rahoitus	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.225717	EUR	\N	\N	\N	2026-01-19 18:34:26.771282
147	1	\N	8	Rent	94718	Fixed Expenses	Rent	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.237762	EUR	\N	\N	\N	2026-01-19 18:34:27.683826
143	1	\N	9	Fortum	3000	Fixed Expenses	Utilities	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.212115	EUR	\N	\N	\N	2026-01-19 18:34:28.587256
160	1	\N	18	Investment (Nordea) Contribution	5000	Savings & Investments	Investment (Nordea)	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-25 20:33:33.013964	EUR	\N	\N	\N	2026-01-19 18:34:30.017943
151	1	\N	4	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.261507	EUR	\N	\N	\N	2026-01-19 18:34:31.093199
164	1	\N	\N	Wolt	2371	Flexible Expenses	Food	2025-12-26	N/A	Credit card	\N	\N	f	2025-12-26 00:54:07.718831	EUR	\N	\N	\N	2025-12-26 00:54:07.718831
162	1	\N	21	GH Copilot	2660	Fixed Expenses	Subscriptions	2025-12-25	N/A	Debit card	\N	\N	t	2025-12-25 22:52:49.855037	EUR	\N	\N	\N	2025-12-25 22:52:49.855037
169	1	\N	\N	Shakerapu Uber TO BE REFUNDED LATER	2717	Flexible Expenses	Transportation	2025-12-26	N/A	Debit card	\N	\N	f	2025-12-27 20:21:39.263007	EUR	\N	\N	\N	2025-12-27 20:21:39.263007
167	1	\N	\N	Pharmace	2087	Flexible Expenses	Health	2025-12-26	N/A	Credit card	\N	\N	f	2025-12-26 15:46:23.778589	EUR	\N	\N	\N	2025-12-26 15:46:23.778589
168	1	\N	\N	Ikea	4736	Flexible Expenses	Shopping	2025-12-26	N/A	Credit card	\N	\N	f	2025-12-26 16:08:29.451183	EUR	\N	\N	\N	2025-12-26 16:08:29.451183
170	1	\N	\N	Wolt	1351	Flexible Expenses	Food	2025-12-27	N/A	Credit card	\N	\N	f	2025-12-27 20:22:55.7972	EUR	\N	\N	\N	2025-12-27 20:22:55.7972
171	1	\N	\N	Wolt	2376	Flexible Expenses	Food	2025-12-27	N/A	Credit card	\N	\N	f	2025-12-27 20:23:17.984519	EUR	\N	\N	\N	2025-12-27 20:23:17.984519
172	1	\N	\N	Wolt	2696	Flexible Expenses	Food	2025-12-29	N/A	Credit card	\N	\N	f	2025-12-29 17:55:28.790884	EUR	\N	\N	\N	2025-12-29 17:55:28.790884
173	1	\N	\N	Wolt	2326	Flexible Expenses	Food	2025-12-29	N/A	Credit card	\N	\N	f	2025-12-29 17:55:41.000062	EUR	\N	\N	\N	2025-12-29 17:55:41.000062
194	1	\N	\N	Wolt	1998	Flexible Expenses	Food	2026-01-11	N/A	Credit card	\N	\N	f	2026-01-12 16:07:28.389005	EUR	\N	\N	\N	2026-01-12 16:07:28.389009
214	1	\N	\N	Groceries	2472	Flexible Expenses	Food	2026-01-19	N/A	Credit card	\N	\N	f	2026-01-19 17:58:09.211965	EUR	\N	\N	\N	2026-01-19 17:58:09.211969
\.


--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.goals (id, user_id, name, description, target_amount, target_date, subcategory_name, is_active, created_at, updated_at, initial_amount, deleted_at) FROM stdin;
4	3	Emergency Fund	For an emergency fund nigga	700000	\N	Emergency Fund	t	2025-12-23 16:44:06.685006	2025-12-23 16:44:06.68501	0	\N
3	1	Emergency Fund	\N	200000	\N	Emergency Fund	t	2025-12-23 00:02:04.667374	2025-12-25 14:46:43.906066	34754	\N
2	1	Investment (Nordea)	\N	100000	2026-12-31	Investment (Nordea)	t	2025-12-22 23:43:36.744481	2025-12-25 14:47:10.676058	5036	\N
\.


--
-- Data for Name: income; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.income (id, user_id, budget_period_id, type, amount, scheduled_date, actual_date, created_at, currency, original_amount, exchange_rate_used, deleted_at, updated_at, recurring_income_id) FROM stdin;
1	1	\N	Initial Balance	307200	2025-11-20	2025-11-20	2025-12-04 16:06:13.923676	EUR	\N	\N	\N	2025-12-04 16:06:13.923676	\N
2	1	2	Other	30350	2025-11-27	2025-11-27	2025-12-04 16:06:14.746151	EUR	\N	\N	\N	2025-12-04 16:06:14.746151	\N
3	1	\N	Salary	281545	2025-12-19	2025-12-19	2025-12-16 22:12:14.124386	EUR	\N	\N	\N	2025-12-16 22:12:14.124386	\N
5	3	\N	Initial Balance	200000	2025-12-23	2025-12-23	2025-12-23 16:45:25.789574	EUR	\N	\N	\N	2025-12-23 16:45:25.789574	\N
6	1	\N	Other	1700	2025-12-26	2025-12-26	2025-12-26 00:55:18.222986	EUR	\N	\N	\N	2025-12-26 00:55:18.222986	\N
7	1	\N	Other	33	2026-01-01	2026-01-01	2026-01-01 12:41:14.635775	EUR	\N	\N	\N	\N	\N
8	1	\N	Salary	281746	2026-01-20	2026-01-20	2026-01-15 23:49:52.274194	EUR	\N	\N	2026-01-19 16:38:51.053636	2026-01-19 16:38:51.055585	\N
9	1	\N	Salary	281746	2026-01-20	2026-01-20	2026-01-19 16:39:11.861294	EUR	\N	\N	2026-01-19 18:28:58.994363	2026-01-19 18:28:59.085335	1
10	1	\N	Salary	281746	2026-01-20	2026-01-20	2026-01-19 18:45:10.719005	EUR	\N	\N	\N	2026-01-19 18:45:10.719011	2
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.password_reset_tokens (id, user_id, token, expires_at, is_used, created_at) FROM stdin;
\.


--
-- Data for Name: period_suggestions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.period_suggestions (id, user_id, budget_period_id, suggestion_type, amount, status, created_at) FROM stdin;
\.


--
-- Data for Name: rate_limits; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.rate_limits (id, key, "timestamp") FROM stdin;
1	127.0.0.1:auth.login	2026-01-02 13:32:06.521104
2	127.0.0.1:auth.login	2026-01-02 20:54:51.450792
3	127.0.0.1:auth.login	2026-01-03 12:53:04.83934
4	127.0.0.1:auth.login	2026-01-04 22:32:42.144205
5	127.0.0.1:auth.login	2026-01-05 12:32:46.10047
6	127.0.0.1:auth.login	2026-01-05 14:54:25.541707
7	127.0.0.1:auth.login	2026-01-06 18:12:52.600699
8	127.0.0.1:auth.login	2026-01-08 10:02:57.268147
9	127.0.0.1:auth.login	2026-01-10 00:21:43.369752
10	127.0.0.1:auth.login	2026-01-12 16:04:16.951563
11	127.0.0.1:auth.login	2026-01-13 00:26:23.566556
12	127.0.0.1:auth.login	2026-01-13 18:41:54.630062
13	127.0.0.1:auth.login	2026-01-13 18:42:03.575116
14	127.0.0.1:auth.login	2026-01-13 18:42:15.613276
15	127.0.0.1:auth.login	2026-01-13 18:42:25.250544
16	127.0.0.1:auth.login	2026-01-13 18:42:38.195113
17	127.0.0.1:auth.login	2026-01-15 23:45:20.471575
18	127.0.0.1:auth.login	2026-01-15 23:45:24.274068
19	127.0.0.1:auth.login	2026-01-16 09:06:30.568283
20	127.0.0.1:auth.login	2026-01-16 10:06:42.02259
21	127.0.0.1:auth.login	2026-01-16 11:40:13.712075
22	127.0.0.1:auth.login	2026-01-18 21:24:09.065068
23	127.0.0.1:auth.login	2026-01-19 16:38:00.417925
24	127.0.0.1:auth.login	2026-01-19 17:46:35.280538
25	127.0.0.1:auth.login	2026-01-19 18:56:12.750494
26	127.0.0.1:auth.login	2026-01-20 00:24:53.535259
\.


--
-- Data for Name: recurring_expenses; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.recurring_expenses (id, user_id, name, amount, category, subcategory, payment_method, frequency, frequency_value, day_of_month, day_of_week, start_date, end_date, next_due_date, is_active, is_fixed_bill, notes, created_at, updated_at, deleted_at) FROM stdin;
10	1	DNA	3490	Fixed Expenses	Subscriptions	Debit card	monthly	\N	20	\N	2025-12-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.831015	2026-01-19 18:33:06.605847	\N
8	1	Rent	94718	Fixed Expenses	Rent	Debit card	monthly	\N	20	\N	2025-12-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.820155	2026-01-19 18:33:06.610341	\N
4	1	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	Debit card	monthly	\N	20	\N	2025-11-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.797164	2026-01-19 18:33:06.614613	\N
25	1	Credit card repayment	50000	Debt Payments	Credit Card	Debit card	monthly	\N	20	\N	2026-01-20	2026-01-20	2026-02-20	f	t	\N	2026-01-18 21:33:44.330619	2026-01-18 21:36:52.887576	2026-01-18 21:36:52.886845
5	1	Klarna Turkish Airlines Old	10080	Debt Payments	Klarna Turkish Airlines Old	Debit card	monthly	\N	20	\N	2025-11-24	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.802794	2026-01-19 18:33:06.619167	\N
28	1	Klarna Turkish Airlines Business Payment	10479	Debt Payments	Klarna Turkish Airlines Business	Debit card	monthly	\N	20	\N	2026-01-20	\N	2026-02-20	t	t	\N	2026-01-19 17:54:26.972551	2026-01-19 18:33:06.623275	\N
3	1	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	Debit card	monthly	\N	20	\N	2025-11-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.790754	2026-01-19 18:33:06.627663	\N
2	1	Elisa	3535	Debt Payments	Elisa (Phone)	Debit card	monthly	\N	20	\N	2025-11-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.744124	2026-01-19 18:33:06.632155	\N
18	1	Investment (Nordea) Contribution	5000	Savings & Investments	Investment (Nordea)	Debit card	monthly	\N	20	\N	2025-12-23	\N	2026-02-20	t	t	\N	2025-12-23 00:23:52.47975	2026-01-19 18:33:06.688192	\N
21	1	GH Copilot	3000	Fixed Expenses	Subscriptions	Debit card	monthly	\N	26	\N	2025-12-25	\N	2026-02-26	t	t	\N	2025-12-25 22:52:44.319215	2026-01-19 18:33:06.692618	\N
12	1	YouTube	1499	Flexible Expenses	Entertainment	Debit card	monthly	\N	30	\N	2025-11-30	\N	2026-02-28	t	t	\N	2025-12-04 16:06:13.887384	2026-01-19 18:33:06.741192	\N
15	1	Telia Dot	810	Fixed Expenses	Subscriptions	Debit card	monthly	\N	15	\N	2026-01-15	\N	2026-03-15	t	t	\N	2025-12-15 15:08:07.74988	2026-01-19 18:33:06.746738	\N
11	1	Insinööriliitto	3525	Fixed Expenses	Insurance	Debit card	monthly	\N	15	\N	2026-01-15	\N	2026-03-15	t	t	\N	2025-12-04 16:06:13.836541	2026-01-19 18:33:06.750861	\N
16	1	Discord	999	Fixed Expenses	Subscriptions	Credit card	monthly	\N	16	\N	2026-01-16	\N	2026-03-16	t	t	\N	2025-12-16 14:23:59.9971	2026-01-19 18:33:06.755066	\N
19	3	Emergency Fund Contribution	1500	Savings & Investments	Emergency Fund	Credit card	monthly	\N	1	\N	2025-12-23	\N	2025-12-23	t	f	\N	2025-12-23 16:44:37.639115	2025-12-23 16:44:37.639117	\N
23	1	Agria Eläinvakuutus	9456	Fixed Expenses	Insurance	Debit card	custom	90	\N	\N	2026-01-20	\N	2026-04-20	t	t	\N	2026-01-02 14:45:24.04644	2026-01-19 18:33:06.760137	\N
27	1	Credit payment	50000	Debt Payments	Credit Card	Debit card	monthly	\N	20	\N	2026-01-20	2026-01-20	2026-02-20	t	t	\N	2026-01-19 17:51:14.425002	2026-01-19 18:56:56.901751	2026-01-19 18:56:56.901141
26	1	Credit card repayment	50000	Debt Payments	Credit Card	Debit card	monthly	\N	20	\N	2026-01-20	2026-01-20	2026-02-20	t	t	\N	2026-01-18 21:36:23.770415	2026-01-19 17:51:34.171301	2026-01-19 17:47:30.090384
30	1	Credit repayment	50000	Debt Payments	Credit Card	Debit card	monthly	\N	20	\N	2026-01-20	\N	2026-02-20	t	t	\N	2026-01-19 18:58:13.656133	2026-01-19 18:58:20.329469	\N
29	1	Emergency Fund Contribution	5000	Savings & Investments	Emergency Fund	Debit card	monthly	\N	19	\N	2026-01-19	\N	2026-02-19	t	f	\N	2026-01-19 17:56:09.97969	2026-01-19 18:33:06.532964	\N
24	1	LähiTapiola Keskinäinen Vakuutus	5515	Fixed Expenses	Insurance	Debit card	custom	90	\N	\N	2026-01-20	\N	2026-04-20	t	t	\N	2026-01-12 16:10:26.347114	2026-01-19 18:33:06.592303	\N
9	1	Fortum	3000	Fixed Expenses	Utilities	Debit card	monthly	\N	20	\N	2025-12-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.825636	2026-01-19 18:33:06.597332	\N
1	1	Telia	4546	Debt Payments	Telia Rahoitus	Debit card	monthly	\N	20	\N	2025-11-20	\N	2026-02-20	t	t	\N	2025-12-04 16:06:13.734805	2026-01-19 18:33:06.601603	\N
\.


--
-- Data for Name: recurring_income; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.recurring_income (id, user_id, name, amount, income_type, currency, frequency, frequency_value, day_of_month, day_of_week, start_date, end_date, next_due_date, is_active, notes, created_at, updated_at, deleted_at) FROM stdin;
1	1	Monthly Salary	281746	Salary	EUR	monthly	\N	20	\N	2026-01-20	\N	2026-01-20	t	\N	2026-01-19 16:39:06.184139	2026-01-19 18:44:34.413523	2026-01-19 18:44:34.4125
2	1	Monthly Salary	281746	Salary	EUR	monthly	\N	20	\N	2026-01-20	\N	2026-02-20	t	\N	2026-01-19 18:45:05.499847	2026-01-19 18:45:10.724572	\N
\.


--
-- Data for Name: salary_periods; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.salary_periods (id, user_id, initial_debit_balance, initial_credit_balance, credit_limit, credit_budget_allowance, salary_amount, total_budget_amount, fixed_bills_total, remaining_amount, weekly_budget, weekly_debit_budget, weekly_credit_budget, start_date, end_date, is_active, created_at, updated_at, num_sub_periods) FROM stdin;
3	3	200000	0	2000000	0	\N	200000	0	200000	50000	50000	0	2025-12-23	2026-01-22	t	2025-12-23 16:45:25.738348	2025-12-23 16:45:25.738348	4
2	1	289374	50178	150000	20000	\N	69558	239816	69558	17389	12389	5000	2025-12-20	2026-01-19	t	2025-12-17 10:14:43.940326	2025-12-17 10:14:43.940326	4
1	1	307200	8942	150000	0	\N	73462	233738	73462	18365	18365	0	2025-11-20	2025-12-19	t	2025-12-04 16:06:13.895815	2025-12-04 16:06:13.895815	4
\.


--
-- Data for Name: subcategories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.subcategories (id, user_id, category, name, is_system, is_active, created_at, updated_at) FROM stdin;
1	\N	Flexible Expenses	Food	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
2	\N	Savings & Investments	Other	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
3	\N	Fixed Expenses	Subscriptions	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
4	\N	Flexible Expenses	Shopping	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
5	\N	Fixed Expenses	Other	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
7	\N	Fixed Expenses	Rent	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
8	\N	Debt Payments	Other	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
9	\N	Flexible Expenses	Other	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
10	\N	Fixed Expenses	Insurance	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
13	\N	Debt Payments	Credit Card	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
14	\N	Flexible Expenses	Entertainment	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
15	\N	Fixed Expenses	Utilities	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
16	\N	Flexible Expenses	Transportation	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
17	\N	Flexible Expenses	Health	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
18	1	Flexible Expenses	Cat Stuff	f	t	2025-12-22 23:35:38.262498	2025-12-22 23:35:38.2625
20	1	Savings & Investments	Investment (Nordea)	f	t	2025-12-22 23:43:36.735751	2025-12-22 23:43:36.735753
21	1	Savings & Investments	Emergency Fund	f	t	2025-12-23 00:02:04.65833	2025-12-23 00:02:04.658332
22	3	Savings & Investments	Emergency Fund	f	t	2025-12-23 16:44:06.66174	2025-12-23 16:44:06.661744
23	3	Flexible Expenses	Bullshit spending	f	t	2025-12-23 16:50:54.530363	2025-12-23 16:51:33.969076
\.


--
-- Data for Name: user_defaults; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.user_defaults (id, user_id, default_expense_name, default_category, default_subcategory, default_payment_method) FROM stdin;
1	1	Wolt	Flexible Expenses	Food	credit
2	2	Wolt	Flexible Expenses	Food	credit
3	3	Wolt	Flexible Expenses	Food	credit
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, email, password_hash, created_at, failed_login_attempts, locked_until, recurring_lookahead_days, default_currency, balance_start_date, user_initial_debit_balance, user_initial_credit_limit, balance_mode, user_initial_credit_available, payment_date_adjustment) FROM stdin;
2	big-boss@bloom-tracker.app	scrypt:32768:8:1$rMuIqMrQKzV7RHjD$61d89186211c4125f5157f52013d9077d6d0c8711de2036fb01e48d9d8b367c63ee2d9d8ed92d9d149819526e0cc97c879237c3dac1d7ccc8ab535075e24992a	2025-12-05 22:12:33.602733	0	\N	14	EUR	\N	0	0	sync	0	exact_date
3	psarakismichail@gmail.com	scrypt:32768:8:1$k9ddNY6qoqP6pvQF$2473df38dc19c5554b6c1e5e37bb86f3211579fb7777ffd799d748e431e5f1c7f88387309348f5b51e917d6bdd44cec57d1f2bd8d4e9c0b15d0df9d54e7bfcbf	2025-12-23 15:51:20.404149	0	\N	14	EUR	2025-12-23	200000	2000000	sync	0	exact_date
1	saiyuriye.rafia@gmail.com	scrypt:32768:8:1$NTBL2jq9wdswJ317$a866f96e54aca726260d216f04bafb477ea426ef8b0e70d692ebf7cf7845861bffea341bc39be6659d6e06e7ec33768e519f3f35ba523f62a5df1bb625f9a905	2025-12-04 16:05:51.698396	0	\N	30	EUR	2025-11-20	307200	150000	sync	8942	previous_workday
\.


--
-- Name: budget_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.budget_periods_id_seq', 20, true);


--
-- Name: credit_card_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.credit_card_settings_id_seq', 3, true);


--
-- Name: debts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.debts_id_seq', 6, true);


--
-- Name: exchange_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.exchange_rates_id_seq', 4059, true);


--
-- Name: expense_name_mappings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.expense_name_mappings_id_seq', 1, false);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.expenses_id_seq', 216, true);


--
-- Name: goals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.goals_id_seq', 4, true);


--
-- Name: income_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.income_id_seq', 10, true);


--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.password_reset_tokens_id_seq', 1, false);


--
-- Name: period_suggestions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.period_suggestions_id_seq', 1, false);


--
-- Name: rate_limits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.rate_limits_id_seq', 26, true);


--
-- Name: recurring_expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.recurring_expenses_id_seq', 30, true);


--
-- Name: recurring_income_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.recurring_income_id_seq', 2, true);


--
-- Name: salary_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.salary_periods_id_seq', 4, true);


--
-- Name: subcategories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.subcategories_id_seq', 23, true);


--
-- Name: user_defaults_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.user_defaults_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: budget_periods budget_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.budget_periods
    ADD CONSTRAINT budget_periods_pkey PRIMARY KEY (id);


--
-- Name: credit_card_settings credit_card_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_card_settings
    ADD CONSTRAINT credit_card_settings_pkey PRIMARY KEY (id);


--
-- Name: credit_card_settings credit_card_settings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_card_settings
    ADD CONSTRAINT credit_card_settings_user_id_key UNIQUE (user_id);


--
-- Name: debts debts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_pkey PRIMARY KEY (id);


--
-- Name: exchange_rates exchange_rates_base_currency_target_currency_rate_date_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_base_currency_target_currency_rate_date_key UNIQUE (base_currency, target_currency, rate_date);


--
-- Name: exchange_rates exchange_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_pkey PRIMARY KEY (id);


--
-- Name: expense_name_mappings expense_name_mappings_expense_name_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expense_name_mappings
    ADD CONSTRAINT expense_name_mappings_expense_name_key UNIQUE (expense_name);


--
-- Name: expense_name_mappings expense_name_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expense_name_mappings
    ADD CONSTRAINT expense_name_mappings_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id);


--
-- Name: income income_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_key UNIQUE (token);


--
-- Name: period_suggestions period_suggestions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.period_suggestions
    ADD CONSTRAINT period_suggestions_pkey PRIMARY KEY (id);


--
-- Name: rate_limits rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_pkey PRIMARY KEY (id);


--
-- Name: recurring_expenses recurring_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_expenses
    ADD CONSTRAINT recurring_expenses_pkey PRIMARY KEY (id);


--
-- Name: recurring_income recurring_income_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_income
    ADD CONSTRAINT recurring_income_pkey PRIMARY KEY (id);


--
-- Name: salary_periods salary_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.salary_periods
    ADD CONSTRAINT salary_periods_pkey PRIMARY KEY (id);


--
-- Name: subcategories subcategories_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT subcategories_pkey PRIMARY KEY (id);


--
-- Name: subcategories uq_subcategory_user_category_name; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT uq_subcategory_user_category_name UNIQUE (user_id, category, name);


--
-- Name: user_defaults user_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_defaults
    ADD CONSTRAINT user_defaults_pkey PRIMARY KEY (id);


--
-- Name: user_defaults user_defaults_user_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_defaults
    ADD CONSTRAINT user_defaults_user_id_key UNIQUE (user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_budget_period_active; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_budget_period_active ON public.budget_periods USING btree (user_id, start_date, end_date);


--
-- Name: idx_debts_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_debts_deleted_at ON public.debts USING btree (deleted_at);


--
-- Name: idx_exchange_rate_lookup; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_exchange_rate_lookup ON public.exchange_rates USING btree (base_currency, target_currency, rate_date);


--
-- Name: idx_expenses_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_expenses_deleted_at ON public.expenses USING btree (deleted_at);


--
-- Name: idx_goal_user_active; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_goal_user_active ON public.goals USING btree (user_id, is_active);


--
-- Name: idx_goal_user_subcategory; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_goal_user_subcategory ON public.goals USING btree (user_id, subcategory_name);


--
-- Name: idx_goals_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_goals_deleted_at ON public.goals USING btree (deleted_at);


--
-- Name: idx_income_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_income_deleted_at ON public.income USING btree (deleted_at);


--
-- Name: idx_recurring_expenses_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_recurring_expenses_deleted_at ON public.recurring_expenses USING btree (deleted_at);


--
-- Name: ix_budget_periods_end_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_budget_periods_end_date ON public.budget_periods USING btree (end_date);


--
-- Name: ix_budget_periods_start_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_budget_periods_start_date ON public.budget_periods USING btree (start_date);


--
-- Name: ix_budget_periods_user_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_budget_periods_user_id ON public.budget_periods USING btree (user_id);


--
-- Name: ix_exchange_rates_base_currency; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_exchange_rates_base_currency ON public.exchange_rates USING btree (base_currency);


--
-- Name: ix_exchange_rates_rate_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_exchange_rates_rate_date ON public.exchange_rates USING btree (rate_date);


--
-- Name: ix_exchange_rates_target_currency; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_exchange_rates_target_currency ON public.exchange_rates USING btree (target_currency);


--
-- Name: ix_income_recurring_income_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_income_recurring_income_id ON public.income USING btree (recurring_income_id);


--
-- Name: ix_rate_limits_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_rate_limits_key ON public.rate_limits USING btree (key);


--
-- Name: ix_rate_limits_timestamp; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_rate_limits_timestamp ON public.rate_limits USING btree ("timestamp");


--
-- Name: ix_recurring_income_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_recurring_income_deleted_at ON public.recurring_income USING btree (deleted_at);


--
-- Name: ix_subcategories_category; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_subcategories_category ON public.subcategories USING btree (category);


--
-- Name: ix_subcategories_user_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_subcategories_user_id ON public.subcategories USING btree (user_id);


--
-- Name: uq_expense_recurring_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX uq_expense_recurring_date ON public.expenses USING btree (user_id, recurring_template_id, date) WHERE (recurring_template_id IS NOT NULL);


--
-- Name: uq_income_initial_balance_per_user; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX uq_income_initial_balance_per_user ON public.income USING btree (user_id) WHERE ((type)::text = 'Initial Balance'::text);


--
-- Name: budget_periods budget_periods_salary_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.budget_periods
    ADD CONSTRAINT budget_periods_salary_period_id_fkey FOREIGN KEY (salary_period_id) REFERENCES public.salary_periods(id);


--
-- Name: budget_periods budget_periods_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.budget_periods
    ADD CONSTRAINT budget_periods_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: credit_card_settings credit_card_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_card_settings
    ADD CONSTRAINT credit_card_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: debts debts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: expenses expenses_budget_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_budget_period_id_fkey FOREIGN KEY (budget_period_id) REFERENCES public.budget_periods(id);


--
-- Name: expenses expenses_recurring_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_recurring_template_id_fkey FOREIGN KEY (recurring_template_id) REFERENCES public.recurring_expenses(id);


--
-- Name: expenses expenses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: goals fk_goal_user; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT fk_goal_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: income fk_income_recurring_income_id; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT fk_income_recurring_income_id FOREIGN KEY (recurring_income_id) REFERENCES public.recurring_income(id) ON DELETE SET NULL;


--
-- Name: subcategories fk_subcategory_user; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT fk_subcategory_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: goals goals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: income income_budget_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_budget_period_id_fkey FOREIGN KEY (budget_period_id) REFERENCES public.budget_periods(id);


--
-- Name: income income_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: period_suggestions period_suggestions_budget_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.period_suggestions
    ADD CONSTRAINT period_suggestions_budget_period_id_fkey FOREIGN KEY (budget_period_id) REFERENCES public.budget_periods(id);


--
-- Name: period_suggestions period_suggestions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.period_suggestions
    ADD CONSTRAINT period_suggestions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: recurring_expenses recurring_expenses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_expenses
    ADD CONSTRAINT recurring_expenses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: recurring_income recurring_income_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_income
    ADD CONSTRAINT recurring_income_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: salary_periods salary_periods_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.salary_periods
    ADD CONSTRAINT salary_periods_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: subcategories subcategories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT subcategories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_defaults user_defaults_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_defaults
    ADD CONSTRAINT user_defaults_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

\unrestrict Nz5z3cEZme5q1qnNKL6O9bkShgdS1Bbxb9oVeWLDAGunVzM9bd7jQykwEXpcWu3

