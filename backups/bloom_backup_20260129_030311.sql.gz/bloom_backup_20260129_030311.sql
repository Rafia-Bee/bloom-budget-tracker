--
-- PostgreSQL database dump
--

\restrict Iwb3VRGzJamRIAZ9Cv2xkJTFVE5W5g4PUZh5EBsyNifrvDYUObLZkGQgxluhwD5

-- Dumped from database version 17.7 (bdd1736)
-- Dumped by pg_dump version 17.7 (Ubuntu 17.7-3.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO neondb_owner;

--
-- Name: budget_periods; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.budget_periods (
    id integer NOT NULL,
    user_id integer NOT NULL,
    salary_period_id integer,
    week_number integer,
    budget_amount integer,
    start_date date NOT NULL,
    end_date date NOT NULL,
    period_type character varying(50) NOT NULL,
    created_at timestamp without time zone,
    CONSTRAINT check_budget_period_date_order CHECK ((start_date <= end_date)),
    CONSTRAINT check_budget_period_date_range CHECK ((start_date <= end_date)),
    CONSTRAINT check_budget_period_week_number CHECK (((week_number IS NULL) OR (week_number >= 1)))
);


ALTER TABLE public.budget_periods OWNER TO neondb_owner;

--
-- Name: budget_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.budget_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_periods_id_seq OWNER TO neondb_owner;

--
-- Name: budget_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.budget_periods_id_seq OWNED BY public.budget_periods.id;


--
-- Name: credit_card_settings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.credit_card_settings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    credit_limit integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.credit_card_settings OWNER TO neondb_owner;

--
-- Name: credit_card_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.credit_card_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.credit_card_settings_id_seq OWNER TO neondb_owner;

--
-- Name: credit_card_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.credit_card_settings_id_seq OWNED BY public.credit_card_settings.id;


--
-- Name: debts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.debts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(200) NOT NULL,
    original_amount integer NOT NULL,
    current_balance integer NOT NULL,
    monthly_payment integer NOT NULL,
    archived boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    CONSTRAINT check_debt_positive_current CHECK ((current_balance >= 0)),
    CONSTRAINT check_debt_positive_original CHECK ((original_amount > 0)),
    CONSTRAINT check_debt_positive_payment CHECK ((monthly_payment > 0))
);


ALTER TABLE public.debts OWNER TO neondb_owner;

--
-- Name: debts_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.debts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.debts_id_seq OWNER TO neondb_owner;

--
-- Name: debts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.debts_id_seq OWNED BY public.debts.id;


--
-- Name: exchange_rates; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.exchange_rates (
    id integer NOT NULL,
    base_currency character varying(3) NOT NULL,
    target_currency character varying(3) NOT NULL,
    rate double precision NOT NULL,
    rate_date date NOT NULL,
    fetched_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT exchange_rates_rate_check CHECK ((rate > (0)::double precision))
);


ALTER TABLE public.exchange_rates OWNER TO neondb_owner;

--
-- Name: exchange_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.exchange_rates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.exchange_rates_id_seq OWNER TO neondb_owner;

--
-- Name: exchange_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.exchange_rates_id_seq OWNED BY public.exchange_rates.id;


--
-- Name: expense_name_mappings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.expense_name_mappings (
    id integer NOT NULL,
    expense_name character varying(200) NOT NULL,
    subcategory character varying(100) NOT NULL,
    confidence double precision,
    last_updated timestamp without time zone
);


ALTER TABLE public.expense_name_mappings OWNER TO neondb_owner;

--
-- Name: expense_name_mappings_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.expense_name_mappings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expense_name_mappings_id_seq OWNER TO neondb_owner;

--
-- Name: expense_name_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.expense_name_mappings_id_seq OWNED BY public.expense_name_mappings.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    user_id integer NOT NULL,
    budget_period_id integer,
    recurring_template_id integer,
    name character varying(200) NOT NULL,
    amount integer NOT NULL,
    category character varying(100) NOT NULL,
    subcategory character varying(100),
    date date NOT NULL,
    due_date character varying(50),
    payment_method character varying(20) NOT NULL,
    notes text,
    receipt_url character varying(500),
    is_fixed_bill boolean NOT NULL,
    created_at timestamp without time zone,
    currency character varying(3) DEFAULT 'EUR'::character varying NOT NULL,
    original_amount integer,
    exchange_rate_used double precision,
    deleted_at timestamp without time zone,
    updated_at timestamp without time zone,
    CONSTRAINT check_expense_positive_amount CHECK ((amount > 0))
);


ALTER TABLE public.expenses OWNER TO neondb_owner;

--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expenses_id_seq OWNER TO neondb_owner;

--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: goals; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.goals (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    target_amount integer NOT NULL,
    target_date date,
    subcategory_name character varying(100) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    initial_amount integer DEFAULT 0 NOT NULL,
    deleted_at timestamp without time zone,
    CONSTRAINT check_goal_positive_amount CHECK ((target_amount > 0))
);


ALTER TABLE public.goals OWNER TO neondb_owner;

--
-- Name: goals_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.goals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.goals_id_seq OWNER TO neondb_owner;

--
-- Name: goals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.goals_id_seq OWNED BY public.goals.id;


--
-- Name: income; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.income (
    id integer NOT NULL,
    user_id integer NOT NULL,
    budget_period_id integer,
    type character varying(50) NOT NULL,
    amount integer NOT NULL,
    scheduled_date date,
    actual_date date,
    created_at timestamp without time zone,
    currency character varying(3) DEFAULT 'EUR'::character varying NOT NULL,
    original_amount integer,
    exchange_rate_used double precision,
    deleted_at timestamp without time zone,
    updated_at timestamp without time zone,
    recurring_income_id integer,
    CONSTRAINT check_income_positive_amount CHECK ((amount > 0))
);


ALTER TABLE public.income OWNER TO neondb_owner;

--
-- Name: income_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.income_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.income_id_seq OWNER TO neondb_owner;

--
-- Name: income_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.income_id_seq OWNED BY public.income.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.password_reset_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    is_used boolean NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO neondb_owner;

--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.password_reset_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.password_reset_tokens_id_seq OWNER TO neondb_owner;

--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.password_reset_tokens_id_seq OWNED BY public.password_reset_tokens.id;


--
-- Name: period_suggestions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.period_suggestions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    budget_period_id integer NOT NULL,
    suggestion_type character varying(100) NOT NULL,
    amount integer NOT NULL,
    status character varying(20),
    created_at timestamp without time zone
);


ALTER TABLE public.period_suggestions OWNER TO neondb_owner;

--
-- Name: period_suggestions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.period_suggestions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.period_suggestions_id_seq OWNER TO neondb_owner;

--
-- Name: period_suggestions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.period_suggestions_id_seq OWNED BY public.period_suggestions.id;


--
-- Name: rate_limits; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.rate_limits (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    "timestamp" timestamp without time zone
);


ALTER TABLE public.rate_limits OWNER TO neondb_owner;

--
-- Name: rate_limits_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.rate_limits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rate_limits_id_seq OWNER TO neondb_owner;

--
-- Name: rate_limits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.rate_limits_id_seq OWNED BY public.rate_limits.id;


--
-- Name: recurring_expenses; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.recurring_expenses (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(200) NOT NULL,
    amount integer NOT NULL,
    category character varying(100) NOT NULL,
    subcategory character varying(100),
    payment_method character varying(20) NOT NULL,
    frequency character varying(20) NOT NULL,
    frequency_value integer,
    day_of_month integer,
    day_of_week integer,
    start_date date NOT NULL,
    end_date date,
    next_due_date date NOT NULL,
    is_active boolean NOT NULL,
    is_fixed_bill boolean NOT NULL,
    notes text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    CONSTRAINT check_recurring_expense_date_range CHECK (((end_date IS NULL) OR (start_date <= end_date))),
    CONSTRAINT check_recurring_positive_amount CHECK ((amount > 0))
);


ALTER TABLE public.recurring_expenses OWNER TO neondb_owner;

--
-- Name: recurring_expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.recurring_expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recurring_expenses_id_seq OWNER TO neondb_owner;

--
-- Name: recurring_expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.recurring_expenses_id_seq OWNED BY public.recurring_expenses.id;


--
-- Name: recurring_income; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.recurring_income (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(200) NOT NULL,
    amount integer NOT NULL,
    income_type character varying(50) DEFAULT 'Salary'::character varying NOT NULL,
    currency character varying(3) DEFAULT 'EUR'::character varying NOT NULL,
    frequency character varying(20) NOT NULL,
    frequency_value integer,
    day_of_month integer,
    day_of_week integer,
    start_date date NOT NULL,
    end_date date,
    next_due_date date NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    deleted_at timestamp without time zone,
    CONSTRAINT check_recurring_income_date_range CHECK (((end_date IS NULL) OR (start_date <= end_date))),
    CONSTRAINT check_recurring_income_day_of_month CHECK (((day_of_month IS NULL) OR ((day_of_month >= 1) AND (day_of_month <= 31)))),
    CONSTRAINT check_recurring_income_day_of_week CHECK (((day_of_week IS NULL) OR ((day_of_week >= 0) AND (day_of_week <= 6)))),
    CONSTRAINT check_recurring_income_frequency_value CHECK (((frequency_value IS NULL) OR (frequency_value > 0))),
    CONSTRAINT check_recurring_income_positive_amount CHECK ((amount > 0))
);


ALTER TABLE public.recurring_income OWNER TO neondb_owner;

--
-- Name: recurring_income_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.recurring_income_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recurring_income_id_seq OWNER TO neondb_owner;

--
-- Name: recurring_income_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.recurring_income_id_seq OWNED BY public.recurring_income.id;


--
-- Name: salary_periods; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.salary_periods (
    id integer NOT NULL,
    user_id integer NOT NULL,
    initial_debit_balance integer NOT NULL,
    initial_credit_balance integer NOT NULL,
    credit_limit integer NOT NULL,
    credit_budget_allowance integer NOT NULL,
    salary_amount integer,
    total_budget_amount integer NOT NULL,
    fixed_bills_total integer NOT NULL,
    remaining_amount integer NOT NULL,
    weekly_budget integer NOT NULL,
    weekly_debit_budget integer NOT NULL,
    weekly_credit_budget integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    num_sub_periods integer DEFAULT 4 NOT NULL,
    CONSTRAINT check_salary_period_date_order CHECK ((start_date <= end_date)),
    CONSTRAINT check_salary_period_positive_credit_limit CHECK ((credit_limit >= 0))
);


ALTER TABLE public.salary_periods OWNER TO neondb_owner;

--
-- Name: salary_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.salary_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.salary_periods_id_seq OWNER TO neondb_owner;

--
-- Name: salary_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.salary_periods_id_seq OWNED BY public.salary_periods.id;


--
-- Name: subcategories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.subcategories (
    id integer NOT NULL,
    user_id integer,
    category character varying(100) NOT NULL,
    name character varying(100) NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.subcategories OWNER TO neondb_owner;

--
-- Name: subcategories_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.subcategories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subcategories_id_seq OWNER TO neondb_owner;

--
-- Name: subcategories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.subcategories_id_seq OWNED BY public.subcategories.id;


--
-- Name: user_defaults; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.user_defaults (
    id integer NOT NULL,
    user_id integer NOT NULL,
    default_expense_name character varying(200),
    default_category character varying(100),
    default_subcategory character varying(100),
    default_payment_method character varying(20)
);


ALTER TABLE public.user_defaults OWNER TO neondb_owner;

--
-- Name: user_defaults_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.user_defaults_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_defaults_id_seq OWNER TO neondb_owner;

--
-- Name: user_defaults_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.user_defaults_id_seq OWNED BY public.user_defaults.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone,
    failed_login_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp without time zone,
    recurring_lookahead_days integer DEFAULT 14 NOT NULL,
    default_currency character varying(3) DEFAULT 'EUR'::character varying NOT NULL,
    balance_start_date date,
    user_initial_debit_balance integer DEFAULT 0 NOT NULL,
    user_initial_credit_limit integer DEFAULT 0 NOT NULL,
    balance_mode character varying(20) DEFAULT 'sync'::character varying NOT NULL,
    user_initial_credit_available integer DEFAULT 0 NOT NULL,
    payment_date_adjustment character varying(20) DEFAULT 'exact_date'::character varying NOT NULL,
    CONSTRAINT check_user_balance_mode_valid CHECK (((balance_mode)::text = ANY ((ARRAY['sync'::character varying, 'budget'::character varying])::text[]))),
    CONSTRAINT check_user_failed_attempts CHECK ((failed_login_attempts >= 0)),
    CONSTRAINT check_user_lookahead_range CHECK (((recurring_lookahead_days >= 7) AND (recurring_lookahead_days <= 90))),
    CONSTRAINT check_user_payment_date_adjustment_valid CHECK (((payment_date_adjustment)::text = ANY ((ARRAY['exact_date'::character varying, 'previous_workday'::character varying, 'next_workday'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: budget_periods id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.budget_periods ALTER COLUMN id SET DEFAULT nextval('public.budget_periods_id_seq'::regclass);


--
-- Name: credit_card_settings id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_card_settings ALTER COLUMN id SET DEFAULT nextval('public.credit_card_settings_id_seq'::regclass);


--
-- Name: debts id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.debts ALTER COLUMN id SET DEFAULT nextval('public.debts_id_seq'::regclass);


--
-- Name: exchange_rates id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.exchange_rates ALTER COLUMN id SET DEFAULT nextval('public.exchange_rates_id_seq'::regclass);


--
-- Name: expense_name_mappings id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expense_name_mappings ALTER COLUMN id SET DEFAULT nextval('public.expense_name_mappings_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: goals id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.goals ALTER COLUMN id SET DEFAULT nextval('public.goals_id_seq'::regclass);


--
-- Name: income id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income ALTER COLUMN id SET DEFAULT nextval('public.income_id_seq'::regclass);


--
-- Name: password_reset_tokens id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens ALTER COLUMN id SET DEFAULT nextval('public.password_reset_tokens_id_seq'::regclass);


--
-- Name: period_suggestions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.period_suggestions ALTER COLUMN id SET DEFAULT nextval('public.period_suggestions_id_seq'::regclass);


--
-- Name: rate_limits id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.rate_limits ALTER COLUMN id SET DEFAULT nextval('public.rate_limits_id_seq'::regclass);


--
-- Name: recurring_expenses id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_expenses ALTER COLUMN id SET DEFAULT nextval('public.recurring_expenses_id_seq'::regclass);


--
-- Name: recurring_income id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_income ALTER COLUMN id SET DEFAULT nextval('public.recurring_income_id_seq'::regclass);


--
-- Name: salary_periods id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.salary_periods ALTER COLUMN id SET DEFAULT nextval('public.salary_periods_id_seq'::regclass);


--
-- Name: subcategories id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories ALTER COLUMN id SET DEFAULT nextval('public.subcategories_id_seq'::regclass);


--
-- Name: user_defaults id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_defaults ALTER COLUMN id SET DEFAULT nextval('public.user_defaults_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.alembic_version (version_num) FROM stdin;
34eed8893f3a
\.


--
-- Data for Name: budget_periods; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.budget_periods (id, user_id, salary_period_id, week_number, budget_amount, start_date, end_date, period_type, created_at) FROM stdin;
1	1	1	1	18365	2025-11-20	2025-11-26	weekly	2025-12-04 16:06:13.903987
2	1	1	2	18365	2025-11-27	2025-12-03	weekly	2025-12-04 16:06:13.903989
3	1	1	3	18365	2025-12-04	2025-12-10	weekly	2025-12-04 16:06:13.90399
4	1	1	4	18365	2025-12-11	2025-12-19	weekly	2025-12-04 16:06:13.90399
5	1	2	1	20743	2025-12-20	2025-12-26	weekly	2025-12-17 10:14:43.949622
9	3	3	1	50000	2025-12-23	2025-12-29	weekly	2025-12-23 16:45:25.74918
10	3	3	2	50000	2025-12-30	2026-01-05	weekly	2025-12-23 16:45:25.749183
11	3	3	3	50000	2026-01-06	2026-01-12	weekly	2025-12-23 16:45:25.749184
12	3	3	4	50000	2026-01-13	2026-01-22	weekly	2025-12-23 16:45:25.749184
6	1	2	2	17389	2025-12-27	2026-01-02	weekly	2025-12-17 10:14:43.949624
7	1	2	3	17389	2026-01-03	2026-01-09	weekly	2025-12-17 10:14:43.949625
8	1	2	4	17389	2026-01-10	2026-01-19	weekly	2025-12-17 10:14:43.949625
21	1	5	1	12706	2026-01-20	2026-01-23	custom	2026-01-21 15:40:39.946523
22	1	5	2	12706	2026-01-24	2026-01-26	custom	2026-01-21 15:40:39.946527
23	1	5	3	12706	2026-01-27	2026-01-29	custom	2026-01-21 15:40:39.94653
24	1	5	4	12706	2026-01-30	2026-02-01	custom	2026-01-21 15:40:39.946532
25	1	5	5	12706	2026-02-02	2026-02-04	custom	2026-01-21 15:40:39.946533
26	1	5	6	12706	2026-02-05	2026-02-07	custom	2026-01-21 15:40:39.946534
27	1	5	7	12706	2026-02-08	2026-02-10	custom	2026-01-21 15:40:39.946535
28	1	5	8	12706	2026-02-11	2026-02-13	custom	2026-01-21 15:40:39.946542
29	1	5	9	12706	2026-02-14	2026-02-16	custom	2026-01-21 15:40:39.946543
30	1	5	10	12706	2026-02-17	2026-02-19	custom	2026-01-21 15:40:39.946544
\.


--
-- Data for Name: credit_card_settings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.credit_card_settings (id, user_id, credit_limit, created_at, updated_at) FROM stdin;
1	1	150000	2025-12-04 16:05:51.79458	2025-12-04 16:05:51.794584
2	2	150000	2025-12-05 22:12:33.70062	2025-12-05 22:12:33.700624
3	3	150000	2025-12-23 15:51:20.432803	2025-12-23 15:51:20.432808
\.


--
-- Data for Name: debts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.debts (id, user_id, name, original_amount, current_balance, monthly_payment, archived, created_at, updated_at, deleted_at) FROM stdin;
3	1	Klarna Turkish Airlines Business	54422	43943	10479	f	2025-12-04 16:06:13.707428	2026-01-19 18:34:17.39287	\N
5	1	Elisa (Phone)	84840	63630	3535	f	2025-12-04 16:06:13.718028	2026-01-19 18:34:21.789283	\N
4	1	Klarna Gigantti	63773	53127	5323	f	2025-12-04 16:06:13.712809	2026-01-19 18:34:24.47247	\N
6	1	Telia Rahoitus	100000	75455	4546	f	2025-12-04 16:06:13.723429	2026-01-19 18:34:26.768981	\N
2	1	Klarna Turkish Airlines New	117469	76305	10291	f	2025-12-04 16:06:13.701772	2026-01-19 18:34:31.090823	\N
1	1	Klarna Turkish Airlines Old	205855	34844	10080	f	2025-12-04 16:06:13.692827	2026-01-21 15:42:45.295443	\N
\.


--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.exchange_rates (id, base_currency, target_currency, rate, rate_date, fetched_at) FROM stdin;
232	BDT	AED	0.030051	2025-12-25	2025-12-25 14:48:04.663885
233	BDT	AFN	0.538188	2025-12-25	2025-12-25 14:48:05.374567
10	EUR	AWG	2.109255	2025-12-25	2025-12-25 14:00:47.26393
234	BDT	ALL	0.669419	2025-12-25	2025-12-25 14:48:05.97569
235	BDT	AMD	3.12223	2025-12-25	2025-12-25 14:48:06.464829
14	EUR	BBD	2.35671	2025-12-25	2025-12-25 14:00:50.964889
236	BDT	ANG	0.014647	2025-12-25	2025-12-25 14:48:06.782005
237	BDT	AOA	7.66021	2025-12-25	2025-12-25 14:48:07.276226
15	EUR	BDT	144.026155	2025-12-25	2025-12-25 14:00:52.265055
238	BDT	ARS	11.88323	2025-12-25	2025-12-25 14:48:07.878169
239	BDT	AUD	0.012204	2025-12-25	2025-12-25 14:48:08.474699
16	EUR	BGN	1.95583	2025-12-25	2025-12-25 14:00:53.664051
240	BDT	AWG	0.014647	2025-12-25	2025-12-25 14:48:08.964049
241	BDT	AZN	0.013917	2025-12-25	2025-12-25 14:48:09.381616
242	BDT	BAM	0.01358	2025-12-25	2025-12-25 14:48:09.963287
243	BDT	BBD	0.016365	2025-12-25	2025-12-25 14:48:10.377981
244	BDT	BGN	0.01358	2025-12-25	2025-12-25 14:48:10.763726
245	BDT	BHD	0.003077	2025-12-25	2025-12-25 14:48:10.983178
246	BDT	BIF	24.206115	2025-12-25	2025-12-25 14:48:11.364216
247	BDT	BMD	0.008183	2025-12-25	2025-12-25 14:48:11.679973
248	BDT	BND	0.010505	2025-12-25	2025-12-25 14:48:11.987781
249	BDT	BOB	0.056693	2025-12-25	2025-12-25 14:48:12.280273
250	BDT	BRL	0.045173	2025-12-25	2025-12-25 14:48:12.564442
251	BDT	BSD	0.008183	2025-12-25	2025-12-25 14:48:12.862953
252	BDT	BTN	0.733957	2025-12-25	2025-12-25 14:48:13.179484
253	BDT	BWP	0.111417	2025-12-25	2025-12-25 14:48:13.473548
254	BDT	BYN	0.023776	2025-12-25	2025-12-25 14:48:13.775082
255	BDT	BZD	0.016365	2025-12-25	2025-12-25 14:48:14.062902
256	BDT	CAD	0.011189	2025-12-25	2025-12-25 14:48:14.284857
257	BDT	CDF	18.636023	2025-12-25	2025-12-25 14:48:14.58798
258	BDT	CHF	0.006446	2025-12-25	2025-12-25 14:48:14.864486
259	BDT	CLF	0.000188	2025-12-25	2025-12-25 14:48:15.177006
260	BDT	CLP	7.431352	2025-12-25	2025-12-25 14:48:15.478888
261	BDT	CNH	0.057365	2025-12-25	2025-12-25 14:48:15.76291
262	BDT	CNY	0.057484	2025-12-25	2025-12-25 14:48:15.988099
263	BDT	COP	30.853449	2025-12-25	2025-12-25 14:48:16.290361
264	BDT	CRC	4.073267	2025-12-25	2025-12-25 14:48:16.581774
265	BDT	CUP	0.196383	2025-12-25	2025-12-25 14:48:16.789983
266	BDT	CVE	0.76559	2025-12-25	2025-12-25 14:48:17.163101
267	BDT	CZK	0.168565	2025-12-25	2025-12-25 14:48:17.383795
268	BDT	DJF	1.454226	2025-12-25	2025-12-25 14:48:17.686084
269	BDT	DKK	0.051799	2025-12-25	2025-12-25 14:48:17.882705
270	BDT	DOP	0.512705	2025-12-25	2025-12-25 14:48:18.184007
271	BDT	DZD	1.060646	2025-12-25	2025-12-25 14:48:18.386673
272	BDT	EGP	0.388718	2025-12-25	2025-12-25 14:48:18.689111
273	BDT	ERN	0.12274	2025-12-25	2025-12-25 14:48:18.98164
274	BDT	ETB	1.274565	2025-12-25	2025-12-25 14:48:19.290395
275	BDT	EUR	0.006943	2025-12-25	2025-12-25 14:48:19.588041
276	BDT	FJD	0.018606	2025-12-25	2025-12-25 14:48:19.97904
277	BDT	FKP	0.006059	2025-12-25	2025-12-25 14:48:20.278606
278	BDT	FOK	0.051799	2025-12-25	2025-12-25 14:48:20.58393
279	BDT	GBP	0.006059	2025-12-25	2025-12-25 14:48:20.878458
280	BDT	GEL	0.02206	2025-12-25	2025-12-25 14:48:21.086672
281	BDT	GGP	0.006059	2025-12-25	2025-12-25 14:48:21.386127
282	BDT	GHS	0.092629	2025-12-25	2025-12-25 14:48:21.67882
283	BDT	GIP	0.006059	2025-12-25	2025-12-25 14:48:21.888193
284	BDT	GMD	0.607194	2025-12-25	2025-12-25 14:48:22.187128
285	BDT	GNF	71.492839	2025-12-25	2025-12-25 14:48:22.488463
286	BDT	GTQ	0.06271	2025-12-25	2025-12-25 14:48:22.793983
287	BDT	GYD	1.712091	2025-12-25	2025-12-25 14:48:23.175583
288	BDT	HKD	0.06362	2025-12-25	2025-12-25 14:48:23.484727
289	BDT	HNL	0.215792	2025-12-25	2025-12-25 14:48:23.776428
290	BDT	HRK	0.052313	2025-12-25	2025-12-25 14:48:23.983625
291	BDT	HTG	1.071565	2025-12-25	2025-12-25 14:48:24.293145
292	BDT	HUF	2.706089	2025-12-25	2025-12-25 14:48:24.585658
293	BDT	IDR	137.217669	2025-12-25	2025-12-25 14:48:24.792356
294	BDT	ILS	0.026047	2025-12-25	2025-12-25 14:48:25.176924
295	BDT	IMP	0.006059	2025-12-25	2025-12-25 14:48:25.462967
296	BDT	INR	0.733957	2025-12-25	2025-12-25 14:48:25.691203
297	BDT	IQD	10.719963	2025-12-25	2025-12-25 14:48:25.992432
298	BDT	IRR	351.99914	2025-12-25	2025-12-25 14:48:26.284093
299	BDT	ISK	1.027335	2025-12-25	2025-12-25 14:48:26.580273
300	BDT	JEP	0.006059	2025-12-25	2025-12-25 14:48:26.875412
301	BDT	JMD	1.307392	2025-12-25	2025-12-25 14:48:27.089827
302	BDT	JOD	0.005801	2025-12-25	2025-12-25 14:48:27.390705
303	BDT	JPY	1.275715	2025-12-25	2025-12-25 14:48:27.681673
304	BDT	KES	1.055364	2025-12-25	2025-12-25 14:48:27.981569
305	BDT	KGS	0.715882	2025-12-25	2025-12-25 14:48:28.280634
306	BDT	KHR	32.840386	2025-12-25	2025-12-25 14:48:28.579849
307	BDT	KID	0.012204	2025-12-25	2025-12-25 14:48:28.887979
308	BDT	KMF	3.415822	2025-12-25	2025-12-25 14:48:29.173876
309	BDT	KRW	11.845218	2025-12-25	2025-12-25 14:48:29.463149
310	BDT	KWD	0.002499	2025-12-25	2025-12-25 14:48:29.764195
311	BDT	KYD	0.006819	2025-12-25	2025-12-25 14:48:29.989568
312	BDT	KZT	4.175405	2025-12-25	2025-12-25 14:48:30.262415
313	BDT	LAK	177.479347	2025-12-25	2025-12-25 14:48:30.483264
314	BDT	LBP	732.345753	2025-12-25	2025-12-25 14:48:31.073947
315	BDT	LKR	2.533017	2025-12-25	2025-12-25 14:48:31.777271
316	BDT	LRD	1.451775	2025-12-25	2025-12-25 14:48:32.664154
317	BDT	LSL	0.136367	2025-12-25	2025-12-25 14:48:33.462698
391	BDT	ZAR	0.136367	2025-12-25	2025-12-25 14:48:59.76412
392	BDT	ZMW	0.184122	2025-12-25	2025-12-25 14:49:00.262663
393	BDT	ZWL	0.212966	2025-12-25	2025-12-25 14:49:00.581205
394	EUR	AED	4.327508	2025-12-26	2025-12-26 00:52:37.835689
395	EUR	AFN	77.434793	2025-12-26	2025-12-26 00:52:38.137134
396	EUR	ALL	96.421234	2025-12-26	2025-12-26 00:52:38.536002
397	EUR	AMD	449.869768	2025-12-26	2025-12-26 00:52:38.920033
398	EUR	ANG	2.109255	2025-12-26	2025-12-26 00:52:39.533525
399	EUR	AOA	1108.346135	2025-12-26	2025-12-26 00:52:39.927923
400	EUR	ARS	1711.265744	2025-12-26	2025-12-26 00:52:40.319071
401	EUR	AUD	1.757653	2025-12-26	2025-12-26 00:52:40.828556
402	EUR	AWG	2.109255	2025-12-26	2025-12-26 00:52:41.03841
403	EUR	AZN	2.005254	2025-12-26	2025-12-26 00:52:41.242239
404	EUR	BAM	1.95583	2025-12-26	2025-12-26 00:52:41.520622
405	EUR	BBD	2.35671	2025-12-26	2025-12-26 00:52:41.739648
406	EUR	BDT	144.026155	2025-12-26	2025-12-26 00:52:42.036509
407	EUR	BGN	1.95583	2025-12-26	2025-12-26 00:52:42.242011
408	EUR	BHD	0.443061	2025-12-26	2025-12-26 00:52:42.532369
409	EUR	BIF	3499.394018	2025-12-26	2025-12-26 00:52:42.738579
410	EUR	BMD	1.178355	2025-12-26	2025-12-26 00:52:42.941744
411	EUR	BND	1.512756	2025-12-26	2025-12-26 00:52:43.143013
412	EUR	BOB	8.166893	2025-12-26	2025-12-26 00:52:43.435646
413	EUR	BRL	6.506005	2025-12-26	2025-12-26 00:52:43.63874
414	EUR	BSD	1.178355	2025-12-26	2025-12-26 00:52:43.937775
415	EUR	BTN	105.670888	2025-12-26	2025-12-26 00:52:44.140412
416	EUR	BWP	16.298807	2025-12-26	2025-12-26 00:52:44.343287
417	EUR	BYN	3.427656	2025-12-26	2025-12-26 00:52:44.539693
418	EUR	BZD	2.35671	2025-12-26	2025-12-26 00:52:44.740783
419	EUR	CAD	1.611689	2025-12-26	2025-12-26 00:52:45.036828
39	EUR	CZK	24.273338	2025-12-25	2025-12-25 14:01:21.265099
1	EUR	AED	4.327508	2025-12-25	2025-12-25 14:00:37.663632
65	EUR	HUF	389.227875	2025-12-25	2025-12-25 14:01:49.365006
3	EUR	AFN	77.434793	2025-12-25	2025-12-25 14:00:38.962435
40	EUR	DJF	209.418392	2025-12-25	2025-12-25 14:01:22.659798
4	EUR	ALL	96.421234	2025-12-25	2025-12-25 14:00:40.563029
5	EUR	AMD	449.869768	2025-12-25	2025-12-25 14:00:41.368354
41	EUR	DKK	7.461265	2025-12-25	2025-12-25 14:01:23.866539
6	EUR	ANG	2.109255	2025-12-25	2025-12-25 14:00:42.866322
318	BDT	LYD	0.044343	2025-12-25	2025-12-25 14:48:34.56457
42	EUR	DOP	73.957209	2025-12-25	2025-12-25 14:01:24.966777
7	EUR	AOA	1108.346135	2025-12-25	2025-12-25 14:00:44.363804
8	EUR	ARS	1711.265744	2025-12-25	2025-12-25 14:00:45.364136
43	EUR	DZD	152.823944	2025-12-25	2025-12-25 14:01:26.066524
9	EUR	AUD	1.757653	2025-12-25	2025-12-25 14:00:46.76436
66	EUR	IDR	19718.198961	2025-12-25	2025-12-25 14:01:50.565758
11	EUR	AZN	2.005254	2025-12-25	2025-12-25 14:00:48.264857
13	EUR	BAM	1.95583	2025-12-25	2025-12-25 14:00:49.564761
44	EUR	EGP	56.116859	2025-12-25	2025-12-25 14:01:27.765972
17	EUR	BHD	0.443061	2025-12-25	2025-12-25 14:00:54.764429
68	EUR	ILS	3.751828	2025-12-25	2025-12-25 14:01:51.365118
18	EUR	BIF	3499.394018	2025-12-25	2025-12-25 14:00:55.966388
45	EUR	ERN	17.675322	2025-12-25	2025-12-25 14:01:29.064496
19	EUR	BMD	1.178355	2025-12-25	2025-12-25 14:00:56.964917
70	EUR	IMP	0.872552	2025-12-25	2025-12-25 14:01:52.266334
20	EUR	BND	1.512756	2025-12-25	2025-12-25 14:00:58.563897
46	EUR	ETB	181.952086	2025-12-25	2025-12-25 14:01:30.06451
21	EUR	BOB	8.166893	2025-12-25	2025-12-25 14:00:59.065021
22	EUR	BRL	6.506005	2025-12-25	2025-12-25 14:01:00.360163
71	EUR	INR	105.671233	2025-12-25	2025-12-25 14:01:53.365128
47	EUR	FJD	2.679777	2025-12-25	2025-12-25 14:01:31.26775
23	EUR	BSD	1.178355	2025-12-25	2025-12-25 14:01:01.565125
24	EUR	BTN	105.670888	2025-12-25	2025-12-25 14:01:02.764742
81	EUR	KHR	4735.960526	2025-12-25	2025-12-25 14:02:05.067907
48	EUR	FKP	0.872552	2025-12-25	2025-12-25 14:01:32.564556
25	EUR	BWP	16.298807	2025-12-25	2025-12-25 14:01:03.96474
26	EUR	BYN	3.427656	2025-12-25	2025-12-25 14:01:05.264781
27	EUR	BZD	2.35671	2025-12-25	2025-12-25 14:01:06.564185
28	EUR	CAD	1.611689	2025-12-25	2025-12-25 14:01:07.967096
29	EUR	CDF	2686.067164	2025-12-25	2025-12-25 14:01:08.763636
30	EUR	CHF	0.928554	2025-12-25	2025-12-25 14:01:09.766506
72	EUR	IQD	1544.776824	2025-12-25	2025-12-25 14:01:54.465955
31	EUR	CLF	0.027101	2025-12-25	2025-12-25 14:01:11.366988
32	EUR	CLP	1071.185109	2025-12-25	2025-12-25 14:01:12.665736
49	EUR	FOK	7.461265	2025-12-25	2025-12-25 14:01:33.860301
33	EUR	CNH	8.259695	2025-12-25	2025-12-25 14:01:13.663921
34	EUR	CNY	8.27748	2025-12-25	2025-12-25 14:01:14.866058
103	EUR	MNT	4159.918972	2025-12-25	2025-12-25 14:02:23.764102
35	EUR	COP	4437.75716	2025-12-25	2025-12-25 14:01:16.364151
50	EUR	GBP	0.872552	2025-12-25	2025-12-25 14:01:35.065353
73	EUR	IRR	50055.669571	2025-12-25	2025-12-25 14:01:55.663785
36	EUR	CRC	587.930617	2025-12-25	2025-12-25 14:01:17.56315
51	EUR	GEL	3.179354	2025-12-25	2025-12-25 14:01:35.865316
37	EUR	CUP	28.280515	2025-12-25	2025-12-25 14:01:18.963609
52	EUR	GGP	0.872552	2025-12-25	2025-12-25 14:01:36.965869
38	EUR	CVE	110.265	2025-12-25	2025-12-25 14:01:20.664476
54	EUR	GHS	13.302211	2025-12-25	2025-12-25 14:01:38.263423
55	EUR	GIP	0.872552	2025-12-25	2025-12-25 14:01:38.964545
56	EUR	GMD	87.454612	2025-12-25	2025-12-25 14:01:40.866413
57	EUR	GNF	10295.45819	2025-12-25	2025-12-25 14:01:41.563699
58	EUR	GTQ	9.036739	2025-12-25	2025-12-25 14:01:42.66118
60	EUR	GYD	246.698424	2025-12-25	2025-12-25 14:01:43.764207
83	EUR	KID	1.757652	2025-12-25	2025-12-25 14:02:05.964072
61	EUR	HKD	9.161437	2025-12-25	2025-12-25 14:01:44.860306
62	EUR	HNL	31.097286	2025-12-25	2025-12-25 14:01:45.964701
74	EUR	ISK	148.015102	2025-12-25	2025-12-25 14:01:56.865677
63	EUR	HRK	7.5345	2025-12-25	2025-12-25 14:01:47.262535
98	EUR	MAD	10.745973	2025-12-25	2025-12-25 14:02:18.167937
64	EUR	HTG	154.411411	2025-12-25	2025-12-25 14:01:48.465102
84	EUR	KMF	491.96775	2025-12-25	2025-12-25 14:02:06.966129
85	EUR	KRW	1707.500739	2025-12-25	2025-12-25 14:02:07.660223
75	EUR	JEP	0.872552	2025-12-25	2025-12-25 14:01:58.264573
76	EUR	JMD	188.108472	2025-12-25	2025-12-25 14:01:59.26715
87	EUR	KWD	0.36144	2025-12-25	2025-12-25 14:02:08.964343
77	EUR	JOD	0.835454	2025-12-25	2025-12-25 14:02:00.464238
88	EUR	KYD	0.981962	2025-12-25	2025-12-25 14:02:09.774816
89	EUR	KZT	604.688772	2025-12-25	2025-12-25 14:02:10.766629
78	EUR	JPY	183.761551	2025-12-25	2025-12-25 14:02:01.559837
79	EUR	KES	152.084181	2025-12-25	2025-12-25 14:02:02.664555
91	EUR	LAK	25596.94192	2025-12-25	2025-12-25 14:02:12.064612
80	EUR	KGS	103.059665	2025-12-25	2025-12-25 14:02:03.762976
92	EUR	LBP	105462.753719	2025-12-25	2025-12-25 14:02:12.864716
93	EUR	LKR	364.95757	2025-12-25	2025-12-25 14:02:13.664966
94	EUR	LRD	209.399615	2025-12-25	2025-12-25 14:02:15.663207
95	EUR	LSL	19.626682	2025-12-25	2025-12-25 14:02:15.963336
97	EUR	LYD	6.38032	2025-12-25	2025-12-25 14:02:16.865448
99	EUR	MDL	19.814089	2025-12-25	2025-12-25 14:02:19.065989
110	EUR	MWK	2055.851882	2025-12-25	2025-12-25 14:02:28.164094
100	EUR	MGA	5307.255534	2025-12-25	2025-12-25 14:02:20.163873
104	EUR	MOP	9.437042	2025-12-25	2025-12-25 14:02:25.064061
101	EUR	MKD	61.4843	2025-12-25	2025-12-25 14:02:21.660231
102	EUR	MMK	2479.74508	2025-12-25	2025-12-25 14:02:22.865264
111	EUR	MXN	21.121538	2025-12-25	2025-12-25 14:02:28.96394
105	EUR	MRU	46.994777	2025-12-25	2025-12-25 14:02:26.364924
109	EUR	MVR	18.237276	2025-12-25	2025-12-25 14:02:27.274293
107	EUR	MUR	54.199771	2025-12-25	2025-12-25 14:02:27.365284
112	EUR	MYR	4.771733	2025-12-25	2025-12-25 14:02:29.764237
113	EUR	MZN	75.349015	2025-12-25	2025-12-25 14:02:31.264308
116	EUR	NGN	1707.140579	2025-12-25	2025-12-25 14:02:33.465819
115	EUR	NAD	19.626682	2025-12-25	2025-12-25 14:02:32.766362
117	EUR	NIO	43.404423	2025-12-25	2025-12-25 14:02:34.464009
119	EUR	NOK	11.791112	2025-12-25	2025-12-25 14:02:35.164829
120	EUR	NPR	169.073422	2025-12-25	2025-12-25 14:02:35.764956
121	EUR	NZD	2.018995	2025-12-25	2025-12-25 14:02:36.274832
122	EUR	OMR	0.453074	2025-12-25	2025-12-25 14:02:36.863554
123	EUR	PAB	1.178355	2025-12-25	2025-12-25 14:02:37.367402
124	EUR	PEN	3.965922	2025-12-25	2025-12-25 14:02:37.963539
126	EUR	PGK	5.094031	2025-12-25	2025-12-25 14:02:38.185927
127	EUR	PHP	69.242381	2025-12-25	2025-12-25 14:02:38.463986
128	EUR	PKR	330.39864	2025-12-25	2025-12-25 14:02:38.685347
129	EUR	PLN	4.214352	2025-12-25	2025-12-25 14:02:38.888412
130	EUR	PYG	7986.800269	2025-12-25	2025-12-25 14:02:39.179194
131	EUR	QAR	4.289211	2025-12-25	2025-12-25 14:02:39.384317
132	EUR	RON	5.090097	2025-12-25	2025-12-25 14:02:39.665169
133	EUR	RSD	117.36913	2025-12-25	2025-12-25 14:02:39.877329
134	EUR	RUB	92.841887	2025-12-25	2025-12-25 14:02:40.082791
135	EUR	RWF	1721.600633	2025-12-25	2025-12-25 14:02:40.364019
136	EUR	SAR	4.41883	2025-12-25	2025-12-25 14:02:40.585125
137	EUR	SBD	9.532682	2025-12-25	2025-12-25 14:02:40.875762
138	EUR	SCR	17.199192	2025-12-25	2025-12-25 14:02:41.085484
139	EUR	SDG	526.988287	2025-12-25	2025-12-25 14:02:41.382449
140	EUR	SEK	10.802992	2025-12-25	2025-12-25 14:02:41.591396
141	EUR	SGD	1.512756	2025-12-25	2025-12-25 14:02:41.889753
142	EUR	SHP	0.872552	2025-12-25	2025-12-25 14:02:42.179215
143	EUR	SLE	28.414724	2025-12-25	2025-12-25 14:02:42.48051
144	EUR	SOS	672.771963	2025-12-25	2025-12-25 14:02:42.790179
145	EUR	SRD	45.246135	2025-12-25	2025-12-25 14:02:43.08802
146	EUR	SSP	5566.917231	2025-12-25	2025-12-25 14:02:43.386334
147	EUR	STN	24.5	2025-12-25	2025-12-25 14:02:43.679741
148	EUR	SYP	12980.000305	2025-12-25	2025-12-25 14:02:43.884506
149	EUR	SZL	19.626682	2025-12-25	2025-12-25 14:02:44.186331
150	EUR	THB	36.62098	2025-12-25	2025-12-25 14:02:44.38846
151	EUR	TJS	10.892974	2025-12-25	2025-12-25 14:02:44.678934
152	EUR	TMT	4.127584	2025-12-25	2025-12-25 14:02:44.982901
153	EUR	TND	3.407744	2025-12-25	2025-12-25 14:02:45.27758
154	EUR	TOP	2.83195	2025-12-25	2025-12-25 14:02:45.484839
155	EUR	TRY	50.520792	2025-12-25	2025-12-25 14:02:45.774965
156	EUR	TTD	8.670925	2025-12-25	2025-12-25 14:02:45.9853
157	EUR	TVD	1.757652	2025-12-25	2025-12-25 14:02:46.185773
319	BDT	MAD	0.074642	2025-12-25	2025-12-25 14:48:35.566111
158	EUR	TWD	37.038321	2025-12-25	2025-12-25 14:10:44.390149
320	BDT	MDL	0.137559	2025-12-25	2025-12-25 14:48:36.075582
321	BDT	MGA	37.3122	2025-12-25	2025-12-25 14:48:36.382856
161	EUR	TZS	2898.306324	2025-12-25	2025-12-25 14:10:45.687145
322	BDT	MKD	0.427623	2025-12-25	2025-12-25 14:48:36.68124
323	BDT	MMK	17.205044	2025-12-25	2025-12-25 14:48:36.884177
165	EUR	UAH	49.625692	2025-12-25	2025-12-25 14:10:46.786241
324	BDT	MNT	28.91163	2025-12-25	2025-12-25 14:48:37.18578
325	BDT	MOP	0.065529	2025-12-25	2025-12-25 14:48:37.477071
169	EUR	UGX	4231.607935	2025-12-25	2025-12-25 14:10:47.789093
326	BDT	MRU	0.326326	2025-12-25	2025-12-25 14:48:37.764493
327	BDT	MUR	0.376576	2025-12-25	2025-12-25 14:48:37.987821
173	EUR	USD	1.178355	2025-12-25	2025-12-25 14:10:49.187211
328	BDT	MVR	0.12655	2025-12-25	2025-12-25 14:48:38.375502
329	BDT	MWK	14.249909	2025-12-25	2025-12-25 14:48:38.588551
177	EUR	UYU	46.067809	2025-12-25	2025-12-25 14:10:50.587387
330	BDT	MXN	0.146506	2025-12-25	2025-12-25 14:48:38.884256
180	EUR	UZS	14278.457713	2025-12-25	2025-12-25 14:10:50.988556
331	BDT	MYR	0.03313	2025-12-25	2025-12-25 14:48:39.090007
332	BDT	MZN	0.523055	2025-12-25	2025-12-25 14:48:39.463855
184	EUR	VES	342.936342	2025-12-25	2025-12-25 14:10:52.086561
333	BDT	NAD	0.136367	2025-12-25	2025-12-25 14:48:39.690585
334	BDT	NGN	11.891306	2025-12-25	2025-12-25 14:48:39.989283
188	EUR	VND	30876.727797	2025-12-25	2025-12-25 14:10:53.187519
335	BDT	NIO	0.301201	2025-12-25	2025-12-25 14:48:40.283318
336	BDT	NOK	0.081843	2025-12-25	2025-12-25 14:48:40.491187
192	EUR	VUV	142.491814	2025-12-25	2025-12-25 14:10:54.288378
337	BDT	NPR	1.174331	2025-12-25	2025-12-25 14:48:40.785362
338	BDT	NZD	0.01402	2025-12-25	2025-12-25 14:48:41.077246
196	EUR	WST	3.261647	2025-12-25	2025-12-25 14:10:55.686876
339	BDT	OMR	0.003146	2025-12-25	2025-12-25 14:48:41.286685
340	BDT	PAB	0.008183	2025-12-25	2025-12-25 14:48:41.563583
200	EUR	XAF	655.957	2025-12-25	2025-12-25 14:10:56.889456
203	EUR	XCD	3.181558	2025-12-25	2025-12-25 14:10:57.48638
341	BDT	PEN	0.027545	2025-12-25	2025-12-25 14:48:41.7869
342	BDT	PGK	0.035347	2025-12-25	2025-12-25 14:48:42.07994
206	EUR	XDR	0.85636	2025-12-25	2025-12-25 14:10:58.487889
343	BDT	PHP	0.480582	2025-12-25	2025-12-25 14:48:42.38138
344	BDT	PKR	2.294097	2025-12-25	2025-12-25 14:48:42.679177
210	EUR	XOF	655.957	2025-12-25	2025-12-25 14:10:59.787348
345	BDT	PLN	0.029269	2025-12-25	2025-12-25 14:48:42.98513
213	EUR	XPF	119.332	2025-12-25	2025-12-25 14:11:00.686539
346	BDT	PYG	55.485938	2025-12-25	2025-12-25 14:48:43.264351
217	EUR	YER	281.237368	2025-12-25	2025-12-25 14:11:01.387009
347	BDT	QAR	0.029785	2025-12-25	2025-12-25 14:48:43.577905
348	BDT	RON	0.03533	2025-12-25	2025-12-25 14:48:43.886386
220	EUR	ZAR	19.624667	2025-12-25	2025-12-25 14:11:02.18606
349	BDT	RSD	0.815368	2025-12-25	2025-12-25 14:48:44.188508
350	BDT	RUB	0.63927	2025-12-25	2025-12-25 14:48:44.488018
224	EUR	ZMW	26.520207	2025-12-25	2025-12-25 14:11:03.088139
351	BDT	RWF	11.932685	2025-12-25	2025-12-25 14:48:45.163716
352	BDT	SAR	0.030685	2025-12-25	2025-12-25 14:48:45.787716
228	EUR	ZWL	30.6958	2025-12-25	2025-12-25 14:11:04.08865
353	BDT	SBD	0.066296	2025-12-25	2025-12-25 14:48:46.081509
354	BDT	SCR	0.118299	2025-12-25	2025-12-25 14:48:46.378988
355	BDT	SDG	4.187704	2025-12-25	2025-12-25 14:48:46.681882
356	BDT	SEK	0.07499	2025-12-25	2025-12-25 14:48:46.974487
357	BDT	SGD	0.010505	2025-12-25	2025-12-25 14:48:47.275006
358	BDT	SHP	0.006059	2025-12-25	2025-12-25 14:48:47.577754
359	BDT	SLE	0.197564	2025-12-25	2025-12-25 14:48:47.873062
360	BDT	SOS	4.669046	2025-12-25	2025-12-25 14:48:48.163822
361	BDT	SRD	0.314576	2025-12-25	2025-12-25 14:48:48.488372
362	BDT	SSP	38.129934	2025-12-25	2025-12-25 14:48:48.789448
363	BDT	STN	0.170108	2025-12-25	2025-12-25 14:48:49.083785
364	BDT	SYP	90.190389	2025-12-25	2025-12-25 14:48:49.388088
365	BDT	SZL	0.136367	2025-12-25	2025-12-25 14:48:49.687312
366	BDT	THB	0.254203	2025-12-25	2025-12-25 14:48:50.075002
367	BDT	TJS	0.075568	2025-12-25	2025-12-25 14:48:50.373086
368	BDT	TMT	0.028648	2025-12-25	2025-12-25 14:48:50.679058
369	BDT	TND	0.023635	2025-12-25	2025-12-25 14:48:51.179716
370	BDT	TOP	0.019675	2025-12-25	2025-12-25 14:48:51.582302
371	BDT	TRY	0.350592	2025-12-25	2025-12-25 14:48:52.079689
372	BDT	TTD	0.05567	2025-12-25	2025-12-25 14:48:52.565136
373	BDT	TVD	0.012204	2025-12-25	2025-12-25 14:48:52.981837
374	BDT	TWD	0.257315	2025-12-25	2025-12-25 14:48:53.463697
375	BDT	TZS	20.268654	2025-12-25	2025-12-25 14:48:53.875707
376	BDT	UAH	0.3439	2025-12-25	2025-12-25 14:48:54.276935
377	BDT	UGX	29.507974	2025-12-25	2025-12-25 14:48:54.683243
378	BDT	USD	0.008183	2025-12-25	2025-12-25 14:48:55.074775
379	BDT	UYU	0.319729	2025-12-25	2025-12-25 14:48:55.285504
380	BDT	UZS	99.325623	2025-12-25	2025-12-25 14:48:55.582304
381	BDT	VES	2.38403	2025-12-25	2025-12-25 14:48:55.885582
382	BDT	VND	215.083175	2025-12-25	2025-12-25 14:48:56.264719
383	BDT	VUV	0.986867	2025-12-25	2025-12-25 14:48:56.562599
384	BDT	WST	0.022683	2025-12-25	2025-12-25 14:48:56.785518
385	BDT	XAF	4.55443	2025-12-25	2025-12-25 14:48:57.078609
386	BDT	XCD	0.022093	2025-12-25	2025-12-25 14:48:57.366223
387	BDT	XDR	0.005941	2025-12-25	2025-12-25 14:48:57.69383
388	BDT	XOF	4.55443	2025-12-25	2025-12-25 14:48:58.079791
389	BDT	XPF	0.828544	2025-12-25	2025-12-25 14:48:58.474982
390	BDT	YER	1.951447	2025-12-25	2025-12-25 14:48:59.181709
420	EUR	CDF	2686.067164	2025-12-26	2025-12-26 00:52:45.237445
421	EUR	CHF	0.928554	2025-12-26	2025-12-26 00:52:45.445625
422	EUR	CLF	0.027101	2025-12-26	2025-12-26 00:52:45.728554
423	EUR	CLP	1071.185109	2025-12-26	2025-12-26 00:52:45.941709
424	EUR	CNH	8.259695	2025-12-26	2025-12-26 00:52:46.237521
425	EUR	CNY	8.27748	2025-12-26	2025-12-26 00:52:46.520122
426	EUR	COP	4437.75716	2025-12-26	2025-12-26 00:52:46.744649
427	EUR	CRC	587.930617	2025-12-26	2025-12-26 00:52:47.118802
428	EUR	CUP	28.280515	2025-12-26	2025-12-26 00:52:47.335664
429	EUR	CVE	110.265	2025-12-26	2025-12-26 00:52:47.535606
430	EUR	CZK	24.273338	2025-12-26	2025-12-26 00:52:47.739815
431	EUR	DJF	209.418392	2025-12-26	2025-12-26 00:52:48.018783
432	EUR	DKK	7.461265	2025-12-26	2025-12-26 00:52:48.241665
433	EUR	DOP	73.957209	2025-12-26	2025-12-26 00:52:48.54326
434	EUR	DZD	152.823944	2025-12-26	2025-12-26 00:52:48.819715
435	EUR	EGP	56.116859	2025-12-26	2025-12-26 00:52:49.041098
436	EUR	ERN	17.675322	2025-12-26	2025-12-26 00:52:49.341907
437	EUR	ETB	181.952086	2025-12-26	2025-12-26 00:52:49.63981
438	EUR	FJD	2.679777	2025-12-26	2025-12-26 00:52:49.932842
439	EUR	FKP	0.872552	2025-12-26	2025-12-26 00:52:50.138766
440	EUR	FOK	7.461265	2025-12-26	2025-12-26 00:52:50.437036
441	EUR	GBP	0.872552	2025-12-26	2025-12-26 00:52:50.64376
442	EUR	GEL	3.179354	2025-12-26	2025-12-26 00:52:50.943489
443	EUR	GGP	0.872552	2025-12-26	2025-12-26 00:52:51.244729
444	EUR	GHS	13.302211	2025-12-26	2025-12-26 00:52:51.519853
445	EUR	GIP	0.872552	2025-12-26	2025-12-26 00:52:51.750792
446	EUR	GMD	87.454612	2025-12-26	2025-12-26 00:52:51.942276
447	EUR	GNF	10295.45819	2025-12-26	2025-12-26 00:52:52.219924
448	EUR	GTQ	9.036739	2025-12-26	2025-12-26 00:52:52.427969
449	EUR	GYD	246.335846	2025-12-26	2025-12-26 00:52:52.805569
450	EUR	HKD	9.161038	2025-12-26	2025-12-26 00:52:52.941409
451	EUR	HNL	31.052379	2025-12-26	2025-12-26 00:52:53.327452
452	EUR	HRK	7.5345	2025-12-26	2025-12-26 00:52:53.819042
453	EUR	HTG	154.18447	2025-12-26	2025-12-26 00:52:54.418634
454	EUR	HUF	389.359462	2025-12-26	2025-12-26 00:52:55.120514
455	EUR	IDR	19734.933824	2025-12-26	2025-12-26 00:52:55.519727
456	EUR	ILS	3.754583	2025-12-26	2025-12-26 00:52:55.821033
457	EUR	IMP	0.872056	2025-12-26	2025-12-26 00:52:56.040544
458	EUR	INR	105.718536	2025-12-26	2025-12-26 00:52:56.34027
459	EUR	IQD	1542.506438	2025-12-26	2025-12-26 00:52:56.54184
460	EUR	IRR	50021.725081	2025-12-26	2025-12-26 00:52:56.844629
461	EUR	ISK	148.014024	2025-12-26	2025-12-26 00:52:57.218735
462	EUR	JEP	0.872056	2025-12-26	2025-12-26 00:52:57.44425
463	EUR	JMD	187.757152	2025-12-26	2025-12-26 00:52:57.733492
464	EUR	JOD	0.835764	2025-12-26	2025-12-26 00:52:57.946993
465	EUR	JPY	183.762937	2025-12-26	2025-12-26 00:52:58.248942
466	EUR	KES	151.942762	2025-12-26	2025-12-26 00:52:58.544592
467	EUR	KGS	103.000823	2025-12-26	2025-12-26 00:52:58.842306
468	EUR	KHR	4729	2025-12-26	2025-12-26 00:52:59.139607
469	EUR	KID	1.757297	2025-12-26	2025-12-26 00:52:59.437213
470	EUR	KMF	491.96775	2025-12-26	2025-12-26 00:52:59.655782
471	EUR	KRW	1704.784388	2025-12-26	2025-12-26 00:52:59.934001
472	EUR	KWD	0.360894	2025-12-26	2025-12-26 00:53:00.145664
473	EUR	KYD	0.982326	2025-12-26	2025-12-26 00:53:00.442725
474	EUR	KZT	601.898534	2025-12-26	2025-12-26 00:53:00.730639
475	EUR	LAK	25511.81021	2025-12-26	2025-12-26 00:53:00.950381
476	EUR	LBP	105501.886944	2025-12-26	2025-12-26 00:53:01.233168
477	EUR	LKR	364.53462	2025-12-26	2025-12-26 00:53:01.447551
478	EUR	LRD	209.369867	2025-12-26	2025-12-26 00:53:01.641093
479	EUR	LSL	19.620184	2025-12-26	2025-12-26 00:53:01.94109
480	EUR	LYD	6.372976	2025-12-26	2025-12-26 00:53:02.137311
481	EUR	MAD	10.736311	2025-12-26	2025-12-26 00:53:02.33494
482	EUR	MDL	19.745623	2025-12-26	2025-12-26 00:53:02.629787
483	EUR	MGA	5322.554329	2025-12-26	2025-12-26 00:53:02.828991
484	EUR	MKD	61.4887	2025-12-26	2025-12-26 00:53:03.035922
485	EUR	MMK	2476.029464	2025-12-26	2025-12-26 00:53:03.248537
486	EUR	MNT	4168.698668	2025-12-26	2025-12-26 00:53:03.542972
487	EUR	MOP	9.43502	2025-12-26	2025-12-26 00:53:03.936202
488	EUR	MRU	46.888976	2025-12-26	2025-12-26 00:53:04.427724
489	EUR	MUR	54.150559	2025-12-26	2025-12-26 00:53:04.920241
490	EUR	MVR	18.214329	2025-12-26	2025-12-26 00:53:05.328568
491	EUR	MWK	2052.481162	2025-12-26	2025-12-26 00:53:05.718685
492	EUR	MXN	21.130693	2025-12-26	2025-12-26 00:53:05.937805
493	EUR	MYR	4.768235	2025-12-26	2025-12-26 00:53:06.14239
494	EUR	MZN	75.279302	2025-12-26	2025-12-26 00:53:06.341474
495	EUR	NAD	19.620184	2025-12-26	2025-12-26 00:53:06.541309
496	EUR	NGN	1706.711685	2025-12-26	2025-12-26 00:53:06.842769
497	EUR	NIO	43.359618	2025-12-26	2025-12-26 00:53:07.138917
498	EUR	NOK	11.796106	2025-12-26	2025-12-26 00:53:07.438896
499	EUR	NPR	169.129649	2025-12-26	2025-12-26 00:53:07.732879
500	EUR	AED	4.32401	2025-12-29	2025-12-29 12:00:39.215135
501	EUR	AFN	77.399773	2025-12-29	2025-12-29 12:00:39.508196
502	EUR	ALL	96.293063	2025-12-29	2025-12-29 12:00:39.797518
503	EUR	AMD	449.102486	2025-12-29	2025-12-29 12:00:40.08896
504	EUR	ANG	2.10755	2025-12-29	2025-12-29 12:00:40.314136
505	EUR	AOA	1085.839956	2025-12-29	2025-12-29 12:00:40.611358
506	EUR	ARS	1709.882347	2025-12-29	2025-12-29 12:00:40.906762
507	EUR	AUD	1.754666	2025-12-29	2025-12-29 12:00:41.111465
508	EUR	AWG	2.10755	2025-12-29	2025-12-29 12:00:41.411069
509	EUR	AZN	2.001181	2025-12-29	2025-12-29 12:00:41.705645
510	EUR	BAM	1.95583	2025-12-29	2025-12-29 12:00:41.987422
511	EUR	BBD	2.354804	2025-12-29	2025-12-29 12:00:42.212136
512	EUR	BDT	143.947084	2025-12-29	2025-12-29 12:00:42.488492
513	EUR	BGN	1.95583	2025-12-29	2025-12-29 12:00:42.70518
514	EUR	BHD	0.442703	2025-12-29	2025-12-29 12:00:42.914866
515	EUR	BIF	3489.988593	2025-12-29	2025-12-29 12:00:43.216532
516	EUR	BMD	1.177402	2025-12-29	2025-12-29 12:00:43.509761
517	EUR	BND	1.512581	2025-12-29	2025-12-29 12:00:43.802008
518	EUR	BOB	8.147883	2025-12-29	2025-12-29 12:00:44.016976
519	EUR	BRL	6.52672	2025-12-29	2025-12-29 12:00:44.297862
520	EUR	BSD	1.177402	2025-12-29	2025-12-29 12:00:44.598877
521	EUR	BTN	105.722091	2025-12-29	2025-12-29 12:00:44.888967
522	EUR	BWP	16.033031	2025-12-29	2025-12-29 12:00:45.189142
523	EUR	BYN	3.430432	2025-12-29	2025-12-29 12:00:45.496675
524	EUR	BZD	2.354804	2025-12-29	2025-12-29 12:00:45.788149
525	EUR	CAD	1.609342	2025-12-29	2025-12-29 12:00:46.01028
526	EUR	CDF	2701.481203	2025-12-29	2025-12-29 12:00:46.306217
527	EUR	CHF	0.929046	2025-12-29	2025-12-29 12:00:46.597921
528	EUR	CLF	0.026945	2025-12-29	2025-12-29 12:00:46.890064
529	EUR	CLP	1065.050875	2025-12-29	2025-12-29 12:00:47.206185
530	EUR	CNH	8.248027	2025-12-29	2025-12-29 12:00:47.504822
531	EUR	CNY	8.257927	2025-12-29	2025-12-29 12:00:47.81284
532	EUR	COP	4367.276616	2025-12-29	2025-12-29 12:00:48.104886
533	EUR	CRC	582.887343	2025-12-29	2025-12-29 12:00:48.407399
534	EUR	CUP	28.257653	2025-12-29	2025-12-29 12:00:48.711122
535	EUR	CVE	110.265	2025-12-29	2025-12-29 12:00:49.007585
536	EUR	CZK	24.261925	2025-12-29	2025-12-29 12:00:49.306567
537	EUR	DJF	209.249097	2025-12-29	2025-12-29 12:00:49.608498
538	EUR	DKK	7.46045	2025-12-29	2025-12-29 12:00:49.906367
539	EUR	DOP	73.847073	2025-12-29	2025-12-29 12:00:50.187221
540	EUR	DZD	152.452995	2025-12-29	2025-12-29 12:00:50.408164
541	EUR	EGP	56.004069	2025-12-29	2025-12-29 12:00:50.615767
542	EUR	ERN	17.661033	2025-12-29	2025-12-29 12:00:50.901777
543	EUR	ETB	182.279229	2025-12-29	2025-12-29 12:00:51.113787
544	EUR	FJD	2.6704	2025-12-29	2025-12-29 12:00:51.312839
545	EUR	FKP	0.872418	2025-12-29	2025-12-29 12:00:51.688251
546	EUR	FOK	7.46045	2025-12-29	2025-12-29 12:00:51.91056
547	EUR	GBP	0.872419	2025-12-29	2025-12-29 12:00:52.209083
548	EUR	GEL	3.172044	2025-12-29	2025-12-29 12:00:52.514847
549	EUR	GGP	0.872418	2025-12-29	2025-12-29 12:00:52.80233
550	EUR	GHS	13.020714	2025-12-29	2025-12-29 12:00:53.091918
551	EUR	GIP	0.872418	2025-12-29	2025-12-29 12:00:53.408655
552	EUR	GMD	87.234308	2025-12-29	2025-12-29 12:00:53.812875
553	EUR	GNF	10267.636869	2025-12-29	2025-12-29 12:00:54.189846
554	EUR	GTQ	9.016493	2025-12-29	2025-12-29 12:00:54.41241
555	EUR	GYD	246.262509	2025-12-29	2025-12-29 12:00:54.707742
556	EUR	HKD	9.149235	2025-12-29	2025-12-29 12:00:54.997327
557	EUR	HNL	31.027207	2025-12-29	2025-12-29 12:00:55.215456
558	EUR	HRK	7.5345	2025-12-29	2025-12-29 12:00:55.513436
559	EUR	HTG	154.204721	2025-12-29	2025-12-29 12:00:55.886901
560	EUR	HUF	387.098124	2025-12-29	2025-12-29 12:00:56.113768
561	EUR	IDR	19731.998832	2025-12-29	2025-12-29 12:00:56.414821
562	EUR	ILS	3.756927	2025-12-29	2025-12-29 12:00:56.706438
563	EUR	IMP	0.872418	2025-12-29	2025-12-29 12:00:56.987099
564	EUR	INR	105.722102	2025-12-29	2025-12-29 12:00:57.205304
565	EUR	IQD	1542.04721	2025-12-29	2025-12-29 12:00:57.505998
566	EUR	IRR	50830.476173	2025-12-29	2025-12-29 12:00:57.798884
567	EUR	ISK	147.983593	2025-12-29	2025-12-29 12:00:58.08735
568	EUR	JEP	0.872418	2025-12-29	2025-12-29 12:00:58.314766
569	EUR	JMD	187.655895	2025-12-29	2025-12-29 12:00:58.687196
570	EUR	JOD	0.834778	2025-12-29	2025-12-29 12:00:58.912207
571	EUR	JPY	184.245489	2025-12-29	2025-12-29 12:00:59.212077
572	EUR	KES	151.776425	2025-12-29	2025-12-29 12:00:59.414668
573	EUR	KGS	102.94942	2025-12-29	2025-12-29 12:00:59.708503
574	EUR	KHR	4727.592105	2025-12-29	2025-12-29 12:01:00.003534
575	EUR	KID	1.754665	2025-12-29	2025-12-29 12:01:00.308032
576	EUR	KMF	491.96775	2025-12-29	2025-12-29 12:01:00.512276
577	EUR	KRW	1696.405265	2025-12-29	2025-12-29 12:01:00.711797
578	EUR	KWD	0.360809	2025-12-29	2025-12-29 12:01:01.003085
579	EUR	KYD	0.981168	2025-12-29	2025-12-29 12:01:01.213002
580	EUR	KZT	593.06877	2025-12-29	2025-12-29 12:01:01.517514
581	EUR	LAK	25532.459614	2025-12-29	2025-12-29 12:01:01.811216
582	EUR	LBP	105377.497009	2025-12-29	2025-12-29 12:01:02.087989
583	EUR	LKR	364.009075	2025-12-29	2025-12-29 12:01:02.307038
584	EUR	LRD	209.019222	2025-12-29	2025-12-29 12:01:02.588231
585	EUR	LSL	19.622429	2025-12-29	2025-12-29 12:01:02.904319
586	EUR	LYD	6.371079	2025-12-29	2025-12-29 12:01:03.12312
587	EUR	MAD	10.732058	2025-12-29	2025-12-29 12:01:03.403465
588	EUR	MDL	19.702079	2025-12-29	2025-12-29 12:01:03.688334
589	EUR	MGA	5354.115465	2025-12-29	2025-12-29 12:01:03.912884
590	EUR	MKD	61.495	2025-12-29	2025-12-29 12:01:04.203817
591	EUR	MMK	2474.214231	2025-12-29	2025-12-29 12:01:04.487718
592	EUR	MNT	4153.077948	2025-12-29	2025-12-29 12:01:04.706806
593	EUR	MOP	9.424202	2025-12-29	2025-12-29 12:01:04.999106
594	EUR	MRU	46.807843	2025-12-29	2025-12-29 12:01:05.213304
595	EUR	MUR	54.077408	2025-12-29	2025-12-29 12:01:05.588975
596	EUR	MVR	18.198443	2025-12-29	2025-12-29 12:01:05.904213
597	EUR	MWK	2042.776724	2025-12-29	2025-12-29 12:01:06.38844
598	EUR	MXN	21.079979	2025-12-29	2025-12-29 12:01:07.000875
599	EUR	MYR	4.766868	2025-12-29	2025-12-29 12:01:07.789113
600	EUR	AED	4.314173	2026-01-02	2026-01-02 14:49:06.557987
601	EUR	AFN	77.034792	2026-01-02	2026-01-02 14:49:06.626258
602	EUR	ALL	96.745395	2026-01-02	2026-01-02 14:49:06.662445
603	EUR	AMD	447.935075	2026-01-02	2026-01-02 14:49:06.737365
604	EUR	ANG	2.102756	2026-01-02	2026-01-02 14:49:06.820447
605	EUR	AOA	1106.682112	2026-01-02	2026-01-02 14:49:06.909584
606	EUR	ARS	1705.992632	2026-01-02	2026-01-02 14:49:06.955837
607	EUR	AUD	1.758889	2026-01-02	2026-01-02 14:49:07.022477
608	EUR	AWG	2.102756	2026-01-02	2026-01-02 14:49:07.109044
609	EUR	AZN	1.996365	2026-01-02	2026-01-02 14:49:07.148236
610	EUR	BAM	1.95583	2026-01-02	2026-01-02 14:49:07.227558
611	EUR	BBD	2.349448	2026-01-02	2026-01-02 14:49:07.320128
612	EUR	BDT	143.679099	2026-01-02	2026-01-02 14:49:07.360791
613	EUR	BGN	1.95583	2026-01-02	2026-01-02 14:49:07.442118
614	EUR	BHD	0.441696	2026-01-02	2026-01-02 14:49:07.528722
615	EUR	BIF	3483.208756	2026-01-02	2026-01-02 14:49:07.56506
616	EUR	BMD	1.174724	2026-01-02	2026-01-02 14:49:07.635361
617	EUR	BND	1.510143	2026-01-02	2026-01-02 14:49:07.716641
618	EUR	BOB	8.132899	2026-01-02	2026-01-02 14:49:07.757001
619	EUR	BRL	6.433197	2026-01-02	2026-01-02 14:49:07.833986
620	EUR	BSD	1.174724	2026-01-02	2026-01-02 14:49:07.913238
621	EUR	BTN	105.480048	2026-01-02	2026-01-02 14:49:07.952513
622	EUR	BWP	15.991235	2026-01-02	2026-01-02 14:49:08.018535
623	EUR	BYN	3.439295	2026-01-02	2026-01-02 14:49:08.05883
624	EUR	BZD	2.349448	2026-01-02	2026-01-02 14:49:08.138789
625	EUR	CAD	1.611095	2026-01-02	2026-01-02 14:49:08.219628
626	EUR	CDF	2675.552239	2026-01-02	2026-01-02 14:49:08.264406
627	EUR	CHF	0.930896	2026-01-02	2026-01-02 14:49:08.343681
628	EUR	CLF	0.026751	2026-01-02	2026-01-02 14:49:08.414757
629	EUR	CLP	1057.377519	2026-01-02	2026-01-02 14:49:08.452476
630	EUR	CNH	8.199923	2026-01-02	2026-01-02 14:49:08.539201
631	EUR	CNY	8.213562	2026-01-02	2026-01-02 14:49:08.630903
632	EUR	COP	4424.19588	2026-01-02	2026-01-02 14:49:08.716619
633	EUR	CRC	584.07313	2026-01-02	2026-01-02 14:49:08.760691
634	EUR	CUP	28.193371	2026-01-02	2026-01-02 14:49:08.820642
635	EUR	CVE	110.265	2026-01-02	2026-01-02 14:49:08.909404
636	EUR	CZK	24.179955	2026-01-02	2026-01-02 14:49:08.948702
637	EUR	DJF	208.773088	2026-01-02	2026-01-02 14:49:09.028232
638	EUR	DKK	7.460713	2026-01-02	2026-01-02 14:49:09.111067
639	EUR	DOP	74.081805	2026-01-02	2026-01-02 14:49:09.15442
640	EUR	DZD	152.164288	2026-01-02	2026-01-02 14:49:09.229559
641	EUR	EGP	56.024236	2026-01-02	2026-01-02 14:49:09.309446
642	EUR	ERN	17.620857	2026-01-02	2026-01-02 14:49:09.343816
643	EUR	ETB	181.235265	2026-01-02	2026-01-02 14:49:09.430837
644	EUR	FJD	2.668895	2026-01-02	2026-01-02 14:49:09.512173
645	EUR	FKP	0.872503	2026-01-02	2026-01-02 14:49:09.553024
646	EUR	FOK	7.460713	2026-01-02	2026-01-02 14:49:09.618577
647	EUR	GBP	0.872503	2026-01-02	2026-01-02 14:49:09.690237
648	EUR	GEL	3.165141	2026-01-02	2026-01-02 14:49:09.737008
649	EUR	GGP	0.872503	2026-01-02	2026-01-02 14:49:09.813647
650	EUR	GHS	12.28968	2026-01-02	2026-01-02 14:49:09.851737
651	EUR	GIP	0.872503	2026-01-02	2026-01-02 14:49:09.920037
652	EUR	GMD	86.563736	2026-01-02	2026-01-02 14:49:09.954698
653	EUR	GNF	10276.902195	2026-01-02	2026-01-02 14:49:10.030106
654	EUR	GTQ	9.006371	2026-01-02	2026-01-02 14:49:10.117179
655	EUR	GYD	245.564384	2026-01-02	2026-01-02 14:49:10.155684
656	EUR	HKD	9.143167	2026-01-02	2026-01-02 14:49:10.239988
657	EUR	HNL	30.962125	2026-01-02	2026-01-02 14:49:10.318296
658	EUR	HRK	7.5345	2026-01-02	2026-01-02 14:49:10.356649
659	EUR	HTG	153.675096	2026-01-02	2026-01-02 14:49:10.435205
660	EUR	HUF	384.449714	2026-01-02	2026-01-02 14:49:10.509037
661	EUR	IDR	19597.886665	2026-01-02	2026-01-02 14:49:10.563808
662	EUR	ILS	3.741684	2026-01-02	2026-01-02 14:49:10.61226
663	EUR	IMP	0.872503	2026-01-02	2026-01-02 14:49:10.653732
664	EUR	INR	105.480187	2026-01-02	2026-01-02 14:49:10.732288
665	EUR	IQD	1538.729614	2026-01-02	2026-01-02 14:49:10.809917
666	EUR	IRR	50088.895443	2026-01-02	2026-01-02 14:49:10.847659
667	EUR	ISK	147.199584	2026-01-02	2026-01-02 14:49:10.926942
668	EUR	JEP	0.872503	2026-01-02	2026-01-02 14:49:10.972334
669	EUR	JMD	186.622754	2026-01-02	2026-01-02 14:49:11.036286
670	EUR	JOD	0.832879	2026-01-02	2026-01-02 14:49:11.12061
671	EUR	JPY	184.087544	2026-01-02	2026-01-02 14:49:11.198992
672	EUR	KES	151.485135	2026-01-02	2026-01-02 14:49:11.237761
673	EUR	KGS	102.645153	2026-01-02	2026-01-02 14:49:11.314627
674	EUR	KHR	4717.421053	2026-01-02	2026-01-02 14:49:11.349587
675	EUR	KID	1.758887	2026-01-02	2026-01-02 14:49:11.421385
676	EUR	KMF	491.96775	2026-01-02	2026-01-02 14:49:11.460113
677	EUR	KRW	1696.485874	2026-01-02	2026-01-02 14:49:11.533431
678	EUR	KWD	0.360613	2026-01-02	2026-01-02 14:49:11.613465
679	EUR	KYD	0.978936	2026-01-02	2026-01-02 14:49:11.652093
680	EUR	KZT	596.12461	2026-01-02	2026-01-02 14:49:11.734098
681	EUR	LAK	25430.26951	2026-01-02	2026-01-02 14:49:11.811992
682	EUR	LBP	105137.779723	2026-01-02	2026-01-02 14:49:11.854017
683	EUR	LKR	363.342275	2026-01-02	2026-01-02 14:49:11.936217
684	EUR	LRD	209.795219	2026-01-02	2026-01-02 14:49:12.032377
685	EUR	LSL	19.45585	2026-01-02	2026-01-02 14:49:12.112164
686	EUR	LYD	6.347243	2026-01-02	2026-01-02 14:49:12.149483
687	EUR	MAD	10.703163	2026-01-02	2026-01-02 14:49:12.220847
688	EUR	MDL	19.721445	2026-01-02	2026-01-02 14:49:12.309285
689	EUR	MGA	5321.099503	2026-01-02	2026-01-02 14:49:12.343254
690	EUR	MKD	61.495	2026-01-02	2026-01-02 14:49:12.412289
691	EUR	MMK	2466.716593	2026-01-02	2026-01-02 14:49:12.447111
692	EUR	MNT	4148.121308	2026-01-02	2026-01-02 14:49:12.521
693	EUR	MOP	9.417457	2026-01-02	2026-01-02 14:49:12.598463
694	EUR	MRU	46.768067	2026-01-02	2026-01-02 14:49:12.635914
695	EUR	MUR	54.103437	2026-01-02	2026-01-02 14:49:12.721578
696	EUR	MVR	18.156906	2026-01-02	2026-01-02 14:49:12.798392
697	EUR	MWK	2049.679274	2026-01-02	2026-01-02 14:49:12.843376
698	EUR	MXN	21.142146	2026-01-02	2026-01-02 14:49:12.931243
699	EUR	MYR	4.763833	2026-01-02	2026-01-02 14:49:13.009811
700	EUR	MZN	75.018466	2026-01-02	2026-01-02 14:49:13.044998
701	EUR	NAD	19.45585	2026-01-02	2026-01-02 14:49:13.124404
702	EUR	NGN	1693.564847	2026-01-02	2026-01-02 14:49:13.211424
703	EUR	NIO	43.222775	2026-01-02	2026-01-02 14:49:13.250563
704	EUR	NOK	11.839115	2026-01-02	2026-01-02 14:49:13.316112
705	EUR	NPR	168.768077	2026-01-02	2026-01-02 14:49:13.357415
706	EUR	NZD	2.040867	2026-01-02	2026-01-02 14:49:13.447711
707	EUR	OMR	0.451678	2026-01-02	2026-01-02 14:49:13.519872
708	EUR	PAB	1.174724	2026-01-02	2026-01-02 14:49:13.55653
709	EUR	PEN	3.947004	2026-01-02	2026-01-02 14:49:13.620069
710	EUR	PGK	5.004358	2026-01-02	2026-01-02 14:49:13.655559
711	EUR	PHP	69.211243	2026-01-02	2026-01-02 14:49:13.731983
712	EUR	PKR	328.986017	2026-01-02	2026-01-02 14:49:13.808336
713	EUR	PLN	4.217109	2026-01-02	2026-01-02 14:49:13.849586
714	EUR	PYG	7904.891802	2026-01-02	2026-01-02 14:49:13.910818
715	EUR	QAR	4.275995	2026-01-02	2026-01-02 14:49:13.945625
716	EUR	RON	5.096269	2026-01-02	2026-01-02 14:49:14.033589
717	EUR	RSD	117.321191	2026-01-02	2026-01-02 14:49:14.069145
718	EUR	RUB	92.616059	2026-01-02	2026-01-02 14:49:14.135522
719	EUR	RWF	1714.263569	2026-01-02	2026-01-02 14:49:14.172557
720	EUR	SAR	4.405214	2026-01-02	2026-01-02 14:49:14.236255
721	EUR	SBD	9.525549	2026-01-02	2026-01-02 14:49:14.307807
722	EUR	SCR	17.732772	2026-01-02	2026-01-02 14:49:14.343934
723	EUR	SDG	524.925329	2026-01-02	2026-01-02 14:49:14.411066
724	EUR	SEK	10.812769	2026-01-02	2026-01-02 14:49:14.444722
725	EUR	SGD	1.510144	2026-01-02	2026-01-02 14:49:14.508486
726	EUR	SHP	0.872503	2026-01-02	2026-01-02 14:49:14.54919
727	EUR	SLE	28.184721	2026-01-02	2026-01-02 14:49:14.619113
728	EUR	SOS	670.138318	2026-01-02	2026-01-02 14:49:14.655311
729	EUR	SRD	44.681456	2026-01-02	2026-01-02 14:49:14.716727
730	EUR	SSP	5542.449238	2026-01-02	2026-01-02 14:49:14.753232
731	EUR	STN	24.5	2026-01-02	2026-01-02 14:49:14.82171
732	EUR	SYP	12952.40238	2026-01-02	2026-01-02 14:49:14.861818
733	EUR	SZL	19.45585	2026-01-02	2026-01-02 14:49:14.926932
734	EUR	THB	37.018988	2026-01-02	2026-01-02 14:49:14.963139
735	EUR	TJS	10.864555	2026-01-02	2026-01-02 14:49:15.042131
736	EUR	TMT	4.107383	2026-01-02	2026-01-02 14:49:15.11049
737	EUR	TND	3.395964	2026-01-02	2026-01-02 14:49:15.1451
738	EUR	TOP	2.803864	2026-01-02	2026-01-02 14:49:15.222894
739	EUR	TRY	50.463633	2026-01-02	2026-01-02 14:49:15.314741
740	EUR	TTD	8.175187	2026-01-02	2026-01-02 14:49:15.354947
741	EUR	TVD	1.758887	2026-01-02	2026-01-02 14:49:15.430846
742	EUR	TWD	36.799092	2026-01-02	2026-01-02 14:49:15.467172
743	EUR	TZS	2889.5249	2026-01-02	2026-01-02 14:49:15.534531
744	EUR	UAH	49.655211	2026-01-02	2026-01-02 14:49:15.614577
745	EUR	UGX	4231.100336	2026-01-02	2026-01-02 14:49:15.676553
746	EUR	USD	1.174725	2026-01-02	2026-01-02 14:49:15.729095
747	EUR	UYU	45.880403	2026-01-02	2026-01-02 14:49:15.809001
748	EUR	UZS	14214.882631	2026-01-02	2026-01-02 14:49:15.852682
749	EUR	VES	354.493549	2026-01-02	2026-01-02 14:49:15.927809
750	EUR	VND	30801.022172	2026-01-02	2026-01-02 14:49:15.998516
751	EUR	VUV	141.916283	2026-01-02	2026-01-02 14:49:16.033853
752	EUR	WST	3.218198	2026-01-02	2026-01-02 14:49:16.113135
753	EUR	XAF	655.957	2026-01-02	2026-01-02 14:49:16.146346
754	EUR	XCD	3.171754	2026-01-02	2026-01-02 14:49:16.217292
755	EUR	XDR	0.852068	2026-01-02	2026-01-02 14:49:16.255153
756	EUR	XOF	655.957	2026-01-02	2026-01-02 14:49:16.333327
757	EUR	XPF	119.332	2026-01-02	2026-01-02 14:49:16.399152
758	EUR	YER	280.012066	2026-01-02	2026-01-02 14:49:16.43836
759	EUR	ZAR	19.471063	2026-01-02	2026-01-02 14:49:16.510056
760	EUR	ZMW	25.981608	2026-01-02	2026-01-02 14:49:16.546379
761	EUR	ZWL	30.4936	2026-01-02	2026-01-02 14:49:16.624787
762	EUR	AED	4.32009738	2026-01-03	2026-01-03 12:53:20.950553
763	EUR	AFN	77.12603514	2026-01-03	2026-01-03 12:53:21.421613
764	EUR	ALL	96.87110731	2026-01-03	2026-01-03 12:53:21.643152
765	EUR	AMD	448.5850353	2026-01-03	2026-01-03 12:53:21.841261
766	EUR	ANG	2.1192242	2026-01-03	2026-01-03 12:53:21.937863
767	EUR	AOA	1083.61579716	2026-01-03	2026-01-03 12:53:22.039248
768	EUR	ARS	1705.99959924	2026-01-03	2026-01-03 12:53:22.152294
769	EUR	AUD	1.7573137	2026-01-03	2026-01-03 12:53:22.258869
770	EUR	AWG	2.10564311	2026-01-03	2026-01-03 12:53:22.346071
771	EUR	AZN	1.99973648	2026-01-03	2026-01-03 12:53:22.418567
772	EUR	BAM	1.95583	2026-01-03	2026-01-03 12:53:22.460081
773	EUR	BBD	2.35267386	2026-01-03	2026-01-03 12:53:22.542973
774	EUR	BDT	143.89926302	2026-01-03	2026-01-03 12:53:22.595869
775	EUR	BGN	1.95583	2026-01-03	2026-01-03 12:53:22.646207
776	EUR	BHD	0.44230269	2026-01-03	2026-01-03 12:53:22.720119
777	EUR	BIF	3483.725035	2026-01-03	2026-01-03 12:53:22.767631
778	EUR	BMD	1.17633693	2026-01-03	2026-01-03 12:53:22.844544
779	EUR	BND	1.5104025	2026-01-03	2026-01-03 12:53:22.936711
780	EUR	BOB	8.15033644	2026-01-03	2026-01-03 12:53:23.019118
781	EUR	BRL	6.46972043	2026-01-03	2026-01-03 12:53:23.060635
782	EUR	BSD	1.17633693	2026-01-03	2026-01-03 12:53:23.166706
783	EUR	BTN	105.79297592	2026-01-03	2026-01-03 12:53:23.211659
784	EUR	BWP	16.09899454	2026-01-03	2026-01-03 12:53:23.265357
785	EUR	BYN	3.45255277	2026-01-03	2026-01-03 12:53:23.348131
786	EUR	BZD	2.36924511	2026-01-03	2026-01-03 12:53:23.435024
787	EUR	CAD	1.61232712	2026-01-03	2026-01-03 12:53:23.474297
788	EUR	CDF	2668.99595686	2026-01-03	2026-01-03 12:53:23.556354
789	EUR	CHF	0.93056352	2026-01-03	2026-01-03 12:53:23.631414
790	EUR	CLP	1058.79105615	2026-01-03	2026-01-03 12:53:23.742366
791	EUR	CNH	8.19918871	2026-01-03	2026-01-03 12:53:23.819668
792	EUR	CNY	8.23035756	2026-01-03	2026-01-03 12:53:23.878789
793	EUR	COP	4437.43601492	2026-01-03	2026-01-03 12:53:23.952779
794	EUR	CRC	585.40182557	2026-01-03	2026-01-03 12:53:24.018594
795	EUR	CUP	28.23154507	2026-01-03	2026-01-03 12:53:24.062237
796	EUR	CVE	110.27	2026-01-03	2026-01-03 12:53:24.154634
797	EUR	CZK	24.15621468	2026-01-03	2026-01-03 12:53:24.219993
798	EUR	DJF	209.35719319	2026-01-03	2026-01-03 12:53:24.266105
799	EUR	DKK	7.46885109	2026-01-03	2026-01-03 12:53:24.352996
800	EUR	DOP	74.20371356	2026-01-03	2026-01-03 12:53:24.432619
801	EUR	DZD	152.35270744	2026-01-03	2026-01-03 12:53:24.487619
802	EUR	EGP	56.06744546	2026-01-03	2026-01-03 12:53:24.589534
803	EUR	ERN	17.64505398	2026-01-03	2026-01-03 12:53:24.628247
804	EUR	ETB	182.67749938	2026-01-03	2026-01-03 12:53:24.685012
805	EUR	FJD	2.67540696	2026-01-03	2026-01-03 12:53:24.740525
806	EUR	FKP	0.87201128	2026-01-03	2026-01-03 12:53:24.78104
807	EUR	GBP	0.87201128	2026-01-03	2026-01-03 12:53:24.878406
808	EUR	GEL	3.16632756	2026-01-03	2026-01-03 12:53:24.96739
809	EUR	GGP	0.87201128	2026-01-03	2026-01-03 12:53:25.044923
810	EUR	GHS	12.30994017	2026-01-03	2026-01-03 12:53:25.086386
811	EUR	GIP	0.87201128	2026-01-03	2026-01-03 12:53:25.154604
812	EUR	GMD	87.00264666	2026-01-03	2026-01-03 12:53:25.248173
813	EUR	GNF	10300.14622922	2026-01-03	2026-01-03 12:53:25.289901
814	EUR	GTQ	9.02009331	2026-01-03	2026-01-03 12:53:25.358559
815	EUR	GYD	246.13153058	2026-01-03	2026-01-03 12:53:25.432757
816	EUR	HKD	9.16377317	2026-01-03	2026-01-03 12:53:25.472688
817	EUR	HNL	31.02591015	2026-01-03	2026-01-03 12:53:25.544886
818	EUR	HRK	7.5345	2026-01-03	2026-01-03 12:53:25.627782
819	EUR	HTG	154.62080942	2026-01-03	2026-01-03 12:53:25.667208
820	EUR	HUF	384.45679313	2026-01-03	2026-01-03 12:53:25.740294
821	EUR	IDR	19642.13797577	2026-01-03	2026-01-03 12:53:25.818669
822	EUR	ILS	3.73292553	2026-01-03	2026-01-03 12:53:25.868397
823	EUR	IMP	0.87201128	2026-01-03	2026-01-03 12:53:25.954449
824	EUR	INR	105.79297592	2026-01-03	2026-01-03 12:53:26.040776
825	EUR	IQD	1541.7605533	2026-01-03	2026-01-03 12:53:26.077922
826	EUR	IRR	49373.81958984	2026-01-03	2026-01-03 12:53:26.140877
827	EUR	ISK	147.23897691	2026-01-03	2026-01-03 12:53:26.180159
828	EUR	JEP	0.87201128	2026-01-03	2026-01-03 12:53:26.259832
829	EUR	JMD	186.99626358	2026-01-03	2026-01-03 12:53:26.351938
830	EUR	JOD	0.83402288	2026-01-03	2026-01-03 12:53:26.399003
831	EUR	JPY	184.22223035	2026-01-03	2026-01-03 12:53:26.462314
832	EUR	KES	151.77266649	2026-01-03	2026-01-03 12:53:26.54124
833	EUR	KGS	102.82710125	2026-01-03	2026-01-03 12:53:26.635647
834	EUR	KHR	4718.09607562	2026-01-03	2026-01-03 12:53:26.675057
835	EUR	KMF	491.96775	2026-01-03	2026-01-03 12:53:26.769854
836	EUR	KRW	1696.24933868	2026-01-03	2026-01-03 12:53:26.837951
837	EUR	KWD	0.36201067	2026-01-03	2026-01-03 12:53:26.919484
838	EUR	KYD	0.9757798	2026-01-03	2026-01-03 12:53:26.964213
839	EUR	KZT	596.68974729	2026-01-03	2026-01-03 12:53:27.044603
840	EUR	LAK	25441.88603587	2026-01-03	2026-01-03 12:53:27.087151
841	EUR	LBP	105848.88930285	2026-01-03	2026-01-03 12:53:27.173121
842	EUR	LKR	364.2398434	2026-01-03	2026-01-03 12:53:27.244266
843	EUR	LRD	209.89771025	2026-01-03	2026-01-03 12:53:27.284687
844	EUR	LSL	19.46107697	2026-01-03	2026-01-03 12:53:27.371366
845	EUR	LYD	6.37431657	2026-01-03	2026-01-03 12:53:27.435654
846	EUR	MAD	10.71721049	2026-01-03	2026-01-03 12:53:27.489918
847	EUR	MDL	19.76919325	2026-01-03	2026-01-03 12:53:27.54898
848	EUR	MGA	5400.81393132	2026-01-03	2026-01-03 12:53:27.619045
849	EUR	MKD	61.63439792	2026-01-03	2026-01-03 12:53:27.656821
850	EUR	MMK	2469.89330039	2026-01-03	2026-01-03 12:53:27.757454
851	EUR	MNT	4187.36797145	2026-01-03	2026-01-03 12:53:27.801243
852	EUR	MOP	9.43868637	2026-01-03	2026-01-03 12:53:27.846627
853	EUR	MRU	46.86842863	2026-01-03	2026-01-03 12:53:27.938047
854	EUR	MUR	54.33135054	2026-01-03	2026-01-03 12:53:27.979922
855	EUR	MVR	18.1849573	2026-01-03	2026-01-03 12:53:28.049745
856	EUR	MWK	2040.60137853	2026-01-03	2026-01-03 12:53:28.136123
857	EUR	MXN	21.14244815	2026-01-03	2026-01-03 12:53:28.183512
858	EUR	MYR	4.77246358	2026-01-03	2026-01-03 12:53:28.255349
859	EUR	MZN	75.11155413	2026-01-03	2026-01-03 12:53:28.35449
860	EUR	NAD	19.46107697	2026-01-03	2026-01-03 12:53:28.395531
861	EUR	NGN	1699.87111041	2026-01-03	2026-01-03 12:53:28.460568
862	EUR	NIO	43.28159407	2026-01-03	2026-01-03 12:53:28.54401
863	EUR	NOK	11.8328731	2026-01-03	2026-01-03 12:53:28.588959
864	EUR	NPR	169.34810621	2026-01-03	2026-01-03 12:53:28.644439
865	EUR	NZD	2.03876021	2026-01-03	2026-01-03 12:53:28.740597
866	EUR	OMR	0.45281591	2026-01-03	2026-01-03 12:53:28.789962
867	EUR	PAB	1.17633693	2026-01-03	2026-01-03 12:53:28.861009
868	EUR	PEN	3.95341111	2026-01-03	2026-01-03 12:53:28.932544
869	EUR	PGK	5.07432082	2026-01-03	2026-01-03 12:53:28.977231
870	EUR	PHP	69.27894536	2026-01-03	2026-01-03 12:53:29.063344
871	EUR	PKR	329.48850844	2026-01-03	2026-01-03 12:53:29.119945
872	EUR	PLN	4.21704549	2026-01-03	2026-01-03 12:53:29.168486
873	EUR	PYG	7833.52306123	2026-01-03	2026-01-03 12:53:29.242752
874	EUR	QAR	4.28186643	2026-01-03	2026-01-03 12:53:29.292168
875	EUR	RON	5.09601922	2026-01-03	2026-01-03 12:53:29.364045
876	EUR	RSD	117.31758554	2026-01-03	2026-01-03 12:53:29.435513
877	EUR	RUB	92.75229834	2026-01-03	2026-01-03 12:53:29.476839
878	EUR	RWF	1713.11688188	2026-01-03	2026-01-03 12:53:29.540418
879	EUR	SAR	4.4112635	2026-01-03	2026-01-03 12:53:29.579199
880	EUR	SBD	9.53283408	2026-01-03	2026-01-03 12:53:29.663722
881	EUR	SCR	17.83917369	2026-01-03	2026-01-03 12:53:29.73833
882	EUR	SDG	705.36265247	2026-01-03	2026-01-03 12:53:29.778467
883	EUR	SEK	10.82482853	2026-01-03	2026-01-03 12:53:29.860465
884	EUR	SGD	1.5104025	2026-01-03	2026-01-03 12:53:29.945532
885	EUR	SHP	0.87201128	2026-01-03	2026-01-03 12:53:30.019878
886	EUR	SLE	26.8497713	2026-01-03	2026-01-03 12:53:30.069472
887	EUR	SOS	669.62223026	2026-01-03	2026-01-03 12:53:30.148709
888	EUR	SRD	44.80049888	2026-01-03	2026-01-03 12:53:30.218985
889	EUR	SSP	5353.88542079	2026-01-03	2026-01-03 12:53:30.260946
890	EUR	STN	24.65530007	2026-01-03	2026-01-03 12:53:30.34219
891	EUR	SYP	13006.49559186	2026-01-03	2026-01-03 12:53:30.419665
892	EUR	SZL	19.46107697	2026-01-03	2026-01-03 12:53:30.463644
893	EUR	THB	37.09095029	2026-01-03	2026-01-03 12:53:30.554597
894	EUR	TJS	10.86153013	2026-01-03	2026-01-03 12:53:30.673658
895	EUR	TMT	4.11640524	2026-01-03	2026-01-03 12:53:30.719553
896	EUR	TND	3.39200084	2026-01-03	2026-01-03 12:53:30.785492
897	EUR	TOP	2.81686827	2026-01-03	2026-01-03 12:53:30.838835
898	EUR	TRY	50.60720742	2026-01-03	2026-01-03 12:53:30.883859
899	EUR	TTD	7.98714227	2026-01-03	2026-01-03 12:53:30.975479
900	EUR	TVD	1.7573137	2026-01-03	2026-01-03 12:53:31.028851
901	EUR	TWD	36.95275036	2026-01-03	2026-01-03 12:53:31.070078
902	EUR	TZS	2905.12650054	2026-01-03	2026-01-03 12:53:31.139089
903	EUR	UAH	49.70107478	2026-01-03	2026-01-03 12:53:31.176857
904	EUR	UGX	4258.38875177	2026-01-03	2026-01-03 12:53:31.253492
905	EUR	USD	1.17633693	2026-01-03	2026-01-03 12:53:31.319919
906	EUR	UYU	45.95006898	2026-01-03	2026-01-03 12:53:31.359108
907	EUR	UZS	14137.61661196	2026-01-03	2026-01-03 12:53:31.442049
908	EUR	VES	352.33228681	2026-01-03	2026-01-03 12:53:31.480801
909	EUR	VND	30965.60589445	2026-01-03	2026-01-03 12:53:31.559901
910	EUR	VUV	142.38432273	2026-01-03	2026-01-03 12:53:31.634027
911	EUR	WST	3.24690163	2026-01-03	2026-01-03 12:53:31.674392
912	EUR	XAF	655.957	2026-01-03	2026-01-03 12:53:31.747974
913	EUR	XCD	3.18320422	2026-01-03	2026-01-03 12:53:31.792711
914	EUR	XDR	0.85875903	2026-01-03	2026-01-03 12:53:31.862406
915	EUR	XOF	655.957	2026-01-03	2026-01-03 12:53:31.937299
916	EUR	XPF	119.33174224	2026-01-03	2026-01-03 12:53:31.9761
917	EUR	YER	280.43227205	2026-01-03	2026-01-03 12:53:32.042744
918	EUR	ZAR	19.46107697	2026-01-03	2026-01-03 12:53:32.119932
919	EUR	ZMW	26.17461111	2026-01-03	2026-01-03 12:53:32.319325
920	EUR	ZWL	76382.33887792	2026-01-03	2026-01-03 12:53:32.436722
921	EUR	AED	4.30786935	2026-01-04	2026-01-04 22:23:18.051089
922	EUR	AFN	77.50047076	2026-01-04	2026-01-04 22:23:18.122938
923	EUR	ALL	96.67006045	2026-01-04	2026-01-04 22:23:18.162828
924	EUR	AMD	450.85752849	2026-01-04	2026-01-04 22:23:18.22389
925	EUR	ANG	2.10800486	2026-01-04	2026-01-04 22:23:18.263701
926	EUR	AOA	1078.97552976	2026-01-04	2026-01-04 22:23:18.315894
927	EUR	ARS	1730.55629109	2026-01-04	2026-01-04 22:23:18.348098
928	EUR	AUD	1.75255685	2026-01-04	2026-01-04 22:23:18.415191
929	EUR	AWG	2.09968309	2026-01-04	2026-01-04 22:23:18.447748
930	EUR	AZN	1.99612579	2026-01-04	2026-01-04 22:23:18.509353
931	EUR	BAM	1.95583	2026-01-04	2026-01-04 22:23:18.543276
932	EUR	BBD	2.34601462	2026-01-04	2026-01-04 22:23:18.617919
933	EUR	BDT	143.41074494	2026-01-04	2026-01-04 22:23:18.652383
934	EUR	BGN	1.95583	2026-01-04	2026-01-04 22:23:18.706574
935	EUR	BHD	0.44105075	2026-01-04	2026-01-04 22:23:18.784108
936	EUR	BIF	3472.32825748	2026-01-04	2026-01-04 22:23:18.818571
937	EUR	BMD	1.17300731	2026-01-04	2026-01-04 22:23:18.85778
938	EUR	BND	1.50812715	2026-01-04	2026-01-04 22:23:18.916076
939	EUR	BOB	8.11842341	2026-01-04	2026-01-04 22:23:18.984168
940	EUR	BRL	6.36184678	2026-01-04	2026-01-04 22:23:19.024044
941	EUR	BSD	1.17300731	2026-01-04	2026-01-04 22:23:19.115089
942	EUR	BTN	105.57056091	2026-01-04	2026-01-04 22:23:19.156845
943	EUR	BWP	15.8066228	2026-01-04	2026-01-04 22:23:19.212026
944	EUR	BYN	3.44216532	2026-01-04	2026-01-04 22:23:19.244393
945	EUR	BZD	2.36006518	2026-01-04	2026-01-04 22:23:19.324322
946	EUR	CAD	1.61094949	2026-01-04	2026-01-04 22:23:19.382912
947	EUR	CDF	2577.20867415	2026-01-04	2026-01-04 22:23:19.417903
948	EUR	CHF	0.92856212	2026-01-04	2026-01-04 22:23:19.501529
949	EUR	CLP	1062.9499386	2026-01-04	2026-01-04 22:23:19.607262
950	EUR	CNH	8.17855926	2026-01-04	2026-01-04 22:23:19.706995
951	EUR	CNY	8.20327076	2026-01-04	2026-01-04 22:23:19.747876
952	EUR	COP	4436.75671848	2026-01-04	2026-01-04 22:23:19.803172
953	EUR	CRC	585.39554868	2026-01-04	2026-01-04 22:23:19.847783
954	EUR	CUP	28.01647031	2026-01-04	2026-01-04 22:23:19.90459
955	EUR	CVE	110.26999999	2026-01-04	2026-01-04 22:23:19.984076
956	EUR	CZK	24.16428559	2026-01-04	2026-01-04 22:23:20.016599
957	EUR	DJF	209.37983565	2026-01-04	2026-01-04 22:23:20.097164
958	EUR	DKK	7.47259136	2026-01-04	2026-01-04 22:23:20.143997
959	EUR	DOP	74.13022754	2026-01-04	2026-01-04 22:23:20.221176
960	EUR	DZD	152.1392767	2026-01-04	2026-01-04 22:23:20.283335
961	EUR	EGP	55.95317262	2026-01-04	2026-01-04 22:23:20.328076
962	EUR	ERN	17.59510965	2026-01-04	2026-01-04 22:23:20.382935
963	EUR	ETB	182.04846073	2026-01-04	2026-01-04 22:23:20.424218
964	EUR	FJD	2.67306284	2026-01-04	2026-01-04 22:23:20.462932
965	EUR	FKP	0.87124635	2026-01-04	2026-01-04 22:23:20.516978
966	EUR	GBP	0.87124635	2026-01-04	2026-01-04 22:23:20.596821
967	EUR	GEL	3.15604444	2026-01-04	2026-01-04 22:23:20.65472
968	EUR	GGP	0.87124635	2026-01-04	2026-01-04 22:23:20.701214
969	EUR	GHS	12.29878323	2026-01-04	2026-01-04 22:23:20.740835
970	EUR	GIP	0.87124635	2026-01-04	2026-01-04 22:23:20.783706
971	EUR	GMD	86.85281307	2026-01-04	2026-01-04 22:23:20.81932
972	EUR	GNF	10258.80086249	2026-01-04	2026-01-04 22:23:20.866661
973	EUR	GTQ	8.99188902	2026-01-04	2026-01-04 22:23:20.91322
974	EUR	GYD	245.46554225	2026-01-04	2026-01-04 22:23:20.949207
975	EUR	HKD	9.13907478	2026-01-04	2026-01-04 22:23:21.006587
976	EUR	HNL	30.95872572	2026-01-04	2026-01-04 22:23:21.053867
977	EUR	HRK	7.5345	2026-01-04	2026-01-04 22:23:21.106464
978	EUR	HTG	153.92353612	2026-01-04	2026-01-04 22:23:21.183457
979	EUR	HUF	383.48967939	2026-01-04	2026-01-04 22:23:21.219727
980	EUR	IDR	19603.70139105	2026-01-04	2026-01-04 22:23:21.255058
981	EUR	ILS	3.73678156	2026-01-04	2026-01-04 22:23:21.320162
982	EUR	IMP	0.87124635	2026-01-04	2026-01-04 22:23:21.358028
983	EUR	INR	105.57056091	2026-01-04	2026-01-04 22:23:21.418227
984	EUR	IQD	1537.07846665	2026-01-04	2026-01-04 22:23:21.461219
985	EUR	IRR	49366.24538237	2026-01-04	2026-01-04 22:23:21.519184
986	EUR	ISK	147.52794529	2026-01-04	2026-01-04 22:23:21.557612
987	EUR	JEP	0.87124635	2026-01-04	2026-01-04 22:23:21.620254
988	EUR	JMD	187.17588615	2026-01-04	2026-01-04 22:23:21.68387
989	EUR	JOD	0.83166218	2026-01-04	2026-01-04 22:23:21.72321
990	EUR	JPY	183.90311243	2026-01-04	2026-01-04 22:23:21.799782
991	EUR	KES	151.33854862	2026-01-04	2026-01-04 22:23:21.834814
992	EUR	KGS	102.58138064	2026-01-04	2026-01-04 22:23:21.90625
993	EUR	KHR	4706.23521082	2026-01-04	2026-01-04 22:23:21.942307
994	EUR	KMF	491.96774997	2026-01-04	2026-01-04 22:23:22.028137
995	EUR	KRW	1693.01829769	2026-01-04	2026-01-04 22:23:22.083994
996	EUR	KWD	0.36066488	2026-01-04	2026-01-04 22:23:22.148328
997	EUR	KYD	0.96250268	2026-01-04	2026-01-04 22:23:22.20395
998	EUR	KZT	593.58028919	2026-01-04	2026-01-04 22:23:22.243635
999	EUR	LAK	25345.1962307	2026-01-04	2026-01-04 22:23:22.315295
1000	EUR	LBP	105211.86095075	2026-01-04	2026-01-04 22:23:22.353265
1001	EUR	LKR	362.63739184	2026-01-04	2026-01-04 22:23:22.405501
1002	EUR	LRD	208.92429715	2026-01-04	2026-01-04 22:23:22.443844
1003	EUR	LSL	19.33528132	2026-01-04	2026-01-04 22:23:22.495391
1004	EUR	LYD	6.36021777	2026-01-04	2026-01-04 22:23:22.538049
1005	EUR	MAD	10.71484804	2026-01-04	2026-01-04 22:23:22.600826
1006	EUR	MDL	19.72798393	2026-01-04	2026-01-04 22:23:22.640311
1007	EUR	MGA	5376.99100551	2026-01-04	2026-01-04 22:23:22.673871
1008	EUR	MKD	61.54515451	2026-01-04	2026-01-04 22:23:22.716201
1009	EUR	MMK	2463.40699333	2026-01-04	2026-01-04 22:23:22.755983
1010	EUR	MNT	4172.42149859	2026-01-04	2026-01-04 22:23:22.810272
1011	EUR	MOP	9.41324702	2026-01-04	2026-01-04 22:23:22.848398
1012	EUR	MRU	46.75011085	2026-01-04	2026-01-04 22:23:22.901572
1013	EUR	MUR	54.17122814	2026-01-04	2026-01-04 22:23:22.942313
1014	EUR	MVR	18.13412203	2026-01-04	2026-01-04 22:23:23.012533
1015	EUR	MWK	2036.97317482	2026-01-04	2026-01-04 22:23:23.049137
1016	EUR	MXN	21.00327493	2026-01-04	2026-01-04 22:23:23.106453
1017	EUR	MYR	4.75640638	2026-01-04	2026-01-04 22:23:23.143031
1018	EUR	MZN	74.92697366	2026-01-04	2026-01-04 22:23:23.202617
1019	EUR	NAD	19.33528132	2026-01-04	2026-01-04 22:23:23.235871
1020	EUR	NGN	1687.46530765	2026-01-04	2026-01-04 22:23:23.31427
1021	EUR	NIO	43.04292266	2026-01-04	2026-01-04 22:23:23.350864
1022	EUR	NOK	11.80431893	2026-01-04	2026-01-04 22:23:23.418492
1023	EUR	NPR	168.99207538	2026-01-04	2026-01-04 22:23:23.458642
1024	EUR	NZD	2.03342513	2026-01-04	2026-01-04 22:23:23.515409
1025	EUR	OMR	0.45154414	2026-01-04	2026-01-04 22:23:23.549217
1026	EUR	PAB	1.17300731	2026-01-04	2026-01-04 22:23:23.60864
1027	EUR	PEN	3.94254462	2026-01-04	2026-01-04 22:23:23.645786
1028	EUR	PGK	4.98770873	2026-01-04	2026-01-04 22:23:23.709746
1029	EUR	PHP	69.04358687	2026-01-04	2026-01-04 22:23:23.783744
1030	EUR	PKR	328.53335555	2026-01-04	2026-01-04 22:23:23.819606
1031	EUR	PLN	4.21274255	2026-01-04	2026-01-04 22:23:23.904842
1032	EUR	PYG	7719.86584837	2026-01-04	2026-01-04 22:23:23.950447
1033	EUR	QAR	4.26974661	2026-01-04	2026-01-04 22:23:24.024991
1034	EUR	RON	5.09168566	2026-01-04	2026-01-04 22:23:24.10187
1035	EUR	RSD	117.395025	2026-01-04	2026-01-04 22:23:24.136761
1036	EUR	RUB	94.16853969	2026-01-04	2026-01-04 22:23:24.201529
1037	EUR	RWF	1706.98739917	2026-01-04	2026-01-04 22:23:24.23834
1038	EUR	SAR	4.39877741	2026-01-04	2026-01-04 22:23:24.301287
1039	EUR	SBD	9.55254273	2026-01-04	2026-01-04 22:23:24.335632
1040	EUR	SCR	17.61115061	2026-01-04	2026-01-04 22:23:24.404007
1041	EUR	SDG	703.56358658	2026-01-04	2026-01-04 22:23:24.439235
1042	EUR	SEK	10.8128903	2026-01-04	2026-01-04 22:23:24.514276
1043	EUR	SGD	1.50812715	2026-01-04	2026-01-04 22:23:24.55257
1044	EUR	SHP	0.87124635	2026-01-04	2026-01-04 22:23:24.631205
1045	EUR	SLE	26.7797596	2026-01-04	2026-01-04 22:23:24.665974
1046	EUR	SOS	670.00248723	2026-01-04	2026-01-04 22:23:24.713443
1047	EUR	SRD	44.83148349	2026-01-04	2026-01-04 22:23:24.754295
1048	EUR	SSP	5343.95153208	2026-01-04	2026-01-04 22:23:24.803265
1049	EUR	STN	24.69241129	2026-01-04	2026-01-04 22:23:24.840564
1050	EUR	SYP	12969.6662986	2026-01-04	2026-01-04 22:23:24.899619
1051	EUR	SZL	19.33528132	2026-01-04	2026-01-04 22:23:24.93598
1052	EUR	THB	36.92906417	2026-01-04	2026-01-04 22:23:25.002377
1053	EUR	TJS	10.83797445	2026-01-04	2026-01-04 22:23:25.039286
1054	EUR	TMT	4.10539445	2026-01-04	2026-01-04 22:23:25.112714
1055	EUR	TND	3.3909886	2026-01-04	2026-01-04 22:23:25.1506
1056	EUR	TOP	2.80661143	2026-01-04	2026-01-04 22:23:25.219743
1057	EUR	TRY	50.48438489	2026-01-04	2026-01-04 22:23:25.259123
1058	EUR	TTD	7.94225034	2026-01-04	2026-01-04 22:23:25.318143
1059	EUR	TVD	1.75255685	2026-01-04	2026-01-04 22:23:25.382919
1060	EUR	TWD	36.81256853	2026-01-04	2026-01-04 22:23:25.41927
1061	EUR	TZS	2889.9159859	2026-01-04	2026-01-04 22:23:25.462563
1062	EUR	UAH	49.55172174	2026-01-04	2026-01-04 22:23:25.509353
1063	EUR	UGX	4250.54076363	2026-01-04	2026-01-04 22:23:25.546228
1064	EUR	USD	1.17300731	2026-01-04	2026-01-04 22:23:25.602799
1065	EUR	UYU	45.67873016	2026-01-04	2026-01-04 22:23:25.64142
1066	EUR	UZS	14083.0439986	2026-01-04	2026-01-04 22:23:25.695841
1067	EUR	VES	352.63177967	2026-01-04	2026-01-04 22:23:25.731488
1068	EUR	VND	30878.29289635	2026-01-04	2026-01-04 22:23:25.800931
1069	EUR	VUV	141.72680651	2026-01-04	2026-01-04 22:23:25.833333
1070	EUR	WST	3.2466395	2026-01-04	2026-01-04 22:23:25.903752
1071	EUR	XAF	655.95699996	2026-01-04	2026-01-04 22:23:25.937614
1072	EUR	XCD	3.16821862	2026-01-04	2026-01-04 22:23:26.001311
1073	EUR	XDR	0.8571857	2026-01-04	2026-01-04 22:23:26.037617
1074	EUR	XOF	655.95699996	2026-01-04	2026-01-04 22:23:26.106735
1075	EUR	XPF	119.33174224	2026-01-04	2026-01-04 22:23:26.143777
1076	EUR	YER	279.61099673	2026-01-04	2026-01-04 22:23:26.226475
1077	EUR	ZAR	19.33528132	2026-01-04	2026-01-04 22:23:26.303015
1078	EUR	ZMW	25.92483679	2026-01-04	2026-01-04 22:23:26.338043
1079	EUR	ZWL	76017.33470016	2026-01-04	2026-01-04 22:23:26.403181
1080	EUR	AED	4.30786935	2026-01-05	2026-01-05 12:32:33.390901
1081	EUR	AFN	77.50047076	2026-01-05	2026-01-05 12:32:33.476876
1082	EUR	ALL	96.67006045	2026-01-05	2026-01-05 12:32:33.519648
1083	EUR	AMD	450.85752849	2026-01-05	2026-01-05 12:32:33.597598
1084	EUR	ANG	2.10800486	2026-01-05	2026-01-05 12:32:33.687054
1085	EUR	AOA	1078.97552976	2026-01-05	2026-01-05 12:32:33.728321
1086	EUR	ARS	1730.55629109	2026-01-05	2026-01-05 12:32:33.781868
1087	EUR	AUD	1.75255685	2026-01-05	2026-01-05 12:32:33.823675
1088	EUR	AWG	2.09968309	2026-01-05	2026-01-05 12:32:33.914976
1089	EUR	AZN	1.99612579	2026-01-05	2026-01-05 12:32:33.97899
1090	EUR	BAM	1.95583	2026-01-05	2026-01-05 12:32:34.01546
1091	EUR	BBD	2.34601462	2026-01-05	2026-01-05 12:32:34.094284
1092	EUR	BDT	143.41074494	2026-01-05	2026-01-05 12:32:34.162802
1093	EUR	BGN	1.95583	2026-01-05	2026-01-05 12:32:34.202904
1094	EUR	BHD	0.44105075	2026-01-05	2026-01-05 12:32:34.283904
1095	EUR	BIF	3472.32825748	2026-01-05	2026-01-05 12:32:34.325398
1096	EUR	BMD	1.17300731	2026-01-05	2026-01-05 12:32:34.393748
1097	EUR	BND	1.50812715	2026-01-05	2026-01-05 12:32:34.435969
1098	EUR	BOB	8.11842341	2026-01-05	2026-01-05 12:32:34.5066
1099	EUR	BRL	6.36184678	2026-01-05	2026-01-05 12:32:34.577005
1100	EUR	BSD	1.17300731	2026-01-05	2026-01-05 12:32:34.614037
1101	EUR	BTN	105.57056091	2026-01-05	2026-01-05 12:32:34.686719
1102	EUR	BWP	15.8066228	2026-01-05	2026-01-05 12:32:34.732951
1103	EUR	BYN	3.44216532	2026-01-05	2026-01-05 12:32:34.818679
1104	EUR	BZD	2.36006518	2026-01-05	2026-01-05 12:32:34.880633
1105	EUR	CAD	1.61094949	2026-01-05	2026-01-05 12:32:34.921857
1106	EUR	CDF	2577.20867415	2026-01-05	2026-01-05 12:32:35.001237
1107	EUR	CHF	0.92856212	2026-01-05	2026-01-05 12:32:35.088773
1108	EUR	CLP	1062.9499386	2026-01-05	2026-01-05 12:32:35.186296
1109	EUR	CNH	8.17855926	2026-01-05	2026-01-05 12:32:35.226636
1110	EUR	CNY	8.20327076	2026-01-05	2026-01-05 12:32:35.285313
1111	EUR	COP	4436.75671848	2026-01-05	2026-01-05 12:32:35.380551
1112	EUR	CRC	585.39554868	2026-01-05	2026-01-05 12:32:35.461135
1113	EUR	CUP	28.01647031	2026-01-05	2026-01-05 12:32:35.497423
1114	EUR	CVE	110.26999999	2026-01-05	2026-01-05 12:32:35.563381
1115	EUR	CZK	24.16428559	2026-01-05	2026-01-05 12:32:35.601372
1116	EUR	DJF	209.37983565	2026-01-05	2026-01-05 12:32:35.685107
1117	EUR	DKK	7.47259136	2026-01-05	2026-01-05 12:32:35.723762
1118	EUR	DOP	74.13022754	2026-01-05	2026-01-05 12:32:35.789849
1119	EUR	DZD	152.1392767	2026-01-05	2026-01-05 12:32:35.863295
1120	EUR	EGP	55.95317262	2026-01-05	2026-01-05 12:32:35.901502
1121	EUR	ERN	17.59510965	2026-01-05	2026-01-05 12:32:35.991194
1122	EUR	ETB	182.04846073	2026-01-05	2026-01-05 12:32:36.065778
1123	EUR	FJD	2.67306284	2026-01-05	2026-01-05 12:32:36.133404
1124	EUR	FKP	0.87124635	2026-01-05	2026-01-05 12:32:36.192216
1125	EUR	GBP	0.87124635	2026-01-05	2026-01-05 12:32:36.288129
1126	EUR	GEL	3.15604444	2026-01-05	2026-01-05 12:32:36.384192
1127	EUR	GGP	0.87124635	2026-01-05	2026-01-05 12:32:36.423822
1128	EUR	GHS	12.29878323	2026-01-05	2026-01-05 12:32:36.504859
1129	EUR	GIP	0.87124635	2026-01-05	2026-01-05 12:32:36.579443
1130	EUR	GMD	86.85281307	2026-01-05	2026-01-05 12:32:36.621768
1131	EUR	GNF	10258.80086249	2026-01-05	2026-01-05 12:32:36.690217
1132	EUR	GTQ	8.99188902	2026-01-05	2026-01-05 12:32:36.77736
1133	EUR	GYD	245.46554225	2026-01-05	2026-01-05 12:32:36.835052
1134	EUR	HKD	9.13907478	2026-01-05	2026-01-05 12:32:36.91747
1135	EUR	HNL	30.95872572	2026-01-05	2026-01-05 12:32:36.999678
1136	EUR	HRK	7.5345	2026-01-05	2026-01-05 12:32:37.06217
1137	EUR	HTG	153.92353612	2026-01-05	2026-01-05 12:32:37.102774
1138	EUR	HUF	383.48967939	2026-01-05	2026-01-05 12:32:37.18403
1139	EUR	IDR	19603.70139105	2026-01-05	2026-01-05 12:32:37.230689
1140	EUR	ILS	3.73678156	2026-01-05	2026-01-05 12:32:37.304398
1141	EUR	IMP	0.87124635	2026-01-05	2026-01-05 12:32:37.385823
1142	EUR	INR	105.57056091	2026-01-05	2026-01-05 12:32:37.462878
1143	EUR	IQD	1537.07846665	2026-01-05	2026-01-05 12:32:37.516987
1144	EUR	IRR	49366.24538237	2026-01-05	2026-01-05 12:32:37.598109
1145	EUR	ISK	147.52794529	2026-01-05	2026-01-05 12:32:37.679971
1146	EUR	JEP	0.87124635	2026-01-05	2026-01-05 12:32:37.720592
1147	EUR	JMD	187.17588615	2026-01-05	2026-01-05 12:32:37.803837
1148	EUR	JOD	0.83166218	2026-01-05	2026-01-05 12:32:37.890156
1149	EUR	JPY	183.90311243	2026-01-05	2026-01-05 12:32:37.931764
1150	EUR	KES	151.33854862	2026-01-05	2026-01-05 12:32:38.021603
1151	EUR	KGS	102.58138064	2026-01-05	2026-01-05 12:32:38.098663
1152	EUR	KHR	4706.23521082	2026-01-05	2026-01-05 12:32:38.162461
1153	EUR	KMF	491.96774997	2026-01-05	2026-01-05 12:32:38.277835
1154	EUR	KRW	1693.01829769	2026-01-05	2026-01-05 12:32:38.322858
1155	EUR	KWD	0.36066488	2026-01-05	2026-01-05 12:32:38.403354
1156	EUR	KYD	0.96250268	2026-01-05	2026-01-05 12:32:38.482639
1157	EUR	KZT	593.58028919	2026-01-05	2026-01-05 12:32:38.518133
1158	EUR	LAK	25345.1962307	2026-01-05	2026-01-05 12:32:38.583765
1159	EUR	LBP	105211.86095075	2026-01-05	2026-01-05 12:32:38.662469
1160	EUR	LKR	362.63739184	2026-01-05	2026-01-05 12:32:38.701297
1161	EUR	LRD	208.92429715	2026-01-05	2026-01-05 12:32:38.776583
1162	EUR	LSL	19.33528132	2026-01-05	2026-01-05 12:32:38.815956
1163	EUR	LYD	6.36021777	2026-01-05	2026-01-05 12:32:38.900847
1164	EUR	MAD	10.71484804	2026-01-05	2026-01-05 12:32:38.996614
1165	EUR	MDL	19.72798393	2026-01-05	2026-01-05 12:32:39.06286
1166	EUR	MGA	5376.99100551	2026-01-05	2026-01-05 12:32:39.101444
1167	EUR	MKD	61.54515451	2026-01-05	2026-01-05 12:32:39.185265
1168	EUR	MMK	2463.40699333	2026-01-05	2026-01-05 12:32:39.223537
1169	EUR	MNT	4172.42149859	2026-01-05	2026-01-05 12:32:39.301031
1170	EUR	MOP	9.41324702	2026-01-05	2026-01-05 12:32:39.379574
1171	EUR	MRU	46.75011085	2026-01-05	2026-01-05 12:32:39.421636
1172	EUR	MUR	54.17122814	2026-01-05	2026-01-05 12:32:39.500938
1173	EUR	MVR	18.13412203	2026-01-05	2026-01-05 12:32:39.563811
1174	EUR	MWK	2036.97317482	2026-01-05	2026-01-05 12:32:39.605331
1175	EUR	MXN	21.00327493	2026-01-05	2026-01-05 12:32:39.692398
1176	EUR	MYR	4.75640638	2026-01-05	2026-01-05 12:32:39.72896
1177	EUR	MZN	74.92697366	2026-01-05	2026-01-05 12:32:39.804639
1178	EUR	NAD	19.33528132	2026-01-05	2026-01-05 12:32:39.862809
1179	EUR	NGN	1687.46530765	2026-01-05	2026-01-05 12:32:39.906799
1180	EUR	NIO	43.04292266	2026-01-05	2026-01-05 12:32:39.999424
1181	EUR	NOK	11.80431893	2026-01-05	2026-01-05 12:32:40.04458
1182	EUR	NPR	168.99207538	2026-01-05	2026-01-05 12:32:40.165706
1183	EUR	NZD	2.03342513	2026-01-05	2026-01-05 12:32:40.277374
1184	EUR	OMR	0.45154414	2026-01-05	2026-01-05 12:32:40.320523
1185	EUR	PAB	1.17300731	2026-01-05	2026-01-05 12:32:40.383148
1186	EUR	PEN	3.94254462	2026-01-05	2026-01-05 12:32:40.431823
1187	EUR	PGK	4.98770873	2026-01-05	2026-01-05 12:32:40.48537
1188	EUR	PHP	69.04358687	2026-01-05	2026-01-05 12:32:40.563675
1189	EUR	PKR	328.53335555	2026-01-05	2026-01-05 12:32:40.60715
1190	EUR	PLN	4.21274255	2026-01-05	2026-01-05 12:32:40.679021
1191	EUR	PYG	7719.86584837	2026-01-05	2026-01-05 12:32:40.730964
1192	EUR	QAR	4.26974661	2026-01-05	2026-01-05 12:32:40.786094
1193	EUR	RON	5.09168566	2026-01-05	2026-01-05 12:32:40.862165
1194	EUR	RSD	117.395025	2026-01-05	2026-01-05 12:32:40.900245
1195	EUR	RUB	94.16853969	2026-01-05	2026-01-05 12:32:40.978862
1196	EUR	RWF	1706.98739917	2026-01-05	2026-01-05 12:32:41.020813
1197	EUR	SAR	4.39877741	2026-01-05	2026-01-05 12:32:41.093527
1198	EUR	SBD	9.55254273	2026-01-05	2026-01-05 12:32:41.162627
1199	EUR	SCR	17.61115061	2026-01-05	2026-01-05 12:32:41.20226
1200	EUR	SDG	703.56358658	2026-01-05	2026-01-05 12:32:41.276671
1201	EUR	SEK	10.8128903	2026-01-05	2026-01-05 12:32:41.315935
1202	EUR	SGD	1.50812715	2026-01-05	2026-01-05 12:32:41.400603
1203	EUR	SHP	0.87124635	2026-01-05	2026-01-05 12:32:41.49623
1204	EUR	SLE	26.7797596	2026-01-05	2026-01-05 12:32:41.538186
1205	EUR	SOS	670.00248723	2026-01-05	2026-01-05 12:32:41.597606
1206	EUR	SRD	44.83148349	2026-01-05	2026-01-05 12:32:41.676146
1207	EUR	SSP	5343.95153208	2026-01-05	2026-01-05 12:32:41.720368
1208	EUR	STN	24.69241129	2026-01-05	2026-01-05 12:32:41.795552
1209	EUR	SYP	12969.6662986	2026-01-05	2026-01-05 12:32:41.879956
1210	EUR	SZL	19.33528132	2026-01-05	2026-01-05 12:32:41.919376
1211	EUR	THB	36.92906417	2026-01-05	2026-01-05 12:32:41.985928
1212	EUR	TJS	10.83797445	2026-01-05	2026-01-05 12:32:42.035007
1213	EUR	TMT	4.10539445	2026-01-05	2026-01-05 12:32:42.112216
1214	EUR	TND	3.3909886	2026-01-05	2026-01-05 12:32:42.203308
1215	EUR	TOP	2.80661143	2026-01-05	2026-01-05 12:32:42.281644
1216	EUR	TRY	50.48438489	2026-01-05	2026-01-05 12:32:42.320465
1217	EUR	TTD	7.94225034	2026-01-05	2026-01-05 12:32:42.387716
1218	EUR	TVD	1.75255685	2026-01-05	2026-01-05 12:32:42.462405
1219	EUR	TWD	36.81256853	2026-01-05	2026-01-05 12:32:42.506655
1220	EUR	TZS	2889.9159859	2026-01-05	2026-01-05 12:32:42.597583
1221	EUR	UAH	49.55172174	2026-01-05	2026-01-05 12:32:42.663633
1222	EUR	UGX	4250.54076363	2026-01-05	2026-01-05 12:32:42.715306
1223	EUR	USD	1.17300731	2026-01-05	2026-01-05 12:32:42.78416
1224	EUR	UYU	45.67873016	2026-01-05	2026-01-05 12:32:42.819488
1225	EUR	UZS	14083.0439986	2026-01-05	2026-01-05 12:32:42.897416
1226	EUR	VES	352.63177967	2026-01-05	2026-01-05 12:32:42.978862
1227	EUR	VND	30878.29289635	2026-01-05	2026-01-05 12:32:43.018273
1228	EUR	VUV	141.72680651	2026-01-05	2026-01-05 12:32:43.087039
1229	EUR	WST	3.2466395	2026-01-05	2026-01-05 12:32:43.137212
1230	EUR	XAF	655.95699996	2026-01-05	2026-01-05 12:32:43.200333
1231	EUR	XCD	3.16821862	2026-01-05	2026-01-05 12:32:43.262324
1232	EUR	XDR	0.8571857	2026-01-05	2026-01-05 12:32:43.304925
1233	EUR	XOF	655.95699996	2026-01-05	2026-01-05 12:32:43.363487
1234	EUR	XPF	119.33174224	2026-01-05	2026-01-05 12:32:43.41022
1235	EUR	YER	279.61099673	2026-01-05	2026-01-05 12:32:43.483869
1236	EUR	ZAR	19.33528132	2026-01-05	2026-01-05 12:32:43.562434
1237	EUR	ZMW	25.92483679	2026-01-05	2026-01-05 12:32:43.599281
1238	EUR	ZWL	76017.33470016	2026-01-05	2026-01-05 12:32:43.684273
1239	EUR	AED	4.30567661	2026-01-06	2026-01-06 18:12:12.488145
1240	EUR	AFN	77.27368662	2026-01-06	2026-01-06 18:12:12.557113
1241	EUR	ALL	96.72192353	2026-01-06	2026-01-06 18:12:12.61995
1242	EUR	AMD	447.0751654	2026-01-06	2026-01-06 18:12:12.686819
1243	EUR	ANG	2.10911362	2026-01-06	2026-01-06 18:12:12.730839
1244	EUR	AOA	1075.89724568	2026-01-06	2026-01-06 18:12:12.816726
1245	EUR	ARS	1723.27941219	2026-01-06	2026-01-06 18:12:12.860738
1246	EUR	AUD	1.74614501	2026-01-06	2026-01-06 18:12:12.92894
1247	EUR	AWG	2.09861433	2026-01-06	2026-01-06 18:12:13.006436
1248	EUR	AZN	1.99309741	2026-01-06	2026-01-06 18:12:13.060751
1249	EUR	BAM	1.95583	2026-01-06	2026-01-06 18:12:13.135237
1250	EUR	BBD	2.34482048	2026-01-06	2026-01-06 18:12:13.209793
1251	EUR	BDT	143.10086113	2026-01-06	2026-01-06 18:12:13.255239
1252	EUR	BGN	1.95583	2026-01-06	2026-01-06 18:12:13.326292
1253	EUR	BHD	0.44082625	2026-01-06	2026-01-06 18:12:13.387332
1254	EUR	BIF	3463.31366579	2026-01-06	2026-01-06 18:12:13.436518
1255	EUR	BMD	1.17241024	2026-01-06	2026-01-06 18:12:13.518523
1256	EUR	BND	1.50311467	2026-01-06	2026-01-06 18:12:13.588025
1257	EUR	BOB	8.10562871	2026-01-06	2026-01-06 18:12:13.639338
1258	EUR	BRL	6.34116683	2026-01-06	2026-01-06 18:12:13.717614
1259	EUR	BSD	1.17241024	2026-01-06	2026-01-06 18:12:13.765782
1260	EUR	BTN	105.76510867	2026-01-06	2026-01-06 18:12:13.839095
1261	EUR	BWP	16.19858829	2026-01-06	2026-01-06 18:12:13.905062
1262	EUR	BYN	3.47475299	2026-01-06	2026-01-06 18:12:13.952681
1263	EUR	BZD	2.35225389	2026-01-06	2026-01-06 18:12:14.020481
1264	EUR	CAD	1.6141842	2026-01-06	2026-01-06 18:12:14.07339
1265	EUR	CDF	2667.2305113	2026-01-06	2026-01-06 18:12:14.131144
1266	EUR	CHF	0.92793691	2026-01-06	2026-01-06 18:12:14.20106
1267	EUR	CLP	1059.85592832	2026-01-06	2026-01-06 18:12:14.269589
1268	EUR	CNH	8.18506954	2026-01-06	2026-01-06 18:12:14.348108
1269	EUR	CNY	8.18932007	2026-01-06	2026-01-06 18:12:14.437092
1270	EUR	COP	4392.83131078	2026-01-06	2026-01-06 18:12:14.489053
1271	EUR	CRC	582.36604394	2026-01-06	2026-01-06 18:12:14.583738
1272	EUR	CUP	28.07278196	2026-01-06	2026-01-06 18:12:14.668086
1273	EUR	CVE	110.27	2026-01-06	2026-01-06 18:12:14.732885
1274	EUR	CZK	24.19598057	2026-01-06	2026-01-06 18:12:14.7876
1275	EUR	DJF	208.65769801	2026-01-06	2026-01-06 18:12:14.836948
1276	EUR	DKK	7.47087328	2026-01-06	2026-01-06 18:12:14.900792
1277	EUR	DOP	73.86533755	2026-01-06	2026-01-06 18:12:14.979389
1278	EUR	DZD	152.35168767	2026-01-06	2026-01-06 18:12:15.030941
1279	EUR	EGP	55.48349485	2026-01-06	2026-01-06 18:12:15.080571
1280	EUR	ERN	17.58615362	2026-01-06	2026-01-06 18:12:15.131984
1281	EUR	ETB	181.96657499	2026-01-06	2026-01-06 18:12:15.222154
1282	EUR	FJD	2.66822968	2026-01-06	2026-01-06 18:12:15.264746
1283	EUR	FKP	0.86568462	2026-01-06	2026-01-06 18:12:15.311823
1284	EUR	GBP	0.86568462	2026-01-06	2026-01-06 18:12:15.422203
1285	EUR	GEL	3.15909478	2026-01-06	2026-01-06 18:12:15.465544
1286	EUR	GGP	0.86568462	2026-01-06	2026-01-06 18:12:15.51891
1287	EUR	GHS	12.27369681	2026-01-06	2026-01-06 18:12:15.612648
1288	EUR	GIP	0.86568462	2026-01-06	2026-01-06 18:12:15.652543
1289	EUR	GMD	86.64831595	2026-01-06	2026-01-06 18:12:15.711073
1290	EUR	GNF	10256.99370869	2026-01-06	2026-01-06 18:12:15.760487
1291	EUR	GTQ	8.98200484	2026-01-06	2026-01-06 18:12:15.835386
1292	EUR	GYD	244.36586807	2026-01-06	2026-01-06 18:12:15.898776
1293	EUR	HKD	9.12733595	2026-01-06	2026-01-06 18:12:15.938485
1294	EUR	HNL	30.92165511	2026-01-06	2026-01-06 18:12:16.018604
1295	EUR	HRK	7.5345	2026-01-06	2026-01-06 18:12:16.063126
1296	EUR	HTG	153.18389805	2026-01-06	2026-01-06 18:12:16.126073
1297	EUR	HUF	384.105517	2026-01-06	2026-01-06 18:12:16.210118
1298	EUR	IDR	19621.20772159	2026-01-06	2026-01-06 18:12:16.252865
1299	EUR	ILS	3.69654076	2026-01-06	2026-01-06 18:12:16.317838
1300	EUR	IMP	0.86568462	2026-01-06	2026-01-06 18:12:16.387011
1301	EUR	INR	105.76510867	2026-01-06	2026-01-06 18:12:16.440073
1302	EUR	IQD	1533.4191917	2026-01-06	2026-01-06 18:12:16.515538
1303	EUR	IRR	49337.3601353	2026-01-06	2026-01-06 18:12:16.586178
1304	EUR	ISK	147.40390099	2026-01-06	2026-01-06 18:12:16.628806
1305	EUR	JEP	0.86568462	2026-01-06	2026-01-06 18:12:16.718527
1306	EUR	JMD	186.05240635	2026-01-06	2026-01-06 18:12:16.760445
1307	EUR	JOD	0.83123886	2026-01-06	2026-01-06 18:12:16.808557
1308	EUR	JPY	183.47138103	2026-01-06	2026-01-06 18:12:16.853907
1309	EUR	KES	150.91124428	2026-01-06	2026-01-06 18:12:16.917055
1310	EUR	KGS	102.5274165	2026-01-06	2026-01-06 18:12:16.961439
1311	EUR	KHR	4706.28551089	2026-01-06	2026-01-06 18:12:17.037681
1312	EUR	KMF	491.96774999	2026-01-06	2026-01-06 18:12:17.156086
1313	EUR	KRW	1695.76755672	2026-01-06	2026-01-06 18:12:17.210921
1314	EUR	KWD	0.36012124	2026-01-06	2026-01-06 18:12:17.255647
1315	EUR	KYD	0.97187468	2026-01-06	2026-01-06 18:12:17.309293
1316	EUR	KZT	601.22862083	2026-01-06	2026-01-06 18:12:17.351439
1317	EUR	LAK	25326.54469619	2026-01-06	2026-01-06 18:12:17.430202
1318	EUR	LBP	105142.70023081	2026-01-06	2026-01-06 18:12:17.468762
1319	EUR	LKR	363.04779899	2026-01-06	2026-01-06 18:12:17.519061
1320	EUR	LRD	208.3731237	2026-01-06	2026-01-06 18:12:17.605782
1321	EUR	LSL	19.16544576	2026-01-06	2026-01-06 18:12:17.651945
1322	EUR	LYD	6.34454618	2026-01-06	2026-01-06 18:12:17.72982
1323	EUR	MAD	10.73848233	2026-01-06	2026-01-06 18:12:17.786679
1324	EUR	MDL	19.71983219	2026-01-06	2026-01-06 18:12:17.830947
1325	EUR	MGA	5399.32618649	2026-01-06	2026-01-06 18:12:17.905478
1326	EUR	MKD	61.55219578	2026-01-06	2026-01-06 18:12:17.947605
1327	EUR	MMK	2461.92580706	2026-01-06	2026-01-06 18:12:18.019891
1328	EUR	MNT	4173.73229212	2026-01-06	2026-01-06 18:12:18.10694
1329	EUR	MOP	9.40115603	2026-01-06	2026-01-06 18:12:18.152526
1330	EUR	MRU	46.83842857	2026-01-06	2026-01-06 18:12:18.209782
1331	EUR	MUR	54.49791092	2026-01-06	2026-01-06 18:12:18.257341
1332	EUR	MVR	18.12470523	2026-01-06	2026-01-06 18:12:18.314704
1333	EUR	MWK	2029.39121438	2026-01-06	2026-01-06 18:12:18.357253
1334	EUR	MXN	20.99959692	2026-01-06	2026-01-06 18:12:18.422393
1335	EUR	MYR	4.75719573	2026-01-06	2026-01-06 18:12:18.486236
1336	EUR	MZN	74.9138124	2026-01-06	2026-01-06 18:12:18.530901
1337	EUR	NAD	19.16544576	2026-01-06	2026-01-06 18:12:18.587542
1338	EUR	NGN	1678.3511691	2026-01-06	2026-01-06 18:12:18.631629
1339	EUR	NIO	43.08588413	2026-01-06	2026-01-06 18:12:18.720537
1340	EUR	NOK	11.75543606	2026-01-06	2026-01-06 18:12:18.76152
1341	EUR	NPR	169.3034977	2026-01-06	2026-01-06 18:12:18.830035
1342	EUR	NZD	2.02345008	2026-01-06	2026-01-06 18:12:18.888004
1343	EUR	OMR	0.45125602	2026-01-06	2026-01-06 18:12:18.93553
1344	EUR	PAB	1.17241024	2026-01-06	2026-01-06 18:12:19.034655
1345	EUR	PEN	3.9373852	2026-01-06	2026-01-06 18:12:19.076959
1346	EUR	PGK	5.06135224	2026-01-06	2026-01-06 18:12:19.120802
1347	EUR	PHP	69.24919156	2026-01-06	2026-01-06 18:12:19.164336
1348	EUR	PKR	327.65582632	2026-01-06	2026-01-06 18:12:19.21869
1349	EUR	PLN	4.21267962	2026-01-06	2026-01-06 18:12:19.287047
1350	EUR	PYG	7712.78118104	2026-01-06	2026-01-06 18:12:19.328388
1351	EUR	QAR	4.26757328	2026-01-06	2026-01-06 18:12:19.420679
1352	EUR	RON	5.08880232	2026-01-06	2026-01-06 18:12:19.460752
1353	EUR	RSD	117.33427672	2026-01-06	2026-01-06 18:12:19.546554
1354	EUR	RUB	94.84093407	2026-01-06	2026-01-06 18:12:19.591396
1355	EUR	RWF	1704.45147968	2026-01-06	2026-01-06 18:12:19.628177
1356	EUR	SAR	4.3965384	2026-01-06	2026-01-06 18:12:19.687738
1357	EUR	SBD	9.54038718	2026-01-06	2026-01-06 18:12:19.731761
1358	EUR	SCR	17.05951989	2026-01-06	2026-01-06 18:12:19.812248
1359	EUR	SDG	703.47165287	2026-01-06	2026-01-06 18:12:19.901062
1360	EUR	SEK	10.74806189	2026-01-06	2026-01-06 18:12:19.962778
1361	EUR	SGD	1.50311467	2026-01-06	2026-01-06 18:12:20.00813
1362	EUR	SHP	0.86568462	2026-01-06	2026-01-06 18:12:20.076245
1363	EUR	SLE	26.79542549	2026-01-06	2026-01-06 18:12:20.141553
1364	EUR	SOS	669.30140052	2026-01-06	2026-01-06 18:12:20.210493
1365	EUR	SRD	44.85087188	2026-01-06	2026-01-06 18:12:20.269089
1366	EUR	SSP	5334.35762553	2026-01-06	2026-01-06 18:12:20.313067
1367	EUR	STN	24.72365455	2026-01-06	2026-01-06 18:12:20.362365
1368	EUR	SYP	12963.08294652	2026-01-06	2026-01-06 18:12:20.431984
1369	EUR	SZL	19.16544576	2026-01-06	2026-01-06 18:12:20.503001
1370	EUR	THB	36.61201197	2026-01-06	2026-01-06 18:12:20.551933
1371	EUR	TJS	10.81791746	2026-01-06	2026-01-06 18:12:20.643647
1372	EUR	TMT	4.11411889	2026-01-06	2026-01-06 18:12:20.68723
1373	EUR	TND	3.38775609	2026-01-06	2026-01-06 18:12:20.734507
1374	EUR	TOP	2.82364264	2026-01-06	2026-01-06 18:12:20.809933
1375	EUR	TRY	50.46777105	2026-01-06	2026-01-06 18:12:20.854467
1376	EUR	TTD	7.95298289	2026-01-06	2026-01-06 18:12:20.923928
1377	EUR	TVD	1.74614501	2026-01-06	2026-01-06 18:12:20.999001
1378	EUR	TWD	36.92860077	2026-01-06	2026-01-06 18:12:21.046111
1379	EUR	TZS	2907.21246863	2026-01-06	2026-01-06 18:12:21.116245
1380	EUR	UAH	49.72892647	2026-01-06	2026-01-06 18:12:21.159064
1381	EUR	UGX	4244.47045355	2026-01-06	2026-01-06 18:12:21.211182
1382	EUR	USD	1.17241024	2026-01-06	2026-01-06 18:12:21.269979
1383	EUR	UYU	45.61350931	2026-01-06	2026-01-06 18:12:21.337198
1384	EUR	UZS	14031.39741709	2026-01-06	2026-01-06 18:12:21.387316
1385	EUR	VES	355.93375457	2026-01-06	2026-01-06 18:12:21.434062
1386	EUR	VND	30806.50329867	2026-01-06	2026-01-06 18:12:21.516333
1387	EUR	VUV	141.77256792	2026-01-06	2026-01-06 18:12:21.557963
1388	EUR	WST	3.25940862	2026-01-06	2026-01-06 18:12:21.629513
1389	EUR	XAF	655.95699998	2026-01-06	2026-01-06 18:12:21.678403
1390	EUR	XCD	3.17271193	2026-01-06	2026-01-06 18:12:21.737211
1391	EUR	XDR	0.85758892	2026-01-06	2026-01-06 18:12:21.808364
1392	EUR	XOF	655.95699998	2026-01-06	2026-01-06 18:12:21.887495
1393	EUR	XPF	119.33174224	2026-01-06	2026-01-06 18:12:21.931462
1394	EUR	YER	279.58838251	2026-01-06	2026-01-06 18:12:22.003629
1395	EUR	ZAR	19.16544576	2026-01-06	2026-01-06 18:12:22.044758
1396	EUR	ZMW	24.77765198	2026-01-06	2026-01-06 18:12:22.128778
1397	EUR	ZWL	75706.75578906	2026-01-06	2026-01-06 18:12:22.171903
1398	EUR	AED	4.29723906	2026-01-08	2026-01-08 10:02:46.841046
1399	EUR	AFN	77.41516413	2026-01-08	2026-01-08 10:02:46.924163
1400	EUR	ALL	96.64958812	2026-01-08	2026-01-08 10:02:46.969205
1401	EUR	AMD	445.06029185	2026-01-08	2026-01-08 10:02:47.010703
1402	EUR	ANG	2.10974439	2026-01-08	2026-01-08 10:02:47.067772
1403	EUR	AOA	1073.82471858	2026-01-08	2026-01-08 10:02:47.11337
1404	EUR	ARS	1716.84098368	2026-01-08	2026-01-08 10:02:47.147235
1405	EUR	AUD	1.73350261	2026-01-08	2026-01-08 10:02:47.199525
1406	EUR	AWG	2.09450181	2026-01-08	2026-01-08 10:02:47.235272
1407	EUR	AZN	1.98919714	2026-01-08	2026-01-08 10:02:47.305052
1408	EUR	BAM	1.95583	2026-01-08	2026-01-08 10:02:47.34271
1409	EUR	BBD	2.34022549	2026-01-08	2026-01-08 10:02:47.403069
1410	EUR	BDT	143.08006303	2026-01-08	2026-01-08 10:02:47.441103
1411	EUR	BGN	1.95583	2026-01-08	2026-01-08 10:02:47.50445
1412	EUR	BHD	0.43996239	2026-01-08	2026-01-08 10:02:47.539837
1413	EUR	BIF	3463.96467527	2026-01-08	2026-01-08 10:02:47.601559
1414	EUR	BMD	1.17011274	2026-01-08	2026-01-08 10:02:47.643763
1415	EUR	BND	1.49902873	2026-01-08	2026-01-08 10:02:47.707771
1416	EUR	BOB	8.10376193	2026-01-08	2026-01-08 10:02:47.787428
1417	EUR	BRL	6.28690407	2026-01-08	2026-01-08 10:02:47.860445
1418	EUR	BSD	1.17011274	2026-01-08	2026-01-08 10:02:47.910631
1419	EUR	BTN	105.4932686	2026-01-08	2026-01-08 10:02:47.984601
1420	EUR	BWP	16.27274187	2026-01-08	2026-01-08 10:02:48.02111
1421	EUR	BYN	3.44099631	2026-01-08	2026-01-08 10:02:48.097739
1422	EUR	BZD	2.35599236	2026-01-08	2026-01-08 10:02:48.142633
1423	EUR	CAD	1.61681	2026-01-08	2026-01-08 10:02:48.209291
1424	EUR	CDF	2686.85245485	2026-01-08	2026-01-08 10:02:48.244488
1425	EUR	CHF	0.92989085	2026-01-08	2026-01-08 10:02:48.295789
1426	EUR	CLP	1046.07717405	2026-01-08	2026-01-08 10:02:48.391216
1427	EUR	CNH	8.17426437	2026-01-08	2026-01-08 10:02:48.47461
1428	EUR	CNY	8.17739186	2026-01-08	2026-01-08 10:02:48.514423
1429	EUR	COP	4348.35750907	2026-01-08	2026-01-08 10:02:48.55139
1430	EUR	CRC	581.83698176	2026-01-08	2026-01-08 10:02:48.591899
1431	EUR	CUP	28.06717565	2026-01-08	2026-01-08 10:02:48.64763
1432	EUR	CVE	110.27	2026-01-08	2026-01-08 10:02:48.722598
1433	EUR	CZK	24.17109527	2026-01-08	2026-01-08 10:02:48.754865
1434	EUR	DJF	208.36335624	2026-01-08	2026-01-08 10:02:48.795304
1435	EUR	DKK	7.47206215	2026-01-08	2026-01-08 10:02:48.836562
1436	EUR	DOP	74.17433476	2026-01-08	2026-01-08 10:02:48.894201
1437	EUR	DZD	151.95655902	2026-01-08	2026-01-08 10:02:48.935168
1438	EUR	EGP	55.29661798	2026-01-08	2026-01-08 10:02:48.989898
1439	EUR	ERN	17.55169117	2026-01-08	2026-01-08 10:02:49.025473
1440	EUR	ETB	181.47270768	2026-01-08	2026-01-08 10:02:49.084741
1441	EUR	FJD	2.65691913	2026-01-08	2026-01-08 10:02:49.121417
1442	EUR	FKP	0.86601139	2026-01-08	2026-01-08 10:02:49.166902
1443	EUR	GBP	0.86601139	2026-01-08	2026-01-08 10:02:49.243465
1444	EUR	GEL	3.15284775	2026-01-08	2026-01-08 10:02:49.291929
1445	EUR	GGP	0.86601139	2026-01-08	2026-01-08 10:02:49.372154
1446	EUR	GHS	12.44216931	2026-01-08	2026-01-08 10:02:49.406202
1447	EUR	GIP	0.86601139	2026-01-08	2026-01-08 10:02:49.451608
1448	EUR	GMD	86.3761454	2026-01-08	2026-01-08 10:02:49.50172
1449	EUR	GNF	10240.33499265	2026-01-08	2026-01-08 10:02:49.570236
1450	EUR	GTQ	8.97029605	2026-01-08	2026-01-08 10:02:49.611953
1451	EUR	GYD	245.01144851	2026-01-08	2026-01-08 10:02:49.650511
1452	EUR	HKD	9.11455848	2026-01-08	2026-01-08 10:02:49.692175
1453	EUR	HNL	30.88962643	2026-01-08	2026-01-08 10:02:49.754275
1454	EUR	HRK	7.5345	2026-01-08	2026-01-08 10:02:49.793941
1455	EUR	HTG	153.25386344	2026-01-08	2026-01-08 10:02:49.824765
1456	EUR	HUF	384.55559871	2026-01-08	2026-01-08 10:02:49.891367
1457	EUR	IDR	19621.58271332	2026-01-08	2026-01-08 10:02:49.930198
1458	EUR	ILS	3.70585853	2026-01-08	2026-01-08 10:02:49.985896
1459	EUR	IMP	0.86601139	2026-01-08	2026-01-08 10:02:50.02613
1460	EUR	INR	105.4932686	2026-01-08	2026-01-08 10:02:50.080297
1461	EUR	IQD	1533.4974818	2026-01-08	2026-01-08 10:02:50.117088
1462	EUR	IRR	49180.17982884	2026-01-08	2026-01-08 10:02:50.169503
1463	EUR	ISK	147.2083667	2026-01-08	2026-01-08 10:02:50.21522
1464	EUR	JEP	0.86601139	2026-01-08	2026-01-08 10:02:50.288404
1465	EUR	JMD	185.94248393	2026-01-08	2026-01-08 10:02:50.321655
1466	EUR	JOD	0.82960994	2026-01-08	2026-01-08 10:02:50.391282
1467	EUR	JPY	183.34284279	2026-01-08	2026-01-08 10:02:50.444232
1468	EUR	KES	151.07404846	2026-01-08	2026-01-08 10:02:50.482325
1469	EUR	KGS	102.32815756	2026-01-08	2026-01-08 10:02:50.526017
1470	EUR	KHR	4702.32285175	2026-01-08	2026-01-08 10:02:50.599801
1471	EUR	KMF	491.96774999	2026-01-08	2026-01-08 10:02:50.667719
1472	EUR	KRW	1695.35639663	2026-01-08	2026-01-08 10:02:50.703141
1473	EUR	KWD	0.35939784	2026-01-08	2026-01-08 10:02:50.750415
1474	EUR	KYD	0.97073893	2026-01-08	2026-01-08 10:02:50.80609
1475	EUR	KZT	596.21202839	2026-01-08	2026-01-08 10:02:50.844811
1476	EUR	LAK	25318.18589151	2026-01-08	2026-01-08 10:02:50.903552
1477	EUR	LBP	104808.76756293	2026-01-08	2026-01-08 10:02:50.94984
1478	EUR	LKR	363.02771116	2026-01-08	2026-01-08 10:02:50.991906
1479	EUR	LRD	208.49660942	2026-01-08	2026-01-08 10:02:51.027423
1480	EUR	LSL	19.13524257	2026-01-08	2026-01-08 10:02:51.092544
1481	EUR	LYD	6.33854873	2026-01-08	2026-01-08 10:02:51.152092
1482	EUR	MAD	10.74713958	2026-01-08	2026-01-08 10:02:51.190085
1483	EUR	MDL	19.75346347	2026-01-08	2026-01-08 10:02:51.232299
1484	EUR	MGA	5398.08291524	2026-01-08	2026-01-08 10:02:51.266841
1485	EUR	MKD	61.5980377	2026-01-08	2026-01-08 10:02:51.302624
1486	EUR	MMK	2456.78112597	2026-01-08	2026-01-08 10:02:51.354358
1487	EUR	MNT	4167.22146752	2026-01-08	2026-01-08 10:02:51.40458
1488	EUR	MOP	9.38799523	2026-01-08	2026-01-08 10:02:51.442825
1489	EUR	MRU	46.34200805	2026-01-08	2026-01-08 10:02:51.495361
1490	EUR	MUR	54.16051339	2026-01-08	2026-01-08 10:02:51.536123
1491	EUR	MVR	18.08985891	2026-01-08	2026-01-08 10:02:51.576034
1492	EUR	MWK	2030.2119612	2026-01-08	2026-01-08 10:02:51.618849
1493	EUR	MXN	21.03167427	2026-01-08	2026-01-08 10:02:51.652315
1494	EUR	MYR	4.73888698	2026-01-08	2026-01-08 10:02:51.692027
1495	EUR	MZN	74.76795051	2026-01-08	2026-01-08 10:02:51.726834
1496	EUR	NAD	19.13524257	2026-01-08	2026-01-08 10:02:51.760808
1497	EUR	NGN	1672.7850231	2026-01-08	2026-01-08 10:02:51.857224
1498	EUR	NIO	43.01397788	2026-01-08	2026-01-08 10:02:51.89368
1499	EUR	NOK	11.7494241	2026-01-08	2026-01-08 10:02:51.932274
1500	EUR	NPR	168.86834972	2026-01-08	2026-01-08 10:02:51.997534
1501	EUR	NZD	2.02113689	2026-01-08	2026-01-08 10:02:52.040422
1502	EUR	OMR	0.45024877	2026-01-08	2026-01-08 10:02:52.083888
1503	EUR	PAB	1.17011274	2026-01-08	2026-01-08 10:02:52.118715
1504	EUR	PEN	3.93606017	2026-01-08	2026-01-08 10:02:52.156637
1505	EUR	PGK	5.00131499	2026-01-08	2026-01-08 10:02:52.200343
1506	EUR	PHP	69.33397957	2026-01-08	2026-01-08 10:02:52.23285
1507	EUR	PKR	329.0466782	2026-01-08	2026-01-08 10:02:52.287853
1508	EUR	PLN	4.2109697	2026-01-08	2026-01-08 10:02:52.336173
1509	EUR	PYG	7690.19922061	2026-01-08	2026-01-08 10:02:52.387635
1510	EUR	QAR	4.25921039	2026-01-08	2026-01-08 10:02:52.424821
1511	EUR	RON	5.08923658	2026-01-08	2026-01-08 10:02:52.486557
1512	EUR	RSD	117.33285813	2026-01-08	2026-01-08 10:02:52.527103
1513	EUR	RUB	94.19546444	2026-01-08	2026-01-08 10:02:52.587851
1514	EUR	RWF	1704.61357553	2026-01-08	2026-01-08 10:02:52.620864
1515	EUR	SAR	4.38792279	2026-01-08	2026-01-08 10:02:52.692914
1516	EUR	SBD	9.48848146	2026-01-08	2026-01-08 10:02:52.731531
1517	EUR	SCR	16.40556149	2026-01-08	2026-01-08 10:02:52.804791
1518	EUR	SDG	701.97097214	2026-01-08	2026-01-08 10:02:52.88796
1519	EUR	SEK	10.75561256	2026-01-08	2026-01-08 10:02:52.92093
1520	EUR	SGD	1.49902873	2026-01-08	2026-01-08 10:02:52.991155
1521	EUR	SHP	0.86601139	2026-01-08	2026-01-08 10:02:53.035829
1522	EUR	SLE	26.73785147	2026-01-08	2026-01-08 10:02:53.114151
1523	EUR	SOS	658.85377241	2026-01-08	2026-01-08 10:02:53.155929
1524	EUR	SRD	44.844871	2026-01-08	2026-01-08 10:02:53.197205
1525	EUR	SSP	5326.78069758	2026-01-08	2026-01-08 10:02:53.23752
1526	EUR	STN	24.68632257	2026-01-08	2026-01-08 10:02:53.314775
1527	EUR	SYP	12940.9495385	2026-01-08	2026-01-08 10:02:53.36742
1528	EUR	SZL	19.13524257	2026-01-08	2026-01-08 10:02:53.408168
1529	EUR	THB	36.5713639	2026-01-08	2026-01-08 10:02:53.484264
1530	EUR	TJS	10.82686212	2026-01-08	2026-01-08 10:02:53.540316
1531	EUR	TMT	4.09088012	2026-01-08	2026-01-08 10:02:53.580177
1532	EUR	TND	3.38009689	2026-01-08	2026-01-08 10:02:53.62524
1533	EUR	TOP	2.79847214	2026-01-08	2026-01-08 10:02:53.668915
1534	EUR	TRY	50.38457248	2026-01-08	2026-01-08 10:02:53.704445
1535	EUR	TTD	7.94231278	2026-01-08	2026-01-08 10:02:53.742718
1536	EUR	TVD	1.73350261	2026-01-08	2026-01-08 10:02:53.801528
1537	EUR	TWD	36.85157762	2026-01-08	2026-01-08 10:02:53.83889
1538	EUR	TZS	2897.57590203	2026-01-08	2026-01-08 10:02:53.907484
1539	EUR	UAH	49.77773922	2026-01-08	2026-01-08 10:02:53.940148
1540	EUR	UGX	4239.48785208	2026-01-08	2026-01-08 10:02:53.99381
1541	EUR	USD	1.17011274	2026-01-08	2026-01-08 10:02:54.03
1542	EUR	UYU	45.56196677	2026-01-08	2026-01-08 10:02:54.09404
1543	EUR	UZS	14014.82028033	2026-01-08	2026-01-08 10:02:54.131339
1544	EUR	VES	361.43649445	2026-01-08	2026-01-08 10:02:54.1915
1545	EUR	VND	30797.95267265	2026-01-08	2026-01-08 10:02:54.23103
1546	EUR	VUV	141.22772651	2026-01-08	2026-01-08 10:02:54.286222
1547	EUR	WST	3.22101415	2026-01-08	2026-01-08 10:02:54.334272
1548	EUR	XAF	655.95699999	2026-01-08	2026-01-08 10:02:54.378756
1549	EUR	XCD	3.1666124	2026-01-08	2026-01-08 10:02:54.417118
1550	EUR	XDR	0.85492161	2026-01-08	2026-01-08 10:02:54.467582
1551	EUR	XOF	655.95699999	2026-01-08	2026-01-08 10:02:54.524302
1552	EUR	XPF	119.33174224	2026-01-08	2026-01-08 10:02:54.559526
1553	EUR	YER	278.94760325	2026-01-08	2026-01-08 10:02:54.623224
1554	EUR	ZAR	19.13524257	2026-01-08	2026-01-08 10:02:54.666191
1555	EUR	ZMW	24.55441555	2026-01-08	2026-01-08 10:02:54.707077
1556	EUR	ZWL	75675.98869827	2026-01-08	2026-01-08 10:02:54.774694
1557	EUR	AED	4.27818692	2026-01-10	2026-01-10 00:21:32.227829
1558	EUR	AFN	76.87927603	2026-01-10	2026-01-10 00:21:32.321264
1559	EUR	ALL	96.51202035	2026-01-10	2026-01-10 00:21:32.351144
1560	EUR	AMD	442.99000401	2026-01-10	2026-01-10 00:21:32.41812
1561	EUR	ANG	2.10213149	2026-01-10	2026-01-10 00:21:32.449267
1562	EUR	AOA	1069.33689548	2026-01-10	2026-01-10 00:21:32.520877
1563	EUR	ARS	1703.92780215	2026-01-10	2026-01-10 00:21:32.554093
1564	EUR	AUD	1.73984178	2026-01-10	2026-01-10 00:21:32.622836
1565	EUR	AWG	2.08521568	2026-01-10	2026-01-10 00:21:32.654856
1566	EUR	AZN	1.98037241	2026-01-10	2026-01-10 00:21:32.713021
1567	EUR	BAM	1.95583	2026-01-10	2026-01-10 00:21:32.755937
1568	EUR	BBD	2.32984992	2026-01-10	2026-01-10 00:21:32.830715
1569	EUR	BDT	142.55554031	2026-01-10	2026-01-10 00:21:32.874797
1570	EUR	BGN	1.95583	2026-01-10	2026-01-10 00:21:32.950075
1571	EUR	BHD	0.43801179	2026-01-10	2026-01-10 00:21:33.026532
1572	EUR	BIF	3455.42211695	2026-01-10	2026-01-10 00:21:33.103462
1573	EUR	BMD	1.16492496	2026-01-10	2026-01-10 00:21:33.145875
1574	EUR	BND	1.49812164	2026-01-10	2026-01-10 00:21:33.218626
1575	EUR	BOB	8.08237045	2026-01-10	2026-01-10 00:21:33.257948
1576	EUR	BRL	6.27684	2026-01-10	2026-01-10 00:21:33.333691
1577	EUR	BSD	1.16492496	2026-01-10	2026-01-10 00:21:33.376136
1578	EUR	BTN	104.70706556	2026-01-10	2026-01-10 00:21:33.442867
1579	EUR	BWP	15.92873604	2026-01-10	2026-01-10 00:21:33.518541
1580	EUR	BYN	3.4430241	2026-01-10	2026-01-10 00:21:33.553866
1581	EUR	BZD	2.34662245	2026-01-10	2026-01-10 00:21:33.620105
1582	EUR	CAD	1.61591516	2026-01-10	2026-01-10 00:21:33.65238
1583	EUR	CDF	2683.68210495	2026-01-10	2026-01-10 00:21:33.716629
1584	EUR	CHF	0.93188839	2026-01-10	2026-01-10 00:21:33.754797
1585	EUR	CLP	1045.1423807	2026-01-10	2026-01-10 00:21:33.870988
1586	EUR	CNH	8.13020529	2026-01-10	2026-01-10 00:21:33.941828
1587	EUR	CNY	8.13404439	2026-01-10	2026-01-10 00:21:33.970905
1588	EUR	COP	4327.62641734	2026-01-10	2026-01-10 00:21:34.028197
1589	EUR	CRC	579.59364168	2026-01-10	2026-01-10 00:21:34.08847
1590	EUR	CUP	27.99140766	2026-01-10	2026-01-10 00:21:34.181405
1591	EUR	CVE	110.27	2026-01-10	2026-01-10 00:21:34.232036
1592	EUR	CZK	24.27897956	2026-01-10	2026-01-10 00:21:34.264027
1593	EUR	DJF	207.51183697	2026-01-10	2026-01-10 00:21:34.311197
1594	EUR	DKK	7.47255105	2026-01-10	2026-01-10 00:21:34.345986
1595	EUR	DOP	74.05828284	2026-01-10	2026-01-10 00:21:34.416471
1596	EUR	DZD	151.47612195	2026-01-10	2026-01-10 00:21:34.455662
1597	EUR	EGP	55.03079109	2026-01-10	2026-01-10 00:21:34.50191
1598	EUR	ERN	17.47387443	2026-01-10	2026-01-10 00:21:34.534855
1599	EUR	ETB	181.62053112	2026-01-10	2026-01-10 00:21:34.595005
1600	EUR	FJD	2.65077312	2026-01-10	2026-01-10 00:21:34.631236
1601	EUR	FKP	0.86754	2026-01-10	2026-01-10 00:21:34.659644
1602	EUR	GBP	0.86754	2026-01-10	2026-01-10 00:21:34.764322
1603	EUR	GEL	3.1386158	2026-01-10	2026-01-10 00:21:34.820166
1604	EUR	GGP	0.86754	2026-01-10	2026-01-10 00:21:34.852097
1605	EUR	GHS	12.4904655	2026-01-10	2026-01-10 00:21:34.916673
1606	EUR	GIP	0.86754	2026-01-10	2026-01-10 00:21:34.951927
1607	EUR	GMD	86.04342057	2026-01-10	2026-01-10 00:21:35.019053
1608	EUR	GNF	10198.21777538	2026-01-10	2026-01-10 00:21:35.050349
1609	EUR	GTQ	8.93543089	2026-01-10	2026-01-10 00:21:35.124273
1610	EUR	GYD	243.99646963	2026-01-10	2026-01-10 00:21:35.155246
1611	EUR	HKD	9.07923314	2026-01-10	2026-01-10 00:21:35.222222
1612	EUR	HNL	30.73052666	2026-01-10	2026-01-10 00:21:35.252133
1613	EUR	HRK	7.5345	2026-01-10	2026-01-10 00:21:35.31993
1614	EUR	HTG	152.75495928	2026-01-10	2026-01-10 00:21:35.35288
1615	EUR	HUF	385.17718155	2026-01-10	2026-01-10 00:21:35.41217
1616	EUR	IDR	19603.77222404	2026-01-10	2026-01-10 00:21:35.447082
1617	EUR	ILS	3.69238055	2026-01-10	2026-01-10 00:21:35.515112
1618	EUR	IMP	0.86754	2026-01-10	2026-01-10 00:21:35.552837
1619	EUR	INR	104.70706556	2026-01-10	2026-01-10 00:21:35.62867
1620	EUR	IQD	1529.89228271	2026-01-10	2026-01-10 00:21:35.658493
1621	EUR	IRR	49070.04136882	2026-01-10	2026-01-10 00:21:35.720457
1622	EUR	ISK	147.19721498	2026-01-10	2026-01-10 00:21:35.754317
1623	EUR	JEP	0.86754	2026-01-10	2026-01-10 00:21:35.825014
1624	EUR	JMD	184.89351709	2026-01-10	2026-01-10 00:21:35.858374
1625	EUR	JOD	0.8259318	2026-01-10	2026-01-10 00:21:35.941836
1626	EUR	JPY	183.12608326	2026-01-10	2026-01-10 00:21:36.01429
1627	EUR	KES	150.57531628	2026-01-10	2026-01-10 00:21:36.048536
1628	EUR	KGS	101.8525802	2026-01-10	2026-01-10 00:21:36.113191
1629	EUR	KHR	4684.60110841	2026-01-10	2026-01-10 00:21:36.147718
1630	EUR	KMF	491.96775002	2026-01-10	2026-01-10 00:21:36.245488
1631	EUR	KRW	1694.53287815	2026-01-10	2026-01-10 00:21:36.322672
1632	EUR	KWD	0.35801217	2026-01-10	2026-01-10 00:21:36.354554
1633	EUR	KYD	0.96921511	2026-01-10	2026-01-10 00:21:36.413549
1634	EUR	KZT	594.68414578	2026-01-10	2026-01-10 00:21:36.456561
1635	EUR	LAK	25175.08373625	2026-01-10	2026-01-10 00:21:36.520122
1636	EUR	LBP	104761.40015358	2026-01-10	2026-01-10 00:21:36.550308
1637	EUR	LKR	360.87210352	2026-01-10	2026-01-10 00:21:36.612634
1638	EUR	LRD	208.97007221	2026-01-10	2026-01-10 00:21:36.644469
1639	EUR	LSL	19.25250175	2026-01-10	2026-01-10 00:21:36.711873
1640	EUR	LYD	6.32400617	2026-01-10	2026-01-10 00:21:36.740538
1641	EUR	MAD	10.75787858	2026-01-10	2026-01-10 00:21:36.812691
1642	EUR	MDL	19.54032476	2026-01-10	2026-01-10 00:21:36.847209
1643	EUR	MGA	5390.68696992	2026-01-10	2026-01-10 00:21:36.913217
1644	EUR	MKD	61.53540196	2026-01-10	2026-01-10 00:21:36.949072
1645	EUR	MMK	2445.97193043	2026-01-10	2026-01-10 00:21:37.01453
1646	EUR	MNT	4147.98685888	2026-01-10	2026-01-10 00:21:37.045408
1647	EUR	MOP	9.35161013	2026-01-10	2026-01-10 00:21:37.119173
1648	EUR	MRU	46.22804954	2026-01-10	2026-01-10 00:21:37.162824
1649	EUR	MUR	54.22304059	2026-01-10	2026-01-10 00:21:37.222659
1650	EUR	MVR	18.00481212	2026-01-10	2026-01-10 00:21:37.254506
1651	EUR	MWK	2023.24972653	2026-01-10	2026-01-10 00:21:37.322459
1652	EUR	MXN	20.95810357	2026-01-10	2026-01-10 00:21:37.360748
1653	EUR	MYR	4.73372252	2026-01-10	2026-01-10 00:21:37.431673
1654	EUR	MZN	74.43044718	2026-01-10	2026-01-10 00:21:37.468282
1655	EUR	NAD	19.25250175	2026-01-10	2026-01-10 00:21:37.518409
1656	EUR	NGN	1660.99992228	2026-01-10	2026-01-10 00:21:37.548866
1657	EUR	NIO	42.89510226	2026-01-10	2026-01-10 00:21:37.6349
1658	EUR	NOK	11.75949605	2026-01-10	2026-01-10 00:21:37.671522
1659	EUR	NPR	167.60983519	2026-01-10	2026-01-10 00:21:37.720762
1660	EUR	NZD	2.02839034	2026-01-10	2026-01-10 00:21:37.750246
1661	EUR	OMR	0.44836312	2026-01-10	2026-01-10 00:21:37.812202
1662	EUR	PAB	1.16492496	2026-01-10	2026-01-10 00:21:37.842121
1663	EUR	PEN	3.92048211	2026-01-10	2026-01-10 00:21:37.914789
1664	EUR	PGK	4.97776599	2026-01-10	2026-01-10 00:21:37.950548
1665	EUR	PHP	68.86712576	2026-01-10	2026-01-10 00:21:38.013973
1666	EUR	PKR	328.45775697	2026-01-10	2026-01-10 00:21:38.04291
1667	EUR	PLN	4.21258194	2026-01-10	2026-01-10 00:21:38.101136
1668	EUR	PYG	7651.17597133	2026-01-10	2026-01-10 00:21:38.13486
1669	EUR	QAR	4.24032686	2026-01-10	2026-01-10 00:21:38.201198
1670	EUR	RON	5.08747556	2026-01-10	2026-01-10 00:21:38.239082
1671	EUR	RSD	117.32091292	2026-01-10	2026-01-10 00:21:38.324367
1672	EUR	RUB	93.6230552	2026-01-10	2026-01-10 00:21:38.401433
1673	EUR	RWF	1698.49266158	2026-01-10	2026-01-10 00:21:38.435189
1674	EUR	SAR	4.36846861	2026-01-10	2026-01-10 00:21:38.467392
1675	EUR	SBD	9.47663853	2026-01-10	2026-01-10 00:21:38.545316
1676	EUR	SCR	14.73144475	2026-01-10	2026-01-10 00:21:38.601991
1677	EUR	SDG	698.88532164	2026-01-10	2026-01-10 00:21:38.636315
1678	EUR	SEK	10.7548927	2026-01-10	2026-01-10 00:21:38.664518
1679	EUR	SGD	1.49812164	2026-01-10	2026-01-10 00:21:38.734063
1680	EUR	SHP	0.86754	2026-01-10	2026-01-10 00:21:38.801525
1681	EUR	SLE	26.62441917	2026-01-10	2026-01-10 00:21:38.833542
1682	EUR	SOS	661.94689036	2026-01-10	2026-01-10 00:21:38.913633
1683	EUR	SRD	44.62284455	2026-01-10	2026-01-10 00:21:38.94921
1684	EUR	SSP	5305.85610864	2026-01-10	2026-01-10 00:21:39.02003
1685	EUR	STN	24.66542774	2026-01-10	2026-01-10 00:21:39.054459
1686	EUR	SYP	128.81940586	2026-01-10	2026-01-10 00:21:39.116663
1687	EUR	SZL	19.25250175	2026-01-10	2026-01-10 00:21:39.148298
1688	EUR	THB	36.64254341	2026-01-10	2026-01-10 00:21:39.200919
1689	EUR	TJS	10.84618795	2026-01-10	2026-01-10 00:21:39.231532
1690	EUR	TMT	4.08426224	2026-01-10	2026-01-10 00:21:39.264621
1691	EUR	TND	3.37924295	2026-01-10	2026-01-10 00:21:39.332268
1692	EUR	TOP	2.80569225	2026-01-10	2026-01-10 00:21:39.368186
1693	EUR	TRY	50.27283039	2026-01-10	2026-01-10 00:21:39.433943
1694	EUR	TTD	7.9132003	2026-01-10	2026-01-10 00:21:39.501776
1695	EUR	TVD	1.73984178	2026-01-10	2026-01-10 00:21:39.534131
1696	EUR	TWD	36.84353337	2026-01-10	2026-01-10 00:21:39.566383
1697	EUR	TZS	2903.034812	2026-01-10	2026-01-10 00:21:39.639497
1698	EUR	UAH	50.14491249	2026-01-10	2026-01-10 00:21:39.720837
1699	EUR	UGX	4192.2729871	2026-01-10	2026-01-10 00:21:39.754895
1700	EUR	USD	1.16492496	2026-01-10	2026-01-10 00:21:39.821739
1701	EUR	UYU	45.47877173	2026-01-10	2026-01-10 00:21:39.856948
1702	EUR	UZS	14061.0921689	2026-01-10	2026-01-10 00:21:39.923393
1703	EUR	VES	370.44797319	2026-01-10	2026-01-10 00:21:39.955855
1704	EUR	VND	30672.12059167	2026-01-10	2026-01-10 00:21:40.028616
1705	EUR	VUV	140.77397725	2026-01-10	2026-01-10 00:21:40.102226
1706	EUR	WST	3.23322893	2026-01-10	2026-01-10 00:21:40.137927
1707	EUR	XAF	655.95700002	2026-01-10	2026-01-10 00:21:40.214575
1708	EUR	XCD	3.15329197	2026-01-10	2026-01-10 00:21:40.24897
1709	EUR	XDR	0.85239491	2026-01-10	2026-01-10 00:21:40.313048
1710	EUR	XOF	655.95700002	2026-01-10	2026-01-10 00:21:40.347407
1711	EUR	XPF	119.33174225	2026-01-10	2026-01-10 00:21:40.415726
1712	EUR	YER	277.76590852	2026-01-10	2026-01-10 00:21:40.445496
1713	EUR	ZAR	19.25250175	2026-01-10	2026-01-10 00:21:40.517866
1714	EUR	ZMW	23.09316588	2026-01-10	2026-01-10 00:21:40.546324
1715	EUR	ZWL	74877.55311768	2026-01-10	2026-01-10 00:21:40.633221
1716	EUR	AED	4.2819269	2026-01-12	2026-01-12 16:02:23.397838
1717	EUR	AFN	76.95724479	2026-01-12	2026-01-12 16:02:23.487927
1718	EUR	ALL	96.65134173	2026-01-12	2026-01-12 16:02:23.533345
1719	EUR	AMD	444.14009074	2026-01-12	2026-01-12 16:02:23.609438
1720	EUR	ANG	2.09996113	2026-01-12	2026-01-12 16:02:23.696032
1721	EUR	AOA	1063.32629795	2026-01-12	2026-01-12 16:02:23.737319
1722	EUR	ARS	1704.40769921	2026-01-12	2026-01-12 16:02:23.8206
1723	EUR	AUD	1.74093168	2026-01-12	2026-01-12 16:02:23.894505
1724	EUR	AWG	2.08703857	2026-01-12	2026-01-12 16:02:23.931645
1725	EUR	AZN	1.98210367	2026-01-12	2026-01-12 16:02:24.015147
1726	EUR	BAM	1.95583	2026-01-12	2026-01-12 16:02:24.079841
1727	EUR	BBD	2.33188667	2026-01-12	2026-01-12 16:02:24.120625
1728	EUR	BDT	142.41236552	2026-01-12	2026-01-12 16:02:24.186375
1729	EUR	BGN	1.95583	2026-01-12	2026-01-12 16:02:24.229235
1730	EUR	BHD	0.43839469	2026-01-12	2026-01-12 16:02:24.331112
1731	EUR	BIF	3450.1568829	2026-01-12	2026-01-12 16:02:24.401984
1732	EUR	BMD	1.16594333	2026-01-12	2026-01-12 16:02:24.443475
1733	EUR	BND	1.49915243	2026-01-12	2026-01-12 16:02:24.505125
1734	EUR	BOB	8.06831568	2026-01-12	2026-01-12 16:02:24.554601
1735	EUR	BRL	6.28870806	2026-01-12	2026-01-12 16:02:24.602675
1736	EUR	BSD	1.16594333	2026-01-12	2026-01-12 16:02:24.676362
1737	EUR	BTN	105.23253946	2026-01-12	2026-01-12 16:02:24.720639
1738	EUR	BWP	16.05776753	2026-01-12	2026-01-12 16:02:24.801157
1739	EUR	BYN	3.4106848	2026-01-12	2026-01-12 16:02:24.886022
1740	EUR	BZD	2.34749525	2026-01-12	2026-01-12 16:02:24.928465
1741	EUR	CAD	1.61979719	2026-01-12	2026-01-12 16:02:24.978943
1742	EUR	CDF	2502.21042238	2026-01-12	2026-01-12 16:02:25.02127
1743	EUR	CHF	0.93099669	2026-01-12	2026-01-12 16:02:25.098444
1744	EUR	CLP	1044.06346092	2026-01-12	2026-01-12 16:02:25.190963
1745	EUR	CNH	8.13034478	2026-01-12	2026-01-12 16:02:25.286504
1746	EUR	CNY	8.13429272	2026-01-12	2026-01-12 16:02:25.324547
1747	EUR	COP	4330.54716242	2026-01-12	2026-01-12 16:02:25.403412
1748	EUR	CRC	579.66628775	2026-01-12	2026-01-12 16:02:25.486309
1749	EUR	CUP	27.95657001	2026-01-12	2026-01-12 16:02:25.530726
1750	EUR	CVE	110.27	2026-01-12	2026-01-12 16:02:25.604098
1751	EUR	CZK	24.25949313	2026-01-12	2026-01-12 16:02:25.698071
1752	EUR	DJF	207.5759168	2026-01-12	2026-01-12 16:02:25.752779
1753	EUR	DKK	7.47222388	2026-01-12	2026-01-12 16:02:25.805629
1754	EUR	DOP	73.98573473	2026-01-12	2026-01-12 16:02:25.888535
1755	EUR	DZD	151.80787215	2026-01-12	2026-01-12 16:02:25.930137
1756	EUR	EGP	55.15294243	2026-01-12	2026-01-12 16:02:25.99571
1757	EUR	ERN	17.48915002	2026-01-12	2026-01-12 16:02:26.081042
1758	EUR	ETB	181.20140322	2026-01-12	2026-01-12 16:02:26.125987
1759	EUR	FJD	2.65639903	2026-01-12	2026-01-12 16:02:26.195198
1760	EUR	FKP	0.86830971	2026-01-12	2026-01-12 16:02:26.2346
1761	EUR	GBP	0.86830971	2026-01-12	2026-01-12 16:02:26.320431
1762	EUR	GEL	3.14204594	2026-01-12	2026-01-12 16:02:26.407977
1763	EUR	GGP	0.86830971	2026-01-12	2026-01-12 16:02:26.480149
1764	EUR	GHS	12.50117716	2026-01-12	2026-01-12 16:02:26.51563
1765	EUR	GIP	0.86830971	2026-01-12	2026-01-12 16:02:26.603178
1766	EUR	GMD	86.11843254	2026-01-12	2026-01-12 16:02:26.645574
1767	EUR	GNF	10206.63457176	2026-01-12	2026-01-12 16:02:26.704812
1768	EUR	GTQ	8.93799095	2026-01-12	2026-01-12 16:02:26.786024
1769	EUR	GYD	243.67508049	2026-01-12	2026-01-12 16:02:26.824839
1770	EUR	HKD	9.08859723	2026-01-12	2026-01-12 16:02:26.892298
1771	EUR	HNL	30.81011884	2026-01-12	2026-01-12 16:02:26.929145
1772	EUR	HRK	7.5345	2026-01-12	2026-01-12 16:02:26.988539
1773	EUR	HTG	152.68638233	2026-01-12	2026-01-12 16:02:27.042051
1774	EUR	HUF	386.05816759	2026-01-12	2026-01-12 16:02:27.100537
1775	EUR	IDR	19645.87932972	2026-01-12	2026-01-12 16:02:27.180196
1776	EUR	ILS	3.66928129	2026-01-12	2026-01-12 16:02:27.229485
1777	EUR	IMP	0.86830971	2026-01-12	2026-01-12 16:02:27.305679
1778	EUR	INR	105.23253946	2026-01-12	2026-01-12 16:02:27.383149
1779	EUR	IQD	1526.98135072	2026-01-12	2026-01-12 16:02:27.425349
1780	EUR	IRR	1163270.86292144	2026-01-12	2026-01-12 16:02:27.490341
1781	EUR	ISK	147.2041025	2026-01-12	2026-01-12 16:02:27.564634
1782	EUR	JEP	0.86830971	2026-01-12	2026-01-12 16:02:27.60568
1783	EUR	JMD	184.54908417	2026-01-12	2026-01-12 16:02:27.681159
1784	EUR	JOD	0.82665382	2026-01-12	2026-01-12 16:02:27.721552
1785	EUR	JPY	183.97105551	2026-01-12	2026-01-12 16:02:27.78913
1786	EUR	KES	150.27778177	2026-01-12	2026-01-12 16:02:27.829403
1787	EUR	KGS	101.93466016	2026-01-12	2026-01-12 16:02:27.900768
1788	EUR	KHR	4687.23164201	2026-01-12	2026-01-12 16:02:27.94642
1789	EUR	KMF	491.96775001	2026-01-12	2026-01-12 16:02:28.06487
1790	EUR	KRW	1705.28861459	2026-01-12	2026-01-12 16:02:28.109305
1791	EUR	KWD	0.3578565	2026-01-12	2026-01-12 16:02:28.165564
1792	EUR	KYD	0.96884178	2026-01-12	2026-01-12 16:02:28.206427
1793	EUR	KZT	595.32419702	2026-01-12	2026-01-12 16:02:28.276903
1794	EUR	LAK	25171.71381721	2026-01-12	2026-01-12 16:02:28.3172
1795	EUR	LBP	104459.34757372	2026-01-12	2026-01-12 16:02:28.368293
1796	EUR	LKR	360.22204597	2026-01-12	2026-01-12 16:02:28.419491
1797	EUR	LRD	209.22117582	2026-01-12	2026-01-12 16:02:28.522812
1798	EUR	LSL	19.1994233	2026-01-12	2026-01-12 16:02:28.564923
1799	EUR	LYD	6.32145734	2026-01-12	2026-01-12 16:02:28.60757
1800	EUR	MAD	10.77643163	2026-01-12	2026-01-12 16:02:28.685542
1801	EUR	MDL	19.55668377	2026-01-12	2026-01-12 16:02:28.728147
1802	EUR	MGA	5371.64718465	2026-01-12	2026-01-12 16:02:28.803876
1803	EUR	MKD	61.59547032	2026-01-12	2026-01-12 16:02:28.842654
1804	EUR	MMK	2448.30305798	2026-01-12	2026-01-12 16:02:28.90846
1805	EUR	MNT	4152.20330066	2026-01-12	2026-01-12 16:02:28.966092
1806	EUR	MOP	9.36125515	2026-01-12	2026-01-12 16:02:29.006907
1807	EUR	MRU	46.30702478	2026-01-12	2026-01-12 16:02:29.092822
1808	EUR	MUR	54.45256425	2026-01-12	2026-01-12 16:02:29.132311
1809	EUR	MVR	18.02535339	2026-01-12	2026-01-12 16:02:29.200822
1810	EUR	MWK	2020.53388786	2026-01-12	2026-01-12 16:02:29.258377
1811	EUR	MXN	20.92026945	2026-01-12	2026-01-12 16:02:29.313069
1812	EUR	MYR	4.74365959	2026-01-12	2026-01-12 16:02:29.364574
1813	EUR	MZN	74.50839813	2026-01-12	2026-01-12 16:02:29.443592
1814	EUR	NAD	19.1994233	2026-01-12	2026-01-12 16:02:29.480798
1815	EUR	NGN	1661.0187077	2026-01-12	2026-01-12 16:02:29.519929
1816	EUR	NIO	42.88505474	2026-01-12	2026-01-12 16:02:29.59385
1817	EUR	NOK	11.75634043	2026-01-12	2026-01-12 16:02:29.637423
1818	EUR	NPR	168.45098755	2026-01-12	2026-01-12 16:02:29.689371
1819	EUR	NZD	2.02939769	2026-01-12	2026-01-12 16:02:29.730974
1820	EUR	OMR	0.44895396	2026-01-12	2026-01-12 16:02:29.799241
1821	EUR	PAB	1.16594333	2026-01-12	2026-01-12 16:02:29.891717
1822	EUR	PEN	3.91808701	2026-01-12	2026-01-12 16:02:29.941674
1823	EUR	PGK	4.97259101	2026-01-12	2026-01-12 16:02:29.998627
1824	EUR	PHP	69.07371351	2026-01-12	2026-01-12 16:02:30.065401
1825	EUR	PKR	326.18429874	2026-01-12	2026-01-12 16:02:30.105723
1826	EUR	PLN	4.2122504	2026-01-12	2026-01-12 16:02:30.185661
1827	EUR	PYG	7706.8829768	2026-01-12	2026-01-12 16:02:30.231394
1828	EUR	QAR	4.24403374	2026-01-12	2026-01-12 16:02:30.291582
1829	EUR	RON	5.09061927	2026-01-12	2026-01-12 16:02:30.344941
1830	EUR	RSD	117.35942675	2026-01-12	2026-01-12 16:02:30.401871
1831	EUR	RUB	92.55378855	2026-01-12	2026-01-12 16:02:30.477015
1832	EUR	RWF	1698.5115687	2026-01-12	2026-01-12 16:02:30.525395
1833	EUR	SAR	4.37228751	2026-01-12	2026-01-12 16:02:30.5773
1834	EUR	SBD	9.45317256	2026-01-12	2026-01-12 16:02:30.628405
1835	EUR	SCR	16.28808536	2026-01-12	2026-01-12 16:02:30.685701
1836	EUR	SDG	699.63793594	2026-01-12	2026-01-12 16:02:30.733512
1837	EUR	SEK	10.71467091	2026-01-12	2026-01-12 16:02:30.798144
1838	EUR	SGD	1.49915243	2026-01-12	2026-01-12 16:02:30.852142
1839	EUR	SHP	0.86830971	2026-01-12	2026-01-12 16:02:30.898034
1840	EUR	SLE	26.59519105	2026-01-12	2026-01-12 16:02:30.93633
1841	EUR	SOS	663.61376195	2026-01-12	2026-01-12 16:02:31.011307
1842	EUR	SRD	44.39255016	2026-01-12	2026-01-12 16:02:31.085715
1843	EUR	SSP	5314.41798451	2026-01-12	2026-01-12 16:02:31.12848
1844	EUR	STN	24.67614062	2026-01-12	2026-01-12 16:02:31.195375
1845	EUR	SYP	128.92644533	2026-01-12	2026-01-12 16:02:31.248108
1846	EUR	SZL	19.1994233	2026-01-12	2026-01-12 16:02:31.296919
1847	EUR	THB	36.4926279	2026-01-12	2026-01-12 16:02:31.337016
1848	EUR	TJS	10.85690446	2026-01-12	2026-01-12 16:02:31.400567
1849	EUR	TMT	4.07888447	2026-01-12	2026-01-12 16:02:31.435626
1850	EUR	TND	3.41642583	2026-01-12	2026-01-12 16:02:31.503707
1851	EUR	TOP	2.79445651	2026-01-12	2026-01-12 16:02:31.586281
1852	EUR	TRY	50.30213222	2026-01-12	2026-01-12 16:02:31.622063
1853	EUR	TTD	7.91448238	2026-01-12	2026-01-12 16:02:31.705232
1854	EUR	TVD	1.74093168	2026-01-12	2026-01-12 16:02:31.765981
1855	EUR	TWD	36.89177787	2026-01-12	2026-01-12 16:02:31.809072
1856	EUR	TZS	2910.77325896	2026-01-12	2026-01-12 16:02:31.893074
1857	EUR	UAH	50.30436463	2026-01-12	2026-01-12 16:02:31.935223
1858	EUR	UGX	4196.85647349	2026-01-12	2026-01-12 16:02:31.999925
1859	EUR	USD	1.16594333	2026-01-12	2026-01-12 16:02:32.08662
1860	EUR	UYU	45.3551315	2026-01-12	2026-01-12 16:02:32.15891
1861	EUR	UZS	14115.10255874	2026-01-12	2026-01-12 16:02:32.201085
1862	EUR	VES	381.8832179	2026-01-12	2026-01-12 16:02:32.268062
1863	EUR	VND	30615.64364642	2026-01-12	2026-01-12 16:02:32.309073
1864	EUR	VUV	140.08031104	2026-01-12	2026-01-12 16:02:32.370941
1865	EUR	WST	3.22659692	2026-01-12	2026-01-12 16:02:32.425011
1866	EUR	XAF	655.95700002	2026-01-12	2026-01-12 16:02:32.465688
1867	EUR	XCD	3.1563281	2026-01-12	2026-01-12 16:02:32.505758
1868	EUR	XDR	0.85430651	2026-01-12	2026-01-12 16:02:32.598219
1869	EUR	XOF	655.95700002	2026-01-12	2026-01-12 16:02:32.632386
1870	EUR	XPF	119.33174225	2026-01-12	2026-01-12 16:02:32.701268
1871	EUR	YER	277.9591195	2026-01-12	2026-01-12 16:02:32.742547
1872	EUR	ZAR	19.1994233	2026-01-12	2026-01-12 16:02:32.815694
1873	EUR	ZMW	22.67625164	2026-01-12	2026-01-12 16:02:32.878507
1874	EUR	ZWL	75059.54941587	2026-01-12	2026-01-12 16:02:32.919815
1875	EUR	AED	4.2819269	2026-01-13	2026-01-13 00:26:14.743102
1876	EUR	AFN	76.95724479	2026-01-13	2026-01-13 00:26:14.786873
1877	EUR	ALL	96.65134173	2026-01-13	2026-01-13 00:26:14.868951
1878	EUR	AMD	444.14009074	2026-01-13	2026-01-13 00:26:14.946482
1879	EUR	ANG	2.09996113	2026-01-13	2026-01-13 00:26:14.973818
1880	EUR	AOA	1063.32629795	2026-01-13	2026-01-13 00:26:15.072806
1881	EUR	ARS	1704.40769921	2026-01-13	2026-01-13 00:26:15.142345
1882	EUR	AUD	1.74093168	2026-01-13	2026-01-13 00:26:15.165227
1883	EUR	AWG	2.08703857	2026-01-13	2026-01-13 00:26:15.19475
1884	EUR	AZN	1.98210367	2026-01-13	2026-01-13 00:26:15.265914
1885	EUR	BAM	1.95583	2026-01-13	2026-01-13 00:26:15.352067
1886	EUR	BBD	2.33188667	2026-01-13	2026-01-13 00:26:15.378022
1887	EUR	BDT	142.41236552	2026-01-13	2026-01-13 00:26:15.464457
1888	EUR	BGN	1.95583	2026-01-13	2026-01-13 00:26:15.486148
1889	EUR	BHD	0.43839469	2026-01-13	2026-01-13 00:26:15.565127
1890	EUR	BIF	3450.1568829	2026-01-13	2026-01-13 00:26:15.587494
1891	EUR	BMD	1.16594333	2026-01-13	2026-01-13 00:26:15.652006
1892	EUR	BND	1.49915243	2026-01-13	2026-01-13 00:26:15.675155
1893	EUR	BOB	8.06831568	2026-01-13	2026-01-13 00:26:15.754068
1894	EUR	BRL	6.28870806	2026-01-13	2026-01-13 00:26:15.775882
1895	EUR	BSD	1.16594333	2026-01-13	2026-01-13 00:26:15.859736
1896	EUR	BTN	105.23253946	2026-01-13	2026-01-13 00:26:15.945358
1897	EUR	BWP	16.05776753	2026-01-13	2026-01-13 00:26:15.967638
1898	EUR	BYN	3.4106848	2026-01-13	2026-01-13 00:26:16.044097
1899	EUR	BZD	2.34749525	2026-01-13	2026-01-13 00:26:16.06817
1900	EUR	CAD	1.61979719	2026-01-13	2026-01-13 00:26:16.150602
1901	EUR	CDF	2502.21042238	2026-01-13	2026-01-13 00:26:16.175235
1902	EUR	CHF	0.93099669	2026-01-13	2026-01-13 00:26:16.262981
1903	EUR	CLP	1044.06346092	2026-01-13	2026-01-13 00:26:16.358666
1904	EUR	CNH	8.13034478	2026-01-13	2026-01-13 00:26:16.379916
1905	EUR	CNY	8.13429272	2026-01-13	2026-01-13 00:26:16.464698
1906	EUR	COP	4330.54716242	2026-01-13	2026-01-13 00:26:16.545877
1907	EUR	CRC	579.66628775	2026-01-13	2026-01-13 00:26:16.579064
1908	EUR	CUP	27.95657001	2026-01-13	2026-01-13 00:26:16.659681
1909	EUR	CVE	110.27	2026-01-13	2026-01-13 00:26:16.684658
1910	EUR	CZK	24.25949313	2026-01-13	2026-01-13 00:26:16.759548
1911	EUR	DJF	207.5759168	2026-01-13	2026-01-13 00:26:16.8464
1912	EUR	DKK	7.47222388	2026-01-13	2026-01-13 00:26:16.872273
1913	EUR	DOP	73.98573473	2026-01-13	2026-01-13 00:26:16.953673
1914	EUR	DZD	151.80787215	2026-01-13	2026-01-13 00:26:16.978475
1915	EUR	EGP	55.15294243	2026-01-13	2026-01-13 00:26:17.06493
1916	EUR	ERN	17.48915002	2026-01-13	2026-01-13 00:26:17.148322
1917	EUR	ETB	181.20140322	2026-01-13	2026-01-13 00:26:17.170983
1918	EUR	FJD	2.65639903	2026-01-13	2026-01-13 00:26:17.246837
1919	EUR	FKP	0.86830971	2026-01-13	2026-01-13 00:26:17.270963
1920	EUR	GBP	0.86830971	2026-01-13	2026-01-13 00:26:17.451887
1921	EUR	GEL	3.14204594	2026-01-13	2026-01-13 00:26:17.475498
1922	EUR	GGP	0.86830971	2026-01-13	2026-01-13 00:26:17.554725
1923	EUR	GHS	12.50117716	2026-01-13	2026-01-13 00:26:17.643921
1924	EUR	GIP	0.86830971	2026-01-13	2026-01-13 00:26:17.667805
1925	EUR	GMD	86.11843254	2026-01-13	2026-01-13 00:26:17.751719
1926	EUR	GNF	10206.63457176	2026-01-13	2026-01-13 00:26:17.777737
1927	EUR	GTQ	8.93799095	2026-01-13	2026-01-13 00:26:17.864708
1928	EUR	GYD	243.67508049	2026-01-13	2026-01-13 00:26:17.946602
1929	EUR	HKD	9.08859723	2026-01-13	2026-01-13 00:26:17.973627
1930	EUR	HNL	30.81011884	2026-01-13	2026-01-13 00:26:18.058121
1931	EUR	HRK	7.5345	2026-01-13	2026-01-13 00:26:18.145477
1932	EUR	HTG	152.68638233	2026-01-13	2026-01-13 00:26:18.183305
1933	EUR	HUF	386.05816759	2026-01-13	2026-01-13 00:26:18.250437
1934	EUR	IDR	19645.87932972	2026-01-13	2026-01-13 00:26:18.277171
1935	EUR	ILS	3.66928129	2026-01-13	2026-01-13 00:26:18.357314
1936	EUR	IMP	0.86830971	2026-01-13	2026-01-13 00:26:18.442753
1937	EUR	INR	105.23253946	2026-01-13	2026-01-13 00:26:18.467493
1938	EUR	IQD	1526.98135072	2026-01-13	2026-01-13 00:26:18.552217
1939	EUR	IRR	1163270.86292144	2026-01-13	2026-01-13 00:26:18.580245
1940	EUR	ISK	147.2041025	2026-01-13	2026-01-13 00:26:18.650996
1941	EUR	JEP	0.86830971	2026-01-13	2026-01-13 00:26:18.748046
1942	EUR	JMD	184.54908417	2026-01-13	2026-01-13 00:26:18.772696
1943	EUR	JOD	0.82665382	2026-01-13	2026-01-13 00:26:18.856081
1944	EUR	JPY	183.97105551	2026-01-13	2026-01-13 00:26:18.881262
1945	EUR	KES	150.27778177	2026-01-13	2026-01-13 00:26:18.961075
1946	EUR	KGS	101.93466016	2026-01-13	2026-01-13 00:26:19.041927
1947	EUR	KHR	4687.23164201	2026-01-13	2026-01-13 00:26:19.073099
1948	EUR	KMF	491.96775001	2026-01-13	2026-01-13 00:26:19.171099
1949	EUR	KRW	1705.28861459	2026-01-13	2026-01-13 00:26:19.26228
1950	EUR	KWD	0.3578565	2026-01-13	2026-01-13 00:26:19.35122
1951	EUR	KYD	0.96884178	2026-01-13	2026-01-13 00:26:19.376771
1952	EUR	KZT	595.32419702	2026-01-13	2026-01-13 00:26:19.453492
1953	EUR	LAK	25171.71381721	2026-01-13	2026-01-13 00:26:19.477131
1954	EUR	LBP	104459.34757372	2026-01-13	2026-01-13 00:26:19.565254
1955	EUR	LKR	360.22204597	2026-01-13	2026-01-13 00:26:19.645175
1956	EUR	LRD	209.22117582	2026-01-13	2026-01-13 00:26:19.668959
1957	EUR	LSL	19.1994233	2026-01-13	2026-01-13 00:26:19.754773
1958	EUR	LYD	6.32145734	2026-01-13	2026-01-13 00:26:19.778651
1959	EUR	MAD	10.77643163	2026-01-13	2026-01-13 00:26:19.866095
1960	EUR	MDL	19.55668377	2026-01-13	2026-01-13 00:26:19.953902
1961	EUR	MGA	5371.64718465	2026-01-13	2026-01-13 00:26:19.979472
1962	EUR	MKD	61.59547032	2026-01-13	2026-01-13 00:26:20.060459
1963	EUR	MMK	2448.30305798	2026-01-13	2026-01-13 00:26:20.142804
1964	EUR	MNT	4152.20330066	2026-01-13	2026-01-13 00:26:20.168883
1965	EUR	MOP	9.36125515	2026-01-13	2026-01-13 00:26:20.247132
1966	EUR	MRU	46.30702478	2026-01-13	2026-01-13 00:26:20.269409
1967	EUR	MUR	54.45256425	2026-01-13	2026-01-13 00:26:20.352417
1968	EUR	MVR	18.02535339	2026-01-13	2026-01-13 00:26:20.376055
1969	EUR	MWK	2020.53388786	2026-01-13	2026-01-13 00:26:20.453069
1970	EUR	MXN	20.92026945	2026-01-13	2026-01-13 00:26:20.542225
1971	EUR	MYR	4.74365959	2026-01-13	2026-01-13 00:26:20.570635
1972	EUR	MZN	74.50839813	2026-01-13	2026-01-13 00:26:20.654018
1973	EUR	NAD	19.1994233	2026-01-13	2026-01-13 00:26:20.679962
1974	EUR	NGN	1661.0187077	2026-01-13	2026-01-13 00:26:20.761091
1975	EUR	NIO	42.88505474	2026-01-13	2026-01-13 00:26:20.781117
1976	EUR	NOK	11.75634043	2026-01-13	2026-01-13 00:26:20.864255
1977	EUR	NPR	168.45098755	2026-01-13	2026-01-13 00:26:20.944862
1978	EUR	NZD	2.02939769	2026-01-13	2026-01-13 00:26:20.968696
1979	EUR	OMR	0.44895396	2026-01-13	2026-01-13 00:26:21.050307
1980	EUR	PAB	1.16594333	2026-01-13	2026-01-13 00:26:21.071217
1981	EUR	PEN	3.91808701	2026-01-13	2026-01-13 00:26:21.093414
1982	EUR	PGK	4.97259101	2026-01-13	2026-01-13 00:26:21.242934
1983	EUR	PHP	69.07371351	2026-01-13	2026-01-13 00:26:21.265655
1984	EUR	PKR	326.18429874	2026-01-13	2026-01-13 00:26:21.444395
1985	EUR	PLN	4.2122504	2026-01-13	2026-01-13 00:26:21.646005
1986	EUR	PYG	7706.8829768	2026-01-13	2026-01-13 00:26:22.053196
1987	EUR	QAR	4.24403374	2026-01-13	2026-01-13 00:26:22.168842
1988	EUR	RON	5.09061927	2026-01-13	2026-01-13 00:26:22.343119
1989	EUR	RSD	117.35942675	2026-01-13	2026-01-13 00:26:22.4706
1990	EUR	RUB	92.55378855	2026-01-13	2026-01-13 00:26:22.653332
1991	EUR	RWF	1698.5115687	2026-01-13	2026-01-13 00:26:22.75268
1992	EUR	SAR	4.37228751	2026-01-13	2026-01-13 00:26:22.856939
1993	EUR	SBD	9.45317256	2026-01-13	2026-01-13 00:26:22.961486
1994	EUR	SCR	16.28808536	2026-01-13	2026-01-13 00:26:23.069959
1995	EUR	SDG	699.63793594	2026-01-13	2026-01-13 00:26:23.242111
1996	EUR	SEK	10.71467091	2026-01-13	2026-01-13 00:26:23.36368
1998	EUR	SGD	1.49915243	2026-01-13	2026-01-13 00:26:23.566454
2000	EUR	SHP	0.86830971	2026-01-13	2026-01-13 00:26:23.643193
2001	EUR	SLE	26.59519105	2026-01-13	2026-01-13 00:26:23.943769
2003	EUR	SOS	663.61376195	2026-01-13	2026-01-13 00:26:24.158584
2005	EUR	SRD	44.39255016	2026-01-13	2026-01-13 00:26:24.442444
2007	EUR	SSP	5314.41798451	2026-01-13	2026-01-13 00:26:24.543127
2009	EUR	STN	24.67614062	2026-01-13	2026-01-13 00:26:24.743472
2011	EUR	SYP	128.92644533	2026-01-13	2026-01-13 00:26:25.042093
2013	EUR	SZL	19.1994233	2026-01-13	2026-01-13 00:26:25.342091
2015	EUR	THB	36.4926279	2026-01-13	2026-01-13 00:26:25.641982
2017	EUR	TJS	10.85690446	2026-01-13	2026-01-13 00:26:25.857752
2019	EUR	TMT	4.07888447	2026-01-13	2026-01-13 00:26:26.241967
2021	EUR	TND	3.41642583	2026-01-13	2026-01-13 00:26:26.555571
2023	EUR	TOP	2.79445651	2026-01-13	2026-01-13 00:26:27.042906
2025	EUR	TRY	50.30213222	2026-01-13	2026-01-13 00:26:27.162729
2027	EUR	TTD	7.91448238	2026-01-13	2026-01-13 00:26:27.742765
2029	EUR	TVD	1.74093168	2026-01-13	2026-01-13 00:26:27.942153
2031	EUR	TWD	36.89177787	2026-01-13	2026-01-13 00:26:28.155192
2033	EUR	TZS	2910.77325896	2026-01-13	2026-01-13 00:26:28.34198
2035	EUR	UAH	50.30436463	2026-01-13	2026-01-13 00:26:28.542156
2037	EUR	UGX	4196.85647349	2026-01-13	2026-01-13 00:26:28.767269
2039	EUR	USD	1.16594333	2026-01-13	2026-01-13 00:26:28.769852
2040	EUR	UYU	45.3551315	2026-01-13	2026-01-13 00:26:29.043198
2042	EUR	UZS	14115.10255874	2026-01-13	2026-01-13 00:26:29.156612
2044	EUR	VES	381.8832179	2026-01-13	2026-01-13 00:26:29.273766
2046	EUR	VND	30615.64364642	2026-01-13	2026-01-13 00:26:29.443263
2048	EUR	VUV	140.08031104	2026-01-13	2026-01-13 00:26:29.654501
2050	EUR	WST	3.22659692	2026-01-13	2026-01-13 00:26:29.763245
2052	EUR	XAF	655.95700002	2026-01-13	2026-01-13 00:26:29.865338
2054	EUR	XCD	3.1563281	2026-01-13	2026-01-13 00:26:30.061843
2056	EUR	XDR	0.85430651	2026-01-13	2026-01-13 00:26:30.161175
2058	EUR	XOF	655.95700002	2026-01-13	2026-01-13 00:26:30.262883
2060	EUR	XPF	119.33174225	2026-01-13	2026-01-13 00:26:30.441981
2062	EUR	YER	277.9591195	2026-01-13	2026-01-13 00:26:30.37171
2063	EUR	ZAR	19.1994233	2026-01-13	2026-01-13 00:26:30.542863
2065	EUR	ZMW	22.67625164	2026-01-13	2026-01-13 00:26:30.641946
2067	EUR	ZWL	75059.54941587	2026-01-13	2026-01-13 00:26:30.761629
2069	EUR	AED	4.27423046	2026-01-15	2026-01-15 23:45:16.601257
2070	EUR	AFN	76.10589477	2026-01-15	2026-01-15 23:45:16.887935
2071	EUR	ALL	96.48596338	2026-01-15	2026-01-15 23:45:17.094536
2072	EUR	AMD	440.38163558	2026-01-15	2026-01-15 23:45:17.384981
2073	EUR	ANG	2.09836231	2026-01-15	2026-01-15 23:45:17.601
2074	EUR	AOA	1067.76736776	2026-01-15	2026-01-15 23:45:17.796248
2075	EUR	ARS	1691.74769523	2026-01-15	2026-01-15 23:45:18.092283
2076	EUR	AUD	1.74257908	2026-01-15	2026-01-15 23:45:18.297222
2077	EUR	AWG	2.08328727	2026-01-15	2026-01-15 23:45:18.588993
2078	EUR	AZN	1.9785409	2026-01-15	2026-01-15 23:45:19.069623
2079	EUR	BAM	1.95583	2026-01-15	2026-01-15 23:45:19.682576
2080	EUR	BBD	2.32769528	2026-01-15	2026-01-15 23:45:20.269438
2082	EUR	BDT	142.3069019	2026-01-15	2026-01-15 23:45:21.170481
2084	EUR	BGN	1.95583	2026-01-15	2026-01-15 23:45:22.070576
2087	EUR	BIF	3447.68678264	2026-01-15	2026-01-15 23:45:23.869012
2086	EUR	BHD	0.43760671	2026-01-15	2026-01-15 23:45:23.87083
2172	EUR	FKP	0.86642818	2026-01-15	2026-01-15 23:45:52.96801
2089	EUR	BMD	1.16384764	2026-01-15	2026-01-15 23:45:26.369959
2091	EUR	BND	1.49867438	2026-01-15	2026-01-15 23:45:26.46895
2123	EUR	CLP	1026.35062798	2026-01-15	2026-01-15 23:45:37.668416
2094	EUR	BOB	8.05522871	2026-01-15	2026-01-15 23:45:27.468633
2097	EUR	BRL	6.2816148	2026-01-15	2026-01-15 23:45:28.570739
2144	EUR	CZK	24.25042572	2026-01-15	2026-01-15 23:45:44.269471
2100	EUR	BSD	1.16384764	2026-01-15	2026-01-15 23:45:29.770567
2102	EUR	BTN	105.04315024	2026-01-15	2026-01-15 23:45:30.270095
2126	EUR	CNH	8.10614146	2026-01-15	2026-01-15 23:45:38.568516
2105	EUR	BWP	16.00378171	2026-01-15	2026-01-15 23:45:31.269249
2108	EUR	BYN	3.38140386	2026-01-15	2026-01-15 23:45:32.169543
2111	EUR	BZD	2.34374121	2026-01-15	2026-01-15 23:45:33.170441
2129	EUR	CNY	8.11002929	2026-01-15	2026-01-15 23:45:39.169834
2114	EUR	CAD	1.61656414	2026-01-15	2026-01-15 23:45:34.068933
2117	EUR	CDF	2652.02032736	2026-01-15	2026-01-15 23:45:35.070186
2160	EUR	DZD	151.34314487	2026-01-15	2026-01-15 23:45:48.567748
2120	EUR	CHF	0.93082887	2026-01-15	2026-01-15 23:45:35.970658
2132	EUR	COP	4276.88581497	2026-01-15	2026-01-15 23:45:40.170234
2135	EUR	CRC	576.88690149	2026-01-15	2026-01-15 23:45:41.068207
2149	EUR	DJF	207.28582544	2026-01-15	2026-01-15 23:45:45.070187
2138	EUR	CUP	27.95100973	2026-01-15	2026-01-15 23:45:42.16898
2163	EUR	EGP	55.05954484	2026-01-15	2026-01-15 23:45:49.570896
2141	EUR	CVE	110.27	2026-01-15	2026-01-15 23:45:43.270221
2165	EUR	ERN	17.45771459	2026-01-15	2026-01-15 23:45:50.568998
2153	EUR	DKK	7.47201841	2026-01-15	2026-01-15 23:45:46.069873
2157	EUR	DOP	74.15282693	2026-01-15	2026-01-15 23:45:47.167817
2167	EUR	ETB	181.25772081	2026-01-15	2026-01-15 23:45:51.468301
2169	EUR	FJD	2.65246786	2026-01-15	2026-01-15 23:45:52.270472
2173	EUR	GBP	0.86642818	2026-01-15	2026-01-15 23:45:54.08748
2174	EUR	GEL	3.13524782	2026-01-15	2026-01-15 23:45:54.288148
2175	EUR	GGP	0.86642818	2026-01-15	2026-01-15 23:45:54.48919
2176	EUR	GHS	12.55063505	2026-01-15	2026-01-15 23:45:54.790511
2177	EUR	GIP	0.86642818	2026-01-15	2026-01-15 23:45:54.994144
2178	EUR	GMD	85.65998795	2026-01-15	2026-01-15 23:45:55.190491
2179	EUR	GNF	10190.39967813	2026-01-15	2026-01-15 23:45:55.389079
2180	EUR	GTQ	8.92483739	2026-01-15	2026-01-15 23:45:55.591131
2181	EUR	GYD	243.61424006	2026-01-15	2026-01-15 23:45:55.795865
2182	EUR	HKD	9.07360556	2026-01-15	2026-01-15 23:45:55.99363
2183	EUR	HNL	30.77841095	2026-01-15	2026-01-15 23:45:56.191184
2184	EUR	HRK	7.5345	2026-01-15	2026-01-15 23:45:56.393124
2185	EUR	HTG	152.61134513	2026-01-15	2026-01-15 23:45:56.667868
2186	EUR	HUF	386.43395593	2026-01-15	2026-01-15 23:45:56.885734
2187	EUR	IDR	19621.43847312	2026-01-15	2026-01-15 23:45:57.087078
2188	EUR	ILS	3.67245006	2026-01-15	2026-01-15 23:45:57.288476
2189	EUR	IMP	0.86642818	2026-01-15	2026-01-15 23:45:57.488967
2190	EUR	INR	105.04315024	2026-01-15	2026-01-15 23:45:57.786173
2191	EUR	IQD	1525.43328243	2026-01-15	2026-01-15 23:45:58.071205
2192	EUR	IRR	1241319.90434728	2026-01-15	2026-01-15 23:45:58.370406
2193	EUR	ISK	146.00035552	2026-01-15	2026-01-15 23:45:58.593005
2194	EUR	JEP	0.86642818	2026-01-15	2026-01-15 23:45:58.797092
2195	EUR	JMD	183.92377286	2026-01-15	2026-01-15 23:45:58.985055
2196	EUR	JOD	0.82516798	2026-01-15	2026-01-15 23:45:59.187813
2197	EUR	JPY	184.29976917	2026-01-15	2026-01-15 23:45:59.388258
2198	EUR	KES	150.20365218	2026-01-15	2026-01-15 23:45:59.593864
2199	EUR	KGS	101.77510639	2026-01-15	2026-01-15 23:45:59.790074
2200	EUR	KHR	4692.83571803	2026-01-15	2026-01-15 23:46:00.092557
2201	EUR	KMF	491.96774999	2026-01-15	2026-01-15 23:46:00.486455
2202	EUR	KRW	1710.32083798	2026-01-15	2026-01-15 23:46:00.688793
2203	EUR	KWD	0.35795623	2026-01-15	2026-01-15 23:46:00.900326
2204	EUR	KYD	0.96803189	2026-01-15	2026-01-15 23:46:01.092459
2205	EUR	KZT	594.49670828	2026-01-15	2026-01-15 23:46:01.303799
2206	EUR	LAK	25147.386215	2026-01-15	2026-01-15 23:46:01.592815
2207	EUR	LBP	104614.58584786	2026-01-15	2026-01-15 23:46:01.80291
2208	EUR	LKR	360.36833712	2026-01-15	2026-01-15 23:46:02.003551
2209	EUR	LRD	209.76583082	2026-01-15	2026-01-15 23:46:02.280458
2210	EUR	LSL	19.09171267	2026-01-15	2026-01-15 23:46:02.492128
2211	EUR	LYD	6.32593617	2026-01-15	2026-01-15 23:46:02.693114
2212	EUR	MAD	10.7249292	2026-01-15	2026-01-15 23:46:02.996407
2213	EUR	MDL	19.85896614	2026-01-15	2026-01-15 23:46:03.268971
2214	EUR	MGA	5397.69727374	2026-01-15	2026-01-15 23:46:03.481306
2215	EUR	MKD	61.52663593	2026-01-15	2026-01-15 23:46:03.695179
2216	EUR	MMK	2443.86079403	2026-01-15	2026-01-15 23:46:03.990773
2217	EUR	MNT	4147.8136955	2026-01-15	2026-01-15 23:46:04.188402
2218	EUR	MOP	9.34581373	2026-01-15	2026-01-15 23:46:04.482779
2219	EUR	MRU	46.43789784	2026-01-15	2026-01-15 23:46:04.68919
2220	EUR	MUR	53.70760461	2026-01-15	2026-01-15 23:46:04.880766
2221	EUR	MVR	17.9916806	2026-01-15	2026-01-15 23:46:05.082769
2222	EUR	MWK	2018.87937232	2026-01-15	2026-01-15 23:46:05.282814
2223	EUR	MXN	20.71283221	2026-01-15	2026-01-15 23:46:05.484579
2224	EUR	MYR	4.71263536	2026-01-15	2026-01-15 23:46:05.702724
2225	EUR	MZN	74.36604591	2026-01-15	2026-01-15 23:46:05.901536
2226	EUR	NAD	19.09171267	2026-01-15	2026-01-15 23:46:06.095763
2227	EUR	NGN	1655.98879956	2026-01-15	2026-01-15 23:46:06.293654
2228	EUR	NIO	42.8402173	2026-01-15	2026-01-15 23:46:06.56811
2229	EUR	NOK	11.71377686	2026-01-15	2026-01-15 23:46:06.788747
2230	EUR	NPR	168.14782274	2026-01-15	2026-01-15 23:46:06.992719
2231	EUR	NZD	2.02846047	2026-01-15	2026-01-15 23:46:07.189326
2232	EUR	OMR	0.44788004	2026-01-15	2026-01-15 23:46:07.387418
2233	EUR	PAB	1.16384764	2026-01-15	2026-01-15 23:46:07.596175
2234	EUR	PEN	3.91158547	2026-01-15	2026-01-15 23:46:07.793456
2235	EUR	PGK	4.96873981	2026-01-15	2026-01-15 23:46:07.997609
2236	EUR	PHP	69.16524936	2026-01-15	2026-01-15 23:46:08.381242
2237	EUR	PKR	325.95994353	2026-01-15	2026-01-15 23:46:08.668459
2238	EUR	PLN	4.21118509	2026-01-15	2026-01-15 23:46:08.885393
2239	EUR	PYG	7709.81515782	2026-01-15	2026-01-15 23:46:09.170133
2240	EUR	QAR	4.23640541	2026-01-15	2026-01-15 23:46:09.396018
2241	EUR	RON	5.08829437	2026-01-15	2026-01-15 23:46:09.699307
2242	EUR	RSD	117.35019859	2026-01-15	2026-01-15 23:46:09.995417
2243	EUR	RUB	91.36000354	2026-01-15	2026-01-15 23:48:57.572041
2244	EUR	RWF	1697.54063751	2026-01-15	2026-01-15 23:48:57.776824
2245	EUR	SAR	4.36442865	2026-01-15	2026-01-15 23:48:57.978932
2246	EUR	SBD	9.45159057	2026-01-15	2026-01-15 23:48:58.182219
2247	EUR	SCR	16.65371965	2026-01-15	2026-01-15 23:48:58.477849
2248	EUR	SDG	698.11762519	2026-01-15	2026-01-15 23:48:58.688062
2249	EUR	SEK	10.70736616	2026-01-15	2026-01-15 23:48:58.96899
2250	EUR	SGD	1.49867438	2026-01-15	2026-01-15 23:48:59.1874
2251	EUR	SHP	0.86642818	2026-01-15	2026-01-15 23:48:59.481985
2252	EUR	SLE	26.72787843	2026-01-15	2026-01-15 23:48:59.780617
2253	EUR	SOS	660.8008188	2026-01-15	2026-01-15 23:49:00.07325
2254	EUR	SRD	44.60625197	2026-01-15	2026-01-15 23:49:00.281893
2255	EUR	SSP	5293.07892932	2026-01-15	2026-01-15 23:49:00.481436
2256	EUR	STN	24.66952623	2026-01-15	2026-01-15 23:49:00.683397
2257	EUR	SYP	128.73476434	2026-01-15	2026-01-15 23:49:00.969601
2258	EUR	SZL	19.09171267	2026-01-15	2026-01-15 23:49:01.17798
2259	EUR	THB	36.64930113	2026-01-15	2026-01-15 23:49:01.382601
2260	EUR	TJS	10.83020916	2026-01-15	2026-01-15 23:49:01.588508
2261	EUR	TMT	4.08092692	2026-01-15	2026-01-15 23:49:01.879503
2262	EUR	TND	3.36504987	2026-01-15	2026-01-15 23:49:02.079863
2263	EUR	TOP	2.79252556	2026-01-15	2026-01-15 23:49:02.282073
2264	EUR	TRY	50.25748126	2026-01-15	2026-01-15 23:49:02.487656
2265	EUR	TTD	7.90311928	2026-01-15	2026-01-15 23:49:02.768652
2266	EUR	TVD	1.74257908	2026-01-15	2026-01-15 23:49:02.976996
2267	EUR	TWD	36.72716938	2026-01-15	2026-01-15 23:49:03.185178
2268	EUR	TZS	2917.37260505	2026-01-15	2026-01-15 23:49:03.569146
2269	EUR	UAH	50.44682232	2026-01-15	2026-01-15 23:49:03.776628
2270	EUR	UGX	4143.51493058	2026-01-15	2026-01-15 23:49:03.977152
2271	EUR	USD	1.16384764	2026-01-15	2026-01-15 23:49:04.176154
2272	EUR	UYU	45.1019236	2026-01-15	2026-01-15 23:49:04.380798
2273	EUR	UZS	13996.32886923	2026-01-15	2026-01-15 23:49:04.581675
2274	EUR	VES	393.78529449	2026-01-15	2026-01-15 23:49:04.779434
2275	EUR	VND	30634.67886302	2026-01-15	2026-01-15 23:49:04.980092
2276	EUR	VUV	140.9211507	2026-01-15	2026-01-15 23:49:05.178505
2277	EUR	WST	3.22366478	2026-01-15	2026-01-15 23:49:05.380102
2278	EUR	XAF	655.95699999	2026-01-15	2026-01-15 23:49:05.590289
2279	EUR	XCD	3.14938427	2026-01-15	2026-01-15 23:49:05.78542
2280	EUR	XDR	0.85271827	2026-01-15	2026-01-15 23:49:06.077373
2281	EUR	XOF	655.95699999	2026-01-15	2026-01-15 23:49:06.276911
2282	EUR	XPF	119.33174224	2026-01-15	2026-01-15 23:49:06.469884
2283	EUR	YER	277.48725254	2026-01-15	2026-01-15 23:49:06.775817
2284	EUR	ZAR	19.09171267	2026-01-15	2026-01-15 23:49:06.983913
2285	EUR	ZMW	22.98343558	2026-01-15	2026-01-15 23:49:07.184929
2286	EUR	ZWL	74745.27400061	2026-01-15	2026-01-15 23:49:07.476418
2287	EUR	AED	4.27423046	2026-01-16	2026-01-16 09:06:11.86812
2288	EUR	AFN	76.10589477	2026-01-16	2026-01-16 09:06:12.087907
2289	EUR	ALL	96.48596338	2026-01-16	2026-01-16 09:06:12.369528
2290	EUR	AMD	440.38163558	2026-01-16	2026-01-16 09:06:12.589472
2291	EUR	ANG	2.09836231	2026-01-16	2026-01-16 09:06:12.792957
2292	EUR	AOA	1067.76736776	2026-01-16	2026-01-16 09:06:13.068195
2293	EUR	ARS	1691.74769523	2026-01-16	2026-01-16 09:06:13.268119
2294	EUR	AUD	1.74257908	2026-01-16	2026-01-16 09:06:13.469444
2295	EUR	AWG	2.08328727	2026-01-16	2026-01-16 09:06:13.688918
2296	EUR	AZN	1.9785409	2026-01-16	2026-01-16 09:06:13.892646
2297	EUR	BAM	1.95583	2026-01-16	2026-01-16 09:06:14.167875
2298	EUR	BBD	2.32769528	2026-01-16	2026-01-16 09:06:14.395236
2299	EUR	BDT	142.3069019	2026-01-16	2026-01-16 09:06:14.692883
2300	EUR	BGN	1.95583	2026-01-16	2026-01-16 09:06:14.894539
2301	EUR	BHD	0.43760671	2026-01-16	2026-01-16 09:06:15.193559
2302	EUR	BIF	3447.68678264	2026-01-16	2026-01-16 09:06:15.469322
2303	EUR	BMD	1.16384764	2026-01-16	2026-01-16 09:06:15.702784
2304	EUR	BND	1.49867438	2026-01-16	2026-01-16 09:06:15.995217
2305	EUR	BOB	8.05522871	2026-01-16	2026-01-16 09:06:16.293539
2306	EUR	BRL	6.2816148	2026-01-16	2026-01-16 09:06:16.592433
2307	EUR	BSD	1.16384764	2026-01-16	2026-01-16 09:06:16.871186
2308	EUR	BTN	105.04315024	2026-01-16	2026-01-16 09:06:17.17201
2309	EUR	BWP	16.00378171	2026-01-16	2026-01-16 09:06:17.489546
2310	EUR	BYN	3.38140386	2026-01-16	2026-01-16 09:06:17.787528
2311	EUR	BZD	2.34374121	2026-01-16	2026-01-16 09:06:18.069724
2312	EUR	CAD	1.61656414	2026-01-16	2026-01-16 09:06:18.368985
2313	EUR	CDF	2652.02032736	2026-01-16	2026-01-16 09:06:18.599345
2314	EUR	CHF	0.93082887	2026-01-16	2026-01-16 09:06:18.884179
2315	EUR	CLP	1026.35062798	2026-01-16	2026-01-16 09:06:19.395295
2316	EUR	CNH	8.10614146	2026-01-16	2026-01-16 09:06:19.679079
2317	EUR	CNY	8.11002929	2026-01-16	2026-01-16 09:06:19.885491
2318	EUR	COP	4276.88581497	2026-01-16	2026-01-16 09:06:20.179754
2319	EUR	CRC	576.88690149	2026-01-16	2026-01-16 09:06:20.469764
2320	EUR	CUP	27.95100973	2026-01-16	2026-01-16 09:06:20.695541
2321	EUR	CVE	110.27	2026-01-16	2026-01-16 09:06:20.983192
2322	EUR	CZK	24.25042572	2026-01-16	2026-01-16 09:06:21.195658
2323	EUR	DJF	207.28582544	2026-01-16	2026-01-16 09:06:21.492002
2324	EUR	DKK	7.47201841	2026-01-16	2026-01-16 09:06:21.784485
2325	EUR	DOP	74.15282693	2026-01-16	2026-01-16 09:06:22.069512
2326	EUR	DZD	151.34314487	2026-01-16	2026-01-16 09:06:22.296192
2327	EUR	EGP	55.05954484	2026-01-16	2026-01-16 09:06:22.593174
2328	EUR	ERN	17.45771459	2026-01-16	2026-01-16 09:06:22.789848
2329	EUR	ETB	181.25772081	2026-01-16	2026-01-16 09:06:23.094188
2330	EUR	FJD	2.65246786	2026-01-16	2026-01-16 09:06:23.299872
2331	EUR	FKP	0.86642818	2026-01-16	2026-01-16 09:06:23.58668
2332	EUR	GBP	0.86642818	2026-01-16	2026-01-16 09:06:24.069821
2333	EUR	GEL	3.13524782	2026-01-16	2026-01-16 09:06:24.302496
2334	EUR	GGP	0.86642818	2026-01-16	2026-01-16 09:06:24.582997
2335	EUR	GHS	12.55063505	2026-01-16	2026-01-16 09:06:24.78777
2336	EUR	GIP	0.86642818	2026-01-16	2026-01-16 09:06:25.069399
2337	EUR	GMD	85.65998795	2026-01-16	2026-01-16 09:06:25.291374
2338	EUR	GNF	10190.39967813	2026-01-16	2026-01-16 09:06:25.592566
2339	EUR	GTQ	8.92483739	2026-01-16	2026-01-16 09:06:25.870103
2340	EUR	GYD	243.61424006	2026-01-16	2026-01-16 09:06:26.182745
2341	EUR	HKD	9.07360556	2026-01-16	2026-01-16 09:06:26.390928
2342	EUR	HNL	30.77841095	2026-01-16	2026-01-16 09:06:26.667798
2343	EUR	HRK	7.5345	2026-01-16	2026-01-16 09:06:26.86948
2344	EUR	HTG	152.61134513	2026-01-16	2026-01-16 09:06:27.091233
2345	EUR	HUF	386.43395593	2026-01-16	2026-01-16 09:06:27.291604
2346	EUR	IDR	19621.43847312	2026-01-16	2026-01-16 09:06:28.171689
2347	EUR	ILS	3.67245006	2026-01-16	2026-01-16 09:06:28.486652
2348	EUR	IMP	0.86642818	2026-01-16	2026-01-16 09:06:28.971325
2349	EUR	INR	105.04315024	2026-01-16	2026-01-16 09:06:29.467537
2350	EUR	IQD	1525.43328243	2026-01-16	2026-01-16 09:06:29.977598
2352	EUR	ISK	146.00035552	2026-01-16	2026-01-16 09:06:31.469917
2351	EUR	IRR	1241319.90434728	2026-01-16	2026-01-16 09:06:31.669333
2354	EUR	JEP	0.86642818	2026-01-16	2026-01-16 09:06:32.670281
2356	EUR	JMD	183.92377286	2026-01-16	2026-01-16 09:06:33.86925
2358	EUR	JOD	0.82516798	2026-01-16	2026-01-16 09:06:34.770876
2360	EUR	JPY	184.29976917	2026-01-16	2026-01-16 09:06:35.769569
2362	EUR	KES	150.20365218	2026-01-16	2026-01-16 09:06:36.570764
2364	EUR	KGS	101.77510639	2026-01-16	2026-01-16 09:06:37.571667
2366	EUR	KHR	4692.83571803	2026-01-16	2026-01-16 09:06:38.269388
2368	EUR	KMF	491.96774999	2026-01-16	2026-01-16 09:06:39.870335
2370	EUR	KRW	1710.32083798	2026-01-16	2026-01-16 09:06:40.669258
2372	EUR	KWD	0.35795623	2026-01-16	2026-01-16 09:06:41.368892
2374	EUR	KYD	0.96803189	2026-01-16	2026-01-16 09:06:41.782544
2376	EUR	KZT	594.49670828	2026-01-16	2026-01-16 09:06:42.368876
2378	EUR	LAK	25147.386215	2026-01-16	2026-01-16 09:06:42.869285
2379	EUR	LBP	104614.58584786	2026-01-16	2026-01-16 09:06:43.47949
2380	EUR	LKR	360.36833712	2026-01-16	2026-01-16 09:06:43.698156
2381	EUR	LRD	209.76583082	2026-01-16	2026-01-16 09:06:43.893653
2382	EUR	LSL	19.09171267	2026-01-16	2026-01-16 09:06:44.18427
2383	EUR	LYD	6.32593617	2026-01-16	2026-01-16 09:06:44.398409
2384	EUR	MAD	10.7249292	2026-01-16	2026-01-16 09:06:44.669651
2385	EUR	MDL	19.85896614	2026-01-16	2026-01-16 09:06:44.885175
2386	EUR	MGA	5397.69727374	2026-01-16	2026-01-16 09:06:45.094866
2387	EUR	MKD	61.52663593	2026-01-16	2026-01-16 09:06:45.38389
2388	EUR	MMK	2443.86079403	2026-01-16	2026-01-16 09:06:45.667907
2389	EUR	MNT	4147.8136955	2026-01-16	2026-01-16 09:06:45.888932
2390	EUR	MOP	9.34581373	2026-01-16	2026-01-16 09:06:46.182723
2391	EUR	MRU	46.43789784	2026-01-16	2026-01-16 09:06:46.384991
2392	EUR	MUR	53.70760461	2026-01-16	2026-01-16 09:06:46.587958
2393	EUR	MVR	17.9916806	2026-01-16	2026-01-16 09:06:46.794149
2394	EUR	MWK	2018.87937232	2026-01-16	2026-01-16 09:06:47.000483
2395	EUR	MXN	20.71283221	2026-01-16	2026-01-16 09:06:47.202944
2396	EUR	MYR	4.71263536	2026-01-16	2026-01-16 09:06:47.479658
2397	EUR	MZN	74.36604591	2026-01-16	2026-01-16 09:06:47.690817
2398	EUR	NAD	19.09171267	2026-01-16	2026-01-16 09:06:47.892838
2399	EUR	NGN	1655.98879956	2026-01-16	2026-01-16 09:06:48.189325
2400	EUR	NIO	42.8402173	2026-01-16	2026-01-16 09:06:48.389643
2401	EUR	NOK	11.71377686	2026-01-16	2026-01-16 09:06:48.668199
2402	EUR	NPR	168.14782274	2026-01-16	2026-01-16 09:06:48.969828
2403	EUR	NZD	2.02846047	2026-01-16	2026-01-16 09:06:49.18963
2404	EUR	OMR	0.44788004	2026-01-16	2026-01-16 09:06:49.485369
2405	EUR	PAB	1.16384764	2026-01-16	2026-01-16 09:06:49.768847
2406	EUR	PEN	3.91158547	2026-01-16	2026-01-16 09:06:50.00015
2407	EUR	PGK	4.96873981	2026-01-16	2026-01-16 09:06:50.293896
2408	EUR	PHP	69.16524936	2026-01-16	2026-01-16 09:06:50.668272
2409	EUR	PKR	325.95994353	2026-01-16	2026-01-16 09:06:50.891424
2410	EUR	PLN	4.21118509	2026-01-16	2026-01-16 09:06:51.18705
2411	EUR	PYG	7709.81515782	2026-01-16	2026-01-16 09:06:51.389132
2412	EUR	QAR	4.23640541	2026-01-16	2026-01-16 09:06:51.596736
2413	EUR	RON	5.08829437	2026-01-16	2026-01-16 09:06:51.895818
2414	EUR	RSD	117.35019859	2026-01-16	2026-01-16 09:06:52.096322
2415	EUR	RUB	91.36000354	2026-01-16	2026-01-16 09:06:52.370204
2416	EUR	RWF	1697.54063751	2026-01-16	2026-01-16 09:06:52.679931
2417	EUR	SAR	4.36442865	2026-01-16	2026-01-16 09:06:52.890234
2418	EUR	SBD	9.45159057	2026-01-16	2026-01-16 09:06:53.181954
2419	EUR	SCR	16.65371965	2026-01-16	2026-01-16 09:06:53.469283
2420	EUR	SDG	698.11762519	2026-01-16	2026-01-16 09:06:53.688586
2421	EUR	SEK	10.70736616	2026-01-16	2026-01-16 09:06:53.970417
2422	EUR	SGD	1.49867438	2026-01-16	2026-01-16 09:06:54.195118
2423	EUR	SHP	0.86642818	2026-01-16	2026-01-16 09:06:54.482806
2424	EUR	SLE	26.72787843	2026-01-16	2026-01-16 09:06:54.68584
2425	EUR	SOS	660.8008188	2026-01-16	2026-01-16 09:06:54.97902
2426	EUR	SRD	44.60625197	2026-01-16	2026-01-16 09:06:55.268047
2427	EUR	SSP	5293.07892932	2026-01-16	2026-01-16 09:06:55.487987
2428	EUR	STN	24.66952623	2026-01-16	2026-01-16 09:06:55.688626
2429	EUR	SYP	128.73476434	2026-01-16	2026-01-16 09:06:55.88786
2430	EUR	SZL	19.09171267	2026-01-16	2026-01-16 09:06:56.167766
2431	EUR	THB	36.64930113	2026-01-16	2026-01-16 09:06:56.379139
2432	EUR	TJS	10.83020916	2026-01-16	2026-01-16 09:06:56.580004
2433	EUR	TMT	4.08092692	2026-01-16	2026-01-16 09:06:56.794665
2434	EUR	TND	3.36504987	2026-01-16	2026-01-16 09:06:57.086773
2435	EUR	TOP	2.79252556	2026-01-16	2026-01-16 09:06:57.286854
2436	EUR	TRY	50.25748126	2026-01-16	2026-01-16 09:06:57.494083
2437	EUR	TTD	7.90311928	2026-01-16	2026-01-16 09:06:57.691653
2438	EUR	TVD	1.74257908	2026-01-16	2026-01-16 09:06:57.893754
2439	EUR	TWD	36.72716938	2026-01-16	2026-01-16 09:06:58.194909
8540	EUR	AED	4.35999173	2026-01-26	2026-01-27 09:41:53.599704
2441	EUR	TZS	2917.37260505	2026-01-16	2026-01-16 09:11:45.979702
2442	EUR	UAH	50.44682232	2026-01-16	2026-01-16 09:11:46.279402
2443	EUR	UGX	4143.51493058	2026-01-16	2026-01-16 09:11:46.60429
2444	EUR	USD	1.16384764	2026-01-16	2026-01-16 09:11:46.882557
2445	EUR	UYU	45.1019236	2026-01-16	2026-01-16 09:11:47.179346
2446	EUR	UZS	13996.32886923	2026-01-16	2026-01-16 09:11:47.477633
2447	EUR	VES	393.78529449	2026-01-16	2026-01-16 09:11:47.693571
2448	EUR	VND	30484.3456163	2026-01-16	2026-01-16 09:11:47.887212
2449	EUR	VUV	140.9211507	2026-01-16	2026-01-16 09:11:48.183675
2450	EUR	WST	3.22366478	2026-01-16	2026-01-16 09:11:48.476898
2451	EUR	XAF	655.95699999	2026-01-16	2026-01-16 09:11:48.684262
2452	EUR	XCD	3.14938427	2026-01-16	2026-01-16 09:11:48.976153
2453	EUR	XDR	0.85271827	2026-01-16	2026-01-16 09:11:49.183396
2454	EUR	XOF	655.95699999	2026-01-16	2026-01-16 09:11:49.482861
2455	EUR	XPF	119.33174224	2026-01-16	2026-01-16 09:11:49.683764
2456	EUR	YER	277.48725254	2026-01-16	2026-01-16 09:11:49.979565
2457	EUR	ZAR	19.09171267	2026-01-16	2026-01-16 09:11:50.269738
2458	EUR	ZMW	22.98343558	2026-01-16	2026-01-16 09:11:50.484741
2459	EUR	ZWL	74745.27400061	2026-01-16	2026-01-16 09:11:50.789779
2460	EUR	AED	4.26223585	2026-01-18	2026-01-18 21:24:03.86405
2461	AED	EUR	0.2346186450475283	2026-01-18	2026-01-18 21:24:03.885413
2462	EUR	AFN	77.17038231	2026-01-18	2026-01-18 21:24:03.896844
2463	AFN	EUR	0.012958339327423763	2026-01-18	2026-01-18 21:24:03.907444
2464	EUR	ALL	96.52939277	2026-01-18	2026-01-18 21:24:03.916668
2465	ALL	EUR	0.010359538906275874	2026-01-18	2026-01-18 21:24:03.92637
2466	EUR	AMD	441.01184201	2026-01-18	2026-01-18 21:24:03.970082
2467	AMD	EUR	0.0022675128074618116	2026-01-18	2026-01-18 21:24:03.980043
2468	EUR	ANG	2.08565071	2026-01-18	2026-01-18 21:24:03.989715
2469	ANG	EUR	0.47946666966109586	2026-01-18	2026-01-18 21:24:03.998815
2470	EUR	AOA	1059.17667626	2026-01-18	2026-01-18 21:24:04.008238
2471	AOA	EUR	0.0009441295512010748	2026-01-18	2026-01-18 21:24:04.062274
2472	EUR	ARS	1657.86773317	2026-01-18	2026-01-18 21:24:04.071649
2473	ARS	EUR	0.0006031844277998615	2026-01-18	2026-01-18 21:24:04.080596
2474	EUR	AUD	1.73666053	2026-01-18	2026-01-18 21:24:04.097899
2475	AUD	EUR	0.5758177736670275	2026-01-18	2026-01-18 21:24:04.106705
2476	EUR	AWG	2.07744103	2026-01-18	2026-01-18 21:24:04.115559
2477	AWG	EUR	0.4813614372485942	2026-01-18	2026-01-18 21:24:04.12422
2478	EUR	AZN	1.97496345	2026-01-18	2026-01-18 21:24:04.132707
2479	AZN	EUR	0.5063384843906859	2026-01-18	2026-01-18 21:24:04.141585
2480	EUR	BAM	1.95583	2026-01-18	2026-01-18 21:24:04.169254
2481	BAM	EUR	0.5112918811962185	2026-01-18	2026-01-18 21:24:04.178199
2482	EUR	BBD	2.32116316	2026-01-18	2026-01-18 21:24:04.187818
2483	BBD	EUR	0.43081848671077483	2026-01-18	2026-01-18 21:24:04.196539
2484	EUR	BDT	141.91142557	2026-01-18	2026-01-18 21:24:04.205427
2485	BDT	EUR	0.007046648964193053	2026-01-18	2026-01-18 21:24:04.214618
2486	EUR	BGN	1.95583	2026-01-18	2026-01-18 21:24:04.223305
2487	BGN	EUR	0.5112918811962185	2026-01-18	2026-01-18 21:24:04.232273
2488	EUR	BHD	0.43637867	2026-01-18	2026-01-18 21:24:04.241009
2489	BHD	EUR	2.2915877166956853	2026-01-18	2026-01-18 21:24:04.269336
2490	EUR	BIF	3433.00097112	2026-01-18	2026-01-18 21:24:04.278557
2491	BIF	EUR	0.0002912903341456833	2026-01-18	2026-01-18 21:24:04.288082
2492	EUR	BMD	1.16058158	2026-01-18	2026-01-18 21:24:04.297376
2493	BMD	EUR	0.8616369734215497	2026-01-18	2026-01-18 21:24:04.307919
2494	EUR	BND	1.49562678	2026-01-18	2026-01-18 21:24:04.317291
2495	BND	EUR	0.6686160032518272	2026-01-18	2026-01-18 21:24:04.365176
2496	EUR	BOB	8.03389743	2026-01-18	2026-01-18 21:24:04.374493
2497	BOB	EUR	0.12447258739772087	2026-01-18	2026-01-18 21:24:04.384165
2498	EUR	BRL	6.23310699	2026-01-18	2026-01-18 21:24:04.393911
2499	BRL	EUR	0.1604336331149676	2026-01-18	2026-01-18 21:24:04.402942
2500	EUR	BSD	1.16058158	2026-01-18	2026-01-18 21:24:04.411857
2501	BSD	EUR	0.8616369734215497	2026-01-18	2026-01-18 21:24:04.421068
2502	EUR	BTN	105.25432603	2026-01-18	2026-01-18 21:24:04.430181
2503	BTN	EUR	0.009500797142674934	2026-01-18	2026-01-18 21:24:04.467658
2504	EUR	BWP	15.51076049	2026-01-18	2026-01-18 21:24:04.476615
2505	BWP	EUR	0.06447137138406037	2026-01-18	2026-01-18 21:24:04.488038
2506	EUR	BYN	3.34749091	2026-01-18	2026-01-18 21:24:04.496666
2507	BYN	EUR	0.29873120701020817	2026-01-18	2026-01-18 21:24:04.505542
2508	EUR	BZD	2.3342758	2026-01-18	2026-01-18 21:24:04.514809
2509	BZD	EUR	0.42839839234078514	2026-01-18	2026-01-18 21:24:04.523808
2510	EUR	CAD	1.61515025	2026-01-18	2026-01-18 21:24:04.538776
2511	CAD	EUR	0.6191374455720141	2026-01-18	2026-01-18 21:24:04.565145
2512	EUR	CDF	2504.77299162	2026-01-18	2026-01-18 21:24:04.574056
2513	CDF	EUR	0.0003992377765752076	2026-01-18	2026-01-18 21:24:04.583283
2514	EUR	CHF	0.9318239	2026-01-18	2026-01-18 21:24:04.592373
2515	CHF	EUR	1.0731641461439227	2026-01-18	2026-01-18 21:24:04.601288
2516	EUR	CLP	1028.8295575	2026-01-18	2026-01-18 21:24:04.610664
2517	CLP	EUR	0.0009719782958315718	2026-01-18	2026-01-18 21:24:04.620453
2518	EUR	CNH	8.09215537	2026-01-18	2026-01-18 21:24:04.629395
2519	CNH	EUR	0.12357647057881439	2026-01-18	2026-01-18 21:24:04.665035
2520	EUR	CNY	8.08821992	2026-01-18	2026-01-18 21:24:04.674562
2521	CNY	EUR	0.12363659864481033	2026-01-18	2026-01-18 21:24:04.684601
2522	EUR	COP	4285.68296463	2026-01-18	2026-01-18 21:24:04.693767
2523	COP	EUR	0.0002333350386048292	2026-01-18	2026-01-18 21:24:04.703285
2524	EUR	CRC	565.73254967	2026-01-18	2026-01-18 21:24:04.712047
2525	CRC	EUR	0.001767619700480933	2026-01-18	2026-01-18 21:24:04.720822
2526	EUR	CUP	27.84989409	2026-01-18	2026-01-18 21:24:04.729952
2527	CUP	EUR	0.035906779277809456	2026-01-18	2026-01-18 21:24:04.774899
2528	EUR	CVE	110.27	2026-01-18	2026-01-18 21:24:04.785668
2529	CVE	EUR	0.009068649678062937	2026-01-18	2026-01-18 21:24:04.794761
2530	EUR	CZK	24.27351067	2026-01-18	2026-01-18 21:24:04.803897
2531	CZK	EUR	0.04119717224241136	2026-01-18	2026-01-18 21:24:04.813355
2532	EUR	DJF	206.89955422	2026-01-18	2026-01-18 21:24:04.822502
2533	DJF	EUR	0.0048332631927117745	2026-01-18	2026-01-18 21:24:04.831774
2534	EUR	DKK	7.47589716	2026-01-18	2026-01-18 21:24:04.867344
2535	DKK	EUR	0.13376320976571593	2026-01-18	2026-01-18 21:24:04.876565
2536	EUR	DOP	73.55862486	2026-01-18	2026-01-18 21:24:04.885777
2537	DOP	EUR	0.013594598891744428	2026-01-18	2026-01-18 21:24:04.894883
2538	EUR	DZD	151.2278417	2026-01-18	2026-01-18 21:24:04.904106
2539	DZD	EUR	0.006612538992547164	2026-01-18	2026-01-18 21:24:04.913424
2540	EUR	EGP	54.79076851	2026-01-18	2026-01-18 21:24:04.969771
2541	EGP	EUR	0.018251249748714286	2026-01-18	2026-01-18 21:24:04.979831
2542	EUR	ERN	17.40872368	2026-01-18	2026-01-18 21:24:04.989259
2543	ERN	EUR	0.057442464960762704	2026-01-18	2026-01-18 21:24:04.998382
2544	EUR	ETB	180.60402174	2026-01-18	2026-01-18 21:24:05.007824
2545	ETB	EUR	0.005536975258721611	2026-01-18	2026-01-18 21:24:05.018751
2546	EUR	EUR	1	2026-01-18	2026-01-18 21:24:05.069566
2548	EUR	FJD	2.64580451	2026-01-18	2026-01-18 21:24:05.080146
2549	FJD	EUR	0.377956873314121	2026-01-18	2026-01-18 21:24:05.090485
2550	EUR	FKP	0.86737936	2026-01-18	2026-01-18 21:24:05.100883
2551	FKP	EUR	1.1528980814115752	2026-01-18	2026-01-18 21:24:05.111636
2552	EUR	GBP	0.86737936	2026-01-18	2026-01-18 21:24:05.121062
2553	GBP	EUR	1.1528980814115752	2026-01-18	2026-01-18 21:24:05.133014
2554	EUR	GEL	3.12335319	2026-01-18	2026-01-18 21:24:05.167492
2555	GEL	EUR	0.32016872225712006	2026-01-18	2026-01-18 21:24:05.177212
2556	EUR	GGP	0.86737936	2026-01-18	2026-01-18 21:24:05.186275
2557	GGP	EUR	1.1528980814115752	2026-01-18	2026-01-18 21:24:05.195099
2558	EUR	GHS	12.55065971	2026-01-18	2026-01-18 21:24:05.205681
2559	GHS	EUR	0.07967708655212993	2026-01-18	2026-01-18 21:24:05.216093
2560	EUR	GIP	0.86737936	2026-01-18	2026-01-18 21:24:05.225148
2561	GIP	EUR	1.1528980814115752	2026-01-18	2026-01-18 21:24:05.2336
8543	AFN	EUR	0.012826118742097674	2026-01-26	2026-01-27 09:41:53.63578
2562	EUR	GMD	85.857055	2026-01-18	2026-01-18 21:24:05.241871
2563	GMD	EUR	0.011647266494291004	2026-01-18	2026-01-18 21:24:05.269363
2564	EUR	GNF	10162.12578709	2026-01-18	2026-01-18 21:24:05.277741
2565	GNF	EUR	9.84046075546913e-05	2026-01-18	2026-01-18 21:24:05.286273
2566	EUR	GTQ	8.89493291	2026-01-18	2026-01-18 21:24:05.294458
2567	GTQ	EUR	0.112423557335184	2026-01-18	2026-01-18 21:24:05.302607
2568	EUR	GYD	242.89206128	2026-01-18	2026-01-18 21:24:05.311107
2569	GYD	EUR	0.00411705510147252	2026-01-18	2026-01-18 21:24:05.320725
2570	EUR	HKD	9.04983878	2026-01-18	2026-01-18 21:24:05.329101
2571	HKD	EUR	0.11049920604220974	2026-01-18	2026-01-18 21:24:05.337415
2572	EUR	HNL	30.69629692	2026-01-18	2026-01-18 21:24:05.345703
2573	HNL	EUR	0.03257721941529877	2026-01-18	2026-01-18 21:24:05.354099
2574	EUR	HRK	7.5345	2026-01-18	2026-01-18 21:24:05.368817
2575	HRK	EUR	0.13272280841462605	2026-01-18	2026-01-18 21:24:05.377561
2576	EUR	HTG	153.06334558	2026-01-18	2026-01-18 21:24:05.386193
2577	HTG	EUR	0.006533242797030989	2026-01-18	2026-01-18 21:24:05.394682
2578	EUR	HUF	385.3942112	2026-01-18	2026-01-18 21:24:05.403359
2579	HUF	EUR	0.002594745771832704	2026-01-18	2026-01-18 21:24:05.41199
2580	EUR	IDR	19596.56642726	2026-01-18	2026-01-18 21:24:05.422021
2581	IDR	EUR	5.102934760086032e-05	2026-01-18	2026-01-18 21:24:05.43144
2582	EUR	ILS	3.64564106	2026-01-18	2026-01-18 21:24:05.44046
2583	ILS	EUR	0.2743001802815991	2026-01-18	2026-01-18 21:24:05.44954
2584	EUR	IMP	0.86737936	2026-01-18	2026-01-18 21:24:05.468565
2585	IMP	EUR	1.1528980814115752	2026-01-18	2026-01-18 21:24:05.478461
2586	EUR	INR	105.25432603	2026-01-18	2026-01-18 21:24:05.487187
2587	INR	EUR	0.009500797142674934	2026-01-18	2026-01-18 21:24:05.496042
2588	EUR	IQD	1520.70655292	2026-01-18	2026-01-18 21:24:05.504527
2589	IQD	EUR	0.0006575890648197971	2026-01-18	2026-01-18 21:24:05.512934
2590	EUR	IRR	1235842.96794875	2026-01-18	2026-01-18 21:24:05.522109
2591	IRR	EUR	8.091642918515759e-07	2026-01-18	2026-01-18 21:24:05.531481
2592	EUR	ISK	146.29310004	2026-01-18	2026-01-18 21:24:05.540161
2593	ISK	EUR	0.006835592380820259	2026-01-18	2026-01-18 21:24:05.548844
2594	EUR	JEP	0.86737936	2026-01-18	2026-01-18 21:24:05.567118
2595	JEP	EUR	1.1528980814115752	2026-01-18	2026-01-18 21:24:05.57641
2596	EUR	JMD	183.1333665	2026-01-18	2026-01-18 21:24:05.585385
2597	JMD	EUR	0.005460501377284516	2026-01-18	2026-01-18 21:24:05.595405
2598	EUR	JOD	0.82285234	2026-01-18	2026-01-18 21:24:05.604557
2599	JOD	EUR	1.2152848711592654	2026-01-18	2026-01-18 21:24:05.613906
2600	EUR	JPY	183.59916423	2026-01-18	2026-01-18 21:24:05.62354
2601	JPY	EUR	0.005446647887499482	2026-01-18	2026-01-18 21:24:05.63315
2602	EUR	KES	149.74256144	2026-01-18	2026-01-18 21:24:05.642563
2603	KES	EUR	0.006678128051126517	2026-01-18	2026-01-18 21:24:05.652054
2604	EUR	KGS	101.4904924	2026-01-18	2026-01-18 21:24:05.664768
2605	KGS	EUR	0.009853139701586472	2026-01-18	2026-01-18 21:24:05.675183
2606	EUR	KHR	4668.39162707	2026-01-18	2026-01-18 21:24:05.684243
2607	KHR	EUR	0.00021420653618720183	2026-01-18	2026-01-18 21:24:05.693141
2608	EUR	KMF	491.96775001	2026-01-18	2026-01-18 21:24:05.702155
2609	KMF	EUR	0.002032653563124155	2026-01-18	2026-01-18 21:24:05.710904
2610	EUR	KRW	1709.34590334	2026-01-18	2026-01-18 21:24:05.720068
2611	KRW	EUR	0.0005850190988529802	2026-01-18	2026-01-18 21:24:05.728894
2612	EUR	KWD	0.35703014	2026-01-18	2026-01-18 21:24:05.73755
2613	KWD	EUR	2.800883981391599	2026-01-18	2026-01-18 21:24:05.746016
2614	EUR	KYD	0.95542252	2026-01-18	2026-01-18 21:24:05.754595
2615	KYD	EUR	1.0466573469505407	2026-01-18	2026-01-18 21:24:05.769681
2616	EUR	KZT	593.98883162	2026-01-18	2026-01-18 21:24:05.778354
2617	KZT	EUR	0.001683533337272817	2026-01-18	2026-01-18 21:24:05.787039
2618	EUR	LAK	25092.09943977	2026-01-18	2026-01-18 21:24:05.796052
2619	LAK	EUR	3.9853181771431965e-05	2026-01-18	2026-01-18 21:24:05.805572
2620	EUR	LBP	104600.46569906	2026-01-18	2026-01-18 21:24:05.814298
2621	LBP	EUR	9.560186881739538e-06	2026-01-18	2026-01-18 21:24:05.822989
2622	EUR	LKR	359.40090742	2026-01-18	2026-01-18 21:24:05.832017
2623	LKR	EUR	0.0027824081112610786	2026-01-18	2026-01-18 21:24:05.840716
2624	EUR	LRD	210.16484613	2026-01-18	2026-01-18 21:24:05.849065
2625	LRD	EUR	0.0047581696863872175	2026-01-18	2026-01-18 21:24:05.857507
2626	EUR	LSL	19.04573007	2026-01-18	2026-01-18 21:24:05.868534
2627	LSL	EUR	0.05250520701094867	2026-01-18	2026-01-18 21:24:05.878885
2628	EUR	LYD	6.30166377	2026-01-18	2026-01-18 21:24:05.887441
2629	LYD	EUR	0.15868825067447226	2026-01-18	2026-01-18 21:24:05.896076
2630	EUR	MAD	10.70133405	2026-01-18	2026-01-18 21:24:05.905032
2631	MAD	EUR	0.09344629326845469	2026-01-18	2026-01-18 21:24:05.913805
2632	EUR	MDL	19.81827107	2026-01-18	2026-01-18 21:24:05.923043
2633	MDL	EUR	0.05045848835490774	2026-01-18	2026-01-18 21:24:05.932182
2634	EUR	MGA	5320.53356367	2026-01-18	2026-01-18 21:24:05.941017
2635	MGA	EUR	0.00018795107446145298	2026-01-18	2026-01-18 21:24:05.950218
2636	EUR	MKD	61.50831096	2026-01-18	2026-01-18 21:24:05.966922
2637	MKD	EUR	0.016257965539816538	2026-01-18	2026-01-18 21:24:05.976032
2638	EUR	MMK	2437.36630323	2026-01-18	2026-01-18 21:24:05.984492
2639	MMK	EUR	0.0004102789140371716	2026-01-18	2026-01-18 21:24:05.992912
2640	EUR	MNT	4134.86586093	2026-01-18	2026-01-18 21:24:06.00114
2641	MNT	EUR	0.00024184581401997003	2026-01-18	2026-01-18 21:24:06.00968
2642	EUR	MOP	9.32133395	2026-01-18	2026-01-18 21:24:06.018016
2643	MOP	EUR	0.10728078248929168	2026-01-18	2026-01-18 21:24:06.026653
2644	EUR	MRU	46.3768438	2026-01-18	2026-01-18 21:24:06.034848
2645	MRU	EUR	0.021562485026201804	2026-01-18	2026-01-18 21:24:06.043515
2646	EUR	MUR	53.73160043	2026-01-18	2026-01-18 21:24:06.069043
2647	MUR	EUR	0.0186110220428437	2026-01-18	2026-01-18 21:24:06.077613
2648	EUR	MVR	17.94222801	2026-01-18	2026-01-18 21:24:06.086476
2649	MVR	EUR	0.055734438300675676	2026-01-18	2026-01-18 21:24:06.094936
2650	EUR	MWK	2011.04180942	2026-01-18	2026-01-18 21:24:06.103545
2651	MWK	EUR	0.0004972547041617239	2026-01-18	2026-01-18 21:24:06.11316
2652	EUR	MXN	20.45594585	2026-01-18	2026-01-18 21:24:06.121518
2653	MXN	EUR	0.048885542000004854	2026-01-18	2026-01-18 21:24:06.130719
2654	EUR	MYR	4.70924981	2026-01-18	2026-01-18 21:24:06.140373
2655	MYR	EUR	0.21234804700241627	2026-01-18	2026-01-18 21:24:06.169698
2656	EUR	MZN	74.12820765	2026-01-18	2026-01-18 21:24:06.179614
2657	MZN	EUR	0.013490141360513524	2026-01-18	2026-01-18 21:24:06.188665
2658	EUR	NAD	19.04573007	2026-01-18	2026-01-18 21:24:06.200847
2659	NAD	EUR	0.05250520701094867	2026-01-18	2026-01-18 21:24:06.210103
2660	EUR	NGN	1648.4868198	2026-01-18	2026-01-18 21:24:06.219337
2661	NGN	EUR	0.0006066169216453447	2026-01-18	2026-01-18 21:24:06.228248
2662	EUR	NIO	42.66766329	2026-01-18	2026-01-18 21:24:06.262242
2663	NIO	EUR	0.02343695255123965	2026-01-18	2026-01-18 21:24:06.271532
2664	EUR	NOK	11.71737517	2026-01-18	2026-01-18 21:24:06.280375
2665	NOK	EUR	0.08534334571451636	2026-01-18	2026-01-18 21:24:06.288584
2666	EUR	NPR	168.48586239	2026-01-18	2026-01-18 21:24:06.297013
2667	NPR	EUR	0.005935216081722428	2026-01-18	2026-01-18 21:24:06.305042
2668	EUR	NZD	2.01813143	2026-01-18	2026-01-18 21:24:06.313495
2669	NZD	EUR	0.49550786689844084	2026-01-18	2026-01-18 21:24:06.321806
2670	EUR	OMR	0.44661114	2026-01-18	2026-01-18 21:24:06.330058
2671	OMR	EUR	2.2390843184072837	2026-01-18	2026-01-18 21:24:06.338589
2672	EUR	PAB	1.16058158	2026-01-18	2026-01-18 21:24:06.346944
2673	PAB	EUR	0.8616369734215497	2026-01-18	2026-01-18 21:24:06.355194
2674	EUR	PEN	3.90068165	2026-01-18	2026-01-18 21:24:06.363065
2675	PEN	EUR	0.2563654483313192	2026-01-18	2026-01-18 21:24:06.371127
2676	EUR	PGK	4.94712584	2026-01-18	2026-01-18 21:24:06.379003
2677	PGK	EUR	0.20213757085265494	2026-01-18	2026-01-18 21:24:06.386892
2678	EUR	PHP	68.93625575	2026-01-18	2026-01-18 21:24:06.395335
2679	PHP	EUR	0.014506154840009569	2026-01-18	2026-01-18 21:24:06.403489
2680	EUR	PKR	324.97600138	2026-01-18	2026-01-18 21:24:06.411763
2681	PKR	EUR	0.003077150299571453	2026-01-18	2026-01-18 21:24:06.419671
2682	EUR	PLN	4.2221594	2026-01-18	2026-01-18 21:24:06.427466
2683	PLN	EUR	0.23684562927681035	2026-01-18	2026-01-18 21:24:06.436694
2684	EUR	PYG	7851.7287999	2026-01-18	2026-01-18 21:24:06.444841
2685	PYG	EUR	0.0001273604865227561	2026-01-18	2026-01-18 21:24:06.453292
2686	EUR	QAR	4.22451695	2026-01-18	2026-01-18 21:24:06.46132
2687	QAR	EUR	0.23671345430392934	2026-01-18	2026-01-18 21:24:06.469747
2688	EUR	RON	5.09116096	2026-01-18	2026-01-18 21:24:06.477848
2689	RON	EUR	0.19641885374608153	2026-01-18	2026-01-18 21:24:06.486235
2690	EUR	RSD	117.42850695	2026-01-18	2026-01-18 21:24:06.494382
2691	RSD	EUR	0.008515819761089111	2026-01-18	2026-01-18 21:24:06.502523
2692	EUR	RUB	90.40957349	2026-01-18	2026-01-18 21:24:06.510767
2693	RUB	EUR	0.011060775550618074	2026-01-18	2026-01-18 21:24:06.51866
2694	EUR	RWF	1689.46565862	2026-01-18	2026-01-18 21:24:06.526745
2695	RWF	EUR	0.0005919031232732048	2026-01-18	2026-01-18 21:24:06.535102
2696	EUR	SAR	4.35218092	2026-01-18	2026-01-18 21:24:06.543593
2697	SAR	EUR	0.22976985984305082	2026-01-18	2026-01-18 21:24:06.552196
2698	EUR	SBD	9.42858224	2026-01-18	2026-01-18 21:24:06.560697
2699	SBD	EUR	0.1060604844445839	2026-01-18	2026-01-18 21:24:06.568815
2700	EUR	SCR	17.21581269	2026-01-18	2026-01-18 21:24:06.577163
2701	SCR	EUR	0.05808613383560227	2026-01-18	2026-01-18 21:24:06.585167
2702	EUR	SDG	695.95154707	2026-01-18	2026-01-18 21:24:06.593628
2703	SDG	EUR	0.0014368816395481313	2026-01-18	2026-01-18 21:24:06.602153
2704	EUR	SEK	10.70265316	2026-01-18	2026-01-18 21:24:06.61092
2705	SEK	EUR	0.09343477594297749	2026-01-18	2026-01-18 21:24:06.61916
2706	EUR	SGD	1.49562678	2026-01-18	2026-01-18 21:24:06.627476
2707	SGD	EUR	0.6686160032518272	2026-01-18	2026-01-18 21:24:06.636064
2708	EUR	SHP	0.86737936	2026-01-18	2026-01-18 21:24:06.644626
2709	SHP	EUR	1.1528980814115752	2026-01-18	2026-01-18 21:24:06.652927
2710	EUR	SLE	26.50200208	2026-01-18	2026-01-18 21:24:06.661594
2711	SLE	EUR	0.03773299832146115	2026-01-18	2026-01-18 21:24:06.669961
2712	EUR	SOS	662.8558282	2026-01-18	2026-01-18 21:24:06.678158
2713	SOS	EUR	0.0015086236817371322	2026-01-18	2026-01-18 21:24:06.686739
2714	EUR	SRD	44.41721826	2026-01-18	2026-01-18 21:24:06.69554
2715	SRD	EUR	0.022513791704523552	2026-01-18	2026-01-18 21:24:06.703729
2716	EUR	SSP	5280.71316996	2026-01-18	2026-01-18 21:24:06.712008
2717	SSP	EUR	0.00018936836139645408	2026-01-18	2026-01-18 21:24:06.720522
2718	EUR	STN	24.65656319	2026-01-18	2026-01-18 21:24:06.729105
2719	STN	EUR	0.040557152766755894	2026-01-18	2026-01-18 21:24:06.738867
2720	EUR	SYP	128.33837496	2026-01-18	2026-01-18 21:24:06.747254
2721	SYP	EUR	0.0077919016842131275	2026-01-18	2026-01-18 21:24:06.755291
2722	EUR	SZL	19.04573007	2026-01-18	2026-01-18 21:24:06.763191
2723	SZL	EUR	0.05250520701094867	2026-01-18	2026-01-18 21:24:06.771516
2724	EUR	THB	36.46539799	2026-01-18	2026-01-18 21:24:06.779932
2725	THB	EUR	0.027423257529623907	2026-01-18	2026-01-18 21:24:06.788219
2726	EUR	TJS	10.82171536	2026-01-18	2026-01-18 21:24:06.796392
2727	TJS	EUR	0.09240679196722099	2026-01-18	2026-01-18 21:24:06.804482
2728	EUR	TMT	4.06596414	2026-01-18	2026-01-18 21:24:06.812714
2729	TMT	EUR	0.2459441267969471	2026-01-18	2026-01-18 21:24:06.821154
2730	EUR	TND	3.36389225	2026-01-18	2026-01-18 21:24:06.829741
2731	TND	EUR	0.29727468232670057	2026-01-18	2026-01-18 21:24:06.837932
2732	EUR	TOP	2.77607749	2026-01-18	2026-01-18 21:24:06.846371
2733	TOP	EUR	0.36022049226010616	2026-01-18	2026-01-18 21:24:06.85475
2734	EUR	TRY	50.16628458	2026-01-18	2026-01-18 21:24:06.862758
2735	TRY	EUR	0.019933706639272904	2026-01-18	2026-01-18 21:24:06.871303
2736	EUR	TTD	7.84791307	2026-01-18	2026-01-18 21:24:06.879342
2737	TTD	EUR	0.12742241040139352	2026-01-18	2026-01-18 21:24:06.88752
2738	EUR	TVD	1.73666053	2026-01-18	2026-01-18 21:24:06.895624
2739	TVD	EUR	0.5758177736670275	2026-01-18	2026-01-18 21:24:06.903586
2740	EUR	TWD	36.71102736	2026-01-18	2026-01-18 21:24:06.911633
2741	TWD	EUR	0.027239771586713774	2026-01-18	2026-01-18 21:24:06.920934
2742	EUR	TZS	2880.53668794	2026-01-18	2026-01-18 21:24:06.92899
2743	TZS	EUR	0.00034715752942384657	2026-01-18	2026-01-18 21:24:06.937238
2744	EUR	UAH	50.39321939	2026-01-18	2026-01-18 21:24:06.945221
2745	UAH	EUR	0.01984393956379059	2026-01-18	2026-01-18 21:24:06.954818
2746	EUR	UGX	4110.39832023	2026-01-18	2026-01-18 21:24:06.962919
2747	UGX	EUR	0.00024328542445104065	2026-01-18	2026-01-18 21:24:06.971063
2748	EUR	USD	1.16058158	2026-01-18	2026-01-18 21:24:06.979826
2749	USD	EUR	0.8616369734215497	2026-01-18	2026-01-18 21:24:06.988104
2750	EUR	UYU	44.66880756	2026-01-18	2026-01-18 21:24:06.99671
2751	UYU	EUR	0.02238698668319679	2026-01-18	2026-01-18 21:24:07.005078
2752	EUR	UZS	13883.88207324	2026-01-18	2026-01-18 21:24:07.013306
2753	UZS	EUR	7.202596469235466e-05	2026-01-18	2026-01-18 21:24:07.021592
2754	EUR	VES	395.98834632	2026-01-18	2026-01-18 21:24:07.029791
2755	VES	EUR	0.0025253268417952265	2026-01-18	2026-01-18 21:24:07.03807
2756	EUR	VND	30515.91384222	2026-01-18	2026-01-18 21:24:07.046248
2757	VND	EUR	3.2769787107488146e-05	2026-01-18	2026-01-18 21:24:07.055286
2758	EUR	VUV	139.68441887	2026-01-18	2026-01-18 21:24:07.063464
2759	VUV	EUR	0.007158994597176005	2026-01-18	2026-01-18 21:24:07.071725
2760	EUR	WST	3.2382415	2026-01-18	2026-01-18 21:24:07.080429
2761	WST	EUR	0.30880958075548104	2026-01-18	2026-01-18 21:24:07.089036
2762	EUR	XAF	655.95700001	2026-01-18	2026-01-18 21:24:07.098193
2763	XAF	EUR	0.001524490172350863	2026-01-18	2026-01-18 21:24:07.106319
2764	EUR	XCD	3.13418175	2026-01-18	2026-01-18 21:24:07.114657
2765	XCD	EUR	0.31906254319807714	2026-01-18	2026-01-18 21:24:07.122792
2766	EUR	XDR	0.85096607	2026-01-18	2026-01-18 21:24:07.131194
2767	XDR	EUR	1.1751349851116861	2026-01-18	2026-01-18 21:24:07.140093
2768	EUR	XOF	655.95700001	2026-01-18	2026-01-18 21:24:07.148185
2769	XOF	EUR	0.001524490172350863	2026-01-18	2026-01-18 21:24:07.156266
2770	EUR	XPF	119.33174225	2026-01-18	2026-01-18 21:24:07.164647
2771	XPF	EUR	0.0083799999995391	2026-01-18	2026-01-18 21:24:07.173069
2772	EUR	YER	276.63737502	2026-01-18	2026-01-18 21:24:07.181299
2773	YER	EUR	0.00361484054686285	2026-01-18	2026-01-18 21:24:07.189457
2774	EUR	ZAR	19.04573007	2026-01-18	2026-01-18 21:24:07.197555
2775	ZAR	EUR	0.05250520701094867	2026-01-18	2026-01-18 21:24:07.205939
2776	EUR	ZMW	23.41449815	2026-01-18	2026-01-18 21:24:07.214339
2777	ZMW	EUR	0.04270858139233704	2026-01-18	2026-01-18 21:24:07.222832
2778	EUR	ZWL	74464.58460879	2026-01-18	2026-01-18 21:24:07.231375
2779	ZWL	EUR	1.3429202690831331e-05	2026-01-18	2026-01-18 21:24:07.239368
8554	EUR	AUD	1.71452832	2026-01-26	2026-01-27 09:41:53.728521
2783	AFN	EUR	0.013111258679784358	2026-01-19	2026-01-20 00:33:33.252909
2784	EUR	ALL	96.67381347	2026-01-19	2026-01-20 00:33:33.260633
2786	EUR	AMD	440.0434776	2026-01-19	2026-01-20 00:33:33.350028
2787	AMD	EUR	0.002272502720535722	2026-01-19	2026-01-20 00:33:33.442536
2788	EUR	ANG	2.09253149	2026-01-19	2026-01-20 00:33:33.449055
2789	ANG	EUR	0.477890060330705	2026-01-19	2026-01-20 00:33:33.455362
2790	EUR	AOA	1065.9781702	2026-01-19	2026-01-20 00:33:33.460769
2791	AOA	EUR	0.0009381055146864582	2026-01-19	2026-01-20 00:33:33.466833
2792	EUR	ARS	1656.87312191	2026-01-19	2026-01-20 00:33:33.472172
2793	ARS	EUR	0.0006035465158896573	2026-01-19	2026-01-20 00:33:33.478554
2794	EUR	AUD	1.73899129	2026-01-19	2026-01-20 00:33:33.485093
2795	AUD	EUR	0.5750460084248036	2026-01-19	2026-01-20 00:33:33.490824
2796	EUR	AWG	2.08000092	2026-01-19	2026-01-20 00:33:33.545096
2797	AWG	EUR	0.4807690181213959	2026-01-19	2026-01-20 00:33:33.551328
2798	EUR	AZN	1.97541631	2026-01-19	2026-01-20 00:33:33.55702
2799	AZN	EUR	0.5062224073668805	2026-01-19	2026-01-20 00:33:33.562534
2800	EUR	BAM	1.95583	2026-01-19	2026-01-20 00:33:33.567975
2801	BAM	EUR	0.5112918811962185	2026-01-19	2026-01-20 00:33:33.573447
2803	BBD	EUR	0.43028827201509595	2026-01-19	2026-01-20 00:33:33.650112
8571	BIF	EUR	0.00028582508945244027	2026-01-26	2026-01-27 09:41:53.843043
8588	EUR	BZD	2.37867608	2026-01-26	2026-01-27 09:41:53.952638
2866	EUR	EUR	1	2026-01-19	2026-01-20 00:33:34.187493
2804	EUR	BDT	142.10088236	2026-01-19	2026-01-20 00:33:33.65619
2805	BDT	EUR	0.007037253980355931	2026-01-19	2026-01-20 00:33:33.663771
2807	BGN	EUR	0.5112918811962185	2026-01-19	2026-01-20 00:33:33.675862
2808	EUR	BHD	0.43691639	2026-01-19	2026-01-20 00:33:33.681676
2809	BHD	EUR	2.288767422984521	2026-01-19	2026-01-20 00:33:33.693986
2810	EUR	BIF	3438.33946671	2026-01-19	2026-01-20 00:33:33.742336
2811	BIF	EUR	0.0002908380657820437	2026-01-19	2026-01-20 00:33:33.748512
2812	EUR	BMD	1.16201168	2026-01-19	2026-01-20 00:33:33.754068
2813	BMD	EUR	0.8605765477331518	2026-01-19	2026-01-20 00:33:33.760394
2814	EUR	BND	1.49532015	2026-01-19	2026-01-20 00:33:33.766051
2815	BND	EUR	0.6687531094929738	2026-01-19	2026-01-20 00:33:33.770988
2816	EUR	BOB	8.02753509	2026-01-19	2026-01-20 00:33:33.776814
2817	BOB	EUR	0.12457123996202923	2026-01-19	2026-01-20 00:33:33.781987
2818	EUR	BRL	6.23908162	2026-01-19	2026-01-20 00:33:33.787101
2819	BRL	EUR	0.160279999670849	2026-01-19	2026-01-20 00:33:33.792052
2820	EUR	BSD	1.16201168	2026-01-19	2026-01-20 00:33:33.797827
2821	BSD	EUR	0.8605765477331518	2026-01-19	2026-01-20 00:33:33.843875
2822	EUR	BTN	105.37185215	2026-01-19	2026-01-20 00:33:33.849302
2824	EUR	BWP	16.02253635	2026-01-19	2026-01-20 00:33:33.859486
2825	BWP	EUR	0.06241209120427429	2026-01-19	2026-01-20 00:33:33.866367
2826	EUR	BYN	3.34756491	2026-01-19	2026-01-20 00:33:33.871537
2827	BYN	EUR	0.2987246033714698	2026-01-19	2026-01-20 00:33:33.876748
2828	EUR	BZD	2.34032054	2026-01-19	2026-01-20 00:33:33.881357
2829	BZD	EUR	0.42729189566485626	2026-01-19	2026-01-20 00:33:33.886582
2830	EUR	CAD	1.61511546	2026-01-19	2026-01-20 00:33:33.891468
2831	CAD	EUR	0.6191507819509078	2026-01-19	2026-01-20 00:33:33.896568
2832	EUR	CDF	2641.63747805	2026-01-19	2026-01-20 00:33:33.901413
2833	CDF	EUR	0.0003785530786526312	2026-01-19	2026-01-20 00:33:33.938671
2834	EUR	CHF	0.92904042	2026-01-19	2026-01-20 00:33:33.94589
2835	CHF	EUR	1.0763794324470835	2026-01-19	2026-01-20 00:33:33.951381
2836	EUR	CLP	1030.25140997	2026-01-19	2026-01-20 00:33:33.957516
2837	CLP	EUR	0.0009706368662277484	2026-01-19	2026-01-20 00:33:33.962748
2838	EUR	CNH	8.08848343	2026-01-19	2026-01-20 00:33:33.968435
2839	CNH	EUR	0.12363257075993045	2026-01-19	2026-01-20 00:33:33.973817
2841	CNY	EUR	0.12356469215185888	2026-01-19	2026-01-20 00:33:33.986791
2842	EUR	COP	4288.7269792	2026-01-19	2026-01-20 00:33:33.991822
2843	COP	EUR	0.00023316942413213155	2026-01-19	2026-01-20 00:33:33.997424
2844	EUR	CRC	568.22112954	2026-01-19	2026-01-20 00:33:34.002678
2845	CRC	EUR	0.0017598782375613945	2026-01-19	2026-01-20 00:33:34.009049
2846	EUR	CUP	27.86555168	2026-01-19	2026-01-20 00:33:34.04226
2847	CUP	EUR	0.035886603340343416	2026-01-19	2026-01-20 00:33:34.047785
2848	EUR	CVE	110.26999999	2026-01-19	2026-01-20 00:33:34.053015
2849	CVE	EUR	0.00906864967888534	2026-01-19	2026-01-20 00:33:34.058552
2850	EUR	CZK	24.26981774	2026-01-19	2026-01-20 00:33:34.064483
2851	CZK	EUR	0.04120344086275779	2026-01-19	2026-01-20 00:33:34.069582
2852	EUR	DJF	206.86787838	2026-01-19	2026-01-20 00:33:34.074361
2853	DJF	EUR	0.004834003267356369	2026-01-19	2026-01-20 00:33:34.08003
2854	EUR	DKK	7.4719387	2026-01-19	2026-01-20 00:33:34.085056
2855	DKK	EUR	0.13383407441498416	2026-01-19	2026-01-20 00:33:34.089861
2856	EUR	DOP	73.97987634	2026-01-19	2026-01-20 00:33:34.095443
2858	EUR	DZD	150.95479059	2026-01-19	2026-01-20 00:33:34.105268
2859	DZD	EUR	0.0066244999320097435	2026-01-19	2026-01-20 00:33:34.144449
2860	EUR	EGP	54.7040646	2026-01-19	2026-01-20 00:33:34.149727
2861	EGP	EUR	0.018280177301487024	2026-01-19	2026-01-20 00:33:34.154912
2862	EUR	ERN	17.43017527	2026-01-19	2026-01-20 00:33:34.159984
2863	ERN	EUR	0.057371769618470396	2026-01-19	2026-01-20 00:33:34.165703
2864	EUR	ETB	181.26529788	2026-01-19	2026-01-20 00:33:34.171021
2865	ETB	EUR	0.005516775751870682	2026-01-19	2026-01-20 00:33:34.176681
2868	EUR	FJD	2.64920752	2026-01-19	2026-01-20 00:33:34.192587
2869	FJD	EUR	0.3774713730240355	2026-01-19	2026-01-20 00:33:34.244749
2870	EUR	FKP	0.86808364	2026-01-19	2026-01-20 00:33:34.250875
2871	FKP	EUR	1.1519627302272393	2026-01-19	2026-01-20 00:33:34.25595
2872	EUR	GBP	0.86808364	2026-01-19	2026-01-20 00:33:34.26124
2873	GBP	EUR	1.1519627302272393	2026-01-19	2026-01-20 00:33:34.267066
2874	EUR	GEL	3.12607497	2026-01-19	2026-01-20 00:33:34.272059
2875	GEL	EUR	0.31988996092438565	2026-01-19	2026-01-20 00:33:34.277272
2877	GGP	EUR	1.1519627302272393	2026-01-19	2026-01-20 00:33:34.288582
2878	EUR	GHS	12.57373638	2026-01-19	2026-01-20 00:33:34.293792
2879	GHS	EUR	0.0795308546145931	2026-01-19	2026-01-20 00:33:34.298517
2880	EUR	GIP	0.86808364	2026-01-19	2026-01-20 00:33:34.303711
2881	GIP	EUR	1.1519627302272393	2026-01-19	2026-01-20 00:33:34.3422
2882	EUR	GMD	85.75194915	2026-01-19	2026-01-20 00:33:34.347379
2883	GMD	EUR	0.011661542506174042	2026-01-19	2026-01-20 00:33:34.352423
2884	EUR	GNF	10177.48380814	2026-01-19	2026-01-20 00:33:34.357233
2885	GNF	EUR	9.825611308761752e-05	2026-01-19	2026-01-20 00:33:34.361961
2886	EUR	GTQ	8.9072365	2026-01-19	2026-01-20 00:33:34.366749
2887	GTQ	EUR	0.11226826636970962	2026-01-19	2026-01-20 00:33:34.371245
2888	EUR	GYD	242.95595434	2026-01-19	2026-01-20 00:33:34.376755
2889	GYD	EUR	0.004115972389796092	2026-01-19	2026-01-20 00:33:34.382511
2890	EUR	HKD	9.05885534	2026-01-19	2026-01-20 00:33:34.394962
2891	HKD	EUR	0.11038922275140339	2026-01-19	2026-01-20 00:33:34.40039
2892	EUR	HNL	30.64238072	2026-01-19	2026-01-20 00:33:34.40601
2894	EUR	HRK	7.5345	2026-01-19	2026-01-20 00:33:34.43913
2895	HRK	EUR	0.13272280841462605	2026-01-19	2026-01-20 00:33:34.44631
2896	EUR	HTG	152.46705463	2026-01-19	2026-01-20 00:33:34.451665
2897	HTG	EUR	0.006558793979635494	2026-01-19	2026-01-20 00:33:34.457504
2898	EUR	HUF	385.12278046	2026-01-19	2026-01-20 00:33:34.462361
2899	HUF	EUR	0.0025965745230795635	2026-01-19	2026-01-20 00:33:34.46741
2900	EUR	IDR	19656.82168084	2026-01-19	2026-01-20 00:33:34.471949
2901	IDR	EUR	5.087292423142472e-05	2026-01-19	2026-01-20 00:33:34.476565
2902	EUR	ILS	3.65897703	2026-01-19	2026-01-20 00:33:34.481359
2903	ILS	EUR	0.2733004311863636	2026-01-19	2026-01-20 00:33:34.486456
2904	EUR	IMP	0.86808364	2026-01-19	2026-01-20 00:33:34.491325
2905	IMP	EUR	1.1519627302272393	2026-01-19	2026-01-20 00:33:34.496466
2906	EUR	INR	105.37185215	2026-01-19	2026-01-20 00:33:34.501261
2907	INR	EUR	0.009490200462420172	2026-01-19	2026-01-20 00:33:34.539094
2908	EUR	IQD	1522.16527887	2026-01-19	2026-01-20 00:33:34.545382
2909	IQD	EUR	0.0006569588821145386	2026-01-19	2026-01-20 00:33:34.550515
2912	EUR	ISK	146.21004911	2026-01-19	2026-01-20 00:33:34.571062
2913	ISK	EUR	0.006839475166632751	2026-01-19	2026-01-20 00:33:34.644773
2914	EUR	JEP	0.86808364	2026-01-19	2026-01-20 00:33:34.650397
2915	JEP	EUR	1.1519627302272393	2026-01-19	2026-01-20 00:33:34.655964
2916	EUR	JMD	183.2353672	2026-01-19	2026-01-20 00:33:34.661287
2917	JMD	EUR	0.005457461707752672	2026-01-19	2026-01-20 00:33:34.666984
2918	EUR	JOD	0.82386628	2026-01-19	2026-01-20 00:33:34.672377
2919	JOD	EUR	1.2137892086079796	2026-01-19	2026-01-20 00:33:34.678825
2920	EUR	JPY	183.36720509	2026-01-19	2026-01-20 00:33:34.684661
2921	JPY	EUR	0.005453537885955024	2026-01-19	2026-01-20 00:33:34.690539
2922	EUR	KES	149.88458238	2026-01-19	2026-01-20 00:33:34.744449
2923	KES	EUR	0.006671800288736275	2026-01-19	2026-01-20 00:33:34.750166
8605	CRC	EUR	0.0017009229223884622	2026-01-26	2026-01-27 09:41:54.060656
2925	KGS	EUR	0.009841333281315982	2026-01-19	2026-01-20 00:33:34.764427
2926	EUR	KHR	4676.48832216	2026-01-19	2026-01-20 00:33:34.770321
2928	EUR	KMF	491.96774997	2026-01-19	2026-01-20 00:33:34.78212
2929	KMF	EUR	0.002032653563289422	2026-01-19	2026-01-20 00:33:34.78831
2930	EUR	KRW	1713.96637702	2026-01-19	2026-01-20 00:33:34.847922
2931	KRW	EUR	0.0005834420169540649	2026-01-19	2026-01-20 00:33:34.864152
2932	EUR	KWD	0.35748074	2026-01-19	2026-01-20 00:33:34.875094
2933	KWD	EUR	2.797353502177488	2026-01-19	2026-01-20 00:33:34.886531
2934	EUR	KYD	0.96566741	2026-01-19	2026-01-20 00:33:34.892578
2935	KYD	EUR	1.0355532242721124	2026-01-19	2026-01-20 00:33:34.898527
2936	EUR	KZT	594.05610665	2026-01-19	2026-01-20 00:33:34.90436
2937	KZT	EUR	0.001683342682291742	2026-01-19	2026-01-20 00:33:34.915963
2938	EUR	LAK	25107.80735698	2026-01-19	2026-01-20 00:33:34.943763
2939	LAK	EUR	3.982824887024628e-05	2026-01-19	2026-01-20 00:33:34.949323
2940	EUR	LBP	104116.50593745	2026-01-19	2026-01-20 00:33:34.955224
2941	LBP	EUR	9.604625039960227e-06	2026-01-19	2026-01-20 00:33:34.961493
2942	EUR	LKR	359.86618357	2026-01-19	2026-01-20 00:33:34.968193
2943	LKR	EUR	0.0027788106959082564	2026-01-19	2026-01-20 00:33:34.974789
2945	LRD	EUR	0.004766044561146981	2026-01-19	2026-01-20 00:33:34.985385
2946	EUR	LSL	19.07102957	2026-01-19	2026-01-20 00:33:35.038915
2947	LSL	EUR	0.05243555395525507	2026-01-19	2026-01-20 00:33:35.046254
2948	EUR	LYD	6.31232479	2026-01-19	2026-01-20 00:33:35.051488
2949	LYD	EUR	0.1584202387025779	2026-01-19	2026-01-20 00:33:35.057185
2950	EUR	MAD	10.72252218	2026-01-19	2026-01-20 00:33:35.062665
2951	MAD	EUR	0.09326163967888383	2026-01-19	2026-01-20 00:33:35.067693
2952	EUR	MDL	19.90269531	2026-01-19	2026-01-20 00:33:35.073145
2953	MDL	EUR	0.05024445103661691	2026-01-19	2026-01-20 00:33:35.078412
2954	EUR	MGA	5386.33196711	2026-01-19	2026-01-20 00:33:35.083862
2955	MGA	EUR	0.00018565510000241283	2026-01-19	2026-01-20 00:33:35.088844
2956	EUR	MKD	61.53134188	2026-01-19	2026-01-20 00:33:35.094188
2957	MKD	EUR	0.01625188025234726	2026-01-19	2026-01-20 00:33:35.142428
2958	EUR	MMK	2440.46608292	2026-01-19	2026-01-20 00:33:35.148445
2959	MMK	EUR	0.00040975779462728987	2026-01-19	2026-01-20 00:33:35.156112
2960	EUR	MNT	4143.96573026	2026-01-19	2026-01-20 00:33:35.161574
2962	EUR	MOP	9.330621	2026-01-19	2026-01-20 00:33:35.173169
2963	MOP	EUR	0.10717400267356267	2026-01-19	2026-01-20 00:33:35.178555
2964	EUR	MRU	46.52550276	2026-01-19	2026-01-20 00:33:35.18378
2965	MRU	EUR	0.02149358826187137	2026-01-19	2026-01-20 00:33:35.188712
2966	EUR	MUR	53.79890038	2026-01-19	2026-01-20 00:33:35.194123
2967	MUR	EUR	0.018587740510245723	2026-01-19	2026-01-20 00:33:35.239279
2968	EUR	MVR	17.96420465	2026-01-19	2026-01-20 00:33:35.246002
2969	MVR	EUR	0.05566625517150296	2026-01-19	2026-01-20 00:33:35.251277
2970	EUR	MWK	2013.87583888	2026-01-19	2026-01-20 00:33:35.257378
2971	MWK	EUR	0.0004965549418161458	2026-01-19	2026-01-20 00:33:35.263443
2972	EUR	MXN	20.48397324	2026-01-19	2026-01-20 00:33:35.268867
2973	MXN	EUR	0.04881865389509755	2026-01-19	2026-01-20 00:33:35.274171
2974	EUR	MYR	4.71438109	2026-01-19	2026-01-20 00:33:35.280336
2975	MYR	EUR	0.21211692073879415	2026-01-19	2026-01-20 00:33:35.28625
2976	EUR	MZN	74.24480539	2026-01-19	2026-01-20 00:33:35.292326
2977	MZN	EUR	0.013468955770671191	2026-01-19	2026-01-20 00:33:35.341567
2979	NAD	EUR	0.05243555395525507	2026-01-19	2026-01-20 00:33:35.357311
2980	EUR	NGN	1650.04836015	2026-01-19	2026-01-20 00:33:35.363118
2981	NGN	EUR	0.0006060428434407181	2026-01-19	2026-01-20 00:33:35.369124
2982	EUR	NIO	42.74736858	2026-01-19	2026-01-20 00:33:35.375195
2983	NIO	EUR	0.023393252806392976	2026-01-19	2026-01-20 00:33:35.381093
2984	EUR	NOK	11.71047703	2026-01-19	2026-01-20 00:33:35.387632
2985	NOK	EUR	0.08539361782087881	2026-01-19	2026-01-20 00:33:35.393256
2986	EUR	NPR	168.67399232	2026-01-19	2026-01-20 00:33:35.447636
2987	NPR	EUR	0.005928596259836248	2026-01-19	2026-01-20 00:33:35.460441
2988	EUR	NZD	2.01631792	2026-01-19	2026-01-20 00:33:35.476846
2989	NZD	EUR	0.4959535349465128	2026-01-19	2026-01-20 00:33:35.499125
2990	EUR	OMR	0.44728437	2026-01-19	2026-01-20 00:33:35.521096
2991	OMR	EUR	2.2357141609933744	2026-01-19	2026-01-20 00:33:35.528342
2992	EUR	PAB	1.16201168	2026-01-19	2026-01-20 00:33:35.539199
2993	PAB	EUR	0.8605765477331518	2026-01-19	2026-01-20 00:33:35.545543
2994	EUR	PEN	3.90250283	2026-01-19	2026-01-20 00:33:35.551189
2996	EUR	PGK	4.96242791	2026-01-19	2026-01-20 00:33:35.564322
2997	PGK	EUR	0.2015142624006401	2026-01-19	2026-01-20 00:33:35.569908
2998	EUR	PHP	69.01349237	2026-01-19	2026-01-20 00:33:35.575814
2999	PHP	EUR	0.014489920241084593	2026-01-19	2026-01-20 00:33:35.581188
3000	EUR	PKR	325.1187535	2026-01-19	2026-01-20 00:33:35.587001
3001	PKR	EUR	0.0030757991940935513	2026-01-19	2026-01-20 00:33:35.592545
3002	EUR	PLN	4.22376676	2026-01-19	2026-01-20 00:33:35.597662
3003	PLN	EUR	0.23675549736084384	2026-01-19	2026-01-20 00:33:35.643509
3004	EUR	PYG	7927.54061198	2026-01-19	2026-01-20 00:33:35.649716
3005	PYG	EUR	0.00012614252628221324	2026-01-19	2026-01-20 00:33:35.685563
3006	EUR	QAR	4.22972253	2026-01-19	2026-01-20 00:33:35.694016
3007	QAR	EUR	0.2364221276708664	2026-01-19	2026-01-20 00:33:35.700989
3008	EUR	RON	5.0895281	2026-01-19	2026-01-20 00:33:35.708361
3009	RON	EUR	0.19648187029363293	2026-01-19	2026-01-20 00:33:35.715955
3010	EUR	RSD	117.33878959	2026-01-19	2026-01-20 00:33:35.722963
3011	RSD	EUR	0.008522330965694769	2026-01-19	2026-01-20 00:33:35.747517
3013	RUB	EUR	0.011058123172469458	2026-01-19	2026-01-20 00:33:35.760049
3014	EUR	RWF	1691.76690703	2026-01-19	2026-01-20 00:33:35.768247
3015	RWF	EUR	0.0005910979791864832	2026-01-19	2026-01-20 00:33:35.777866
3016	EUR	SAR	4.35754382	2026-01-19	2026-01-20 00:33:35.786868
3017	SAR	EUR	0.22948707834222076	2026-01-19	2026-01-20 00:33:35.794929
3018	EUR	SBD	9.43445122	2026-01-19	2026-01-20 00:33:35.800257
3019	SBD	EUR	0.10599450637681075	2026-01-19	2026-01-20 00:33:35.847757
3020	EUR	SCR	17.72791132	2026-01-19	2026-01-20 00:33:35.854724
3021	SCR	EUR	0.056408224406664056	2026-01-19	2026-01-20 00:33:35.860086
3022	EUR	SDG	696.99895865	2026-01-19	2026-01-20 00:33:35.86923
3023	SDG	EUR	0.0014347223730963319	2026-01-19	2026-01-20 00:33:35.875433
3024	EUR	SEK	10.70673948	2026-01-19	2026-01-20 00:33:35.88117
3025	SEK	EUR	0.09339911575022278	2026-01-19	2026-01-20 00:33:35.887489
3026	EUR	SGD	1.49532015	2026-01-19	2026-01-20 00:33:35.893278
3027	SGD	EUR	0.6687531094929738	2026-01-19	2026-01-20 00:33:35.901086
3028	EUR	SHP	0.86808364	2026-01-19	2026-01-20 00:33:35.945991
3030	EUR	SLE	26.53539333	2026-01-19	2026-01-20 00:33:35.95967
3031	SLE	EUR	0.03768551638047266	2026-01-19	2026-01-20 00:33:35.966482
3032	EUR	SOS	662.33714182	2026-01-19	2026-01-20 00:33:35.973708
3033	SOS	EUR	0.0015098051080936737	2026-01-19	2026-01-20 00:33:35.980674
3034	EUR	SRD	44.60525352	2026-01-19	2026-01-20 00:33:35.988804
3035	SRD	EUR	0.0224188839001133	2026-01-19	2026-01-20 00:33:35.996102
3036	EUR	SSP	5287.27449358	2026-01-19	2026-01-20 00:33:36.046801
3037	SSP	EUR	0.00018913336185103237	2026-01-19	2026-01-20 00:33:36.05605
3038	EUR	STN	24.69450207	2026-01-19	2026-01-20 00:33:36.062741
3039	STN	EUR	0.04049484363626207	2026-01-19	2026-01-20 00:33:36.071446
3040	EUR	SYP	128.61998615	2026-01-19	2026-01-20 00:33:36.078454
3041	SYP	EUR	0.007774841452974298	2026-01-19	2026-01-20 00:33:36.085145
3042	EUR	SZL	19.07102957	2026-01-19	2026-01-20 00:33:36.09214
3043	SZL	EUR	0.05243555395525507	2026-01-19	2026-01-20 00:33:36.100139
8622	EUR	ERN	17.80799889	2026-01-26	2026-01-27 09:41:54.171196
2780	EUR	AED	4.26748791	2026-01-19	2026-01-20 00:33:33.13984
2781	AED	EUR	0.23432989643783197	2026-01-19	2026-01-20 00:33:33.15936
2782	EUR	AFN	76.270328	2026-01-19	2026-01-20 00:33:33.245764
2785	ALL	EUR	0.010344062824317176	2026-01-19	2026-01-20 00:33:33.344195
2802	EUR	BBD	2.32402337	2026-01-19	2026-01-20 00:33:33.643583
2806	EUR	BGN	1.95583	2026-01-19	2026-01-20 00:33:33.670061
2823	BTN	EUR	0.009490200462420172	2026-01-19	2026-01-20 00:33:33.8545
2840	EUR	CNY	8.09292673	2026-01-19	2026-01-20 00:33:33.97971
2857	DOP	EUR	0.013517189396264406	2026-01-19	2026-01-20 00:33:34.100184
2876	EUR	GGP	0.86808364	2026-01-19	2026-01-20 00:33:34.281995
2893	HNL	EUR	0.032634540022776666	2026-01-19	2026-01-20 00:33:34.410796
2910	EUR	IRR	1238130.08924966	2026-01-19	2026-01-20 00:33:34.556837
2911	IRR	EUR	8.076695725939645e-07	2026-01-19	2026-01-20 00:33:34.565546
2924	EUR	KGS	101.6122482	2026-01-19	2026-01-20 00:33:34.756431
2927	KHR	EUR	0.00021383566708835805	2026-01-19	2026-01-20 00:33:34.776282
2944	EUR	LRD	209.81759343	2026-01-19	2026-01-20 00:33:34.980003
2961	MNT	EUR	0.00024131473691923078	2026-01-19	2026-01-20 00:33:35.16757
2978	EUR	NAD	19.07102957	2026-01-19	2026-01-20 00:33:35.349475
2995	PEN	EUR	0.25624581033295496	2026-01-19	2026-01-20 00:33:35.557014
3012	EUR	RUB	90.43125894	2026-01-19	2026-01-20 00:33:35.753226
3029	SHP	EUR	1.1519627302272393	2026-01-19	2026-01-20 00:33:35.954051
3044	EUR	THB	36.38716008	2026-01-19	2026-01-20 00:33:36.144768
3045	THB	EUR	0.02748222169032764	2026-01-19	2026-01-20 00:33:36.150868
3046	EUR	TJS	10.82957312	2026-01-19	2026-01-20 00:33:36.159087
3047	TJS	EUR	0.09233974311999475	2026-01-19	2026-01-20 00:33:36.165415
3048	EUR	TMT	4.07471084	2026-01-19	2026-01-20 00:33:36.170946
3049	TMT	EUR	0.2454161876183587	2026-01-19	2026-01-20 00:33:36.178343
3050	EUR	TND	3.40917418	2026-01-19	2026-01-20 00:33:36.187465
3051	TND	EUR	0.29332616850923116	2026-01-19	2026-01-20 00:33:36.193318
3052	EUR	TOP	2.78468941	2026-01-19	2026-01-20 00:33:36.246767
3053	TOP	EUR	0.35910647572003374	2026-01-19	2026-01-20 00:33:36.256014
3054	EUR	TRY	50.2817567	2026-01-19	2026-01-20 00:33:36.262724
3055	TRY	EUR	0.019887928855914453	2026-01-19	2026-01-20 00:33:36.268659
3056	EUR	TTD	7.88375304	2026-01-19	2026-01-20 00:33:36.274335
3057	TTD	EUR	0.1268431411950976	2026-01-19	2026-01-20 00:33:36.281175
3058	EUR	TVD	1.73899129	2026-01-19	2026-01-20 00:33:36.287485
3059	TVD	EUR	0.5750460084248036	2026-01-19	2026-01-20 00:33:36.294785
3060	EUR	TWD	36.64154903	2026-01-19	2026-01-20 00:33:36.344099
3061	TWD	EUR	0.027291422619203608	2026-01-19	2026-01-20 00:33:36.352178
3062	EUR	TZS	2925.43748558	2026-01-19	2026-01-20 00:33:36.359128
3063	TZS	EUR	0.00034182921526410226	2026-01-19	2026-01-20 00:33:36.366325
3064	EUR	UAH	50.46725334	2026-01-19	2026-01-20 00:33:36.372743
3065	UAH	EUR	0.019814829098444453	2026-01-19	2026-01-20 00:33:36.380269
3066	EUR	UGX	4121.19936863	2026-01-19	2026-01-20 00:33:36.387156
3067	UGX	EUR	0.00024264780966722012	2026-01-19	2026-01-20 00:33:36.441016
3068	EUR	USD	1.16201168	2026-01-19	2026-01-20 00:33:36.452762
3069	USD	EUR	0.8605765477331518	2026-01-19	2026-01-20 00:33:36.461737
3070	EUR	UYU	44.95347323	2026-01-19	2026-01-20 00:33:36.471077
3071	UYU	EUR	0.022245222185249155	2026-01-19	2026-01-20 00:33:36.477258
3072	EUR	UZS	13882.02593455	2026-01-19	2026-01-20 00:33:36.483837
3073	UZS	EUR	7.203559514401786e-05	2026-01-19	2026-01-20 00:33:36.491681
3074	EUR	VES	398.31738671	2026-01-19	2026-01-20 00:33:36.497994
3075	VES	EUR	0.002510560757238706	2026-01-19	2026-01-20 00:33:36.543752
3076	EUR	VND	30599.07220798	2026-01-19	2026-01-20 00:33:36.553473
3077	VND	EUR	3.268072944182954e-05	2026-01-19	2026-01-20 00:33:36.559447
3078	EUR	VUV	140.84647471	2026-01-19	2026-01-20 00:33:36.564814
3079	VUV	EUR	0.007099929210574702	2026-01-19	2026-01-20 00:33:36.571753
3080	EUR	WST	3.22137484	2026-01-19	2026-01-20 00:33:36.577666
3081	WST	EUR	0.31042646375173155	2026-01-19	2026-01-20 00:33:36.584515
3082	EUR	XAF	655.95699996	2026-01-19	2026-01-20 00:33:36.594092
3083	XAF	EUR	0.0015244901724670668	2026-01-19	2026-01-20 00:33:36.646575
3084	EUR	XCD	3.14566365	2026-01-19	2026-01-20 00:33:36.652496
3085	XCD	EUR	0.31789794182222886	2026-01-19	2026-01-20 00:33:36.659291
3086	EUR	XDR	0.85197889	2026-01-19	2026-01-20 00:33:36.665503
3087	XDR	EUR	1.1737380018887558	2026-01-19	2026-01-20 00:33:36.672846
3088	EUR	XOF	655.95699996	2026-01-19	2026-01-20 00:33:36.747124
3089	XOF	EUR	0.0015244901724670668	2026-01-19	2026-01-20 00:33:36.752896
3090	EUR	XPF	119.33174224	2026-01-19	2026-01-20 00:33:36.75864
3091	XPF	EUR	0.008380000000241344	2026-01-19	2026-01-20 00:33:36.768187
3092	EUR	YER	277.08772006	2026-01-19	2026-01-20 00:33:36.776061
3093	YER	EUR	0.0036089654199885227	2026-01-19	2026-01-20 00:33:36.781958
3094	EUR	ZAR	19.07102957	2026-01-19	2026-01-20 00:33:36.788693
3095	ZAR	EUR	0.05243555395525507	2026-01-19	2026-01-20 00:33:36.842737
3096	EUR	ZMW	23.46307224	2026-01-19	2026-01-20 00:33:36.853997
3097	ZMW	EUR	0.04262016456204714	2026-01-19	2026-01-20 00:33:36.86003
3098	EUR	ZWL	74556.34229988	2026-01-19	2026-01-20 00:33:36.868206
3099	ZWL	EUR	1.3412675154821933e-05	2026-01-19	2026-01-20 00:33:36.877154
8641	GIP	EUR	1.1517774817504889	2026-01-26	2026-01-27 09:41:54.315449
3421	EUR	AED	4.27556088	2026-01-20	2026-01-21 15:42:50.372837
3422	AED	EUR	0.23388744262249872	2026-01-20	2026-01-21 15:42:50.3777
3423	EUR	AFN	76.23945745	2026-01-20	2026-01-21 15:42:50.384326
3424	AFN	EUR	0.013116567633706317	2026-01-20	2026-01-21 15:42:50.47792
3425	EUR	ALL	96.49431747	2026-01-20	2026-01-21 15:42:50.484999
3431	EUR	AOA	1065.58639964	2026-01-20	2026-01-21 15:42:50.880082
3432	AOA	EUR	0.0009384504159755062	2026-01-20	2026-01-21 15:42:50.887457
3433	EUR	ARS	1671.98264703	2026-01-20	2026-01-21 15:42:50.894559
3434	ARS	EUR	0.0005980923317453888	2026-01-20	2026-01-21 15:42:50.901341
3435	EUR	AUD	1.73465231	2026-01-20	2026-01-21 15:42:50.907779
3436	AUD	EUR	0.5764844022258271	2026-01-20	2026-01-21 15:42:50.914623
8658	EUR	HUF	381.69245768	2026-01-26	2026-01-27 09:41:54.448999
8672	EUR	ISK	145.80404021	2026-01-26	2026-01-27 09:41:54.564957
8675	JEP	EUR	1.1517774817504889	2026-01-26	2026-01-27 09:41:54.614547
8692	EUR	KWD	0.36379849	2026-01-26	2026-01-27 09:41:54.733084
8709	LYD	EUR	0.13324888569719906	2026-01-26	2026-01-27 09:41:54.850332
8726	EUR	MUR	54.51328571	2026-01-26	2026-01-27 09:41:54.954899
3426	ALL	EUR	0.010363304557399446	2026-01-20	2026-01-21 15:42:50.57572
3427	EUR	AMD	441.1516171	2026-01-20	2026-01-21 15:42:50.672175
3428	AMD	EUR	0.0022667943655600847	2026-01-20	2026-01-21 15:42:50.777122
3429	EUR	ANG	2.09509016	2026-01-20	2026-01-21 15:42:50.784184
3430	ANG	EUR	0.47730642771001325	2026-01-20	2026-01-21 15:42:50.871364
8743	NIO	EUR	0.0228779636133511	2026-01-26	2026-01-27 09:41:55.100413
8760	EUR	PKR	329.29442479	2026-01-26	2026-01-27 09:41:55.220625
8777	SAR	EUR	0.22461816327337955	2026-01-26	2026-01-27 09:41:55.326584
9253	DJF	EUR	0.004732531102399797	2026-01-27	2026-01-28 03:07:39.827902
9254	EUR	DKK	7.46840047	2026-01-27	2026-01-28 03:07:39.83741
9255	DKK	EUR	0.13389747965671156	2026-01-27	2026-01-28 03:07:39.846193
9256	EUR	DOP	74.44189527	2026-01-27	2026-01-28 03:07:39.855026
9257	DOP	EUR	0.0134332958124321	2026-01-27	2026-01-28 03:07:39.864276
9258	EUR	DZD	153.57695676	2026-01-27	2026-01-28 03:07:39.873173
9259	DZD	EUR	0.00651139351304333	2026-01-27	2026-01-28 03:07:39.881945
9260	EUR	EGP	55.92301793	2026-01-27	2026-01-28 03:07:39.890983
9261	EGP	EUR	0.01788172450298946	2026-01-27	2026-01-28 03:07:39.900046
9252	EUR	DJF	211.30341848	2026-01-27	2026-01-28 03:07:39.818242
8787	SGD	EUR	0.6642060489377718	2026-01-26	2026-01-27 09:41:55.90362
3516	GEL	EUR	0.31927202810413735	2026-01-20	2026-01-21 15:42:51.684142
3445	EUR	BDT	142.27655704	2026-01-20	2026-01-21 15:42:51.022562
3446	BDT	EUR	0.007028564795244921	2026-01-20	2026-01-21 15:42:51.029204
3447	EUR	BGN	1.95583	2026-01-20	2026-01-21 15:42:51.035468
3448	BGN	EUR	0.5112918811962185	2026-01-20	2026-01-21 15:42:51.041998
3449	EUR	BHD	0.43774292	2026-01-20	2026-01-21 15:42:51.070883
3450	BHD	EUR	2.2844458569427006	2026-01-20	2026-01-21 15:42:51.078393
3451	EUR	BIF	3443.61402062	2026-01-20	2026-01-21 15:42:51.085851
3452	BIF	EUR	0.0002903925916238303	2026-01-20	2026-01-21 15:42:51.091923
3453	EUR	BMD	1.1642099	2026-01-20	2026-01-21 15:42:51.098394
3454	BMD	EUR	0.858951637501107	2026-01-20	2026-01-21 15:42:51.104808
3455	EUR	BND	1.49692663	2026-01-20	2026-01-21 15:42:51.110841
3457	EUR	BOB	8.06137124	2026-01-20	2026-01-21 15:42:51.124472
3458	BOB	EUR	0.12404837467825139	2026-01-20	2026-01-21 15:42:51.130966
3459	EUR	BRL	6.25184061	2026-01-20	2026-01-21 15:42:51.138064
3460	BRL	EUR	0.1599528942565284	2026-01-20	2026-01-21 15:42:51.145588
3461	EUR	BSD	1.1642099	2026-01-20	2026-01-21 15:42:51.153737
3462	BSD	EUR	0.858951637501107	2026-01-20	2026-01-21 15:42:51.175224
3463	EUR	BTN	105.88259668	2026-01-20	2026-01-21 15:42:51.181858
3464	BTN	EUR	0.009444422703593256	2026-01-20	2026-01-21 15:42:51.188209
3465	EUR	BWP	15.98969483	2026-01-20	2026-01-21 15:42:51.194781
3466	BWP	EUR	0.06254028051390897	2026-01-20	2026-01-21 15:42:51.200914
3467	EUR	BYN	3.349708	2026-01-20	2026-01-21 15:42:51.207339
3468	BYN	EUR	0.298533484112645	2026-01-20	2026-01-21 15:42:51.213989
3469	EUR	BZD	2.3430603	2026-01-20	2026-01-21 15:42:51.220453
3470	BZD	EUR	0.4267922596785068	2026-01-20	2026-01-21 15:42:51.227396
3471	EUR	CAD	1.61477406	2026-01-20	2026-01-21 15:42:51.233673
3472	CAD	EUR	0.6192816845224774	2026-01-20	2026-01-21 15:42:51.239673
3474	CDF	EUR	0.00037652716288844555	2026-01-20	2026-01-21 15:42:51.281831
3475	EUR	CHF	0.92851089	2026-01-20	2026-01-21 15:42:51.287963
3476	CHF	EUR	1.0769932919149716	2026-01-20	2026-01-21 15:42:51.294298
3477	EUR	CLP	1033.70546054	2026-01-20	2026-01-21 15:42:51.300685
3478	CLP	EUR	0.0009673935547149063	2026-01-20	2026-01-21 15:42:51.307367
3479	EUR	CNH	8.09989654	2026-01-20	2026-01-21 15:42:51.313829
3480	CNH	EUR	0.12345836703736465	2026-01-20	2026-01-21 15:42:51.320036
3481	EUR	CNY	8.10493349	2026-01-20	2026-01-21 15:42:51.327015
3482	CNY	EUR	0.12338164171659352	2026-01-20	2026-01-21 15:42:51.336171
3483	EUR	COP	4272.59362772	2026-01-20	2026-01-21 15:42:51.37521
3484	COP	EUR	0.00023404987394825885	2026-01-20	2026-01-21 15:42:51.382267
3485	EUR	CRC	566.93698406	2026-01-20	2026-01-21 15:42:51.388697
3486	CRC	EUR	0.0017638644648629383	2026-01-20	2026-01-21 15:42:51.395644
3487	EUR	CUP	27.88978107	2026-01-20	2026-01-21 15:42:51.4023
3488	CUP	EUR	0.03585542667008106	2026-01-20	2026-01-21 15:42:51.408993
3489	EUR	CVE	110.26999999	2026-01-20	2026-01-21 15:42:51.416164
3491	EUR	CZK	24.30172221	2026-01-20	2026-01-21 15:42:51.470761
3492	CZK	EUR	0.041149347003419635	2026-01-20	2026-01-21 15:42:51.481091
3493	EUR	DJF	207.24432359	2026-01-20	2026-01-21 15:42:51.488336
3494	DJF	EUR	0.004825222629394383	2026-01-20	2026-01-21 15:42:51.495269
3495	EUR	DKK	7.47064309	2026-01-20	2026-01-21 15:42:51.501403
3496	DKK	EUR	0.1338572848351667	2026-01-20	2026-01-21 15:42:51.507612
3497	EUR	DOP	73.95952274	2026-01-20	2026-01-21 15:42:51.514528
3498	DOP	EUR	0.01352090931570011	2026-01-20	2026-01-21 15:42:51.520661
3499	EUR	DZD	151.58497847	2026-01-20	2026-01-21 15:42:51.527374
3500	DZD	EUR	0.006596959738975117	2026-01-20	2026-01-21 15:42:51.533818
3501	EUR	EGP	55.21201123	2026-01-20	2026-01-21 15:42:51.539939
3502	EGP	EUR	0.01811200095273182	2026-01-20	2026-01-21 15:42:51.546714
3503	EUR	ERN	17.46314857	2026-01-20	2026-01-21 15:42:51.576706
3504	ERN	EUR	0.05726344227053667	2026-01-20	2026-01-21 15:42:51.583241
3505	EUR	ETB	181.47961861	2026-01-20	2026-01-21 15:42:51.589312
3506	ETB	EUR	0.005510260643367351	2026-01-20	2026-01-21 15:42:51.595589
3509	EUR	FJD	2.6460254	2026-01-20	2026-01-21 15:42:51.613294
3510	FJD	EUR	0.3779253215029606	2026-01-20	2026-01-21 15:42:51.619422
3511	EUR	FKP	0.86738201	2026-01-20	2026-01-21 15:42:51.625303
3512	FKP	EUR	1.1528945591112731	2026-01-20	2026-01-21 15:42:51.630977
3513	EUR	GBP	0.86738201	2026-01-20	2026-01-21 15:42:51.637629
3514	GBP	EUR	1.1528945591112731	2026-01-20	2026-01-21 15:42:51.643602
3515	EUR	GEL	3.13212531	2026-01-20	2026-01-21 15:42:51.677509
3517	EUR	GGP	0.86738201	2026-01-20	2026-01-21 15:42:51.690255
3518	GGP	EUR	1.1528945591112731	2026-01-20	2026-01-21 15:42:51.696605
3519	EUR	GHS	12.59348285	2026-01-20	2026-01-21 15:42:51.702497
3520	GHS	EUR	0.07940615093623604	2026-01-20	2026-01-21 15:42:51.708202
3521	EUR	GIP	0.86738201	2026-01-20	2026-01-21 15:42:51.715325
3522	GIP	EUR	1.1528945591112731	2026-01-20	2026-01-21 15:42:51.721373
3523	EUR	GMD	85.87822896	2026-01-20	2026-01-21 15:42:51.728082
3524	GMD	EUR	0.011644394768152192	2026-01-20	2026-01-21 15:42:51.73429
3525	EUR	GNF	10196.58573358	2026-01-20	2026-01-21 15:42:51.740677
3527	EUR	GTQ	8.92206474	2026-01-20	2026-01-21 15:42:51.782915
3528	GTQ	EUR	0.11208167942524927	2026-01-20	2026-01-21 15:42:51.788964
3529	EUR	GYD	243.21969868	2026-01-20	2026-01-21 15:42:51.795869
3530	GYD	EUR	0.004111509081818586	2026-01-20	2026-01-21 15:42:51.802281
3531	EUR	HKD	9.0782037	2026-01-20	2026-01-21 15:42:51.808074
3532	HKD	EUR	0.1101539503899874	2026-01-20	2026-01-21 15:42:51.814645
3533	EUR	HNL	30.68475655	2026-01-20	2026-01-21 15:42:51.820659
3534	HNL	EUR	0.032589471530286594	2026-01-20	2026-01-21 15:42:51.827011
3535	EUR	HRK	7.5345	2026-01-20	2026-01-21 15:42:51.832778
3536	HRK	EUR	0.13272280841462605	2026-01-20	2026-01-21 15:42:51.838976
3537	EUR	HTG	152.2783331	2026-01-20	2026-01-21 15:42:51.871219
3538	HTG	EUR	0.006566922421874081	2026-01-20	2026-01-21 15:42:51.878154
3539	EUR	HUF	385.62027058	2026-01-20	2026-01-21 15:42:51.883932
3540	HUF	EUR	0.0025932246728003422	2026-01-20	2026-01-21 15:42:51.889915
3541	EUR	IDR	19779.88430084	2026-01-20	2026-01-21 15:42:51.895585
3542	IDR	EUR	5.0556413009834064e-05	2026-01-20	2026-01-21 15:42:51.90107
3544	ILS	EUR	0.272229043586358	2026-01-20	2026-01-21 15:42:51.912426
3545	EUR	IMP	0.86738201	2026-01-20	2026-01-21 15:42:51.918038
3546	IMP	EUR	1.1528945591112731	2026-01-20	2026-01-21 15:42:51.924437
3547	EUR	INR	105.88259668	2026-01-20	2026-01-21 15:42:51.930429
3548	INR	EUR	0.009444422703593256	2026-01-20	2026-01-21 15:42:51.936282
3549	EUR	IQD	1523.38396206	2026-01-20	2026-01-21 15:42:51.942047
3550	IQD	EUR	0.0006564333253500631	2026-01-20	2026-01-21 15:42:51.947669
3551	EUR	IRR	1248856.54192747	2026-01-20	2026-01-21 15:42:51.953918
3552	IRR	EUR	8.007324832174977e-07	2026-01-20	2026-01-21 15:42:51.960741
3553	EUR	ISK	146.20389271	2026-01-20	2026-01-21 15:42:51.976144
3554	ISK	EUR	0.00683976316542769	2026-01-20	2026-01-21 15:42:51.981954
3555	EUR	JEP	0.86738201	2026-01-20	2026-01-21 15:42:51.987975
3556	JEP	EUR	1.1528945591112731	2026-01-20	2026-01-21 15:42:51.993785
3437	EUR	AWG	2.08393573	2026-01-20	2026-01-21 15:42:50.921386
3438	AWG	EUR	0.4798612479282171	2026-01-20	2026-01-21 15:42:50.977592
3440	AZN	EUR	0.5052580640424904	2026-01-20	2026-01-21 15:42:50.990492
3441	EUR	BAM	1.95583	2026-01-20	2026-01-21 15:42:50.996854
3442	BAM	EUR	0.5112918811962185	2026-01-20	2026-01-21 15:42:51.003522
3443	EUR	BBD	2.32841981	2026-01-20	2026-01-21 15:42:51.00982
3444	BBD	EUR	0.4294758169060587	2026-01-20	2026-01-21 15:42:51.016309
3566	KGS	EUR	0.009822486900892559	2026-01-20	2026-01-21 15:42:52.08136
3567	EUR	KHR	4683.99456263	2026-01-20	2026-01-21 15:42:52.087425
3568	KHR	EUR	0.00021349298907779124	2026-01-20	2026-01-21 15:42:52.093916
3569	EUR	KMF	491.96774997	2026-01-20	2026-01-21 15:42:52.100208
3570	KMF	EUR	0.002032653563289422	2026-01-20	2026-01-21 15:42:52.106488
3571	EUR	KRW	1720.9446911	2026-01-20	2026-01-21 15:42:52.112987
3572	KRW	EUR	0.0005810761991199241	2026-01-20	2026-01-21 15:42:52.119382
3573	EUR	KWD	0.35824795	2026-01-20	2026-01-21 15:42:52.125767
3574	KWD	EUR	2.791362797749436	2026-01-20	2026-01-21 15:42:52.132013
3575	EUR	KYD	0.96544542	2026-01-20	2026-01-21 15:42:52.13777
3576	KYD	EUR	1.0357913345324068	2026-01-20	2026-01-21 15:42:52.144585
3578	KZT	EUR	0.0016896046898105964	2026-01-20	2026-01-21 15:42:52.182437
3579	EUR	LAK	25113.01050496	2026-01-20	2026-01-21 15:42:52.188392
3580	LAK	EUR	3.981999688179531e-05	2026-01-20	2026-01-21 15:42:52.194723
3581	EUR	LBP	104442.59602678	2026-01-20	2026-01-21 15:42:52.200501
3582	LBP	EUR	9.574637533364176e-06	2026-01-20	2026-01-21 15:42:52.207305
3583	EUR	LKR	360.12952416	2026-01-20	2026-01-21 15:42:52.213862
3584	LKR	EUR	0.002776778722412427	2026-01-20	2026-01-21 15:42:52.219696
3585	EUR	LRD	210.4854112	2026-01-20	2026-01-21 15:42:52.226059
3586	LRD	EUR	0.004750923089153269	2026-01-20	2026-01-21 15:42:52.231972
3587	EUR	LSL	19.09464477	2026-01-20	2026-01-21 15:42:52.238476
3588	LSL	EUR	0.052370704563780165	2026-01-20	2026-01-21 15:42:52.24501
3589	EUR	LYD	6.31941666	2026-01-20	2026-01-21 15:42:52.278463
3590	LYD	EUR	0.15824245397992162	2026-01-20	2026-01-21 15:42:52.284879
3591	EUR	MAD	10.72913194	2026-01-20	2026-01-21 15:42:52.291076
3592	MAD	EUR	0.09320418516542169	2026-01-20	2026-01-21 15:42:52.297716
3593	EUR	MDL	19.85884563	2026-01-20	2026-01-21 15:42:52.303977
3595	EUR	MGA	5271.77514306	2026-01-20	2026-01-21 15:42:52.316826
3596	MGA	EUR	0.00018968942583153317	2026-01-20	2026-01-21 15:42:52.323221
3597	EUR	MKD	61.54455054	2026-01-20	2026-01-21 15:42:52.329667
3598	MKD	EUR	0.016248392282108944	2026-01-20	2026-01-21 15:42:52.336391
3599	EUR	MMK	2444.51537258	2026-01-20	2026-01-21 15:42:52.375359
3600	MMK	EUR	0.00040907903923082146	2026-01-20	2026-01-21 15:42:52.382014
3601	EUR	MNT	4148.75491459	2026-01-20	2026-01-21 15:42:52.388317
3602	MNT	EUR	0.0002410361712337555	2026-01-20	2026-01-21 15:42:52.395362
3603	EUR	MOP	9.35054981	2026-01-20	2026-01-21 15:42:52.401347
3604	MOP	EUR	0.10694558291433774	2026-01-20	2026-01-21 15:42:52.408012
3605	EUR	MRU	46.41420887	2026-01-20	2026-01-21 15:42:52.414443
3606	MRU	EUR	0.02154512646764844	2026-01-20	2026-01-21 15:42:52.42032
3607	EUR	MUR	53.86653733	2026-01-20	2026-01-21 15:42:52.426579
3608	MUR	EUR	0.01856440100973537	2026-01-20	2026-01-21 15:42:52.433407
3609	EUR	MVR	17.99873657	2026-01-20	2026-01-21 15:42:52.447617
3610	MVR	EUR	0.05555945530458976	2026-01-20	2026-01-21 15:42:52.476736
3612	MWK	EUR	0.0004957568637235173	2026-01-20	2026-01-21 15:42:52.489313
3613	EUR	MXN	20.48398813	2026-01-20	2026-01-21 15:42:52.495917
3614	MXN	EUR	0.04881861840836753	2026-01-20	2026-01-21 15:42:52.501877
3615	EUR	MYR	4.718618	2026-01-20	2026-01-21 15:42:52.507796
3616	MYR	EUR	0.21192645812820618	2026-01-20	2026-01-21 15:42:52.513936
3617	EUR	MZN	74.3872436	2026-01-20	2026-01-21 15:42:52.519939
3618	MZN	EUR	0.013443165139674565	2026-01-20	2026-01-21 15:42:52.525945
3619	EUR	NAD	19.09464477	2026-01-20	2026-01-21 15:42:52.532293
3620	NAD	EUR	0.052370704563780165	2026-01-20	2026-01-21 15:42:52.538212
3621	EUR	NGN	1651.32284463	2026-01-20	2026-01-21 15:42:52.576681
3622	NGN	EUR	0.0006055751019565547	2026-01-20	2026-01-21 15:42:52.582966
3623	EUR	NIO	42.78674866	2026-01-20	2026-01-21 15:42:52.588608
3624	NIO	EUR	0.023371722117667446	2026-01-20	2026-01-21 15:42:52.594012
3625	EUR	NOK	11.71675918	2026-01-20	2026-01-21 15:42:52.599398
3626	NOK	EUR	0.08534783250533617	2026-01-20	2026-01-21 15:42:52.605377
3627	EUR	NPR	169.49156664	2026-01-20	2026-01-21 15:42:52.610986
3629	EUR	NZD	2.00455215	2026-01-20	2026-01-21 15:42:52.624177
3630	NZD	EUR	0.4988645468764682	2026-01-20	2026-01-21 15:42:52.630417
3631	EUR	OMR	0.44810252	2026-01-20	2026-01-21 15:42:52.636515
3632	OMR	EUR	2.2316321720306327	2026-01-20	2026-01-21 15:42:52.642283
3633	EUR	PAB	1.1642099	2026-01-20	2026-01-21 15:42:52.674492
3634	PAB	EUR	0.858951637501107	2026-01-20	2026-01-21 15:42:52.68044
3635	EUR	PEN	3.90683377	2026-01-20	2026-01-21 15:42:52.686365
3636	PEN	EUR	0.2559617477658897	2026-01-20	2026-01-21 15:42:52.692351
3637	EUR	PGK	4.96975902	2026-01-20	2026-01-21 15:42:52.698311
3638	PGK	EUR	0.20121699985364683	2026-01-20	2026-01-21 15:42:52.705063
3639	EUR	PHP	69.22631304	2026-01-20	2026-01-21 15:42:52.711428
3640	PHP	EUR	0.014445374252738046	2026-01-20	2026-01-21 15:42:52.717795
3641	EUR	PKR	325.37471561	2026-01-20	2026-01-21 15:42:52.724013
3642	PKR	EUR	0.003073379559088476	2026-01-20	2026-01-21 15:42:52.730328
3643	EUR	PLN	4.22401521	2026-01-20	2026-01-21 15:42:52.737042
3644	PLN	EUR	0.23674157177099747	2026-01-20	2026-01-21 15:42:52.743072
3646	PYG	EUR	0.00012911111448757735	2026-01-20	2026-01-21 15:42:52.784595
3647	EUR	QAR	4.23772405	2026-01-20	2026-01-21 15:42:52.790968
3648	QAR	EUR	0.23597572380863263	2026-01-20	2026-01-21 15:42:52.79726
3649	EUR	RON	5.09240979	2026-01-20	2026-01-21 15:42:52.803264
3650	RON	EUR	0.19637068524290935	2026-01-20	2026-01-21 15:42:52.809518
3651	EUR	RSD	117.37709654	2026-01-20	2026-01-21 15:42:52.815556
3652	RSD	EUR	0.008519549635130207	2026-01-20	2026-01-21 15:42:52.821685
3653	EUR	RUB	90.24671028	2026-01-20	2026-01-21 15:42:52.827444
3654	RUB	EUR	0.01108073631600968	2026-01-20	2026-01-21 15:42:52.833157
3655	EUR	RWF	1695.54475555	2026-01-20	2026-01-21 15:42:52.838809
3656	RWF	EUR	0.0005897809519487561	2026-01-20	2026-01-21 15:42:52.874246
3657	EUR	SAR	4.36578714	2026-01-20	2026-01-21 15:42:52.879937
3658	SAR	EUR	0.22905376921331075	2026-01-20	2026-01-21 15:42:52.88592
3659	EUR	SBD	9.44790957	2026-01-20	2026-01-21 15:42:52.891459
3660	SBD	EUR	0.10584351941463385	2026-01-20	2026-01-21 15:42:52.897218
3661	EUR	SCR	15.83908296	2026-01-20	2026-01-21 15:42:52.902908
3663	EUR	SDG	698.62006592	2026-01-20	2026-01-21 15:42:52.914509
3664	SDG	EUR	0.0014313931831933832	2026-01-20	2026-01-21 15:42:52.921332
3665	EUR	SEK	10.7181004	2026-01-20	2026-01-21 15:42:52.927835
3666	SEK	EUR	0.09330011500918577	2026-01-20	2026-01-21 15:42:52.933843
3667	EUR	SGD	1.49692663	2026-01-20	2026-01-21 15:42:52.939841
3668	SGD	EUR	0.6680354133321819	2026-01-20	2026-01-21 15:42:52.946325
3669	EUR	SHP	0.86738201	2026-01-20	2026-01-21 15:42:52.97105
3670	SHP	EUR	1.1528945591112731	2026-01-20	2026-01-21 15:42:52.977997
3671	EUR	SLE	26.66598628	2026-01-20	2026-01-21 15:42:52.983977
3672	SLE	EUR	0.03750095681816274	2026-01-20	2026-01-21 15:42:52.989698
3673	EUR	SOS	662.09763623	2026-01-20	2026-01-21 15:42:52.996252
3674	SOS	EUR	0.0015103512613245747	2026-01-20	2026-01-21 15:42:53.002514
3675	EUR	SRD	44.6410628	2026-01-20	2026-01-21 15:42:53.008946
3676	SRD	EUR	0.02240090036566065	2026-01-20	2026-01-21 15:42:53.015094
3558	JMD	EUR	0.00544933547340457	2026-01-20	2026-01-21 15:42:52.005565
3559	EUR	JOD	0.82542482	2026-01-20	2026-01-21 15:42:52.01188
3561	EUR	JPY	183.99283631	2026-01-20	2026-01-21 15:42:52.02434
3562	JPY	EUR	0.005434994209856909	2026-01-20	2026-01-21 15:42:52.030789
3563	EUR	KES	150.05939373	2026-01-20	2026-01-21 15:42:52.03752
3564	KES	EUR	0.006664027990138941	2026-01-20	2026-01-21 15:42:52.043784
3565	EUR	KGS	101.80721136	2026-01-20	2026-01-21 15:42:52.075038
3700	TVD	EUR	0.5764844022258271	2026-01-20	2026-01-21 15:42:53.226296
3701	EUR	TWD	36.83044895	2026-01-20	2026-01-21 15:42:53.232718
3702	TWD	EUR	0.027151447471019767	2026-01-20	2026-01-21 15:42:53.239512
3703	EUR	TZS	2939.74113299	2026-01-20	2026-01-21 15:42:53.276936
6308	EUR	ANG	2.11322495	2026-01-21	2026-01-22 12:43:27.636324
3725	EUR	XCD	3.15050975	2026-01-20	2026-01-21 15:42:53.475422
3726	XCD	EUR	0.3174089526306021	2026-01-20	2026-01-21 15:42:53.482202
3727	EUR	XDR	0.85365695	2026-01-20	2026-01-21 15:42:53.488372
3728	XDR	EUR	1.1714307486162914	2026-01-20	2026-01-21 15:42:53.496326
3729	EUR	XOF	655.95699997	2026-01-20	2026-01-21 15:42:53.5026
3730	XOF	EUR	0.001524490172443826	2026-01-20	2026-01-21 15:42:53.508989
3731	EUR	XPF	119.33174224	2026-01-20	2026-01-21 15:42:53.515653
3732	XPF	EUR	0.008380000000241344	2026-01-20	2026-01-21 15:42:53.522219
3733	EUR	YER	277.63163699	2026-01-20	2026-01-21 15:42:53.52934
3734	YER	EUR	0.0036018949815723594	2026-01-20	2026-01-21 15:42:53.577322
3735	EUR	ZAR	19.09464477	2026-01-20	2026-01-21 15:42:53.584509
3736	ZAR	EUR	0.052370704563780165	2026-01-20	2026-01-21 15:42:53.590652
3737	EUR	ZMW	23.31229346	2026-01-20	2026-01-21 15:42:53.597821
3738	ZMW	EUR	0.04289582240013549	2026-01-20	2026-01-21 15:42:53.60566
3739	EUR	ZWL	74523.28206904	2026-01-20	2026-01-21 15:42:53.615
3740	ZWL	EUR	1.341862532401053e-05	2026-01-20	2026-01-21 15:42:53.621357
6309	ANG	EUR	0.47321038869998194	2026-01-21	2026-01-22 12:43:27.645224
6310	EUR	AOA	1075.64931209	2026-01-21	2026-01-22 12:43:27.654099
6311	AOA	EUR	0.0009296710263840429	2026-01-21	2026-01-22 12:43:27.662887
6312	EUR	ARS	1682.16220162	2026-01-21	2026-01-22 12:43:27.672781
6313	ARS	EUR	0.0005944729937677554	2026-01-21	2026-01-22 12:43:27.73179
6314	EUR	AUD	1.74016706	2026-01-21	2026-01-22 12:43:27.740544
6315	AUD	EUR	0.5746574699557868	2026-01-21	2026-01-22 12:43:27.749756
6316	EUR	AWG	2.09941153	2026-01-21	2026-01-22 12:43:27.758281
6317	AWG	EUR	0.4763239535032944	2026-01-21	2026-01-22 12:43:27.834521
6318	EUR	AZN	1.99381176	2026-01-21	2026-01-22 12:43:27.843563
3439	EUR	AZN	1.97918662	2026-01-20	2026-01-21 15:42:50.984298
3456	BND	EUR	0.6680354133321819	2026-01-20	2026-01-21 15:42:51.116878
3473	EUR	CDF	2655.85088823	2026-01-20	2026-01-21 15:42:51.275152
3490	CVE	EUR	0.00906864967888534	2026-01-20	2026-01-21 15:42:51.423215
3645	EUR	PYG	7745.26657886	2026-01-20	2026-01-21 15:42:52.777861
3507	EUR	EUR	1	2026-01-20	2026-01-21 15:42:51.607234
3526	GNF	EUR	9.80720435377443e-05	2026-01-20	2026-01-21 15:42:51.77664
3543	EUR	ILS	3.67337734	2026-01-20	2026-01-21 15:42:51.906762
3557	EUR	JMD	183.50861401	2026-01-20	2026-01-21 15:42:51.999336
3662	SCR	EUR	0.0631349682633394	2026-01-20	2026-01-21 15:42:52.908686
3677	EUR	SSP	5302.01650544	2026-01-20	2026-01-21 15:42:53.020876
3678	SSP	EUR	0.00018860748527922824	2026-01-20	2026-01-21 15:42:53.027278
3679	EUR	STN	24.65286422	2026-01-20	2026-01-21 15:42:53.033636
3680	STN	EUR	0.04056323805120929	2026-01-20	2026-01-21 15:42:53.040287
3681	EUR	SYP	128.7641955	2026-01-20	2026-01-21 15:42:53.046241
3682	SYP	EUR	0.007766134025976188	2026-01-20	2026-01-21 15:42:53.075191
3683	EUR	SZL	19.09464477	2026-01-20	2026-01-21 15:42:53.081996
3684	SZL	EUR	0.052370704563780165	2026-01-20	2026-01-21 15:42:53.088384
3685	EUR	THB	36.38024506	2026-01-20	2026-01-21 15:42:53.094457
3704	TZS	EUR	0.00034016600603975754	2026-01-20	2026-01-21 15:42:53.283378
3686	THB	EUR	0.027487445407548886	2026-01-20	2026-01-21 15:42:53.100432
3687	EUR	TJS	10.83820876	2026-01-20	2026-01-21 15:42:53.106293
3688	TJS	EUR	0.0922661688978207	2026-01-20	2026-01-21 15:42:53.112063
3689	EUR	TMT	4.08311697	2026-01-20	2026-01-21 15:42:53.118216
3690	TMT	EUR	0.24491093626445878	2026-01-20	2026-01-21 15:42:53.124658
3691	EUR	TND	3.37059789	2026-01-20	2026-01-21 15:42:53.130783
3692	TND	EUR	0.29668326885471347	2026-01-20	2026-01-21 15:42:53.137652
3693	EUR	TOP	2.78502237	2026-01-20	2026-01-21 15:42:53.178875
3694	TOP	EUR	0.35906354317721334	2026-01-20	2026-01-21 15:42:53.185033
3705	EUR	UAH	50.39516741	2026-01-20	2026-01-21 15:42:53.289167
3706	UAH	EUR	0.019843172498352855	2026-01-20	2026-01-21 15:42:53.295268
3707	EUR	UGX	4052.10952464	2026-01-20	2026-01-21 15:42:53.300881
3708	UGX	EUR	0.0002467850372550931	2026-01-20	2026-01-21 15:42:53.307288
3709	EUR	USD	1.1642099	2026-01-20	2026-01-21 15:42:53.313365
3710	USD	EUR	0.858951637501107	2026-01-20	2026-01-21 15:42:53.319484
3711	EUR	UYU	44.89270859	2026-01-20	2026-01-21 15:42:53.325918
3712	UYU	EUR	0.02227533226236996	2026-01-20	2026-01-21 15:42:53.332486
3713	EUR	UZS	13991.58975911	2026-01-20	2026-01-21 15:42:53.339114
3714	UZS	EUR	7.147150661338499e-05	2026-01-20	2026-01-21 15:42:53.345368
3715	EUR	VES	398.97098542	2026-01-20	2026-01-21 15:42:53.376015
3716	VES	EUR	0.002506447928656496	2026-01-20	2026-01-21 15:42:53.382054
3717	EUR	VND	30575.47909716	2026-01-20	2026-01-21 15:42:53.388411
3718	VND	EUR	3.270594703756857e-05	2026-01-20	2026-01-21 15:42:53.394553
3719	EUR	VUV	141.13324202	2026-01-20	2026-01-21 15:42:53.400458
3560	JOD	EUR	1.211497371741257	2026-01-20	2026-01-21 15:42:52.017881
3720	VUV	EUR	0.007085502931040795	2026-01-20	2026-01-21 15:42:53.406292
6319	AZN	EUR	0.5015518616461566	2026-01-21	2026-01-22 12:43:27.927248
3577	EUR	KZT	591.8544178	2026-01-20	2026-01-21 15:42:52.176136
3594	MDL	EUR	0.05035539419720037	2026-01-20	2026-01-21 15:42:52.310003
3611	EUR	MWK	2017.11781152	2026-01-20	2026-01-21 15:42:52.483178
3628	NPR	EUR	0.005899998565261948	2026-01-20	2026-01-21 15:42:52.617603
3695	EUR	TRY	50.39073611	2026-01-20	2026-01-21 15:42:53.19122
3696	TRY	EUR	0.019844917482790072	2026-01-20	2026-01-21 15:42:53.198461
3697	EUR	TTD	7.89681267	2026-01-20	2026-01-21 15:42:53.205386
3698	TTD	EUR	0.12663336991632093	2026-01-20	2026-01-21 15:42:53.211373
3699	EUR	TVD	1.73465231	2026-01-20	2026-01-21 15:42:53.218654
3721	EUR	WST	3.20540761	2026-01-20	2026-01-21 15:42:53.41234
3722	WST	EUR	0.3119728039829543	2026-01-20	2026-01-21 15:42:53.418628
3723	EUR	XAF	655.95699997	2026-01-20	2026-01-21 15:42:53.434778
3724	XAF	EUR	0.001524490172443826	2026-01-20	2026-01-21 15:42:53.441322
6300	EUR	AED	4.3073122	2026-01-21	2026-01-22 12:43:27.227785
6301	AED	EUR	0.23216334307041872	2026-01-21	2026-01-22 12:43:27.234237
6302	EUR	AFN	76.89136886	2026-01-21	2026-01-22 12:43:27.328741
6303	AFN	EUR	0.013005360872437458	2026-01-21	2026-01-22 12:43:27.338059
6304	EUR	ALL	96.47057627	2026-01-21	2026-01-22 12:43:27.527069
6305	ALL	EUR	0.010365854944218631	2026-01-21	2026-01-22 12:43:27.536279
6306	EUR	AMD	444.80790479	2026-01-21	2026-01-22 12:43:27.544841
6307	AMD	EUR	0.002248161485511625	2026-01-21	2026-01-22 12:43:27.553311
9183	AFN	EUR	0.01284731108435186	2026-01-27	2026-01-28 03:07:38.964776
9184	EUR	ALL	96.65425844	2026-01-27	2026-01-28 03:07:38.974492
9185	ALL	EUR	0.01034615562873279	2026-01-27	2026-01-28 03:07:39.033659
9186	EUR	AMD	444.40664452	2026-01-27	2026-01-28 03:07:39.047759
9188	EUR	ANG	2.13211396	2026-01-27	2026-01-28 03:07:39.068566
9189	ANG	EUR	0.46901808194154876	2026-01-27	2026-01-28 03:07:39.078445
9190	EUR	AOA	1089.36632858	2026-01-27	2026-01-28 03:07:39.088499
9191	AOA	EUR	0.0009179648514595728	2026-01-27	2026-01-28 03:07:39.102232
9192	EUR	ARS	1708.27661188	2026-01-27	2026-01-28 03:07:39.130403
9193	ARS	EUR	0.0005853852900903886	2026-01-27	2026-01-28 03:07:39.141142
9194	EUR	AUD	1.71698112	2026-01-27	2026-01-28 03:07:39.151599
9195	AUD	EUR	0.5824175865137061	2026-01-27	2026-01-28 03:07:39.163373
9182	EUR	AFN	77.83729945	2026-01-27	2026-01-28 03:07:38.955378
6386	EUR	EUR	1	2026-01-21	2026-01-22 12:43:29.162883
6323	BBD	EUR	0.42630993778641657	2026-01-21	2026-01-22 12:43:27.961339
6324	EUR	BDT	143.4854925	2026-01-21	2026-01-22 12:43:27.969313
6325	BDT	EUR	0.006969345698834326	2026-01-21	2026-01-22 12:43:27.977225
6326	EUR	BGN	1.95583	2026-01-21	2026-01-22 12:43:27.985375
6327	BGN	EUR	0.5112918811962185	2026-01-21	2026-01-22 12:43:27.99406
6328	EUR	BHD	0.44099371	2026-01-21	2026-01-22 12:43:28.031869
6329	BHD	EUR	2.267606039097474	2026-01-21	2026-01-22 12:43:28.040566
6330	EUR	BIF	3473.83176166	2026-01-21	2026-01-22 12:43:28.049532
6331	BIF	EUR	0.00028786656021653203	2026-01-21	2026-01-22 12:43:28.136248
6332	EUR	BMD	1.1728556	2026-01-21	2026-01-22 12:43:28.145051
6333	BMD	EUR	0.8526198792076364	2026-01-21	2026-01-22 12:43:28.153838
6334	EUR	BND	1.50561349	2026-01-21	2026-01-22 12:43:28.232112
6335	BND	EUR	0.6641810840842027	2026-01-21	2026-01-22 12:43:28.240913
6336	EUR	BOB	8.11099813	2026-01-21	2026-01-22 12:43:28.250438
6337	BOB	EUR	0.1232893885527255	2026-01-21	2026-01-22 12:43:28.331944
6338	EUR	BRL	6.30613333	2026-01-21	2026-01-22 12:43:28.342478
6340	EUR	BSD	1.1728556	2026-01-21	2026-01-22 12:43:28.428391
6341	BSD	EUR	0.8526198792076364	2026-01-21	2026-01-22 12:43:28.439641
6342	EUR	BTN	106.83801116	2026-01-21	2026-01-22 12:43:28.454547
6343	BTN	EUR	0.00935996457761092	2026-01-21	2026-01-22 12:43:28.464009
6344	EUR	BWP	16.05030802	2026-01-21	2026-01-22 12:43:28.473754
6345	BWP	EUR	0.06230410025489343	2026-01-21	2026-01-22 12:43:28.48305
6346	EUR	BYN	3.38343823	2026-01-21	2026-01-22 12:43:28.535431
6347	BYN	EUR	0.29555733902078657	2026-01-21	2026-01-22 12:43:28.549719
6348	EUR	BZD	2.36165716	2026-01-21	2026-01-22 12:43:28.63729
6349	BZD	EUR	0.4234314857114993	2026-01-21	2026-01-22 12:43:28.647394
6350	EUR	CAD	1.62187045	2026-01-21	2026-01-22 12:43:28.657863
6351	CAD	EUR	0.6165720572811472	2026-01-21	2026-01-22 12:43:28.730152
6352	EUR	CDF	2508.88742686	2026-01-21	2026-01-22 12:43:28.738764
6353	CDF	EUR	0.00039858304892202793	2026-01-21	2026-01-22 12:43:28.74777
6354	EUR	CHF	0.92629885	2026-01-21	2026-01-22 12:43:28.756577
6355	CHF	EUR	1.079565196480596	2026-01-21	2026-01-22 12:43:28.765179
6357	CLP	EUR	0.0009623320827422456	2026-01-21	2026-01-22 12:43:28.832075
6358	EUR	CNH	8.16386387	2026-01-21	2026-01-22 12:43:28.841154
6359	CNH	EUR	0.12249101845937566	2026-01-21	2026-01-22 12:43:28.849889
6360	EUR	CNY	8.16848312	2026-01-21	2026-01-22 12:43:28.858683
6361	CNY	EUR	0.12242175019638163	2026-01-21	2026-01-22 12:43:28.867883
6362	EUR	COP	4308.82333211	2026-01-21	2026-01-22 12:43:28.876309
6363	COP	EUR	0.00023208192188986946	2026-01-21	2026-01-22 12:43:28.884771
6364	EUR	CRC	571.94743681	2026-01-21	2026-01-22 12:43:28.894975
6365	CRC	EUR	0.001748412416318247	2026-01-21	2026-01-22 12:43:28.931952
6366	EUR	CUP	28.14846102	2026-01-21	2026-01-22 12:43:28.94107
6367	CUP	EUR	0.035525920912318494	2026-01-21	2026-01-22 12:43:28.950424
6368	EUR	CVE	110.27	2026-01-21	2026-01-22 12:43:28.9592
6369	CVE	EUR	0.009068649678062937	2026-01-21	2026-01-22 12:43:28.967838
6370	EUR	CZK	24.33649802	2026-01-21	2026-01-22 12:43:28.976308
6371	CZK	EUR	0.04109054635462296	2026-01-21	2026-01-22 12:43:28.984978
6372	EUR	DJF	208.684061	2026-01-21	2026-01-22 12:43:28.993185
6374	EUR	DKK	7.47056589	2026-01-21	2026-01-22 12:43:29.030044
6375	DKK	EUR	0.1338586681015138	2026-01-21	2026-01-22 12:43:29.039087
6376	EUR	DOP	74.26247324	2026-01-21	2026-01-22 12:43:29.047856
6377	DOP	EUR	0.01346575135961631	2026-01-21	2026-01-22 12:43:29.056842
6378	EUR	DZD	152.21382607	2026-01-21	2026-01-22 12:43:29.065742
6379	DZD	EUR	0.0065697054322786715	2026-01-21	2026-01-22 12:43:29.074763
6380	EUR	EGP	55.67239984	2026-01-21	2026-01-22 12:43:29.083429
6381	EGP	EUR	0.017962221906617202	2026-01-21	2026-01-22 12:43:29.091874
6382	EUR	ERN	17.59283405	2026-01-21	2026-01-22 12:43:29.100322
6383	ERN	EUR	0.05684132511896228	2026-01-21	2026-01-22 12:43:29.108555
6384	EUR	ETB	182.99539534	2026-01-21	2026-01-22 12:43:29.136365
6385	ETB	EUR	0.005464618375462562	2026-01-21	2026-01-22 12:43:29.145357
6388	EUR	FJD	2.66116398	2026-01-21	2026-01-22 12:43:29.171391
6389	FJD	EUR	0.3757754153879687	2026-01-21	2026-01-22 12:43:29.180216
6390	EUR	FKP	0.87202912	2026-01-21	2026-01-22 12:43:29.188888
6391	FKP	EUR	1.1467506956648421	2026-01-21	2026-01-22 12:43:29.197359
6393	GBP	EUR	1.1467506956648421	2026-01-21	2026-01-22 12:43:29.214439
6394	EUR	GEL	3.15583118	2026-01-21	2026-01-22 12:43:29.232246
6395	GEL	EUR	0.3168737308692159	2026-01-21	2026-01-22 12:43:29.241126
6396	EUR	GGP	0.87202912	2026-01-21	2026-01-22 12:43:29.249734
6397	GGP	EUR	1.1467506956648421	2026-01-21	2026-01-22 12:43:29.258008
6398	EUR	GHS	12.72347149	2026-01-21	2026-01-22 12:43:29.266112
6399	GHS	EUR	0.07859490240426514	2026-01-21	2026-01-22 12:43:29.274561
6400	EUR	GIP	0.87202912	2026-01-21	2026-01-22 12:43:29.283525
6401	GIP	EUR	1.1467506956648421	2026-01-21	2026-01-22 12:43:29.291994
6402	EUR	GMD	86.54958012	2026-01-21	2026-01-22 12:43:29.300989
6403	GMD	EUR	0.011554071072482517	2026-01-21	2026-01-22 12:43:29.309715
6404	EUR	GNF	10266.42063231	2026-01-21	2026-01-22 12:43:29.327173
6405	GNF	EUR	9.740493165191835e-05	2026-01-21	2026-01-22 12:43:29.336121
6406	EUR	GTQ	8.99825927	2026-01-21	2026-01-22 12:43:29.345099
6407	GTQ	EUR	0.11113260576231429	2026-01-21	2026-01-22 12:43:29.354089
6408	EUR	GYD	245.2365359	2026-01-21	2026-01-22 12:43:29.362723
6410	EUR	HKD	9.14552974	2026-01-21	2026-01-22 12:43:29.379425
6411	HKD	EUR	0.10934303735586562	2026-01-21	2026-01-22 12:43:29.388385
6412	EUR	HNL	30.92804637	2026-01-21	2026-01-22 12:43:29.39724
6413	HNL	EUR	0.032333112413139464	2026-01-21	2026-01-22 12:43:29.434297
6414	EUR	HRK	7.5345	2026-01-21	2026-01-22 12:43:29.443211
6415	HRK	EUR	0.13272280841462605	2026-01-21	2026-01-22 12:43:29.452233
6416	EUR	HTG	153.62531251	2026-01-21	2026-01-22 12:43:29.461091
6417	HTG	EUR	0.006509343959413633	2026-01-21	2026-01-22 12:43:29.469844
6418	EUR	HUF	385.06083709	2026-01-21	2026-01-22 12:43:29.478584
6419	HUF	EUR	0.0025969922248059484	2026-01-21	2026-01-22 12:43:29.487333
6420	EUR	IDR	19885.90443661	2026-01-21	2026-01-22 12:43:29.495854
6421	IDR	EUR	5.0286875469390145e-05	2026-01-21	2026-01-22 12:43:29.504026
6422	EUR	ILS	3.71898922	2026-01-21	2026-01-22 12:43:29.512942
6423	ILS	EUR	0.26889026583411285	2026-01-21	2026-01-22 12:43:29.529945
6424	EUR	IMP	0.87202912	2026-01-21	2026-01-22 12:43:29.538102
6425	IMP	EUR	1.1467506956648421	2026-01-21	2026-01-22 12:43:29.546358
6427	INR	EUR	0.00935996457761092	2026-01-21	2026-01-22 12:43:29.563111
6428	EUR	IQD	1537.02013766	2026-01-21	2026-01-22 12:43:29.571816
6429	IQD	EUR	0.0006506095629445859	2026-01-21	2026-01-22 12:43:29.580391
6430	EUR	IRR	1256063.95802081	2026-01-21	2026-01-22 12:43:29.590556
6431	IRR	EUR	7.961378030269318e-07	2026-01-21	2026-01-22 12:43:29.600221
6432	EUR	ISK	146.20565821	2026-01-21	2026-01-22 12:43:29.635128
6433	ISK	EUR	0.006839680572168193	2026-01-21	2026-01-22 12:43:29.644834
6434	EUR	JEP	0.87202912	2026-01-21	2026-01-22 12:43:29.655533
6435	JEP	EUR	1.1467506956648421	2026-01-21	2026-01-22 12:43:29.664284
6436	EUR	JMD	184.73982558	2026-01-21	2026-01-22 12:43:29.673946
6437	JMD	EUR	0.0054130179936050585	2026-01-21	2026-01-22 12:43:29.683531
6438	EUR	JOD	0.83155462	2026-01-21	2026-01-22 12:43:29.69248
6439	JOD	EUR	1.2025668259771078	2026-01-21	2026-01-22 12:43:29.73482
6320	EUR	BAM	1.95583	2026-01-21	2026-01-22 12:43:27.9359
6321	BAM	EUR	0.5112918811962185	2026-01-21	2026-01-22 12:43:27.944473
6444	EUR	KGS	102.57476317	2026-01-21	2026-01-22 12:43:29.779504
6445	KGS	EUR	0.009748986681477122	2026-01-21	2026-01-22 12:43:29.787794
6446	EUR	KHR	4722.7716257	2026-01-21	2026-01-22 12:43:29.832255
6447	KHR	EUR	0.00021174007113921835	2026-01-21	2026-01-22 12:43:29.841145
6448	EUR	KMF	491.96775001	2026-01-21	2026-01-22 12:43:29.849525
6449	KMF	EUR	0.002032653563124155	2026-01-21	2026-01-22 12:43:29.857814
6450	EUR	KRW	1726.37372791	2026-01-21	2026-01-22 12:43:29.8665
6451	KRW	EUR	0.000579248851991411	2026-01-21	2026-01-22 12:43:29.875357
6452	EUR	KWD	0.3605804	2026-01-21	2026-01-22 12:43:29.883976
6453	KWD	EUR	2.773306591262309	2026-01-21	2026-01-22 12:43:29.893001
6454	EUR	KYD	0.9754271	2026-01-21	2026-01-22 12:43:29.901999
6455	KYD	EUR	1.025191938997799	2026-01-21	2026-01-22 12:43:29.932229
6456	EUR	KZT	596.10895086	2026-01-21	2026-01-22 12:43:29.952781
6457	KZT	EUR	0.0016775456878433224	2026-01-21	2026-01-22 12:43:29.96558
6458	EUR	LAK	25351.92577948	2026-01-21	2026-01-22 12:43:29.974081
6459	LAK	EUR	3.944473523227991e-05	2026-01-21	2026-01-22 12:43:29.982979
6461	LBP	EUR	9.538904743311685e-06	2026-01-21	2026-01-22 12:43:30.000377
6462	EUR	LKR	363.34388916	2026-01-21	2026-01-22 12:43:30.00959
6463	LKR	EUR	0.002752213618651629	2026-01-21	2026-01-22 12:43:30.026873
6464	EUR	LRD	215.88109348	2026-01-21	2026-01-22 12:43:30.036212
6465	LRD	EUR	0.00463217961276745	2026-01-21	2026-01-22 12:43:30.044695
6466	EUR	LSL	19.23578414	2026-01-21	2026-01-22 12:43:30.053955
6467	LSL	EUR	0.05198644322071291	2026-01-21	2026-01-22 12:43:30.062904
6468	EUR	LYD	6.39800786	2026-01-21	2026-01-22 12:43:30.071728
6469	LYD	EUR	0.15629865137427323	2026-01-21	2026-01-22 12:43:30.080657
6470	EUR	MAD	10.76231052	2026-01-21	2026-01-22 12:43:30.08994
6471	MAD	EUR	0.09291685072101041	2026-01-21	2026-01-22 12:43:30.130024
6472	EUR	MDL	19.98903069	2026-01-21	2026-01-22 12:43:30.139049
6473	MDL	EUR	0.05002743832397408	2026-01-21	2026-01-22 12:43:30.147861
6474	EUR	MGA	5334.06597015	2026-01-21	2026-01-22 12:43:30.156803
6475	MGA	EUR	0.00018747424677461927	2026-01-21	2026-01-22 12:43:30.165574
6476	EUR	MKD	61.62183577	2026-01-21	2026-01-22 12:43:30.174107
6478	EUR	MMK	2463.16026761	2026-01-21	2026-01-22 12:43:30.19143
6479	MMK	EUR	0.00040598251488129845	2026-01-21	2026-01-22 12:43:30.199835
6480	EUR	MNT	4182.71512527	2026-01-21	2026-01-22 12:43:30.208337
6481	MNT	EUR	0.000239079155536668	2026-01-21	2026-01-22 12:43:30.227252
6482	EUR	MOP	9.41989563	2026-01-21	2026-01-22 12:43:30.236217
6483	MOP	EUR	0.10615828871980826	2026-01-21	2026-01-22 12:43:30.24507
6484	EUR	MRU	46.84197196	2026-01-21	2026-01-22 12:43:30.253473
6485	MRU	EUR	0.021348375359900196	2026-01-21	2026-01-22 12:43:30.262004
6486	EUR	MUR	54.15366648	2026-01-21	2026-01-22 12:43:30.27033
6487	MUR	EUR	0.01846597035806097	2026-01-21	2026-01-22 12:43:30.278678
6488	EUR	MVR	18.13162888	2026-01-21	2026-01-22 12:43:30.287014
6489	MVR	EUR	0.055152242891042445	2026-01-21	2026-01-22 12:43:30.295771
6490	EUR	MWK	2033.90865586	2026-01-21	2026-01-22 12:43:30.304806
6491	MWK	EUR	0.0004916641645232435	2026-01-21	2026-01-22 12:43:30.331818
6492	EUR	MXN	20.62006071	2026-01-21	2026-01-22 12:43:30.340646
6493	MXN	EUR	0.04849646245294687	2026-01-21	2026-01-22 12:43:30.349948
6495	MYR	EUR	0.21017093576309878	2026-01-21	2026-01-22 12:43:30.367532
6496	EUR	MZN	74.94437777	2026-01-21	2026-01-22 12:43:30.380549
6497	MZN	EUR	0.013343229068749395	2026-01-21	2026-01-22 12:43:30.38958
6498	EUR	NAD	19.23578414	2026-01-21	2026-01-22 12:43:30.39864
6499	NAD	EUR	0.05198644322071291	2026-01-21	2026-01-22 12:43:30.40758
6500	EUR	NGN	1664.93352817	2026-01-21	2026-01-22 12:43:30.416041
6501	NGN	EUR	0.0006006245793483076	2026-01-21	2026-01-22 12:43:30.433709
6502	EUR	NIO	43.16180409	2026-01-21	2026-01-22 12:43:30.441993
6503	NIO	EUR	0.023168633032920105	2026-01-21	2026-01-22 12:43:30.450429
6504	EUR	NOK	11.70532319	2026-01-21	2026-01-22 12:43:30.458856
6505	NOK	EUR	0.08543121653012642	2026-01-21	2026-01-22 12:43:30.466886
6506	EUR	NPR	171.02094636	2026-01-21	2026-01-22 12:43:30.475335
6507	NPR	EUR	0.005847236968827167	2026-01-21	2026-01-22 12:43:30.483914
6508	EUR	NZD	2.01102349	2026-01-21	2026-01-22 12:43:30.492573
6509	NZD	EUR	0.49725923390382676	2026-01-21	2026-01-22 12:43:30.507629
6510	EUR	OMR	0.45145521	2026-01-21	2026-01-22 12:43:30.516097
6512	EUR	PAB	1.1728556	2026-01-21	2026-01-22 12:43:30.532983
6513	PAB	EUR	0.8526198792076364	2026-01-21	2026-01-22 12:43:30.541021
6514	EUR	PEN	3.93842061	2026-01-21	2026-01-22 12:43:30.54896
6515	PEN	EUR	0.25390888861918687	2026-01-21	2026-01-22 12:43:30.556871
6516	EUR	PGK	5.01214079	2026-01-21	2026-01-22 12:43:30.564944
6517	PGK	EUR	0.19951554473392993	2026-01-21	2026-01-22 12:43:30.573113
6518	EUR	PHP	69.6160627	2026-01-21	2026-01-22 12:43:30.581159
6519	PHP	EUR	0.014364500967389527	2026-01-21	2026-01-22 12:43:30.589547
6520	EUR	PKR	328.26984621	2026-01-21	2026-01-22 12:43:30.597555
6521	PKR	EUR	0.003046274312262852	2026-01-21	2026-01-22 12:43:30.605701
6522	EUR	PLN	4.22374924	2026-01-21	2026-01-22 12:43:30.613672
6523	PLN	EUR	0.23675647941637748	2026-01-21	2026-01-22 12:43:30.631284
6524	EUR	PYG	7830.41580716	2026-01-21	2026-01-22 12:43:30.639428
6525	PYG	EUR	0.0001277071390111387	2026-01-21	2026-01-22 12:43:30.64771
6526	EUR	QAR	4.2691944	2026-01-21	2026-01-22 12:43:30.655853
6527	QAR	EUR	0.2342362296736827	2026-01-21	2026-01-22 12:43:30.664491
6529	RON	EUR	0.19636733469603362	2026-01-21	2026-01-22 12:43:30.681991
6530	EUR	RSD	117.41283426	2026-01-21	2026-01-22 12:43:30.690234
6531	RSD	EUR	0.008516956483527101	2026-01-21	2026-01-22 12:43:30.698359
6532	EUR	RUB	91.54158645	2026-01-21	2026-01-22 12:43:30.706391
6533	RUB	EUR	0.010923996827891986	2026-01-21	2026-01-22 12:43:30.71429
6534	EUR	RWF	1709.02626202	2026-01-21	2026-01-22 12:43:30.722275
6535	RWF	EUR	0.0005851285157069736	2026-01-21	2026-01-22 12:43:30.730586
6536	EUR	SAR	4.39820851	2026-01-21	2026-01-22 12:43:30.739559
6537	SAR	EUR	0.22736530060508658	2026-01-21	2026-01-22 12:43:30.748051
6538	EUR	SBD	9.50426264	2026-01-21	2026-01-22 12:43:30.75639
6539	SBD	EUR	0.10521594760979795	2026-01-21	2026-01-22 12:43:30.76478
6540	EUR	SCR	16.62302056	2026-01-21	2026-01-22 12:43:30.773073
6541	SCR	EUR	0.06015753854063692	2026-01-21	2026-01-22 12:43:30.781256
6542	EUR	SDG	703.70203339	2026-01-21	2026-01-22 12:43:30.789448
6543	SDG	EUR	0.0014210560046027153	2026-01-21	2026-01-22 12:43:30.798278
6544	EUR	SEK	10.6933873	2026-01-21	2026-01-22 12:43:30.806903
6546	EUR	SGD	1.50561349	2026-01-21	2026-01-22 12:43:30.833287
6547	SGD	EUR	0.6641810840842027	2026-01-21	2026-01-22 12:43:30.841919
6548	EUR	SHP	0.87202912	2026-01-21	2026-01-22 12:43:30.850714
6549	SHP	EUR	1.1467506956648421	2026-01-21	2026-01-22 12:43:30.859031
6550	EUR	SLE	26.99678707	2026-01-21	2026-01-22 12:43:30.867812
6551	SLE	EUR	0.037041444872943544	2026-01-21	2026-01-22 12:43:30.876138
6552	EUR	SOS	667.71192326	2026-01-21	2026-01-22 12:43:30.884498
6553	SOS	EUR	0.0014976518542871825	2026-01-21	2026-01-22 12:43:30.893109
6554	EUR	SRD	44.97584413	2026-01-21	2026-01-22 12:43:30.901477
6555	SRD	EUR	0.022234157453711365	2026-01-21	2026-01-22 12:43:30.909828
6556	EUR	SSP	5337.84681383	2026-01-21	2026-01-22 12:43:30.934042
6557	SSP	EUR	0.00018734145712257376	2026-01-21	2026-01-22 12:43:30.942662
6558	EUR	STN	24.74453324	2026-01-21	2026-01-22 12:43:30.951083
6559	STN	EUR	0.04041296678748748	2026-01-21	2026-01-22 12:43:30.95921
6441	JPY	EUR	0.005396206008239679	2026-01-21	2026-01-22 12:43:29.753315
6442	EUR	KES	151.35858539	2026-01-21	2026-01-22 12:43:29.762027
6592	EUR	UZS	14149.09841674	2026-01-21	2026-01-22 12:43:31.310222
6593	UZS	EUR	7.067588128561504e-05	2026-01-21	2026-01-22 12:43:31.318849
6594	EUR	VES	403.49326164	2026-01-21	2026-01-22 12:43:31.333793
6595	VES	EUR	0.0024783561339673825	2026-01-21	2026-01-22 12:43:31.342272
6596	EUR	VND	30809.0636371	2026-01-21	2026-01-22 12:43:31.350635
6597	VND	EUR	3.2457980929865355e-05	2026-01-21	2026-01-22 12:43:31.359793
6598	EUR	VUV	141.54967123	2026-01-21	2026-01-22 12:43:31.368859
6599	VUV	EUR	0.007064657878117771	2026-01-21	2026-01-22 12:43:31.377264
6600	EUR	WST	3.23175682	2026-01-21	2026-01-22 12:43:31.385634
6601	WST	EUR	0.309429222462351	2026-01-21	2026-01-22 12:43:31.394158
6602	EUR	XAF	655.95700001	2026-01-21	2026-01-22 12:43:31.40262
6603	XAF	EUR	0.001524490172350863	2026-01-21	2026-01-22 12:43:31.411062
6322	EUR	BBD	2.34571121	2026-01-21	2026-01-22 12:43:27.953321
6339	BRL	EUR	0.15857577816230536	2026-01-21	2026-01-22 12:43:28.355156
6356	EUR	CLP	1039.1423272	2026-01-21	2026-01-22 12:43:28.773765
6373	DJF	EUR	0.004791932815606842	2026-01-21	2026-01-22 12:43:29.001267
6392	EUR	GBP	0.87202912	2026-01-21	2026-01-22 12:43:29.206125
6409	GYD	EUR	0.0040776958308029986	2026-01-21	2026-01-22 12:43:29.371176
6426	EUR	INR	106.83801116	2026-01-21	2026-01-22 12:43:29.554771
6440	EUR	JPY	185.31538612	2026-01-21	2026-01-22 12:43:29.744428
6443	KES	EUR	0.00660682707507696	2026-01-21	2026-01-22 12:43:29.770871
6460	EUR	LBP	104833.83857053	2026-01-21	2026-01-22 12:43:29.991845
6477	MKD	EUR	0.016228013779603114	2026-01-21	2026-01-22 12:43:30.182885
6494	EUR	MYR	4.75803182	2026-01-21	2026-01-22 12:43:30.358486
6511	OMR	EUR	2.215059163898009	2026-01-21	2026-01-22 12:43:30.524169
6528	EUR	RON	5.09249668	2026-01-21	2026-01-22 12:43:30.673644
6545	SEK	EUR	0.09351573752500296	2026-01-21	2026-01-22 12:43:30.814916
6560	EUR	SYP	130.27801451	2026-01-21	2026-01-22 12:43:30.968019
6561	SYP	EUR	0.007675892235241589	2026-01-21	2026-01-22 12:43:30.976876
6562	EUR	SZL	19.23578414	2026-01-21	2026-01-22 12:43:30.985575
6563	SZL	EUR	0.05198644322071291	2026-01-21	2026-01-22 12:43:30.99425
6564	EUR	THB	36.31949166	2026-01-21	2026-01-22 12:43:31.003562
6565	THB	EUR	0.027533425009396182	2026-01-21	2026-01-22 12:43:31.013485
6566	EUR	TJS	10.9429377	2026-01-21	2026-01-22 12:43:31.035959
6567	TJS	EUR	0.09138313928260781	2026-01-21	2026-01-22 12:43:31.044891
6568	EUR	TMT	4.11502491	2026-01-21	2026-01-22 12:43:31.055045
6569	TMT	EUR	0.24301189467161696	2026-01-21	2026-01-22 12:43:31.064284
6570	EUR	TND	3.37822065	2026-01-21	2026-01-22 12:43:31.073294
6571	TND	EUR	0.2960138201748308	2026-01-21	2026-01-22 12:43:31.082228
6572	EUR	TOP	2.80602124	2026-01-21	2026-01-22 12:43:31.092268
6573	TOP	EUR	0.35637648986577164	2026-01-21	2026-01-22 12:43:31.127317
6574	EUR	TRY	50.78573111	2026-01-21	2026-01-22 12:43:31.137175
6575	TRY	EUR	0.01969057012951211	2026-01-21	2026-01-22 12:43:31.14673
6576	EUR	TTD	7.94830615	2026-01-21	2026-01-22 12:43:31.161249
6577	TTD	EUR	0.1258129695973022	2026-01-21	2026-01-22 12:43:31.169333
6578	EUR	TVD	1.74016706	2026-01-21	2026-01-22 12:43:31.177492
6579	TVD	EUR	0.5746574699557868	2026-01-21	2026-01-22 12:43:31.185492
6580	EUR	TWD	37.12651854	2026-01-21	2026-01-22 12:43:31.193804
6581	TWD	EUR	0.026934925205082266	2026-01-21	2026-01-22 12:43:31.202225
6582	EUR	TZS	2965.43320082	2026-01-21	2026-01-22 12:43:31.211117
6583	TZS	EUR	0.00033721885885795055	2026-01-21	2026-01-22 12:43:31.226762
6584	EUR	UAH	50.75829057	2026-01-21	2026-01-22 12:43:31.235768
6585	UAH	EUR	0.019701215087630168	2026-01-21	2026-01-22 12:43:31.252767
6586	EUR	UGX	4060.22028599	2026-01-21	2026-01-22 12:43:31.261326
6587	UGX	EUR	0.0002462920554952527	2026-01-21	2026-01-22 12:43:31.269579
6588	EUR	USD	1.1728556	2026-01-21	2026-01-22 12:43:31.277697
6589	USD	EUR	0.8526198792076364	2026-01-21	2026-01-22 12:43:31.285582
6590	EUR	UYU	44.99790584	2026-01-21	2026-01-22 12:43:31.293678
6591	UYU	EUR	0.022223256423437147	2026-01-21	2026-01-22 12:43:31.301888
6604	EUR	XCD	3.17529459	2026-01-21	2026-01-22 12:43:31.427051
6605	XCD	EUR	0.3149314092460316	2026-01-21	2026-01-22 12:43:31.435982
6606	EUR	XDR	0.85663514	2026-01-21	2026-01-22 12:43:31.444561
6607	XDR	EUR	1.1673581356935696	2026-01-21	2026-01-22 12:43:31.453267
6608	EUR	XOF	655.95700001	2026-01-21	2026-01-22 12:43:31.461718
6609	XOF	EUR	0.001524490172350863	2026-01-21	2026-01-22 12:43:31.470262
6610	EUR	XPF	119.33174225	2026-01-21	2026-01-22 12:43:31.478565
6611	XPF	EUR	0.0083799999995391	2026-01-21	2026-01-22 12:43:31.486908
6612	EUR	YER	279.68916165	2026-01-21	2026-01-22 12:43:31.495814
6613	YER	EUR	0.0035753977526357963	2026-01-21	2026-01-22 12:43:31.504626
6614	EUR	ZAR	19.23578414	2026-01-21	2026-01-22 12:43:31.513446
6615	ZAR	EUR	0.05198644322071291	2026-01-21	2026-01-22 12:43:31.53618
6616	EUR	ZMW	23.77069675	2026-01-21	2026-01-22 12:43:31.544853
6617	ZMW	EUR	0.04206860280609991	2026-01-21	2026-01-22 12:43:31.553481
6618	EUR	ZWL	75128.29415722	2026-01-21	2026-01-22 12:43:31.561837
6619	ZWL	EUR	1.3310564431388699e-05	2026-01-21	2026-01-22 12:43:31.570218
7580	EUR	AED	4.29347706	2026-01-22	2026-01-22 13:20:06.34681
7581	AED	EUR	0.2329114575495135	2026-01-22	2026-01-22 13:20:06.368197
7582	EUR	AFN	76.6075664	2026-01-22	2026-01-22 13:20:06.379927
7583	AFN	EUR	0.01305354088365872	2026-01-22	2026-01-22 13:20:06.388502
7584	EUR	ALL	96.45308093	2026-01-22	2026-01-22 13:20:06.39797
7585	ALL	EUR	0.010367735176087755	2026-01-22	2026-01-22 13:20:06.406539
7586	EUR	AMD	441.18335659	2026-01-22	2026-01-22 13:20:06.415295
7587	AMD	EUR	0.0022666312884720144	2026-01-22	2026-01-22 13:20:06.423597
7588	EUR	ANG	2.10841647	2026-01-22	2026-01-22 13:20:06.432201
7589	ANG	EUR	0.4742895980128632	2026-01-22	2026-01-22 13:20:06.440563
7590	EUR	AOA	1072.7886546	2026-01-22	2026-01-22 13:20:06.453869
7591	AOA	EUR	0.0009321500518411617	2026-01-22	2026-01-22 13:20:06.461907
9200	EUR	BAM	1.95583	2026-01-27	2026-01-28 03:07:39.240371
9201	BAM	EUR	0.5112918811962185	2026-01-27	2026-01-28 03:07:39.249969
9202	EUR	BBD	2.37646403	2026-01-27	2026-01-28 03:07:39.259331
9203	BBD	EUR	0.42079324045144495	2026-01-27	2026-01-28 03:07:39.268482
9204	EUR	BDT	145.22604763	2026-01-27	2026-01-28 03:07:39.2779
9205	BDT	EUR	0.006885817085291423	2026-01-27	2026-01-28 03:07:39.286853
9206	EUR	BGN	1.95583	2026-01-27	2026-01-28 03:07:39.296529
9207	BGN	EUR	0.5112918811962185	2026-01-27	2026-01-28 03:07:39.334607
9208	EUR	BHD	0.44677524	2026-01-27	2026-01-28 03:07:39.345516
9209	BHD	EUR	2.2382619054717536	2026-01-27	2026-01-28 03:07:39.355179
9210	EUR	BIF	3509.36803108	2026-01-27	2026-01-28 03:07:39.364692
9212	EUR	BMD	1.18823202	2026-01-27	2026-01-28 03:07:39.385059
9213	BMD	EUR	0.8415864773615509	2026-01-27	2026-01-28 03:07:39.394379
9214	EUR	BND	1.50815025	2026-01-27	2026-01-28 03:07:39.424353
9215	BND	EUR	0.6630639089175632	2026-01-27	2026-01-28 03:07:39.435628
9216	EUR	BOB	8.20189221	2026-01-27	2026-01-28 03:07:39.445264
9217	BOB	EUR	0.12192308486824163	2026-01-27	2026-01-28 03:07:39.454275
9218	EUR	BRL	6.27654014	2026-01-27	2026-01-28 03:07:39.463719
9219	BRL	EUR	0.15932344535280865	2026-01-27	2026-01-28 03:07:39.473202
9220	EUR	BSD	1.18823202	2026-01-27	2026-01-28 03:07:39.482738
9221	BSD	EUR	0.8415864773615509	2026-01-27	2026-01-28 03:07:39.49143
9222	EUR	BTN	108.96326986	2026-01-27	2026-01-28 03:07:39.500603
9223	BTN	EUR	0.009177404471110647	2026-01-27	2026-01-28 03:07:39.510433
9224	EUR	BWP	15.71681195	2026-01-27	2026-01-28 03:07:39.528307
9225	BWP	EUR	0.06362613506996882	2026-01-27	2026-01-28 03:07:39.537104
9199	AZN	EUR	0.49505054161573814	2026-01-27	2026-01-28 03:07:39.231415
7592	EUR	ARS	1671.84817808	2026-01-22	2026-01-22 13:20:06.470083
7593	ARS	EUR	0.0005981404370990371	2026-01-22	2026-01-22 13:20:06.480827
7594	EUR	AUD	1.7197167	2026-01-22	2026-01-22 13:20:06.489359
7595	AUD	EUR	0.5814911258348541	2026-01-22	2026-01-22 13:20:06.497331
7596	EUR	AWG	2.09266819	2026-01-22	2026-01-22 13:20:06.506289
7597	AWG	EUR	0.47785884297309456	2026-01-22	2026-01-22 13:20:06.514338
7598	EUR	AZN	1.98745632	2026-01-22	2026-01-22 13:20:06.522535
7599	AZN	EUR	0.5031557121215122	2026-01-22	2026-01-22 13:20:06.53065
7600	EUR	BAM	1.95583	2026-01-22	2026-01-22 13:20:06.539034
7601	BAM	EUR	0.5112918811962185	2026-01-22	2026-01-22 13:20:06.547184
7602	EUR	BBD	2.33817675	2026-01-22	2026-01-22 13:20:06.55546
7603	BBD	EUR	0.42768366420545406	2026-01-22	2026-01-22 13:20:06.563995
7604	EUR	BDT	143.15733171	2026-01-22	2026-01-22 13:20:06.572022
7605	BDT	EUR	0.00698532159027484	2026-01-22	2026-01-22 13:20:06.580241
7606	EUR	BGN	1.95583	2026-01-22	2026-01-22 13:20:06.588527
7607	BGN	EUR	0.5112918811962185	2026-01-22	2026-01-22 13:20:06.597051
7608	EUR	BHD	0.43957723	2026-01-22	2026-01-22 13:20:06.605362
7609	BHD	EUR	2.27491310230059	2026-01-22	2026-01-22 13:20:06.613436
7610	EUR	BIF	3464.18425882	2026-01-22	2026-01-22 13:20:06.621722
7611	BIF	EUR	0.00028866824778559224	2026-01-22	2026-01-22 13:20:06.630058
7612	EUR	BMD	1.16908838	2026-01-22	2026-01-22 13:20:06.638809
7613	BMD	EUR	0.8553673247526419	2026-01-22	2026-01-22 13:20:06.648384
7614	EUR	BND	1.50088421	2026-01-22	2026-01-22 13:20:06.657095
7615	BND	EUR	0.6662739159605124	2026-01-22	2026-01-22 13:20:06.668553
7616	EUR	BOB	8.08934585	2026-01-22	2026-01-22 13:20:06.677349
7617	BOB	EUR	0.12361939006477266	2026-01-22	2026-01-22 13:20:06.686329
7618	EUR	BRL	6.21851074	2026-01-22	2026-01-22 13:20:06.695364
7619	BRL	EUR	0.16081020710756222	2026-01-22	2026-01-22 13:20:06.704091
7620	EUR	BSD	1.16908838	2026-01-22	2026-01-22 13:20:06.71232
7621	BSD	EUR	0.8553673247526419	2026-01-22	2026-01-22 13:20:06.72058
7622	EUR	BTN	106.98614189	2026-01-22	2026-01-22 13:20:06.730093
7623	BTN	EUR	0.00934700497030887	2026-01-22	2026-01-22 13:20:06.738874
7624	EUR	BWP	15.84446209	2026-01-22	2026-01-22 13:20:06.748177
7625	BWP	EUR	0.06311353420013768	2026-01-22	2026-01-22 13:20:06.757339
7626	EUR	BYN	3.36266902	2026-01-22	2026-01-22 13:20:06.767158
7627	BYN	EUR	0.2973828212209836	2026-01-22	2026-01-22 13:20:06.776218
7628	EUR	BZD	2.36294119	2026-01-22	2026-01-22 13:20:06.784543
7629	BZD	EUR	0.4232013916520707	2026-01-22	2026-01-22 13:20:06.793224
7630	EUR	CAD	1.61624693	2026-01-22	2026-01-22 13:20:06.801701
7631	CAD	EUR	0.6187173391877688	2026-01-22	2026-01-22 13:20:06.810228
7632	EUR	CDF	2556.81264669	2026-01-22	2026-01-22 13:20:06.819192
7633	CDF	EUR	0.00039111195780988515	2026-01-22	2026-01-22 13:20:06.828834
7634	EUR	CHF	0.92964446	2026-01-22	2026-01-22 13:20:06.837459
7635	CHF	EUR	1.075680050844384	2026-01-22	2026-01-22 13:20:06.846353
7636	EUR	CLP	1022.75575228	2026-01-22	2026-01-22 13:20:06.854977
7637	CLP	EUR	0.000977750550677157	2026-01-22	2026-01-22 13:20:06.863392
7638	EUR	CNH	8.1351413	2026-01-22	2026-01-22 13:20:06.872126
7639	CNH	EUR	0.12292349488754423	2026-01-22	2026-01-22 13:20:06.881929
7640	EUR	CNY	8.13901146	2026-01-22	2026-01-22 13:20:06.893786
7641	CNY	EUR	0.12286504385877839	2026-01-22	2026-01-22 13:20:06.903598
7642	EUR	COP	4295.27644289	2026-01-22	2026-01-22 13:20:06.912947
7643	COP	EUR	0.00023281388597358075	2026-01-22	2026-01-22 13:20:06.921728
7644	EUR	CRC	575.46707171	2026-01-22	2026-01-22 13:20:06.930586
7645	CRC	EUR	0.0017377188881172656	2026-01-22	2026-01-22 13:20:06.939735
7646	EUR	CUP	28.0530997	2026-01-22	2026-01-22 13:20:06.948995
7647	CUP	EUR	0.03564668470486347	2026-01-22	2026-01-22 13:20:06.958157
7648	EUR	CVE	110.26999999	2026-01-22	2026-01-22 13:20:06.968004
7649	CVE	EUR	0.00906864967888534	2026-01-22	2026-01-22 13:20:06.976935
7650	EUR	CZK	24.33439176	2026-01-22	2026-01-22 13:20:06.986707
7651	CZK	EUR	0.0410941029413262	2026-01-22	2026-01-22 13:20:06.996098
7652	EUR	DJF	208.28627788	2026-01-22	2026-01-22 13:20:07.004858
7653	DJF	EUR	0.004801084402574663	2026-01-22	2026-01-22 13:20:07.014872
7654	EUR	DKK	7.47052524	2026-01-22	2026-01-22 13:20:07.023514
7655	DKK	EUR	0.13385939647799117	2026-01-22	2026-01-22 13:20:07.032081
7656	EUR	DOP	73.74557277	2026-01-22	2026-01-22 13:20:07.050386
7657	DOP	EUR	0.013560136052083172	2026-01-22	2026-01-22 13:20:07.05889
7658	EUR	DZD	151.89445056	2026-01-22	2026-01-22 13:20:07.067397
7659	DZD	EUR	0.00658351899172899	2026-01-22	2026-01-22 13:20:07.075734
7660	EUR	EGP	55.40713448	2026-01-22	2026-01-22 13:20:07.083861
7661	EGP	EUR	0.01804821724467567	2026-01-22	2026-01-22 13:20:07.092516
7662	EUR	ERN	17.53632565	2026-01-22	2026-01-22 13:20:07.100837
7663	ERN	EUR	0.05702448847943241	2026-01-22	2026-01-22 13:20:07.108751
7664	EUR	ETB	182.30531031	2026-01-22	2026-01-22 13:20:07.117048
7665	ETB	EUR	0.0054853037374476684	2026-01-22	2026-01-22 13:20:07.125355
7666	EUR	EUR	1	2026-01-22	2026-01-22 13:20:07.142407
7668	EUR	FJD	2.64875534	2026-01-22	2026-01-22 13:20:07.150715
7669	FJD	EUR	0.3775358127262898	2026-01-22	2026-01-22 13:20:07.158932
7670	EUR	FKP	0.870397	2026-01-22	2026-01-22 13:20:07.168825
7671	FKP	EUR	1.1489010187305333	2026-01-22	2026-01-22 13:20:07.178404
7672	EUR	GBP	0.870397	2026-01-22	2026-01-22 13:20:07.186909
7673	GBP	EUR	1.1489010187305333	2026-01-22	2026-01-22 13:20:07.195636
7674	EUR	GEL	3.14591757	2026-01-22	2026-01-22 13:20:07.203804
7675	GEL	EUR	0.31787228296639697	2026-01-22	2026-01-22 13:20:07.212452
7676	EUR	GGP	0.870397	2026-01-22	2026-01-22 13:20:07.220683
7677	GGP	EUR	1.1489010187305333	2026-01-22	2026-01-22 13:20:07.228503
7678	EUR	GHS	12.71422984	2026-01-22	2026-01-22 13:20:07.23702
7679	GHS	EUR	0.07865203103800426	2026-01-22	2026-01-22 13:20:07.24519
7680	EUR	GIP	0.870397	2026-01-22	2026-01-22 13:20:07.253453
7681	GIP	EUR	1.1489010187305333	2026-01-22	2026-01-22 13:20:07.261912
7682	EUR	GMD	86.23730391	2026-01-22	2026-01-22 13:20:07.270143
7683	GMD	EUR	0.011595909828577573	2026-01-22	2026-01-22 13:20:07.279327
7684	EUR	GNF	10249.59763112	2026-01-22	2026-01-22 13:20:07.288023
7685	GNF	EUR	9.756480556502856e-05	2026-01-22	2026-01-22 13:20:07.296137
7686	EUR	GTQ	8.97074747	2026-01-22	2026-01-22 13:20:07.3044
7687	GTQ	EUR	0.11147343109860165	2026-01-22	2026-01-22 13:20:07.31244
7688	EUR	GYD	245.08437111	2026-01-22	2026-01-22 13:20:07.320812
7689	GYD	EUR	0.0040802275374433195	2026-01-22	2026-01-22 13:20:07.330286
7690	EUR	HKD	9.1149398	2026-01-22	2026-01-22 13:20:07.33888
7691	HKD	EUR	0.10970999501280304	2026-01-22	2026-01-22 13:20:07.347367
7692	EUR	HNL	30.84184739	2026-01-22	2026-01-22 13:20:07.355313
7693	HNL	EUR	0.032423479286271116	2026-01-22	2026-01-22 13:20:07.363202
7694	EUR	HRK	7.5345	2026-01-22	2026-01-22 13:20:07.371491
7695	HRK	EUR	0.13272280841462605	2026-01-22	2026-01-22 13:20:07.380022
7696	EUR	HTG	153.28569576	2026-01-22	2026-01-22 13:20:07.388347
7697	HTG	EUR	0.0065237659329002474	2026-01-22	2026-01-22 13:20:07.39684
7698	EUR	HUF	384.25443896	2026-01-22	2026-01-22 13:20:07.404879
7699	HUF	EUR	0.0026024422846136533	2026-01-22	2026-01-22 13:20:07.413168
7700	EUR	IDR	19755.8687714	2026-01-22	2026-01-22 13:20:07.421562
7701	IDR	EUR	5.061787014133598e-05	2026-01-22	2026-01-22 13:20:07.429961
7702	EUR	ILS	3.68254973	2026-01-22	2026-01-22 13:20:07.438254
7703	ILS	EUR	0.2715509832368238	2026-01-22	2026-01-22 13:20:07.448075
7704	EUR	IMP	0.870397	2026-01-22	2026-01-22 13:20:07.456941
7705	IMP	EUR	1.1489010187305333	2026-01-22	2026-01-22 13:20:07.46515
7706	EUR	INR	106.98614189	2026-01-22	2026-01-22 13:20:07.473405
7707	INR	EUR	0.00934700497030887	2026-01-22	2026-01-22 13:20:07.484139
7708	EUR	IQD	1533.27981469	2026-01-22	2026-01-22 13:20:07.492527
7709	IQD	EUR	0.0006521966769660898	2026-01-22	2026-01-22 13:20:07.500793
7710	EUR	IRR	1252311.57063787	2026-01-22	2026-01-22 13:20:07.509168
7711	IRR	EUR	7.985233255416189e-07	2026-01-22	2026-01-22 13:20:07.517547
7712	EUR	ISK	146.19974367	2026-01-22	2026-01-22 13:20:07.525847
7713	ISK	EUR	0.006839957272819752	2026-01-22	2026-01-22 13:20:07.534378
7714	EUR	JEP	0.870397	2026-01-22	2026-01-22 13:20:07.54241
7715	JEP	EUR	1.1489010187305333	2026-01-22	2026-01-22 13:20:07.550651
7716	EUR	JMD	184.14191994	2026-01-22	2026-01-22 13:20:07.559119
7717	JMD	EUR	0.00543059396972637	2026-01-22	2026-01-22 13:20:07.567227
7718	EUR	JOD	0.82888366	2026-01-22	2026-01-22 13:20:07.575797
7719	JOD	EUR	1.2064419269647564	2026-01-22	2026-01-22 13:20:07.584859
7720	EUR	JPY	185.19153401	2026-01-22	2026-01-22 13:20:07.593445
7721	JPY	EUR	0.005399814874615175	2026-01-22	2026-01-22 13:20:07.601694
7722	EUR	KES	150.99598789	2026-01-22	2026-01-22 13:20:07.609997
7723	KES	EUR	0.006622692522986082	2026-01-22	2026-01-22 13:20:07.619635
7724	EUR	KGS	102.24452809	2026-01-22	2026-01-22 13:20:07.628496
7725	KGS	EUR	0.009780474502457063	2026-01-22	2026-01-22 13:20:07.63816
7726	EUR	KHR	4715.85070351	2026-01-22	2026-01-22 13:20:07.646457
7727	KHR	EUR	0.0002120508181600621	2026-01-22	2026-01-22 13:20:07.654901
7728	EUR	KMF	491.96774998	2026-01-22	2026-01-22 13:20:07.663417
7729	KMF	EUR	0.0020326535632481054	2026-01-22	2026-01-22 13:20:07.672294
7730	EUR	KRW	1716.17320753	2026-01-22	2026-01-22 13:20:07.680723
7731	KRW	EUR	0.0005826917677145472	2026-01-22	2026-01-22 13:20:07.689935
7732	EUR	KWD	0.35928349	2026-01-22	2026-01-22 13:20:07.698469
7733	KWD	EUR	2.783317429921425	2026-01-22	2026-01-22 13:20:07.706882
7734	EUR	KYD	0.97003881	2026-01-22	2026-01-22 13:20:07.715374
7735	KYD	EUR	1.0308865889602912	2026-01-22	2026-01-22 13:20:07.723515
7736	EUR	KZT	593.48397701	2026-01-22	2026-01-22 13:20:07.732855
7737	KZT	EUR	0.0016849654560819767	2026-01-22	2026-01-22 13:20:07.740754
7738	EUR	LAK	25308.46847267	2026-01-22	2026-01-22 13:20:07.749621
7739	LAK	EUR	3.951246599848093e-05	2026-01-22	2026-01-22 13:20:07.758242
7740	EUR	LBP	100432.22095432	2026-01-22	2026-01-22 13:20:07.76705
7741	LBP	EUR	9.956963915542942e-06	2026-01-22	2026-01-22 13:20:07.775424
7742	EUR	LKR	362.68570446	2026-01-22	2026-01-22 13:20:07.783365
7743	LKR	EUR	0.0027572082045221285	2026-01-22	2026-01-22 13:20:07.791745
7744	EUR	LRD	216.03570182	2026-01-22	2026-01-22 13:20:07.800133
7745	LRD	EUR	0.004628864542181994	2026-01-22	2026-01-22 13:20:07.808406
7746	EUR	LSL	19.00904354	2026-01-22	2026-01-22 13:20:07.816343
7747	LSL	EUR	0.05260653950819453	2026-01-22	2026-01-22 13:20:07.825614
7748	EUR	LYD	7.29339703	2026-01-22	2026-01-22 13:20:07.834064
7749	LYD	EUR	0.13711031990808814	2026-01-22	2026-01-22 13:20:07.842133
7750	EUR	MAD	10.73967743	2026-01-22	2026-01-22 13:20:07.850485
7751	MAD	EUR	0.09311266623396156	2026-01-22	2026-01-22 13:20:07.859128
7752	EUR	MDL	19.87551346	2026-01-22	2026-01-22 13:20:07.867691
7753	MDL	EUR	0.050313165595068855	2026-01-22	2026-01-22 13:20:07.87625
7754	EUR	MGA	5380.75391815	2026-01-22	2026-01-22 13:20:07.884647
7755	MGA	EUR	0.00018584756248132196	2026-01-22	2026-01-22 13:20:07.892976
7756	EUR	MKD	61.5430232	2026-01-22	2026-01-22 13:20:07.901244
7757	MKD	EUR	0.016248795525534078	2026-01-22	2026-01-22 13:20:07.909248
7758	EUR	MMK	2454.83598489	2026-01-22	2026-01-22 13:20:07.923079
7759	MMK	EUR	0.0004073591906568086	2026-01-22	2026-01-22 13:20:07.931241
7760	EUR	MNT	4168.03281201	2026-01-22	2026-01-22 13:20:07.939217
7761	MNT	EUR	0.0002399213358202327	2026-01-22	2026-01-22 13:20:07.947873
7762	EUR	MOP	9.38838799	2026-01-22	2026-01-22 13:20:07.956927
7763	MOP	EUR	0.10651455831023873	2026-01-22	2026-01-22 13:20:07.970383
7764	EUR	MRU	46.69410093	2026-01-22	2026-01-22 13:20:07.978909
7765	MRU	EUR	0.021415981464106542	2026-01-22	2026-01-22 13:20:07.987314
7766	EUR	MUR	53.80724583	2026-01-22	2026-01-22 13:20:07.995901
7767	MUR	EUR	0.018584857570287574	2026-01-22	2026-01-22 13:20:08.004481
7768	EUR	MVR	18.07329823	2026-01-22	2026-01-22 13:20:08.01272
7769	MVR	EUR	0.055330243947399306	2026-01-22	2026-01-22 13:20:08.021654
7770	EUR	MWK	2029.08856274	2026-01-22	2026-01-22 13:20:08.030096
7771	MWK	EUR	0.000492832111107876	2026-01-22	2026-01-22 13:20:08.040431
7772	EUR	MXN	20.44347346	2026-01-22	2026-01-22 13:20:08.050788
7773	MXN	EUR	0.04891536665511439	2026-01-22	2026-01-22 13:20:08.059441
7774	EUR	MYR	4.72919556	2026-01-22	2026-01-22 13:20:08.067606
7775	MYR	EUR	0.21145245260274245	2026-01-22	2026-01-22 13:20:08.076909
7776	EUR	MZN	74.68728325	2026-01-22	2026-01-22 13:20:08.085251
7777	MZN	EUR	0.013389160195487497	2026-01-22	2026-01-22 13:20:08.093365
7778	EUR	NAD	19.00904354	2026-01-22	2026-01-22 13:20:08.101738
7779	NAD	EUR	0.05260653950819453	2026-01-22	2026-01-22 13:20:08.110194
7780	EUR	NGN	1664.15308277	2026-01-22	2026-01-22 13:20:08.11928
7781	NGN	EUR	0.0006009062569745625	2026-01-22	2026-01-22 13:20:08.128025
7782	EUR	NIO	43.00081748	2026-01-22	2026-01-22 13:20:08.136087
7783	NIO	EUR	0.023255371841828527	2026-01-22	2026-01-22 13:20:08.144251
7784	EUR	NOK	11.6354346	2026-01-22	2026-01-22 13:20:08.152577
7785	NOK	EUR	0.08594436171726667	2026-01-22	2026-01-22 13:20:08.161386
7786	EUR	NPR	171.25806664	2026-01-22	2026-01-22 13:20:08.169696
7787	NPR	EUR	0.005839141008768309	2026-01-22	2026-01-22 13:20:08.178173
7788	EUR	NZD	1.99649827	2026-01-22	2026-01-22 13:20:08.187091
7789	NZD	EUR	0.5008769679524941	2026-01-22	2026-01-22 13:20:08.195346
7790	EUR	OMR	0.44979946	2026-01-22	2026-01-22 13:20:08.203823
7791	OMR	EUR	2.2232129847376876	2026-01-22	2026-01-22 13:20:08.21221
7792	EUR	PAB	1.16908838	2026-01-22	2026-01-22 13:20:08.221416
7793	PAB	EUR	0.8553673247526419	2026-01-22	2026-01-22 13:20:08.229951
7794	EUR	PEN	3.9283146	2026-01-22	2026-01-22 13:20:08.238148
7795	PEN	EUR	0.2545620964267984	2026-01-22	2026-01-22 13:20:08.247223
7796	EUR	PGK	5.00027604	2026-01-22	2026-01-22 13:20:08.255535
7797	PGK	EUR	0.199988959009551	2026-01-22	2026-01-22 13:20:08.263829
7798	EUR	PHP	69.16000644	2026-01-22	2026-01-22 13:20:08.272087
7799	PHP	EUR	0.014459223639135333	2026-01-22	2026-01-22 13:20:08.280292
7800	EUR	PKR	327.65914328	2026-01-22	2026-01-22 13:20:08.288268
7801	PKR	EUR	0.0030519520682059935	2026-01-22	2026-01-22 13:20:08.296344
7802	EUR	PLN	4.21606352	2026-01-22	2026-01-22 13:20:08.304259
7803	PLN	EUR	0.23718807728020191	2026-01-22	2026-01-22 13:20:08.316408
7804	EUR	PYG	7820.02616424	2026-01-22	2026-01-22 13:20:08.324479
7805	PYG	EUR	0.00012787681000005788	2026-01-22	2026-01-22 13:20:08.332623
7806	EUR	QAR	4.25548169	2026-01-22	2026-01-22 13:20:08.340747
7807	QAR	EUR	0.23499102401260713	2026-01-22	2026-01-22 13:20:08.349062
7808	EUR	RON	5.09486047	2026-01-22	2026-01-22 13:20:08.357378
7809	RON	EUR	0.1962762289346856	2026-01-22	2026-01-22 13:20:08.365817
7810	EUR	RSD	117.41231462	2026-01-22	2026-01-22 13:20:08.374477
7811	RSD	EUR	0.008516994177624875	2026-01-22	2026-01-22 13:20:08.382465
7812	EUR	RUB	89.96960498	2026-01-22	2026-01-22 13:20:08.390381
7813	RUB	EUR	0.011114864850438071	2026-01-22	2026-01-22 13:20:08.398956
7814	EUR	RWF	1705.38692221	2026-01-22	2026-01-22 13:20:08.407252
7815	RWF	EUR	0.0005863771950966449	2026-01-22	2026-01-22 13:20:08.415521
7816	EUR	SAR	4.38408141	2026-01-22	2026-01-22 13:20:08.423638
7817	SAR	EUR	0.2280979540478013	2026-01-22	2026-01-22 13:20:08.431787
7818	EUR	SBD	9.47268771	2026-01-22	2026-01-22 13:20:08.440155
7819	SBD	EUR	0.10556665970781802	2026-01-22	2026-01-22 13:20:08.44885
7820	EUR	SCR	16.75652894	2026-01-22	2026-01-22 13:20:08.457612
7821	SCR	EUR	0.0596782307111869	2026-01-22	2026-01-22 13:20:08.46635
7822	EUR	SDG	701.55479647	2026-01-22	2026-01-22 13:20:08.474531
7823	SDG	EUR	0.0014254054067218713	2026-01-22	2026-01-22 13:20:08.482652
7824	EUR	SEK	10.62921846	2026-01-22	2026-01-22 13:20:08.490793
7825	SEK	EUR	0.09408029421572355	2026-01-22	2026-01-22 13:20:08.499829
7826	EUR	SGD	1.50088421	2026-01-22	2026-01-22 13:20:08.508238
7827	SGD	EUR	0.6662739159605124	2026-01-22	2026-01-22 13:20:08.516662
7828	EUR	SHP	0.870397	2026-01-22	2026-01-22 13:20:08.525332
7829	SHP	EUR	1.1489010187305333	2026-01-22	2026-01-22 13:20:08.53328
7830	EUR	SLE	26.70795262	2026-01-22	2026-01-22 13:20:08.541394
7831	SLE	EUR	0.03744203137649568	2026-01-22	2026-01-22 13:20:08.549653
7832	EUR	SOS	661.13814554	2026-01-22	2026-01-22 13:20:08.557914
7833	SOS	EUR	0.001512543190475308	2026-01-22	2026-01-22 13:20:08.567141
7834	EUR	SRD	44.68850031	2026-01-22	2026-01-22 13:20:08.575626
7835	SRD	EUR	0.022377121475616598	2026-01-22	2026-01-22 13:20:08.584094
7836	EUR	SSP	5314.8427627	2026-01-22	2026-01-22 13:20:08.592276
7837	SSP	EUR	0.00018815232070797683	2026-01-22	2026-01-22 13:20:08.600874
7838	EUR	STN	24.68578511	2026-01-22	2026-01-22 13:20:08.609345
7839	STN	EUR	0.04050914303693377	2026-01-22	2026-01-22 13:20:08.617788
7840	EUR	SYP	129.27546308	2026-01-22	2026-01-22 13:20:08.626361
7841	SYP	EUR	0.007735419979746399	2026-01-22	2026-01-22 13:20:08.63445
7842	EUR	SZL	19.00904354	2026-01-22	2026-01-22 13:20:08.642163
7843	SZL	EUR	0.05260653950819453	2026-01-22	2026-01-22 13:20:08.649934
7844	EUR	THB	36.59379666	2026-01-22	2026-01-22 13:20:08.658291
7845	THB	EUR	0.02732703603540218	2026-01-22	2026-01-22 13:20:08.666857
7846	EUR	TJS	10.9239954	2026-01-22	2026-01-22 13:20:08.675069
7847	TJS	EUR	0.09154159841553942	2026-01-22	2026-01-22 13:20:08.683043
7848	EUR	TMT	4.10144749	2026-01-22	2026-01-22 13:20:08.691133
7849	TMT	EUR	0.24381636055030903	2026-01-22	2026-01-22 13:20:08.699565
7850	EUR	TND	3.37116266	2026-01-22	2026-01-22 13:20:08.707822
7851	TND	EUR	0.29663356558416554	2026-01-22	2026-01-22 13:20:08.715902
7852	EUR	TOP	2.79185572	2026-01-22	2026-01-22 13:20:08.723984
7853	TOP	EUR	0.3581846987422402	2026-01-22	2026-01-22 13:20:08.732
7854	EUR	TRY	50.64228641	2026-01-22	2026-01-22 13:20:08.739976
7855	TRY	EUR	0.019746343834162603	2026-01-22	2026-01-22 13:20:08.747989
7856	EUR	TTD	7.93856958	2026-01-22	2026-01-22 13:20:08.755902
7857	TTD	EUR	0.12596727784805786	2026-01-22	2026-01-22 13:20:08.763719
7858	EUR	TVD	1.7197167	2026-01-22	2026-01-22 13:20:08.77181
7859	TVD	EUR	0.5814911258348541	2026-01-22	2026-01-22 13:20:08.780297
7860	EUR	TWD	37.00203318	2026-01-22	2026-01-22 13:20:08.788949
7861	TWD	EUR	0.027025541951584187	2026-01-22	2026-01-22 13:20:08.79825
7862	EUR	TZS	2959.42553201	2026-01-22	2026-01-22 13:20:08.807112
7863	TZS	EUR	0.0003379034171273146	2026-01-22	2026-01-22 13:20:08.815326
7864	EUR	UAH	50.42108777	2026-01-22	2026-01-22 13:20:08.823537
7865	UAH	EUR	0.01983297156462755	2026-01-22	2026-01-22 13:20:08.832888
7866	EUR	UGX	4044.71297523	2026-01-22	2026-01-22 13:20:08.841004
7867	UGX	EUR	0.00024723633200280065	2026-01-22	2026-01-22 13:20:08.849048
7868	EUR	USD	1.16908838	2026-01-22	2026-01-22 13:20:08.857208
7869	USD	EUR	0.8553673247526419	2026-01-22	2026-01-22 13:20:08.865096
7870	EUR	UYU	44.94017039	2026-01-22	2026-01-22 13:20:08.873204
7871	UYU	EUR	0.022251807043048463	2026-01-22	2026-01-22 13:20:08.881318
7872	EUR	UZS	14128.90985715	2026-01-22	2026-01-22 13:20:08.889248
7873	UZS	EUR	7.077686885332809e-05	2026-01-22	2026-01-22 13:20:08.897572
7874	EUR	VES	406.9809355	2026-01-22	2026-01-22 13:20:08.906749
7875	VES	EUR	0.002457117552131628	2026-01-22	2026-01-22 13:20:08.914873
7876	EUR	VND	30756.96212169	2026-01-22	2026-01-22 13:20:08.923259
7877	VND	EUR	3.251296392808553e-05	2026-01-22	2026-01-22 13:20:08.931321
7878	EUR	VUV	140.98451419	2026-01-22	2026-01-22 13:20:08.939235
7879	VUV	EUR	0.0070929775922221805	2026-01-22	2026-01-22 13:20:08.94723
7880	EUR	WST	3.2100699	2026-01-22	2026-01-22 13:20:08.955383
7881	WST	EUR	0.3115196961910393	2026-01-22	2026-01-22 13:20:08.963616
7882	EUR	XAF	655.95699997	2026-01-22	2026-01-22 13:20:08.971929
7883	XAF	EUR	0.001524490172443826	2026-01-22	2026-01-22 13:20:08.980246
7884	EUR	XCD	3.16371825	2026-01-22	2026-01-22 13:20:08.988279
7885	XCD	EUR	0.3160837726305116	2026-01-22	2026-01-22 13:20:08.998235
7886	EUR	XDR	0.85487986	2026-01-22	2026-01-22 13:20:09.007015
7887	XDR	EUR	1.1697550109555745	2026-01-22	2026-01-22 13:20:09.015413
7888	EUR	XOF	655.95699997	2026-01-22	2026-01-22 13:20:09.024005
7889	XOF	EUR	0.001524490172443826	2026-01-22	2026-01-22 13:20:09.032639
7890	EUR	XPF	119.33174224	2026-01-22	2026-01-22 13:20:09.040959
7891	XPF	EUR	0.008380000000241344	2026-01-22	2026-01-22 13:20:09.049059
7892	EUR	YER	278.59599353	2026-01-22	2026-01-22 13:20:09.057682
7893	YER	EUR	0.003589427067235686	2026-01-22	2026-01-22 13:20:09.066159
7894	EUR	ZAR	19.00904354	2026-01-22	2026-01-22 13:20:09.074388
7895	ZAR	EUR	0.05260653950819453	2026-01-22	2026-01-22 13:20:09.082885
7896	EUR	ZMW	23.64785452	2026-01-22	2026-01-22 13:20:09.091099
7897	ZMW	EUR	0.04228713430024941	2026-01-22	2026-01-22 13:20:09.099402
7898	EUR	ZWL	74839.26125565	2026-01-22	2026-01-22 13:20:09.108309
7899	ZWL	EUR	1.3361970484770184e-05	2026-01-22	2026-01-22 13:20:09.116816
7900	EUR	AED	4.3141656	2026-01-23	2026-01-23 11:40:05.653692
7901	AED	EUR	0.23179453287560403	2026-01-23	2026-01-23 11:40:05.675271
7902	EUR	AFN	76.32934376	2026-01-23	2026-01-23 11:40:05.687102
7903	AFN	EUR	0.01310112141333573	2026-01-23	2026-01-23 11:40:05.697908
7904	EUR	ALL	96.45380471	2026-01-23	2026-01-23 11:40:05.707004
7905	ALL	EUR	0.010367657377608076	2026-01-23	2026-01-23 11:40:05.716168
7906	EUR	AMD	445.37558829	2026-01-23	2026-01-23 11:40:05.748132
7907	AMD	EUR	0.0022452959396348057	2026-01-23	2026-01-23 11:40:05.757384
7908	EUR	ANG	2.11194303	2026-01-23	2026-01-23 11:40:05.766781
7909	ANG	EUR	0.4734976208141372	2026-01-23	2026-01-23 11:40:05.776756
7910	EUR	AOA	1077.14506581	2026-01-23	2026-01-23 11:40:05.785522
7911	AOA	EUR	0.0009283800592337228	2026-01-23	2026-01-23 11:40:05.794579
7912	EUR	ARS	1678.78365014	2026-01-23	2026-01-23 11:40:05.80353
7913	ARS	EUR	0.0005956693704496147	2026-01-23	2026-01-23 11:40:05.812182
7914	EUR	AUD	1.71667181	2026-01-23	2026-01-23 11:40:05.821147
7915	AUD	EUR	0.5825225265393039	2026-01-23	2026-01-23 11:40:05.829618
7916	EUR	AWG	2.10275192	2026-01-23	2026-01-23 11:40:05.838566
7917	AWG	EUR	0.47556727471683863	2026-01-23	2026-01-23 11:40:05.847301
7918	EUR	AZN	1.99702895	2026-01-23	2026-01-23 11:40:05.856501
7919	AZN	EUR	0.5007438675338182	2026-01-23	2026-01-23 11:40:05.866466
7920	EUR	BAM	1.95583	2026-01-23	2026-01-23 11:40:05.875754
7921	BAM	EUR	0.5112918811962185	2026-01-23	2026-01-23 11:40:05.884727
7922	EUR	BBD	2.34944348	2026-01-23	2026-01-23 11:40:05.893426
7923	BBD	EUR	0.4256327119646223	2026-01-23	2026-01-23 11:40:05.902395
7924	EUR	BDT	143.67639428	2026-01-23	2026-01-23 11:40:05.911818
7925	BDT	EUR	0.006960085579898225	2026-01-23	2026-01-23 11:40:05.920271
7926	EUR	BGN	1.95583	2026-01-23	2026-01-23 11:40:05.929454
7927	BGN	EUR	0.5112918811962185	2026-01-23	2026-01-23 11:40:05.938904
7928	EUR	BHD	0.44169537	2026-01-23	2026-01-23 11:40:05.948193
7929	BHD	EUR	2.2640038087788876	2026-01-23	2026-01-23 11:40:05.95736
7930	EUR	BIF	3468.85550784	2026-01-23	2026-01-23 11:40:05.965828
7931	BIF	EUR	0.00028827951978394273	2026-01-23	2026-01-23 11:40:05.974809
7932	EUR	BMD	1.17472174	2026-01-23	2026-01-23 11:40:05.983832
7933	BMD	EUR	0.8512654239292446	2026-01-23	2026-01-23 11:40:05.993673
7934	EUR	BND	1.50450237	2026-01-23	2026-01-23 11:40:06.00238
7935	BND	EUR	0.6646716016804946	2026-01-23	2026-01-23 11:40:06.011061
7936	EUR	BOB	8.12722009	2026-01-23	2026-01-23 11:40:06.0202
7937	BOB	EUR	0.12304330249779172	2026-01-23	2026-01-23 11:40:06.028865
7938	EUR	BRL	6.20830695	2026-01-23	2026-01-23 11:40:06.038038
7939	BRL	EUR	0.16107451001597142	2026-01-23	2026-01-23 11:40:06.047439
7940	EUR	BSD	1.17472174	2026-01-23	2026-01-23 11:40:06.057437
7941	BSD	EUR	0.8512654239292446	2026-01-23	2026-01-23 11:40:06.066435
7942	EUR	BTN	107.59283395	2026-01-23	2026-01-23 11:40:06.075627
7943	BTN	EUR	0.00929429928822876	2026-01-23	2026-01-23 11:40:06.08507
7944	EUR	BWP	16.12389924	2026-01-23	2026-01-23 11:40:06.095418
7945	BWP	EUR	0.06201973760287527	2026-01-23	2026-01-23 11:40:06.107274
7946	EUR	BYN	3.31545242	2026-01-23	2026-01-23 11:40:06.116419
7947	BYN	EUR	0.30161796138820773	2026-01-23	2026-01-23 11:40:06.12528
7948	EUR	BZD	2.35594142	2026-01-23	2026-01-23 11:40:06.134071
7949	BZD	EUR	0.4244587711353196	2026-01-23	2026-01-23 11:40:06.142827
7950	EUR	CAD	1.62038313	2026-01-23	2026-01-23 11:40:06.151713
7951	CAD	EUR	0.6171379974808797	2026-01-23	2026-01-23 11:40:06.160394
7952	EUR	CDF	2538.12028736	2026-01-23	2026-01-23 11:40:06.169889
7953	CDF	EUR	0.00039399235921956237	2026-01-23	2026-01-23 11:40:06.180845
7954	EUR	CHF	0.92795957	2026-01-23	2026-01-23 11:40:06.189833
7955	CHF	EUR	1.0776331559358778	2026-01-23	2026-01-23 11:40:06.198594
7956	EUR	CLP	1023.20673671	2026-01-23	2026-01-23 11:40:06.208446
7957	CLP	EUR	0.0009773196013304032	2026-01-23	2026-01-23 11:40:06.217451
7958	EUR	CNH	8.17907165	2026-01-23	2026-01-23 11:40:06.226262
7959	CNH	EUR	0.12226326443784119	2026-01-23	2026-01-23 11:40:06.235009
7960	EUR	CNY	8.18256368	2026-01-23	2026-01-23 11:40:06.243775
7961	CNY	EUR	0.12221108678252292	2026-01-23	2026-01-23 11:40:06.252711
7962	EUR	COP	4229.19787493	2026-01-23	2026-01-23 11:40:06.261316
7963	COP	EUR	0.00023645145712567343	2026-01-23	2026-01-23 11:40:06.274929
7964	EUR	CRC	579.86440007	2026-01-23	2026-01-23 11:40:06.284285
7965	CRC	EUR	0.0017245411166460333	2026-01-23	2026-01-23 11:40:06.293786
7966	EUR	CUP	28.11715177	2026-01-23	2026-01-23 11:40:06.305078
7967	CUP	EUR	0.03556548003795194	2026-01-23	2026-01-23 11:40:06.315035
7968	EUR	CVE	110.27	2026-01-23	2026-01-23 11:40:06.324767
7969	CVE	EUR	0.009068649678062937	2026-01-23	2026-01-23 11:40:06.334293
7970	EUR	CZK	24.26435988	2026-01-23	2026-01-23 11:40:06.351238
7971	CZK	EUR	0.041212708884368884	2026-01-23	2026-01-23 11:40:06.361745
7972	EUR	DJF	209.38282942	2026-01-23	2026-01-23 11:40:06.371457
7973	DJF	EUR	0.004775940810285378	2026-01-23	2026-01-23 11:40:06.394493
7974	EUR	DKK	7.46883304	2026-01-23	2026-01-23 11:40:06.404026
7975	DKK	EUR	0.13388972475946523	2026-01-23	2026-01-23 11:40:06.412678
7976	EUR	DOP	73.8736162	2026-01-23	2026-01-23 11:40:06.421466
7977	DOP	EUR	0.013536632581958266	2026-01-23	2026-01-23 11:40:06.430775
7978	EUR	DZD	152.43246163	2026-01-23	2026-01-23 11:40:06.439585
7979	DZD	EUR	0.006560282431358384	2026-01-23	2026-01-23 11:40:06.44844
7980	EUR	EGP	55.29762426	2026-01-23	2026-01-23 11:40:06.457464
7981	EGP	EUR	0.018083959544051488	2026-01-23	2026-01-23 11:40:06.466034
7982	EUR	ERN	17.62082613	2026-01-23	2026-01-23 11:40:06.475518
7983	ERN	EUR	0.056751028165329266	2026-01-23	2026-01-23 11:40:06.48474
7984	EUR	ETB	182.66641866	2026-01-23	2026-01-23 11:40:06.493918
7985	ETB	EUR	0.005474459987422847	2026-01-23	2026-01-23 11:40:06.502707
7986	EUR	EUR	1	2026-01-23	2026-01-23 11:40:06.520019
7988	EUR	FJD	2.64701	2026-01-23	2026-01-23 11:40:06.528885
7989	FJD	EUR	0.3777847458075338	2026-01-23	2026-01-23 11:40:06.538419
7990	EUR	FKP	0.87041871	2026-01-23	2026-01-23 11:40:06.550371
7991	FKP	EUR	1.1488723628194986	2026-01-23	2026-01-23 11:40:06.560015
7992	EUR	GBP	0.87041871	2026-01-23	2026-01-23 11:40:06.568876
7993	GBP	EUR	1.1488723628194986	2026-01-23	2026-01-23 11:40:06.577588
7994	EUR	GEL	3.16085129	2026-01-23	2026-01-23 11:40:06.586325
7995	GEL	EUR	0.3163704674002553	2026-01-23	2026-01-23 11:40:06.595363
7996	EUR	GGP	0.87041871	2026-01-23	2026-01-23 11:40:06.603826
7997	GGP	EUR	1.1488723628194986	2026-01-23	2026-01-23 11:40:06.613064
7998	EUR	GHS	12.77299402	2026-01-23	2026-01-23 11:40:06.621976
7999	GHS	EUR	0.07829017992447161	2026-01-23	2026-01-23 11:40:06.630548
8000	EUR	GIP	0.87041871	2026-01-23	2026-01-23 11:40:06.639337
8001	GIP	EUR	1.1488723628194986	2026-01-23	2026-01-23 11:40:06.647822
8002	EUR	GMD	86.35940775	2026-01-23	2026-01-23 11:40:06.656356
8003	GMD	EUR	0.01157951433496254	2026-01-23	2026-01-23 11:40:06.665197
8004	EUR	GNF	10284.75216456	2026-01-23	2026-01-23 11:40:06.674388
8005	GNF	EUR	9.723131719652689e-05	2026-01-23	2026-01-23 11:40:06.683223
8006	EUR	GTQ	9.01238876	2026-01-23	2026-01-23 11:40:06.691453
8007	GTQ	EUR	0.1109583737042431	2026-01-23	2026-01-23 11:40:06.700092
8008	EUR	GYD	245.69494573	2026-01-23	2026-01-23 11:40:06.708974
8009	GYD	EUR	0.004070087795370946	2026-01-23	2026-01-23 11:40:06.718519
8010	EUR	HKD	9.15975246	2026-01-23	2026-01-23 11:40:06.727231
8011	HKD	EUR	0.10917325597683238	2026-01-23	2026-01-23 11:40:06.736182
8012	EUR	HNL	31.01515168	2026-01-23	2026-01-23 11:40:06.744476
8013	HNL	EUR	0.03224230564201452	2026-01-23	2026-01-23 11:40:06.753226
8014	EUR	HRK	7.5345	2026-01-23	2026-01-23 11:40:06.761514
8015	HRK	EUR	0.13272280841462605	2026-01-23	2026-01-23 11:40:06.76996
8016	EUR	HTG	153.51638052	2026-01-23	2026-01-23 11:40:06.778673
8017	HTG	EUR	0.006513962852776617	2026-01-23	2026-01-23 11:40:06.786887
8018	EUR	HUF	382.00984622	2026-01-23	2026-01-23 11:40:06.795496
8019	HUF	EUR	0.0026177335738725924	2026-01-23	2026-01-23 11:40:06.805217
8020	EUR	IDR	19791.32433031	2026-01-23	2026-01-23 11:40:06.81404
8021	IDR	EUR	5.052718975801538e-05	2026-01-23	2026-01-23 11:40:06.822536
8022	EUR	ILS	3.6865038	2026-01-23	2026-01-23 11:40:06.831214
8023	ILS	EUR	0.2712597231013298	2026-01-23	2026-01-23 11:40:06.839879
8024	EUR	IMP	0.87041871	2026-01-23	2026-01-23 11:40:06.848692
8025	IMP	EUR	1.1488723628194986	2026-01-23	2026-01-23 11:40:06.858321
8026	EUR	INR	107.59283395	2026-01-23	2026-01-23 11:40:06.867045
8027	INR	EUR	0.00929429928822876	2026-01-23	2026-01-23 11:40:06.876989
8028	EUR	IQD	1536.48052295	2026-01-23	2026-01-23 11:40:06.885542
8029	IQD	EUR	0.0006508380581877001	2026-01-23	2026-01-23 11:40:06.894563
8030	EUR	IRR	1263121.35465038	2026-01-23	2026-01-23 11:40:06.903853
8031	IRR	EUR	7.916895683208447e-07	2026-01-23	2026-01-23 11:40:06.912548
8032	EUR	ISK	146.00726207	2026-01-23	2026-01-23 11:40:06.920793
8033	ISK	EUR	0.006848974399099216	2026-01-23	2026-01-23 11:40:06.929358
8034	EUR	JEP	0.87041871	2026-01-23	2026-01-23 11:40:06.937749
8035	JEP	EUR	1.1488723628194986	2026-01-23	2026-01-23 11:40:06.946538
8036	EUR	JMD	184.55367664	2026-01-23	2026-01-23 11:40:06.95498
8037	JMD	EUR	0.005418477801180044	2026-01-23	2026-01-23 11:40:06.96331
8038	EUR	JOD	0.83287771	2026-01-23	2026-01-23 11:40:06.971795
8039	JOD	EUR	1.2006564565162874	2026-01-23	2026-01-23 11:40:06.980961
8040	EUR	JPY	186.40266955	2026-01-23	2026-01-23 11:40:06.990443
8041	JPY	EUR	0.0053647300353269	2026-01-23	2026-01-23 11:40:06.999589
8042	EUR	KES	151.53784669	2026-01-23	2026-01-23 11:40:07.008263
8043	KES	EUR	0.006599011546242263	2026-01-23	2026-01-23 11:40:07.016964
8044	EUR	KGS	102.73872289	2026-01-23	2026-01-23 11:40:07.026173
8045	KGS	EUR	0.009733428369269074	2026-01-23	2026-01-23 11:40:07.035712
8046	EUR	KHR	4723.87020503	2026-01-23	2026-01-23 11:40:07.044648
8047	KHR	EUR	0.0002116908290442009	2026-01-23	2026-01-23 11:40:07.053628
8048	EUR	KMF	491.96775001	2026-01-23	2026-01-23 11:40:07.062101
8049	KMF	EUR	0.002032653563124155	2026-01-23	2026-01-23 11:40:07.071173
8050	EUR	KRW	1725.55261423	2026-01-23	2026-01-23 11:40:07.082347
8051	KRW	EUR	0.0005795244907361077	2026-01-23	2026-01-23 11:40:07.094123
8052	EUR	KWD	0.36086009	2026-01-23	2026-01-23 11:40:07.104034
8053	KWD	EUR	2.7711570985863245	2026-01-23	2026-01-23 11:40:07.112546
8054	EUR	KYD	0.97374753	2026-01-23	2026-01-23 11:40:07.121072
8055	KYD	EUR	1.0269602429697562	2026-01-23	2026-01-23 11:40:07.129799
8056	EUR	KZT	593.44800649	2026-01-23	2026-01-23 11:40:07.139149
8057	KZT	EUR	0.0016850675864842604	2026-01-23	2026-01-23 11:40:07.147591
8058	EUR	LAK	25326.61902505	2026-01-23	2026-01-23 11:40:07.157234
8059	LAK	EUR	3.948414902956143e-05	2026-01-23	2026-01-23 11:40:07.166063
8060	EUR	LBP	101134.86547698	2026-01-23	2026-01-23 11:40:07.175315
8061	LBP	EUR	9.887786919809734e-06	2026-01-23	2026-01-23 11:40:07.184762
8062	EUR	LKR	363.53216544	2026-01-23	2026-01-23 11:40:07.193554
8063	LKR	EUR	0.0027507882247218844	2026-01-23	2026-01-23 11:40:07.202352
8064	EUR	LRD	217.50910689	2026-01-23	2026-01-23 11:40:07.211368
8065	LRD	EUR	0.00459750864825042	2026-01-23	2026-01-23 11:40:07.220612
8066	EUR	LSL	18.92736794	2026-01-23	2026-01-23 11:40:07.229677
8067	LSL	EUR	0.052833547864130546	2026-01-23	2026-01-23 11:40:07.239478
8068	EUR	LYD	7.37655187	2026-01-23	2026-01-23 11:40:07.248186
8069	LYD	EUR	0.13556469440239968	2026-01-23	2026-01-23 11:40:07.257251
8070	EUR	MAD	10.77337242	2026-01-23	2026-01-23 11:40:07.266283
8071	MAD	EUR	0.09282144541328313	2026-01-23	2026-01-23 11:40:07.274733
8072	EUR	MDL	19.98351888	2026-01-23	2026-01-23 11:40:07.283598
8073	MDL	EUR	0.05004123678141715	2026-01-23	2026-01-23 11:40:07.292877
8074	EUR	MGA	5333.27846358	2026-01-23	2026-01-23 11:40:07.301771
8075	MGA	EUR	0.00018750192903461168	2026-01-23	2026-01-23 11:40:07.311033
8076	EUR	MKD	61.67684334	2026-01-23	2026-01-23 11:40:07.319973
8077	MKD	EUR	0.01621354054207016	2026-01-23	2026-01-23 11:40:07.329063
8078	EUR	MMK	2466.72243903	2026-01-23	2026-01-23 11:40:07.337712
8079	MMK	EUR	0.0004053962392271562	2026-01-23	2026-01-23 11:40:07.346879
8080	EUR	MNT	4199.03775406	2026-01-23	2026-01-23 11:40:07.35575
8081	MNT	EUR	0.00023814979968520448	2026-01-23	2026-01-23 11:40:07.364374
8082	EUR	MOP	9.43454503	2026-01-23	2026-01-23 11:40:07.373378
8083	MOP	EUR	0.10599345244738313	2026-01-23	2026-01-23 11:40:07.382455
8084	EUR	MRU	46.87700423	2026-01-23	2026-01-23 11:40:07.391111
8085	MRU	EUR	0.021332421224990045	2026-01-23	2026-01-23 11:40:07.399593
8086	EUR	MUR	54.13780959	2026-01-23	2026-01-23 11:40:07.408209
8087	MUR	EUR	0.018471379015391743	2026-01-23	2026-01-23 11:40:07.416812
8088	EUR	MVR	18.15687263	2026-01-23	2026-01-23 11:40:07.42556
8089	MVR	EUR	0.05507556396841894	2026-01-23	2026-01-23 11:40:07.434673
8090	EUR	MWK	2032.5821132	2026-01-23	2026-01-23 11:40:07.443463
8091	MWK	EUR	0.000491985043805019	2026-01-23	2026-01-23 11:40:07.453524
8092	EUR	MXN	20.5033939	2026-01-23	2026-01-23 11:40:07.462065
8093	MXN	EUR	0.04877241323447432	2026-01-23	2026-01-23 11:40:07.470131
8094	EUR	MYR	4.72649091	2026-01-23	2026-01-23 11:40:07.478967
8095	MYR	EUR	0.21157345249184029	2026-01-23	2026-01-23 11:40:07.488449
8096	EUR	MZN	75.06750669	2026-01-23	2026-01-23 11:40:07.497173
8097	MZN	EUR	0.013321342936426759	2026-01-23	2026-01-23 11:40:07.507597
8098	EUR	NAD	18.92736794	2026-01-23	2026-01-23 11:40:07.516566
8099	NAD	EUR	0.052833547864130546	2026-01-23	2026-01-23 11:40:07.526711
8100	EUR	NGN	1667.76798405	2026-01-23	2026-01-23 11:40:07.535602
8101	NGN	EUR	0.0005996037875553917	2026-01-23	2026-01-23 11:40:07.54399
8102	EUR	NIO	43.13686941	2026-01-23	2026-01-23 11:40:07.552338
8103	NIO	EUR	0.02318202534577485	2026-01-23	2026-01-23 11:40:07.560822
8104	EUR	NOK	11.56979357	2026-01-23	2026-01-23 11:40:07.5697
8105	NOK	EUR	0.08643196561371319	2026-01-23	2026-01-23 11:40:07.578201
8106	EUR	NPR	172.22922895	2026-01-23	2026-01-23 11:40:07.586503
8107	NPR	EUR	0.005806215391525156	2026-01-23	2026-01-23 11:40:07.594884
8108	EUR	NZD	1.98565775	2026-01-23	2026-01-23 11:40:07.603745
8109	NZD	EUR	0.5036114607363731	2026-01-23	2026-01-23 11:40:07.612123
8110	EUR	OMR	0.45210343	2026-01-23	2026-01-23 11:40:07.621343
8111	OMR	EUR	2.211883240965458	2026-01-23	2026-01-23 11:40:07.630135
8112	EUR	PAB	1.17472174	2026-01-23	2026-01-23 11:40:07.639552
8113	PAB	EUR	0.8512654239292446	2026-01-23	2026-01-23 11:40:07.648675
8114	EUR	PEN	3.94187806	2026-01-23	2026-01-23 11:40:07.657208
8115	PEN	EUR	0.25368618328086995	2026-01-23	2026-01-23 11:40:07.666096
8116	EUR	PGK	5.0146962	2026-01-23	2026-01-23 11:40:07.674598
8117	PGK	EUR	0.19941387476274233	2026-01-23	2026-01-23 11:40:07.683522
8118	EUR	PHP	69.35199404	2026-01-23	2026-01-23 11:40:07.693285
8119	PHP	EUR	0.01441919607132323	2026-01-23	2026-01-23 11:40:07.701753
8120	EUR	PKR	327.85872115	2026-01-23	2026-01-23 11:40:07.711013
8121	PKR	EUR	0.0030500942494144784	2026-01-23	2026-01-23 11:40:07.719527
8122	EUR	PLN	4.1997945	2026-01-23	2026-01-23 11:40:07.72831
8123	PLN	EUR	0.23810688832513113	2026-01-23	2026-01-23 11:40:07.736879
8124	EUR	PYG	7870.52055191	2026-01-23	2026-01-23 11:40:07.745501
8125	PYG	EUR	0.00012705639905321412	2026-01-23	2026-01-23 11:40:07.754529
8126	EUR	QAR	4.27598714	2026-01-23	2026-01-23 11:40:07.763011
8127	QAR	EUR	0.23386412710305768	2026-01-23	2026-01-23 11:40:07.771217
8128	EUR	RON	5.09163217	2026-01-23	2026-01-23 11:40:07.780423
8129	RON	EUR	0.19640067597420338	2026-01-23	2026-01-23 11:40:07.789385
8130	EUR	RSD	117.41589115	2026-01-23	2026-01-23 11:40:07.797669
8131	RSD	EUR	0.008516734746938894	2026-01-23	2026-01-23 11:40:07.806252
8132	EUR	RUB	89.25457914	2026-01-23	2026-01-23 11:40:07.81478
8133	RUB	EUR	0.011203906955086898	2026-01-23	2026-01-23 11:40:07.823524
8134	EUR	RWF	1707.89285217	2026-01-23	2026-01-23 11:40:07.832594
8135	RWF	EUR	0.0005855168248578525	2026-01-23	2026-01-23 11:40:07.841069
8136	EUR	SAR	4.40520653	2026-01-23	2026-01-23 11:40:07.850068
8137	SAR	EUR	0.22700411279014426	2026-01-23	2026-01-23 11:40:07.859463
8138	EUR	SBD	9.50875763	2026-01-23	2026-01-23 11:40:07.868212
8139	SBD	EUR	0.10516620981536155	2026-01-23	2026-01-23 11:40:07.877138
8140	EUR	SCR	17.09371613	2026-01-23	2026-01-23 11:40:07.886052
8141	SCR	EUR	0.05850102999224195	2026-01-23	2026-01-23 11:40:07.895887
8142	EUR	SDG	704.86223543	2026-01-23	2026-01-23 11:40:07.904507
8143	SDG	EUR	0.0014187169488374585	2026-01-23	2026-01-23 11:40:07.913257
8144	EUR	SEK	10.58156489	2026-01-23	2026-01-23 11:40:07.92141
8145	SEK	EUR	0.09450398030871973	2026-01-23	2026-01-23 11:40:07.931848
8146	EUR	SGD	1.50450237	2026-01-23	2026-01-23 11:40:07.941033
8147	SGD	EUR	0.6646716016804946	2026-01-23	2026-01-23 11:40:07.950849
8148	EUR	SHP	0.87041871	2026-01-23	2026-01-23 11:40:07.960396
8149	SHP	EUR	1.1488723628194986	2026-01-23	2026-01-23 11:40:07.969523
8150	EUR	SLE	26.97159561	2026-01-23	2026-01-23 11:40:07.980833
8151	SLE	EUR	0.03707604156830972	2026-01-23	2026-01-23 11:40:07.989901
8152	EUR	SOS	664.54123192	2026-01-23	2026-01-23 11:40:07.999038
8153	SOS	EUR	0.0015047975234144446	2026-01-23	2026-01-23 11:40:08.011088
8154	EUR	SRD	44.89213968	2026-01-23	2026-01-23 11:40:08.020209
8155	SRD	EUR	0.02227561455364339	2026-01-23	2026-01-23 11:40:08.045866
8156	EUR	SSP	5337.35905	2026-01-23	2026-01-23 11:40:08.054656
8157	SSP	EUR	0.00018735857764712308	2026-01-23	2026-01-23 11:40:08.063226
8158	EUR	STN	24.81631863	2026-01-23	2026-01-23 11:40:08.071578
8159	STN	EUR	0.04029606546037485	2026-01-23	2026-01-23 11:40:08.081713
8160	EUR	SYP	129.89549291	2026-01-23	2026-01-23 11:40:08.090517
8161	SYP	EUR	0.007698496518989036	2026-01-23	2026-01-23 11:40:08.099213
8162	EUR	SZL	18.92736794	2026-01-23	2026-01-23 11:40:08.108093
8163	SZL	EUR	0.052833547864130546	2026-01-23	2026-01-23 11:40:08.116487
8164	EUR	THB	36.69643285	2026-01-23	2026-01-23 11:40:08.125335
8165	THB	EUR	0.027250605095257917	2026-01-23	2026-01-23 11:40:08.13413
8166	EUR	TJS	10.9607359	2026-01-23	2026-01-23 11:40:08.14384
8167	TJS	EUR	0.0912347500317018	2026-01-23	2026-01-23 11:40:08.15294
8168	EUR	TMT	4.10916506	2026-01-23	2026-01-23 11:40:08.161473
8169	TMT	EUR	0.24335844031536666	2026-01-23	2026-01-23 11:40:08.170145
8170	EUR	TND	3.37579749	2026-01-23	2026-01-23 11:40:08.178621
8171	TND	EUR	0.2962262999964491	2026-01-23	2026-01-23 11:40:08.188074
8172	EUR	TOP	2.80157077	2026-01-23	2026-01-23 11:40:08.196851
8173	TOP	EUR	0.3569426161595768	2026-01-23	2026-01-23 11:40:08.20582
8174	EUR	TRY	50.92606347	2026-01-23	2026-01-23 11:40:08.214438
8175	TRY	EUR	0.019636310601330677	2026-01-23	2026-01-23 11:40:08.223013
8176	EUR	TTD	7.96698433	2026-01-23	2026-01-23 11:40:08.231828
8177	TTD	EUR	0.1255180076399121	2026-01-23	2026-01-23 11:40:08.24011
8178	EUR	TVD	1.71667181	2026-01-23	2026-01-23 11:40:08.248317
8179	TVD	EUR	0.5825225265393039	2026-01-23	2026-01-23 11:40:08.257014
8180	EUR	TWD	37.12394828	2026-01-23	2026-01-23 11:40:08.265958
8181	TWD	EUR	0.026936790032614493	2026-01-23	2026-01-23 11:40:08.27555
8182	EUR	TZS	2985.62302904	2026-01-23	2026-01-23 11:40:08.284464
8183	TZS	EUR	0.0003349384668705282	2026-01-23	2026-01-23 11:40:08.293351
8184	EUR	UAH	50.66965422	2026-01-23	2026-01-23 11:40:08.30195
8185	UAH	EUR	0.01973567839358348	2026-01-23	2026-01-23 11:40:08.31214
8186	EUR	UGX	4117.70287111	2026-01-23	2026-01-23 11:40:08.320788
8187	UGX	EUR	0.00024285385111588495	2026-01-23	2026-01-23 11:40:08.329525
8188	EUR	USD	1.17472174	2026-01-23	2026-01-23 11:40:08.343061
8189	USD	EUR	0.8512654239292446	2026-01-23	2026-01-23 11:40:08.354
8190	EUR	UYU	44.48763769	2026-01-23	2026-01-23 11:40:08.364729
8191	UYU	EUR	0.02247815464979795	2026-01-23	2026-01-23 11:40:08.373777
8192	EUR	UZS	14267.33482453	2026-01-23	2026-01-23 11:40:08.383118
8193	UZS	EUR	7.009017537604066e-05	2026-01-23	2026-01-23 11:40:08.392372
8194	EUR	VES	413.56281428	2026-01-23	2026-01-23 11:40:08.401176
8195	VES	EUR	0.002418012368304846	2026-01-23	2026-01-23 11:40:08.410653
8196	EUR	VND	30845.93032069	2026-01-23	2026-01-23 11:40:08.420095
8197	VND	EUR	3.241918754284571e-05	2026-01-23	2026-01-23 11:40:08.429279
8198	EUR	VUV	140.96923416	2026-01-23	2026-01-23 11:40:08.438278
8199	VUV	EUR	0.0070937464189171975	2026-01-23	2026-01-23 11:40:08.447063
8200	EUR	WST	3.2216264	2026-01-23	2026-01-23 11:40:08.45579
8201	WST	EUR	0.31040222416851315	2026-01-23	2026-01-23 11:40:08.464629
8202	EUR	XAF	655.95700001	2026-01-23	2026-01-23 11:40:08.474606
8203	XAF	EUR	0.001524490172350863	2026-01-23	2026-01-23 11:40:08.483467
8204	EUR	XCD	3.17896166	2026-01-23	2026-01-23 11:40:08.492008
8205	XCD	EUR	0.31456812222139224	2026-01-23	2026-01-23 11:40:08.500757
8206	EUR	XDR	0.85969112	2026-01-23	2026-01-23 11:40:08.509929
8207	XDR	EUR	1.1632084788778556	2026-01-23	2026-01-23 11:40:08.518606
8208	EUR	XOF	655.95700001	2026-01-23	2026-01-23 11:40:08.527536
8209	XOF	EUR	0.001524490172350863	2026-01-23	2026-01-23 11:40:08.536275
8210	EUR	XPF	119.33174225	2026-01-23	2026-01-23 11:40:08.545126
8211	XPF	EUR	0.0083799999995391	2026-01-23	2026-01-23 11:40:08.553819
8212	EUR	YER	279.93471101	2026-01-23	2026-01-23 11:40:08.562429
8213	YER	EUR	0.0035722615333840376	2026-01-23	2026-01-23 11:40:08.571486
8214	EUR	ZAR	18.92736794	2026-01-23	2026-01-23 11:40:08.580326
8215	ZAR	EUR	0.052833547864130546	2026-01-23	2026-01-23 11:40:08.589824
8216	EUR	ZMW	23.31156262	2026-01-23	2026-01-23 11:40:08.598904
8217	ZMW	EUR	0.04289716722559202	2026-01-23	2026-01-23 11:40:08.608231
8218	EUR	ZWL	75186.97140191	2026-01-23	2026-01-23 11:40:08.616764
8219	ZWL	EUR	1.3300176631061863e-05	2026-01-23	2026-01-23 11:40:08.625959
8220	EUR	AED	4.34250036	2026-01-25	2026-01-26 12:30:47.415067
8221	AED	EUR	0.2302820764763276	2026-01-25	2026-01-26 12:30:47.437397
8222	EUR	AFN	78.29040384	2026-01-25	2026-01-26 12:30:47.446486
8223	AFN	EUR	0.012772957488425699	2026-01-25	2026-01-26 12:30:47.452938
8224	EUR	ALL	96.66586465	2026-01-25	2026-01-26 12:30:47.45892
8225	ALL	EUR	0.010344913415099731	2026-01-25	2026-01-26 12:30:47.488278
8226	EUR	AMD	452.36138055	2026-01-25	2026-01-26 12:30:47.49487
8227	AMD	EUR	0.002210621956242502	2026-01-25	2026-01-26 12:30:47.500751
8228	EUR	ANG	2.12497467	2026-01-25	2026-01-26 12:30:47.506438
8229	ANG	EUR	0.47059384477274735	2026-01-25	2026-01-26 12:30:47.512356
8230	EUR	AOA	1079.29310563	2026-01-25	2026-01-26 12:30:47.518021
8231	AOA	EUR	0.0009265323708486813	2026-01-25	2026-01-26 12:30:47.524056
8232	EUR	ARS	1696.17253514	2026-01-25	2026-01-26 12:30:47.529443
8233	ARS	EUR	0.0005895626649310539	2026-01-25	2026-01-26 12:30:47.535951
8234	EUR	AUD	1.71531717	2026-01-25	2026-01-26 12:30:47.541429
8235	AUD	EUR	0.5829825629274148	2026-01-25	2026-01-26 12:30:47.547307
8236	EUR	AWG	2.11656246	2026-01-25	2026-01-26 12:30:47.591997
8237	AWG	EUR	0.47246420500153824	2026-01-25	2026-01-26 12:30:47.597627
8238	EUR	AZN	2.01162208	2026-01-25	2026-01-26 12:30:47.602935
8239	AZN	EUR	0.4971112665456526	2026-01-25	2026-01-26 12:30:47.607947
8240	EUR	BAM	1.95583	2026-01-25	2026-01-26 12:30:47.613692
8241	BAM	EUR	0.5112918811962185	2026-01-25	2026-01-26 12:30:47.618953
8242	EUR	BBD	2.36487426	2026-01-25	2026-01-26 12:30:47.624547
8243	BBD	EUR	0.4228554629369597	2026-01-25	2026-01-26 12:30:47.629996
8244	EUR	BDT	144.66538634	2026-01-25	2026-01-26 12:30:47.635234
8245	BDT	EUR	0.006912503573244182	2026-01-25	2026-01-26 12:30:47.640675
8246	EUR	BGN	1.95583	2026-01-25	2026-01-26 12:30:47.655701
8247	BGN	EUR	0.5112918811962185	2026-01-25	2026-01-26 12:30:47.661301
8248	EUR	BHD	0.44459636	2026-01-25	2026-01-26 12:30:47.685777
8249	BHD	EUR	2.249231190286848	2026-01-25	2026-01-26 12:30:47.696025
8250	EUR	BIF	3498.34760185	2026-01-25	2026-01-26 12:30:47.701831
8251	BIF	EUR	0.00028584923907252064	2026-01-25	2026-01-26 12:30:47.708726
8252	EUR	BMD	1.18243713	2026-01-25	2026-01-26 12:30:47.71442
8253	BMD	EUR	0.8457109258739194	2026-01-25	2026-01-26 12:30:47.721196
8254	EUR	BND	1.50503373	2026-01-25	2026-01-26 12:30:47.726842
8255	BND	EUR	0.6644369359084065	2026-01-25	2026-01-26 12:30:47.732518
8256	EUR	BOB	8.17663479	2026-01-25	2026-01-26 12:30:47.738249
8257	BOB	EUR	0.12229970222260594	2026-01-25	2026-01-26 12:30:47.743938
8258	EUR	BRL	6.2551696	2026-01-25	2026-01-26 12:30:47.749759
8259	BRL	EUR	0.15986776761416668	2026-01-25	2026-01-26 12:30:47.755826
8260	EUR	BSD	1.18243713	2026-01-25	2026-01-26 12:30:47.761508
8261	BSD	EUR	0.8457109258739194	2026-01-25	2026-01-26 12:30:47.790754
8262	EUR	BTN	108.41674074	2026-01-25	2026-01-26 12:30:47.796404
8263	BTN	EUR	0.00922366779497784	2026-01-25	2026-01-26 12:30:47.80182
8264	EUR	BWP	15.59198576	2026-01-25	2026-01-26 12:30:47.807603
8265	BWP	EUR	0.0641355126532645	2026-01-25	2026-01-26 12:30:47.812853
8266	EUR	BYN	3.33582639	2026-01-25	2026-01-26 12:30:47.81912
8267	BYN	EUR	0.2997757925885346	2026-01-25	2026-01-26 12:30:47.840255
8268	EUR	BZD	2.37906182	2026-01-25	2026-01-26 12:30:47.845986
8269	BZD	EUR	0.4203337599692975	2026-01-25	2026-01-26 12:30:47.851488
8270	EUR	CAD	1.62211278	2026-01-25	2026-01-26 12:30:47.856903
8271	CAD	EUR	0.6164799466039593	2026-01-25	2026-01-26 12:30:47.862098
8272	EUR	CDF	2614.52073929	2026-01-25	2026-01-26 12:30:47.868688
8273	CDF	EUR	0.00038247927621012494	2026-01-25	2026-01-26 12:30:47.881747
8274	EUR	CHF	0.92300717	2026-01-25	2026-01-26 12:30:47.892593
8275	CHF	EUR	1.0834152025059567	2026-01-25	2026-01-26 12:30:47.956517
8276	EUR	CLP	1024.66670948	2026-01-25	2026-01-26 12:30:47.991979
8277	CLP	EUR	0.000975927089997373	2026-01-25	2026-01-26 12:30:48.024506
8278	EUR	CNH	8.21805691	2026-01-25	2026-01-26 12:30:48.035408
8279	CNH	EUR	0.12168326539369269	2026-01-25	2026-01-26 12:30:48.070039
8280	EUR	CNY	8.23372953	2026-01-25	2026-01-26 12:30:48.099391
8281	CNY	EUR	0.12145164549751733	2026-01-25	2026-01-26 12:30:48.10508
8282	EUR	COP	4304.60457479	2026-01-25	2026-01-26 12:30:48.110417
8283	COP	EUR	0.0002323093753736451	2026-01-25	2026-01-26 12:30:48.115746
8284	EUR	CRC	588.35070821	2026-01-25	2026-01-26 12:30:48.121267
8285	CRC	EUR	0.00169966651870345	2026-01-25	2026-01-26 12:30:48.126524
8286	EUR	CUP	28.30515008	2026-01-25	2026-01-26 12:30:48.132079
8287	CUP	EUR	0.03532925976981783	2026-01-25	2026-01-26 12:30:48.137902
8288	EUR	CVE	110.27	2026-01-25	2026-01-26 12:30:48.143845
8289	CVE	EUR	0.009068649678062937	2026-01-25	2026-01-26 12:30:48.149384
8290	EUR	CZK	24.26758251	2026-01-25	2026-01-26 12:30:48.158617
8291	CZK	EUR	0.04120723601487407	2026-01-25	2026-01-26 12:30:48.164
8292	EUR	DJF	210.88093229	2026-01-25	2026-01-26 12:30:48.193276
8293	DJF	EUR	0.004742012419713776	2026-01-25	2026-01-26 12:30:48.200862
8294	EUR	DKK	7.47259201	2026-01-25	2026-01-26 12:30:48.209205
8295	DKK	EUR	0.13382237363712302	2026-01-25	2026-01-26 12:30:48.21573
8296	EUR	DOP	74.39503337	2026-01-25	2026-01-26 12:30:48.221501
8297	DOP	EUR	0.013441757530056473	2026-01-25	2026-01-26 12:30:48.227122
8298	EUR	DZD	153.42134198	2026-01-25	2026-01-26 12:30:48.232922
8299	DZD	EUR	0.0065179979988074935	2026-01-25	2026-01-26 12:30:48.23866
8300	EUR	EGP	55.72809769	2026-01-25	2026-01-26 12:30:48.245465
8301	EGP	EUR	0.01794426943411425	2026-01-25	2026-01-26 12:30:48.250714
8302	EUR	ERN	17.73655696	2026-01-25	2026-01-26 12:30:48.256725
8303	ERN	EUR	0.05638072835980676	2026-01-25	2026-01-26 12:30:48.290056
8304	EUR	ETB	184.07783609	2026-01-25	2026-01-26 12:30:48.298191
8305	ETB	EUR	0.0054324845469775965	2026-01-25	2026-01-26 12:30:48.30354
8306	EUR	EUR	1	2026-01-25	2026-01-26 12:30:48.337438
8308	EUR	FJD	2.66539661	2026-01-25	2026-01-26 12:30:48.342713
8309	FJD	EUR	0.3751786868221461	2026-01-25	2026-01-26 12:30:48.348795
8310	EUR	FKP	0.86681911	2026-01-25	2026-01-26 12:30:48.356684
8311	FKP	EUR	1.1536432324386572	2026-01-25	2026-01-26 12:30:48.36313
8312	EUR	GBP	0.86681911	2026-01-25	2026-01-26 12:30:48.368234
8313	GBP	EUR	1.1536432324386572	2026-01-25	2026-01-26 12:30:48.374767
8314	EUR	GEL	3.18277964	2026-01-25	2026-01-26 12:30:48.379756
8315	GEL	EUR	0.31419077445147914	2026-01-25	2026-01-26 12:30:48.3874
8316	EUR	GGP	0.86681911	2026-01-25	2026-01-26 12:30:48.392793
8317	GGP	EUR	1.1536432324386572	2026-01-25	2026-01-26 12:30:48.397954
8318	EUR	GHS	12.87568991	2026-01-25	2026-01-26 12:30:48.403428
8319	GHS	EUR	0.07766574117502958	2026-01-25	2026-01-26 12:30:48.408815
8320	EUR	GIP	0.86681911	2026-01-25	2026-01-26 12:30:48.413725
8321	GIP	EUR	1.1536432324386572	2026-01-25	2026-01-26 12:30:48.41895
8322	EUR	GMD	87.08130221	2026-01-25	2026-01-26 12:30:48.42471
8323	GMD	EUR	0.011483521429071657	2026-01-25	2026-01-26 12:30:48.429759
8324	EUR	GNF	10349.27745979	2026-01-25	2026-01-26 12:30:48.435013
8325	GNF	EUR	9.662510294900252e-05	2026-01-25	2026-01-26 12:30:48.440527
8326	EUR	GTQ	9.06677311	2026-01-25	2026-01-26 12:30:48.446137
8327	GTQ	EUR	0.11029282280120938	2026-01-25	2026-01-26 12:30:48.451137
8328	EUR	GYD	247.43164674	2026-01-25	2026-01-26 12:30:48.456364
8329	GYD	EUR	0.004041520206389748	2026-01-25	2026-01-26 12:30:48.490842
8330	EUR	HKD	9.22004437	2026-01-25	2026-01-26 12:30:48.497074
8331	HKD	EUR	0.10845934790224876	2026-01-25	2026-01-26 12:30:48.502638
8332	EUR	HNL	31.27561414	2026-01-25	2026-01-26 12:30:48.50764
8333	HNL	EUR	0.0319737926015991	2026-01-25	2026-01-26 12:30:48.513216
8334	EUR	HRK	7.5345	2026-01-25	2026-01-26 12:30:48.518509
8335	HRK	EUR	0.13272280841462605	2026-01-25	2026-01-26 12:30:48.523787
8336	EUR	HTG	155.56292316	2026-01-25	2026-01-26 12:30:48.529076
8337	HTG	EUR	0.006428266965461155	2026-01-25	2026-01-26 12:30:48.535344
8338	EUR	HUF	382.20176539	2026-01-25	2026-01-26 12:30:48.540863
8339	HUF	EUR	0.00261641910256379	2026-01-25	2026-01-26 12:30:48.546166
8340	EUR	IDR	19930.57458482	2026-01-25	2026-01-26 12:30:48.551578
8341	IDR	EUR	5.0174168122661346e-05	2026-01-25	2026-01-26 12:30:48.556448
8342	EUR	ILS	3.69898382	2026-01-25	2026-01-26 12:30:48.561832
8343	ILS	EUR	0.2703445185656422	2026-01-25	2026-01-26 12:30:48.590403
8344	EUR	IMP	0.86681911	2026-01-25	2026-01-26 12:30:48.596104
8345	IMP	EUR	1.1536432324386572	2026-01-25	2026-01-26 12:30:48.602364
8346	EUR	INR	108.41674074	2026-01-25	2026-01-26 12:30:48.607591
8347	INR	EUR	0.00922366779497784	2026-01-25	2026-01-26 12:30:48.614104
8348	EUR	IQD	1549.28682546	2026-01-25	2026-01-26 12:30:48.619452
8349	IQD	EUR	0.0006454582738112997	2026-01-25	2026-01-26 12:30:48.625677
8350	EUR	IRR	1272517.84497105	2026-01-25	2026-01-26 12:30:48.630898
8351	IRR	EUR	7.858435965766359e-07	2026-01-25	2026-01-26 12:30:48.636613
8352	EUR	ISK	146.06095792	2026-01-25	2026-01-26 12:30:48.642127
8353	ISK	EUR	0.006846456535960257	2026-01-25	2026-01-26 12:30:48.647495
8354	EUR	JEP	0.86681911	2026-01-25	2026-01-26 12:30:48.6531
8355	JEP	EUR	1.1536432324386572	2026-01-25	2026-01-26 12:30:48.658792
8356	EUR	JMD	186.35492959	2026-01-25	2026-01-26 12:30:48.689027
8357	JMD	EUR	0.005366104359031998	2026-01-25	2026-01-26 12:30:48.694519
8358	EUR	JOD	0.83834793	2026-01-25	2026-01-26 12:30:48.699705
8359	JOD	EUR	1.192822173485894	2026-01-25	2026-01-26 12:30:48.704896
8360	EUR	JPY	184.17118997	2026-01-25	2026-01-26 12:30:48.710274
8361	JPY	EUR	0.005429730894190844	2026-01-25	2026-01-26 12:30:48.715612
8362	EUR	KES	152.55172326	2026-01-25	2026-01-26 12:30:48.72111
8363	KES	EUR	0.006555153744777173	2026-01-25	2026-01-26 12:30:48.726282
8364	EUR	KGS	103.41048792	2026-01-25	2026-01-26 12:30:48.731433
8365	KGS	EUR	0.009670199030233915	2026-01-25	2026-01-26 12:30:48.737972
8366	EUR	KHR	4760.37937016	2026-01-25	2026-01-26 12:30:48.745467
8367	KHR	EUR	0.00021006729133152876	2026-01-25	2026-01-26 12:30:48.750709
8368	EUR	KMF	491.96775001	2026-01-25	2026-01-26 12:30:48.756624
8369	KMF	EUR	0.002032653563124155	2026-01-25	2026-01-26 12:30:48.761654
8370	EUR	KRW	1718.58798106	2026-01-25	2026-01-26 12:30:48.789784
8371	KRW	EUR	0.0005818730324083929	2026-01-25	2026-01-26 12:30:48.795604
8372	EUR	KWD	0.36244172	2026-01-25	2026-01-26 12:30:48.802751
8373	KWD	EUR	2.7590642710778437	2026-01-25	2026-01-26 12:30:48.808457
8374	EUR	KYD	0.97341425	2026-01-25	2026-01-26 12:30:48.814222
8375	KYD	EUR	1.0273118561804493	2026-01-25	2026-01-26 12:30:48.819581
8376	EUR	KZT	595.28099685	2026-01-25	2026-01-26 12:30:48.82551
8377	KZT	EUR	0.001679878923217134	2026-01-25	2026-01-26 12:30:48.830857
8378	EUR	LAK	25480.98341959	2026-01-25	2026-01-26 12:30:48.836419
8379	LAK	EUR	3.924495312968146e-05	2026-01-25	2026-01-26 12:30:48.842369
8380	EUR	LBP	106292.20772542	2026-01-25	2026-01-26 12:30:48.847794
8381	LBP	EUR	9.408027374718344e-06	2026-01-25	2026-01-26 12:30:48.853482
8382	EUR	LKR	366.21799666	2026-01-25	2026-01-26 12:30:48.889424
8383	LKR	EUR	0.0027306140307692436	2026-01-25	2026-01-26 12:30:48.895366
8384	EUR	LRD	218.81613542	2026-01-25	2026-01-26 12:30:48.902328
8385	LRD	EUR	0.004570046893848026	2026-01-25	2026-01-26 12:30:48.907713
8386	EUR	LSL	19.04412734	2026-01-25	2026-01-26 12:30:48.9131
8387	LSL	EUR	0.052509625783672166	2026-01-25	2026-01-26 12:30:48.919796
8388	EUR	LYD	7.48317671	2026-01-25	2026-01-26 12:30:48.925311
8389	LYD	EUR	0.13363308642219676	2026-01-25	2026-01-26 12:30:48.931054
8390	EUR	MAD	10.78292458	2026-01-25	2026-01-26 12:30:48.93698
8391	MAD	EUR	0.09273921862115074	2026-01-25	2026-01-26 12:30:48.942578
8392	EUR	MDL	20.11798346	2026-01-25	2026-01-26 12:30:48.947707
8393	MDL	EUR	0.04970677115766949	2026-01-25	2026-01-26 12:30:48.952896
8394	EUR	MGA	5356.96143066	2026-01-25	2026-01-26 12:30:48.958219
8395	MGA	EUR	0.0001866729885857692	2026-01-25	2026-01-26 12:30:48.963719
8396	EUR	MKD	62.11227993	2026-01-25	2026-01-26 12:30:48.988972
8397	MKD	EUR	0.016099875920300967	2026-01-25	2026-01-26 12:30:48.994747
8398	EUR	MMK	2482.98053435	2026-01-25	2026-01-26 12:30:48.99977
8399	MMK	EUR	0.0004027417799559118	2026-01-25	2026-01-26 12:30:49.005148
8400	EUR	MNT	4214.77210362	2026-01-25	2026-01-26 12:30:49.010232
8401	MNT	EUR	0.00023726075228150913	2026-01-25	2026-01-26 12:30:49.015591
8402	EUR	MOP	9.4966457	2026-01-25	2026-01-26 12:30:49.021215
8403	MOP	EUR	0.10530033778137053	2026-01-25	2026-01-26 12:30:49.027062
8404	EUR	MRU	47.12837873	2026-01-25	2026-01-26 12:30:49.032832
8405	MRU	EUR	0.02121863783452073	2026-01-25	2026-01-26 12:30:49.038624
8406	EUR	MUR	54.37862215	2026-01-25	2026-01-26 12:30:49.04471
8407	MUR	EUR	0.01838957958959613	2026-01-25	2026-01-26 12:30:49.050922
8408	EUR	MVR	18.27032411	2026-01-25	2026-01-26 12:30:49.056785
8409	MVR	EUR	0.05473356651908897	2026-01-25	2026-01-26 12:30:49.062443
8410	EUR	MWK	2049.86244898	2026-01-25	2026-01-26 12:30:49.088937
8411	MWK	EUR	0.0004878376110053601	2026-01-25	2026-01-26 12:30:49.095938
8412	EUR	MXN	20.53128059	2026-01-25	2026-01-26 12:30:49.101435
8413	MXN	EUR	0.048706167918578916	2026-01-25	2026-01-26 12:30:49.106961
8414	EUR	MYR	4.73701547	2026-01-25	2026-01-26 12:30:49.112593
8415	MYR	EUR	0.21110338489141559	2026-01-25	2026-01-26 12:30:49.118799
8416	EUR	MZN	75.53903961	2026-01-25	2026-01-26 12:30:49.123935
8417	MZN	EUR	0.013238187898110609	2026-01-25	2026-01-26 12:30:49.129054
8418	EUR	NAD	19.04412734	2026-01-25	2026-01-26 12:30:49.134401
8419	NAD	EUR	0.052509625783672166	2026-01-25	2026-01-26 12:30:49.139614
8420	EUR	NGN	1682.51237	2026-01-25	2026-01-26 12:30:49.145927
8421	NGN	EUR	0.0005943492706683637	2026-01-25	2026-01-26 12:30:49.151727
8422	EUR	NIO	43.48497374	2026-01-25	2026-01-26 12:30:49.156927
8423	NIO	EUR	0.022996449439732374	2026-01-25	2026-01-26 12:30:49.191048
8424	EUR	NOK	11.55716676	2026-01-25	2026-01-26 12:30:49.196513
8425	NOK	EUR	0.08652639706308089	2026-01-25	2026-01-26 12:30:49.20189
8426	EUR	NPR	173.54809774	2026-01-25	2026-01-26 12:30:49.207381
8427	NPR	EUR	0.0057620913915066	2026-01-25	2026-01-26 12:30:49.214187
8428	EUR	NZD	1.98850251	2026-01-25	2026-01-26 12:30:49.219501
8429	NZD	EUR	0.5028909920762433	2026-01-25	2026-01-26 12:30:49.225409
8430	EUR	OMR	0.45485017	2026-01-25	2026-01-26 12:30:49.23096
8431	OMR	EUR	2.1985261652205166	2026-01-25	2026-01-26 12:30:49.236361
8432	EUR	PAB	1.18243713	2026-01-25	2026-01-26 12:30:49.243687
8433	PAB	EUR	0.8457109258739194	2026-01-25	2026-01-26 12:30:49.249176
8434	EUR	PEN	3.9689755	2026-01-25	2026-01-26 12:30:49.254782
8435	PEN	EUR	0.25195418817778037	2026-01-25	2026-01-26 12:30:49.26008
8436	EUR	PGK	5.04463471	2026-01-25	2026-01-26 12:30:49.287794
8437	PGK	EUR	0.19823040863943941	2026-01-25	2026-01-26 12:30:49.293099
8438	EUR	PHP	69.83593337	2026-01-25	2026-01-26 12:30:49.29917
8439	PHP	EUR	0.014319275933520753	2026-01-25	2026-01-26 12:30:49.304467
8440	EUR	PKR	330.81860337	2026-01-25	2026-01-26 12:30:49.310486
8441	PKR	EUR	0.0030228046119932447	2026-01-25	2026-01-26 12:30:49.315644
8442	EUR	PLN	4.20936917	2026-01-25	2026-01-26 12:30:49.320907
8443	PLN	EUR	0.2375652881973286	2026-01-25	2026-01-26 12:30:49.327686
8444	EUR	PYG	7900.46393257	2026-01-25	2026-01-26 12:30:49.332773
8445	PYG	EUR	0.00012657484529199068	2026-01-25	2026-01-26 12:30:49.338255
8446	EUR	QAR	4.30407116	2026-01-25	2026-01-26 12:30:49.343717
8447	QAR	EUR	0.232338166081808	2026-01-25	2026-01-26 12:30:49.349026
8448	EUR	RON	5.11017023	2026-01-25	2026-01-26 12:30:49.354629
8449	RON	EUR	0.1956881972599179	2026-01-25	2026-01-26 12:30:49.359802
8450	EUR	RSD	117.5233657	2026-01-25	2026-01-26 12:30:49.365078
8451	RSD	EUR	0.008508946234170011	2026-01-25	2026-01-26 12:30:49.390582
8452	EUR	RUB	89.43511609	2026-01-25	2026-01-26 12:30:49.396129
8453	RUB	EUR	0.011181290344540773	2026-01-25	2026-01-26 12:30:49.401791
8454	EUR	RWF	1720.293505	2026-01-25	2026-01-26 12:30:49.407254
8455	RWF	EUR	0.0005812961550418688	2026-01-25	2026-01-26 12:30:49.412228
8456	EUR	SAR	4.43413924	2026-01-25	2026-01-26 12:30:49.41728
8457	SAR	EUR	0.22552291343922704	2026-01-25	2026-01-26 12:30:49.422383
8458	EUR	SBD	9.60657106	2026-01-25	2026-01-26 12:30:49.427751
8459	SBD	EUR	0.10409541487324406	2026-01-25	2026-01-26 12:30:49.432783
8460	EUR	SCR	17.52558389	2026-01-25	2026-01-26 12:30:49.438
8461	SCR	EUR	0.057059439860979146	2026-01-25	2026-01-26 12:30:49.444766
8462	EUR	SDG	709.08732411	2026-01-25	2026-01-26 12:30:49.450139
8463	SDG	EUR	0.0014102635401854553	2026-01-25	2026-01-26 12:30:49.455532
8464	EUR	SEK	10.58435954	2026-01-25	2026-01-26 12:30:49.4605
8465	SEK	EUR	0.09447902787323494	2026-01-25	2026-01-26 12:30:49.49035
8466	EUR	SGD	1.50503373	2026-01-25	2026-01-26 12:30:49.495989
8467	SGD	EUR	0.6644369359084065	2026-01-25	2026-01-26 12:30:49.501257
8468	EUR	SHP	0.86681911	2026-01-25	2026-01-26 12:30:49.506175
8469	SHP	EUR	1.1536432324386572	2026-01-25	2026-01-26 12:30:49.511421
8470	EUR	SLE	27.01285535	2026-01-25	2026-01-26 12:30:49.516608
8471	SLE	EUR	0.037019411204154695	2026-01-25	2026-01-26 12:30:49.521833
8472	EUR	SOS	680.17058352	2026-01-25	2026-01-26 12:30:49.527209
8473	SOS	EUR	0.0014702194188181846	2026-01-25	2026-01-26 12:30:49.532648
8474	EUR	SRD	45.1649343	2026-01-25	2026-01-26 12:30:49.538002
8475	SRD	EUR	0.022141070622569245	2026-01-25	2026-01-26 12:30:49.543648
8476	EUR	SSP	5367.97150002	2026-01-25	2026-01-26 12:30:49.548728
8477	SSP	EUR	0.00018629010977354744	2026-01-25	2026-01-26 12:30:49.553972
8478	EUR	STN	24.91221036	2026-01-25	2026-01-26 12:30:49.590396
8479	STN	EUR	0.04014095841152812	2026-01-25	2026-01-26 12:30:49.597929
8480	EUR	SYP	130.74815457	2026-01-25	2026-01-26 12:30:49.604172
8481	SYP	EUR	0.007648291505824808	2026-01-25	2026-01-26 12:30:49.609607
8482	EUR	SZL	19.04412734	2026-01-25	2026-01-26 12:30:49.616867
8483	SZL	EUR	0.052509625783672166	2026-01-25	2026-01-26 12:30:49.622751
8484	EUR	THB	36.74824212	2026-01-25	2026-01-26 12:30:49.628298
8485	THB	EUR	0.027212186007007838	2026-01-25	2026-01-26 12:30:49.634321
8486	EUR	TJS	11.05829838	2026-01-25	2026-01-26 12:30:49.63979
8487	TJS	EUR	0.09042982614835177	2026-01-25	2026-01-26 12:30:49.645075
8488	EUR	TMT	4.13802972	2026-01-25	2026-01-26 12:30:49.650384
8489	TMT	EUR	0.241660903295784	2026-01-25	2026-01-26 12:30:49.655725
8490	EUR	TND	3.39836215	2026-01-25	2026-01-26 12:30:49.685755
8491	TND	EUR	0.29425939786905875	2026-01-25	2026-01-26 12:30:49.691867
8492	EUR	TOP	2.80456935	2026-01-25	2026-01-26 12:30:49.697705
8493	TOP	EUR	0.3565609814569214	2026-01-25	2026-01-26 12:30:49.7029
8494	EUR	TRY	51.24931884	2026-01-25	2026-01-26 12:30:49.707858
8495	TRY	EUR	0.019512454460555714	2026-01-25	2026-01-26 12:30:49.713235
8496	EUR	TTD	8.00315352	2026-01-25	2026-01-26 12:30:49.718161
8497	TTD	EUR	0.12495074566556609	2026-01-25	2026-01-26 12:30:49.72392
8498	EUR	TVD	1.71531717	2026-01-25	2026-01-26 12:30:49.729362
8499	TVD	EUR	0.5829825629274148	2026-01-25	2026-01-26 12:30:49.734636
8500	EUR	TWD	37.09034975	2026-01-25	2026-01-26 12:30:49.739528
8501	TWD	EUR	0.026961190895753145	2026-01-25	2026-01-26 12:30:49.746527
8502	EUR	TZS	2969.88336909	2026-01-25	2026-01-26 12:30:49.752033
8503	TZS	EUR	0.0003367135593295737	2026-01-25	2026-01-26 12:30:49.757112
8504	EUR	UAH	51.05342859	2026-01-25	2026-01-26 12:30:49.762587
8505	UAH	EUR	0.019587323077374538	2026-01-25	2026-01-26 12:30:49.790842
8506	EUR	UGX	4191.80845755	2026-01-25	2026-01-26 12:30:49.797301
8507	UGX	EUR	0.00023856051871808887	2026-01-25	2026-01-26 12:30:49.803473
8508	EUR	USD	1.18243713	2026-01-25	2026-01-26 12:30:49.808674
8509	USD	EUR	0.8457109258739194	2026-01-25	2026-01-26 12:30:49.814605
8510	EUR	UYU	44.35972621	2026-01-25	2026-01-26 12:30:49.82049
8511	UYU	EUR	0.022542970514875953	2026-01-25	2026-01-26 12:30:49.825769
8512	EUR	UZS	14288.16674347	2026-01-25	2026-01-26 12:30:49.83286
8513	UZS	EUR	6.998798501963323e-05	2026-01-25	2026-01-26 12:30:49.838028
8514	EUR	VES	416.38760736	2026-01-25	2026-01-26 12:30:49.84317
8515	VES	EUR	0.002401608458859394	2026-01-25	2026-01-26 12:30:49.848238
8516	EUR	VND	31118.84238175	2026-01-25	2026-01-26 12:30:49.853615
8517	VND	EUR	3.2134871462521416e-05	2026-01-25	2026-01-26 12:30:49.858845
8518	EUR	VUV	141.84800585	2026-01-25	2026-01-26 12:30:49.878318
8519	VUV	EUR	0.007049799494942988	2026-01-25	2026-01-26 12:30:49.889713
8520	EUR	WST	3.25831202	2026-01-25	2026-01-26 12:30:49.895721
8521	WST	EUR	0.30690737837931187	2026-01-25	2026-01-26 12:30:49.900985
8522	EUR	XAF	655.95700002	2026-01-25	2026-01-26 12:30:49.906445
8523	XAF	EUR	0.0015244901723276223	2026-01-25	2026-01-26 12:30:49.911911
8524	EUR	XCD	3.19426304	2026-01-25	2026-01-26 12:30:49.916881
8525	XCD	EUR	0.31306125622015146	2026-01-25	2026-01-26 12:30:49.921908
8526	EUR	XDR	0.86362859	2026-01-25	2026-01-26 12:30:49.927001
8527	XDR	EUR	1.1579051592073857	2026-01-25	2026-01-26 12:30:49.932602
8528	EUR	XOF	655.95700002	2026-01-25	2026-01-26 12:30:49.937947
8529	XOF	EUR	0.0015244901723276223	2026-01-25	2026-01-26 12:30:49.944069
8530	EUR	XPF	119.33174225	2026-01-25	2026-01-26 12:30:49.949154
8531	XPF	EUR	0.0083799999995391	2026-01-25	2026-01-26 12:30:49.954448
8532	EUR	YER	281.81839806	2026-01-25	2026-01-26 12:30:49.959417
8533	YER	EUR	0.003548384374064524	2026-01-25	2026-01-26 12:30:49.964709
8534	EUR	ZAR	19.04412734	2026-01-25	2026-01-26 12:30:49.989157
8535	ZAR	EUR	0.052509625783672166	2026-01-25	2026-01-26 12:30:49.995179
8536	EUR	ZMW	23.10837299	2026-01-25	2026-01-26 12:30:50.000454
8537	ZMW	EUR	0.04327435775910072	2026-01-25	2026-01-26 12:30:50.005676
8538	EUR	ZWL	75695.64561968	2026-01-25	2026-01-26 12:30:50.010867
8539	ZWL	EUR	1.3210799535607785e-05	2026-01-25	2026-01-26 12:30:50.015921
8541	AED	EUR	0.22935823320930931	2026-01-26	2026-01-27 09:41:53.624076
8542	EUR	AFN	77.96590848	2026-01-26	2026-01-27 09:41:53.630299
8544	EUR	ALL	96.79510016	2026-01-26	2026-01-27 09:41:53.643885
8545	ALL	EUR	0.010331101453968473	2026-01-26	2026-01-27 09:41:53.648775
8546	EUR	AMD	450.03826679	2026-01-26	2026-01-27 09:41:53.654143
8547	AMD	EUR	0.0022220332664880404	2026-01-26	2026-01-27 09:41:53.659582
8548	EUR	ANG	2.12080876	2026-01-26	2026-01-27 09:41:53.66553
8549	ANG	EUR	0.4715182334497713	2026-01-26	2026-01-27 09:41:53.701188
8550	EUR	AOA	1090.96160609	2026-01-26	2026-01-27 09:41:53.706258
8551	AOA	EUR	0.0009166225414512927	2026-01-26	2026-01-27 09:41:53.711271
8626	EUR	EUR	1	2026-01-26	2026-01-27 09:41:54.214048
8552	EUR	ARS	1696.69675889	2026-01-26	2026-01-27 09:41:53.716247
8553	ARS	EUR	0.0005893805093694011	2026-01-26	2026-01-27 09:41:53.723509
8555	AUD	EUR	0.5832507916812946	2026-01-26	2026-01-27 09:41:53.735159
8556	EUR	AWG	2.12508787	2026-01-26	2026-01-27 09:41:53.740203
8557	AWG	EUR	0.47056877699838356	2026-01-26	2026-01-27 09:41:53.745522
8558	EUR	AZN	2.01823502	2026-01-26	2026-01-27 09:41:53.750325
8559	AZN	EUR	0.49548243395360364	2026-01-26	2026-01-27 09:41:53.755578
8560	EUR	BAM	1.95583	2026-01-26	2026-01-27 09:41:53.760522
8561	BAM	EUR	0.5112918811962185	2026-01-26	2026-01-27 09:41:53.765766
8562	EUR	BBD	2.37439985	2026-01-26	2026-01-27 09:41:53.771375
8563	BBD	EUR	0.4211590562558366	2026-01-26	2026-01-27 09:41:53.800245
8564	EUR	BDT	144.15379276	2026-01-26	2026-01-27 09:41:53.805667
8565	BDT	EUR	0.006937035653754103	2026-01-26	2026-01-27 09:41:53.810559
8566	EUR	BGN	1.95583	2026-01-26	2026-01-27 09:41:53.815836
8567	BGN	EUR	0.5112918811962185	2026-01-26	2026-01-27 09:41:53.820714
8568	EUR	BHD	0.44638717	2026-01-26	2026-01-27 09:41:53.826685
8569	BHD	EUR	2.2402077550750397	2026-01-26	2026-01-27 09:41:53.831681
8570	EUR	BIF	3498.6431804	2026-01-26	2026-01-27 09:41:53.837639
8572	EUR	BMD	1.18719993	2026-01-26	2026-01-27 09:41:53.849308
8573	BMD	EUR	0.8423181089641743	2026-01-26	2026-01-27 09:41:53.855483
8574	EUR	BND	1.5055569	2026-01-26	2026-01-27 09:41:53.860466
8575	BND	EUR	0.6642060489377718	2026-01-26	2026-01-27 09:41:53.865664
8576	EUR	BOB	8.15759518	2026-01-26	2026-01-27 09:41:53.870639
8577	BOB	EUR	0.12258514647205135	2026-01-26	2026-01-27 09:41:53.875474
8578	EUR	BRL	6.29034553	2026-01-26	2026-01-27 09:41:53.880336
8579	BRL	EUR	0.15897377898094575	2026-01-26	2026-01-27 09:41:53.899109
8580	EUR	BSD	1.18719993	2026-01-26	2026-01-27 09:41:53.90519
8581	BSD	EUR	0.8423181089641743	2026-01-26	2026-01-27 09:41:53.910293
8582	EUR	BTN	108.65404093	2026-01-26	2026-01-27 09:41:53.915555
8583	BTN	EUR	0.009203523324496019	2026-01-26	2026-01-27 09:41:53.920334
8584	EUR	BWP	15.93245172	2026-01-26	2026-01-27 09:41:53.925537
8585	BWP	EUR	0.06276497914910989	2026-01-26	2026-01-27 09:41:53.930552
8586	EUR	BYN	3.34467418	2026-01-26	2026-01-27 09:41:53.942655
8587	BYN	EUR	0.29898278462507816	2026-01-26	2026-01-27 09:41:53.947637
8589	BZD	EUR	0.4204019237457502	2026-01-26	2026-01-27 09:41:53.958546
8590	EUR	CAD	1.62415158	2026-01-26	2026-01-27 09:41:53.963634
8591	CAD	EUR	0.6157060783698527	2026-01-26	2026-01-27 09:41:53.968734
8592	EUR	CDF	2696.0806833	2026-01-26	2026-01-27 09:41:53.974147
8593	CDF	EUR	0.0003709087811036875	2026-01-26	2026-01-27 09:41:53.999661
8594	EUR	CHF	0.92189991	2026-01-26	2026-01-27 09:41:54.005808
8595	CHF	EUR	1.0847164525702144	2026-01-26	2026-01-27 09:41:54.011093
8596	EUR	CLP	1026.28177893	2026-01-26	2026-01-27 09:41:54.016217
8597	CLP	EUR	0.0009743912642028962	2026-01-26	2026-01-27 09:41:54.021127
8598	EUR	CNH	8.25185628	2026-01-26	2026-01-27 09:41:54.025944
8599	CNH	EUR	0.12118485417925869	2026-01-26	2026-01-27 09:41:54.030986
8600	EUR	CNY	8.2581273	2026-01-26	2026-01-27 09:41:54.036226
8601	CNY	EUR	0.12109282936338363	2026-01-26	2026-01-27 09:41:54.041162
8602	EUR	COP	4289.02443415	2026-01-26	2026-01-27 09:41:54.046067
8603	COP	EUR	0.00023315325322882666	2026-01-26	2026-01-27 09:41:54.050869
8604	EUR	CRC	587.91611709	2026-01-26	2026-01-27 09:41:54.0557
8606	EUR	CUP	28.21554913	2026-01-26	2026-01-27 09:41:54.066768
8607	CUP	EUR	0.03544145093163388	2026-01-26	2026-01-27 09:41:54.071811
8608	EUR	CVE	110.26999999	2026-01-26	2026-01-27 09:41:54.099265
8609	CVE	EUR	0.00906864967888534	2026-01-26	2026-01-27 09:41:54.104763
8610	EUR	CZK	24.26275226	2026-01-26	2026-01-27 09:41:54.109725
8611	CZK	EUR	0.04121543958756145	2026-01-26	2026-01-27 09:41:54.115383
8612	EUR	DJF	211.24930908	2026-01-26	2026-01-27 09:41:54.120463
8613	DJF	EUR	0.004733743292960549	2026-01-26	2026-01-27 09:41:54.12628
8614	EUR	DKK	7.46791016	2026-01-26	2026-01-27 09:41:54.131273
8615	DKK	EUR	0.1339062707738841	2026-01-26	2026-01-27 09:41:54.136132
8616	EUR	DOP	74.3658861	2026-01-26	2026-01-27 09:41:54.141025
8617	DOP	EUR	0.013447025947560115	2026-01-26	2026-01-27 09:41:54.145811
8618	EUR	DZD	153.53974779	2026-01-26	2026-01-27 09:41:54.150565
8619	DZD	EUR	0.00651297149040341	2026-01-26	2026-01-27 09:41:54.155863
8620	EUR	EGP	55.72391086	2026-01-26	2026-01-27 09:41:54.160783
8621	EGP	EUR	0.017945617681292804	2026-01-26	2026-01-27 09:41:54.165688
8623	ERN	EUR	0.056154540786811556	2026-01-26	2026-01-27 09:41:54.178212
8624	EUR	ETB	183.94868006	2026-01-26	2026-01-27 09:41:54.198771
8625	ETB	EUR	0.005436298861583688	2026-01-26	2026-01-27 09:41:54.203693
8628	EUR	FJD	2.63062271	2026-01-26	2026-01-27 09:41:54.218996
8629	FJD	EUR	0.3801381308686414	2026-01-26	2026-01-27 09:41:54.223992
8630	EUR	FKP	0.86822326	2026-01-26	2026-01-27 09:41:54.229616
8631	FKP	EUR	1.1517774817504889	2026-01-26	2026-01-27 09:41:54.235293
8632	EUR	GBP	0.86822326	2026-01-26	2026-01-27 09:41:54.240559
8633	GBP	EUR	1.1517774817504889	2026-01-26	2026-01-27 09:41:54.245716
8634	EUR	GEL	3.19593398	2026-01-26	2026-01-27 09:41:54.250679
8635	GEL	EUR	0.3128975774399445	2026-01-26	2026-01-27 09:41:54.256258
8636	EUR	GGP	0.86822326	2026-01-26	2026-01-27 09:41:54.261316
8637	GGP	EUR	1.1517774817504889	2026-01-26	2026-01-27 09:41:54.266302
8638	EUR	GHS	12.88171426	2026-01-26	2026-01-27 09:41:54.299361
8639	GHS	EUR	0.07762941948690608	2026-01-26	2026-01-27 09:41:54.304902
8640	EUR	GIP	0.86822326	2026-01-26	2026-01-27 09:41:54.310118
8642	EUR	GMD	87.71152774	2026-01-26	2026-01-27 09:41:54.322284
8643	GMD	EUR	0.011401009944374275	2026-01-26	2026-01-27 09:41:54.327478
8644	EUR	GNF	10387.07587989	2026-01-26	2026-01-27 09:41:54.332743
8645	GNF	EUR	9.627348558568439e-05	2026-01-26	2026-01-27 09:41:54.338167
8646	EUR	GTQ	9.10713837	2026-01-26	2026-01-27 09:41:54.343633
8647	GTQ	EUR	0.10980397566969217	2026-01-26	2026-01-27 09:41:54.348995
8648	EUR	GYD	246.43723313	2026-01-26	2026-01-27 09:41:54.354738
8649	GYD	EUR	0.00405782838615333	2026-01-26	2026-01-27 09:41:54.396517
8650	EUR	HKD	9.25458373	2026-01-26	2026-01-27 09:41:54.403409
8651	HKD	EUR	0.10805456292521975	2026-01-26	2026-01-27 09:41:54.409151
8652	EUR	HNL	31.25960547	2026-01-26	2026-01-27 09:41:54.414773
8653	HNL	EUR	0.03199016702113227	2026-01-26	2026-01-27 09:41:54.420279
8654	EUR	HRK	7.5345	2026-01-26	2026-01-27 09:41:54.425909
8655	HRK	EUR	0.13272280841462605	2026-01-26	2026-01-27 09:41:54.43146
8656	EUR	HTG	155.0067299	2026-01-26	2026-01-27 09:41:54.437975
8657	HTG	EUR	0.006451332794680162	2026-01-26	2026-01-27 09:41:54.443522
8659	HUF	EUR	0.0026199102965727746	2026-01-26	2026-01-27 09:41:54.456571
8660	EUR	IDR	19906.58583295	2026-01-26	2026-01-27 09:41:54.498683
8661	IDR	EUR	5.0234631312053965e-05	2026-01-26	2026-01-27 09:41:54.505461
8662	EUR	ILS	3.72064257	2026-01-26	2026-01-27 09:41:54.511045
8663	ILS	EUR	0.2687707784841047	2026-01-26	2026-01-27 09:41:54.516448
8664	EUR	IMP	0.86822326	2026-01-26	2026-01-27 09:41:54.52218
8665	IMP	EUR	1.1517774817504889	2026-01-26	2026-01-27 09:41:54.527374
8666	EUR	INR	108.65404093	2026-01-26	2026-01-27 09:41:54.533123
8667	INR	EUR	0.009203523324496019	2026-01-26	2026-01-27 09:41:54.539035
8668	EUR	IQD	1547.20629977	2026-01-26	2026-01-27 09:41:54.544523
8669	IQD	EUR	0.0006463262204585485	2026-01-26	2026-01-27 09:41:54.549499
8670	EUR	IRR	1278128.73188325	2026-01-26	2026-01-27 09:41:54.554516
8671	IRR	EUR	7.823938035776388e-07	2026-01-26	2026-01-27 09:41:54.559513
8673	ISK	EUR	0.00685852050848324	2026-01-26	2026-01-27 09:41:54.60361
8674	EUR	JEP	0.86822326	2026-01-26	2026-01-27 09:41:54.60894
8676	EUR	JMD	185.65358266	2026-01-26	2026-01-27 09:41:54.629608
8677	JMD	EUR	0.005386375989475882	2026-01-26	2026-01-27 09:41:54.635424
8678	EUR	JOD	0.84172475	2026-01-26	2026-01-27 09:41:54.640643
8679	JOD	EUR	1.1880368255774825	2026-01-26	2026-01-27 09:41:54.646543
8680	EUR	JPY	182.92242063	2026-01-26	2026-01-27 09:41:54.652255
8681	JPY	EUR	0.005466798419548118	2026-01-26	2026-01-27 09:41:54.658725
8682	EUR	KES	152.17771385	2026-01-26	2026-01-27 09:41:54.664906
8683	KES	EUR	0.006571264442740214	2026-01-26	2026-01-27 09:41:54.670313
8684	EUR	KGS	103.84445034	2026-01-26	2026-01-27 09:41:54.675562
8685	KGS	EUR	0.00962978759794936	2026-01-26	2026-01-27 09:41:54.681612
8686	EUR	KHR	4751.55261268	2026-01-26	2026-01-27 09:41:54.699054
8687	KHR	EUR	0.00021045752441662934	2026-01-26	2026-01-27 09:41:54.704997
8688	EUR	KMF	491.96774997	2026-01-26	2026-01-27 09:41:54.710608
8689	KMF	EUR	0.002032653563289422	2026-01-26	2026-01-27 09:41:54.716324
8690	EUR	KRW	1711.32069718	2026-01-26	2026-01-27 09:41:54.72179
8691	KRW	EUR	0.0005843440108261708	2026-01-26	2026-01-27 09:41:54.727564
8693	KWD	EUR	2.74877446577637	2026-01-26	2026-01-27 09:41:54.739974
8694	EUR	KYD	0.98662621	2026-01-26	2026-01-27 09:41:54.745751
8695	KYD	EUR	1.0135550726956666	2026-01-26	2026-01-27 09:41:54.751074
8696	EUR	KZT	594.51601789	2026-01-26	2026-01-27 09:41:54.757116
8697	KZT	EUR	0.0016820404663765083	2026-01-26	2026-01-27 09:41:54.762793
8698	EUR	LAK	25500.25486365	2026-01-26	2026-01-27 09:41:54.768828
8699	LAK	EUR	3.921529433125298e-05	2026-01-26	2026-01-27 09:41:54.774429
8700	EUR	LBP	102924.30990335	2026-01-26	2026-01-27 09:41:54.800681
8701	LBP	EUR	9.715877628317737e-06	2026-01-26	2026-01-27 09:41:54.806998
8702	EUR	LKR	364.11602983	2026-01-26	2026-01-27 09:41:54.812199
8703	LKR	EUR	0.0027463773030450872	2026-01-26	2026-01-27 09:41:54.817285
8704	EUR	LRD	219.22645887	2026-01-26	2026-01-27 09:41:54.822656
8705	LRD	EUR	0.00456149319363405	2026-01-26	2026-01-27 09:41:54.828456
8706	EUR	LSL	19.07349744	2026-01-26	2026-01-27 09:41:54.833785
8707	LSL	EUR	0.05242876945592837	2026-01-26	2026-01-27 09:41:54.839486
8708	EUR	LYD	7.50475319	2026-01-26	2026-01-27 09:41:54.845158
8710	EUR	MAD	10.87317624	2026-01-26	2026-01-27 09:41:54.856644
8711	MAD	EUR	0.09196944645495786	2026-01-26	2026-01-27 09:41:54.861738
8712	EUR	MDL	20.04510311	2026-01-26	2026-01-27 09:41:54.867042
8713	MDL	EUR	0.049887495939151594	2026-01-26	2026-01-27 09:41:54.872584
8714	EUR	MGA	5338.46797126	2026-01-26	2026-01-27 09:41:54.878151
8715	MGA	EUR	0.00018731965900770913	2026-01-26	2026-01-27 09:41:54.896233
8716	EUR	MKD	61.93128995	2026-01-26	2026-01-27 09:41:54.901612
8717	MKD	EUR	0.01614692671196331	2026-01-26	2026-01-27 09:41:54.906997
8718	EUR	MMK	2492.58711285	2026-01-26	2026-01-27 09:41:54.912018
8719	MMK	EUR	0.00040118958926037686	2026-01-26	2026-01-27 09:41:54.917688
8720	EUR	MNT	4235.28264142	2026-01-26	2026-01-27 09:41:54.922821
8721	MNT	EUR	0.00023611175089479302	2026-01-26	2026-01-27 09:41:54.928381
8722	EUR	MOP	9.53222125	2026-01-26	2026-01-27 09:41:54.933621
8723	MOP	EUR	0.10490734255669948	2026-01-26	2026-01-27 09:41:54.938803
8724	EUR	MRU	47.24372006	2026-01-26	2026-01-27 09:41:54.944533
8725	MRU	EUR	0.02116683442222564	2026-01-26	2026-01-27 09:41:54.949458
8727	MUR	EUR	0.018344152016809334	2026-01-26	2026-01-27 09:41:54.96117
8728	EUR	MVR	18.35360121	2026-01-26	2026-01-27 09:41:54.966527
8729	MVR	EUR	0.054485220015304016	2026-01-26	2026-01-27 09:41:54.999154
8730	EUR	MWK	2045.75969558	2026-01-26	2026-01-27 09:41:55.005267
8731	MWK	EUR	0.0004888159651207161	2026-01-26	2026-01-27 09:41:55.011361
8732	EUR	MXN	20.61479584	2026-01-26	2026-01-27 09:41:55.016845
8733	MXN	EUR	0.04850884809926888	2026-01-26	2026-01-27 09:41:55.02201
8734	EUR	MYR	4.71200957	2026-01-26	2026-01-27 09:41:55.027484
8735	MYR	EUR	0.21222367763569716	2026-01-26	2026-01-27 09:41:55.033074
8736	EUR	MZN	75.66956542	2026-01-26	2026-01-27 09:41:55.038384
8737	MZN	EUR	0.013215352757076797	2026-01-26	2026-01-27 09:41:55.044071
8738	EUR	NAD	19.07349744	2026-01-26	2026-01-27 09:41:55.049481
8739	NAD	EUR	0.05242876945592837	2026-01-26	2026-01-27 09:41:55.05467
8740	EUR	NGN	1676.93101351	2026-01-26	2026-01-27 09:41:55.059589
8741	NGN	EUR	0.0005963274529146495	2026-01-26	2026-01-27 09:41:55.064722
8742	EUR	NIO	43.71018404	2026-01-26	2026-01-27 09:41:55.069925
8744	EUR	NOK	11.55091871	2026-01-26	2026-01-27 09:41:55.106805
8745	NOK	EUR	0.08657320037533188	2026-01-26	2026-01-27 09:41:55.112087
8746	EUR	NPR	173.92795601	2026-01-26	2026-01-27 09:41:55.117266
8747	NPR	EUR	0.005749506996692958	2026-01-26	2026-01-27 09:41:55.123231
8748	EUR	NZD	1.98933151	2026-01-26	2026-01-27 09:41:55.128336
8749	NZD	EUR	0.5026814258826072	2026-01-26	2026-01-27 09:41:55.134263
8750	EUR	OMR	0.45705459	2026-01-26	2026-01-27 09:41:55.13921
8751	OMR	EUR	2.1879224536395094	2026-01-26	2026-01-27 09:41:55.144262
8752	EUR	PAB	1.18719993	2026-01-26	2026-01-27 09:41:55.149213
8753	PAB	EUR	0.8423181089641743	2026-01-26	2026-01-27 09:41:55.154447
8754	EUR	PEN	3.96204692	2026-01-26	2026-01-27 09:41:55.159278
8755	PEN	EUR	0.25239478991329056	2026-01-26	2026-01-27 09:41:55.164004
8756	EUR	PGK	5.05841291	2026-01-26	2026-01-27 09:41:55.200275
8757	PGK	EUR	0.19769046493280437	2026-01-26	2026-01-27 09:41:55.205227
8758	EUR	PHP	70.03746734	2026-01-26	2026-01-27 09:41:55.210778
8759	PHP	EUR	0.01427807198032241	2026-01-26	2026-01-27 09:41:55.215748
8761	PKR	EUR	0.0030367960242197456	2026-01-26	2026-01-27 09:41:55.227203
8762	EUR	PLN	4.21161036	2026-01-26	2026-01-27 09:41:55.232291
8763	PLN	EUR	0.23743886887010127	2026-01-26	2026-01-27 09:41:55.237668
8764	EUR	PYG	7941.30043695	2026-01-26	2026-01-27 09:41:55.242882
8765	PYG	EUR	0.00012592396018001152	2026-01-26	2026-01-27 09:41:55.247847
8766	EUR	QAR	4.32140773	2026-01-26	2026-01-27 09:41:55.252667
8767	QAR	EUR	0.231406074705198	2026-01-26	2026-01-27 09:41:55.25753
8768	EUR	RON	5.10857152	2026-01-26	2026-01-27 09:41:55.262669
8769	RON	EUR	0.19574943721253804	2026-01-26	2026-01-27 09:41:55.267565
8770	EUR	RSD	117.70542216	2026-01-26	2026-01-27 09:41:55.27247
8771	RSD	EUR	0.008495785339783875	2026-01-26	2026-01-27 09:41:55.296252
8772	EUR	RUB	89.64362936	2026-01-26	2026-01-27 09:41:55.30203
8773	RUB	EUR	0.01115528239027559	2026-01-26	2026-01-27 09:41:55.307039
8774	EUR	RWF	1719.0262269	2026-01-26	2026-01-27 09:41:55.311909
8775	RWF	EUR	0.0005817246906135613	2026-01-26	2026-01-27 09:41:55.316764
8776	EUR	SAR	4.45199972	2026-01-26	2026-01-27 09:41:55.321747
8778	EUR	SBD	9.5593023	2026-01-26	2026-01-27 09:41:55.332972
8779	SBD	EUR	0.10461014503119123	2026-01-26	2026-01-27 09:41:55.396434
8780	EUR	SCR	17.53281014	2026-01-26	2026-01-27 09:41:55.402068
8781	SCR	EUR	0.057035922479908865	2026-01-26	2026-01-27 09:41:55.500325
8782	EUR	SDG	711.84732209	2026-01-26	2026-01-27 09:41:55.505948
8783	SDG	EUR	0.0014047956197460673	2026-01-26	2026-01-27 09:41:55.596446
8784	EUR	SEK	10.56352525	2026-01-26	2026-01-27 09:41:55.603506
8785	SEK	EUR	0.09466536751071808	2026-01-26	2026-01-27 09:41:55.609239
8786	EUR	SGD	1.5055569	2026-01-26	2026-01-27 09:41:55.903371
8788	EUR	SHP	0.86822326	2026-01-26	2026-01-27 09:41:55.913678
8789	SHP	EUR	1.1517774817504889	2026-01-26	2026-01-27 09:41:55.99703
8790	EUR	SLE	27.12165008	2026-01-26	2026-01-27 09:41:56.004445
8791	SLE	EUR	0.036870912980970075	2026-01-26	2026-01-27 09:41:56.013003
8792	EUR	SOS	673.91518361	2026-01-26	2026-01-27 09:41:56.022697
8793	SOS	EUR	0.0014838662554585028	2026-01-26	2026-01-27 09:41:56.030563
8794	EUR	SRD	45.23553467	2026-01-26	2026-01-27 09:41:56.107278
8795	SRD	EUR	0.02210651443152269	2026-01-26	2026-01-27 09:41:56.200005
8796	EUR	SSP	5389.50359682	2026-01-26	2026-01-27 09:41:56.20677
8797	SSP	EUR	0.00018554584518508082	2026-01-26	2026-01-27 09:41:56.296376
8798	EUR	STN	24.84601831	2026-01-26	2026-01-27 09:41:56.303912
8799	STN	EUR	0.04024789757148013	2026-01-26	2026-01-27 09:41:56.396501
8800	EUR	SYP	132.97564996	2026-01-26	2026-01-27 09:41:56.403857
8801	SYP	EUR	0.007520173808519131	2026-01-26	2026-01-27 09:41:56.410106
8802	EUR	SZL	19.07349744	2026-01-26	2026-01-27 09:41:56.501769
8803	SZL	EUR	0.05242876945592837	2026-01-26	2026-01-27 09:41:56.60148
8804	EUR	THB	36.87077036	2026-01-26	2026-01-27 09:41:56.608104
8805	THB	EUR	0.02712175499009563	2026-01-26	2026-01-27 09:41:56.701789
8806	EUR	TJS	11.03604201	2026-01-26	2026-01-27 09:41:56.796582
8807	TJS	EUR	0.09061219584828312	2026-01-26	2026-01-27 09:41:56.803715
8808	EUR	TMT	4.15323332	2026-01-26	2026-01-27 09:41:56.901873
8809	TMT	EUR	0.24077626344382694	2026-01-26	2026-01-27 09:41:56.908709
8810	EUR	TND	3.40486889	2026-01-26	2026-01-27 09:41:57.002154
8811	TND	EUR	0.2936970650872845	2026-01-26	2026-01-27 09:41:57.008418
8812	EUR	TOP	2.81441381	2026-01-26	2026-01-27 09:41:57.014493
8813	TOP	EUR	0.3553137766901449	2026-01-26	2026-01-27 09:41:57.020622
8814	EUR	TRY	51.52114618	2026-01-26	2026-01-27 09:41:57.026984
8815	TRY	EUR	0.01940950607943171	2026-01-26	2026-01-27 09:41:57.03338
8816	EUR	TTD	8.04081186	2026-01-26	2026-01-27 09:41:57.100008
8817	TTD	EUR	0.12436555131635675	2026-01-26	2026-01-27 09:41:57.106687
8818	EUR	TVD	1.71452832	2026-01-26	2026-01-27 09:41:57.112866
8819	TVD	EUR	0.5832507916812946	2026-01-26	2026-01-27 09:41:57.118992
8820	EUR	TWD	37.29547094	2026-01-26	2026-01-27 09:41:57.1259
8821	TWD	EUR	0.02681290716529024	2026-01-26	2026-01-27 09:41:57.13235
8822	EUR	TZS	3014.90438737	2026-01-26	2026-01-27 09:41:57.139033
8823	TZS	EUR	0.0003316854770549897	2026-01-26	2026-01-27 09:41:57.145101
8824	EUR	UAH	51.15131949	2026-01-26	2026-01-27 09:41:57.151229
8825	UAH	EUR	0.019549837813968775	2026-01-26	2026-01-27 09:41:57.158094
8826	EUR	UGX	4209.35185424	2026-01-26	2026-01-27 09:41:57.164593
8827	UGX	EUR	0.00023756626545550454	2026-01-26	2026-01-27 09:41:57.198681
8828	EUR	USD	1.18719993	2026-01-26	2026-01-27 09:41:57.205608
8829	USD	EUR	0.8423181089641743	2026-01-26	2026-01-27 09:41:57.301843
8830	EUR	UYU	44.53015541	2026-01-26	2026-01-27 09:41:57.402953
8831	UYU	EUR	0.02245669234236342	2026-01-26	2026-01-27 09:41:57.410758
8832	EUR	UZS	14302.90073099	2026-01-26	2026-01-27 09:41:57.502025
8833	UZS	EUR	6.991588760965855e-05	2026-01-26	2026-01-27 09:41:57.603566
8834	EUR	VES	420.16835292	2026-01-26	2026-01-27 09:41:57.796573
8835	VES	EUR	0.0023799983817210523	2026-01-26	2026-01-27 09:41:57.896566
8836	EUR	VND	31118.05039724	2026-01-26	2026-01-27 09:41:57.99894
8837	VND	EUR	3.2135689326111975e-05	2026-01-26	2026-01-27 09:41:58.196244
8838	EUR	VUV	142.22906498	2026-01-26	2026-01-27 09:41:58.301543
8839	VUV	EUR	0.007030911720755657	2026-01-26	2026-01-27 09:41:58.402481
8840	EUR	WST	3.22953209	2026-01-26	2026-01-27 09:41:58.409273
8841	WST	EUR	0.30964237918440995	2026-01-26	2026-01-27 09:41:58.596426
8842	EUR	XAF	655.95699997	2026-01-26	2026-01-27 09:41:58.696905
8843	XAF	EUR	0.001524490172443826	2026-01-26	2026-01-27 09:41:58.903279
8844	EUR	XCD	3.21697087	2026-01-26	2026-01-27 09:41:59.100355
8845	XCD	EUR	0.31085143148964856	2026-01-26	2026-01-27 09:41:59.196541
8846	EUR	XDR	0.86710548	2026-01-26	2026-01-27 09:41:59.203892
8847	XDR	EUR	1.153262230565075	2026-01-26	2026-01-27 09:41:59.301909
8848	EUR	XOF	655.95699997	2026-01-26	2026-01-27 09:41:59.401931
8849	XOF	EUR	0.001524490172443826	2026-01-26	2026-01-27 09:41:59.497183
8850	EUR	XPF	119.33174224	2026-01-26	2026-01-27 09:41:59.59803
8851	XPF	EUR	0.008380000000241344	2026-01-26	2026-01-27 09:41:59.696588
8852	EUR	YER	282.86708955	2026-01-26	2026-01-27 09:41:59.705144
8853	YER	EUR	0.0035352292187502375	2026-01-26	2026-01-27 09:41:59.798607
8854	EUR	ZAR	19.07349744	2026-01-26	2026-01-27 09:41:59.805947
8855	ZAR	EUR	0.05242876945592837	2026-01-26	2026-01-27 09:41:59.81255
8856	EUR	ZMW	23.17631965	2026-01-26	2026-01-27 09:41:59.818743
8857	ZMW	EUR	0.043147489122588104	2026-01-26	2026-01-27 09:41:59.901973
8858	EUR	ZWL	75963.79032706	2026-01-26	2026-01-27 09:41:59.908805
8859	ZWL	EUR	1.3164166712778912e-05	2026-01-26	2026-01-27 09:41:59.915515
9236	EUR	CLP	1027.72831798	2026-01-27	2026-01-28 03:07:39.658907
9237	CLP	EUR	0.0009730197976499277	2026-01-27	2026-01-28 03:07:39.667817
9238	EUR	CNH	8.26366864	2026-01-27	2026-01-28 03:07:39.676639
9239	CNH	EUR	0.12101162855920126	2026-01-27	2026-01-28 03:07:39.685518
9240	EUR	CNY	8.26717271	2026-01-27	2026-01-28 03:07:39.694838
9241	CNY	EUR	0.12096033735818734	2026-01-27	2026-01-28 03:07:39.703749
9242	EUR	COP	4375.78222897	2026-01-27	2026-01-28 03:07:39.723749
9249	CVE	EUR	0.009068649678062937	2026-01-27	2026-01-28 03:07:39.790005
9250	EUR	CZK	24.23807407	2026-01-27	2026-01-28 03:07:39.799076
9229	BZD	EUR	0.4180681582956719	2026-01-27	2026-01-28 03:07:39.57435
9230	EUR	CAD	1.62950902	2026-01-27	2026-01-28 03:07:39.583505
9231	CAD	EUR	0.613681782504033	2026-01-27	2026-01-28 03:07:39.592141
9232	EUR	CDF	2701.1959115	2026-01-27	2026-01-28 03:07:39.601139
9233	CDF	EUR	0.0003702063947833722	2026-01-27	2026-01-28 03:07:39.631196
9234	EUR	CHF	0.92282633	2026-01-27	2026-01-28 03:07:39.640498
9235	CHF	EUR	1.0836275120151806	2026-01-27	2026-01-28 03:07:39.649792
9243	COP	EUR	0.0002285305684043117	2026-01-27	2026-01-28 03:07:39.734673
9244	EUR	CRC	590.90308054	2026-01-27	2026-01-28 03:07:39.744069
9245	CRC	EUR	0.001692324905610823	2026-01-27	2026-01-28 03:07:39.753413
9246	EUR	CUP	28.38107622	2026-01-27	2026-01-28 03:07:39.762696
9247	CUP	EUR	0.03523474558358379	2026-01-27	2026-01-28 03:07:39.77177
9248	EUR	CVE	110.27	2026-01-27	2026-01-28 03:07:39.780906
9266	EUR	EUR	1	2026-01-27	2026-01-28 03:07:39.974566
9263	ERN	EUR	0.05610576531482958	2026-01-27	2026-01-28 03:07:39.937659
9265	ETB	EUR	0.005420831264510575	2026-01-27	2026-01-28 03:07:39.956269
9268	EUR	FJD	2.6296704	2026-01-27	2026-01-28 03:07:39.984173
9269	FJD	EUR	0.3802757942592349	2026-01-27	2026-01-28 03:07:39.994325
9270	EUR	FKP	0.86820375	2026-01-27	2026-01-28 03:07:40.023677
9271	FKP	EUR	1.1518033641296757	2026-01-27	2026-01-28 03:07:40.078822
9272	EUR	GBP	0.86820375	2026-01-27	2026-01-28 03:07:40.088575
9273	GBP	EUR	1.1518033641296757	2026-01-27	2026-01-28 03:07:40.098415
9274	EUR	GEL	3.19586066	2026-01-27	2026-01-28 03:07:40.108451
9275	GEL	EUR	0.312904755991458	2026-01-27	2026-01-28 03:07:40.118248
9276	EUR	GGP	0.86820375	2026-01-27	2026-01-28 03:07:40.127797
9277	GGP	EUR	1.1518033641296757	2026-01-27	2026-01-28 03:07:40.138679
9278	EUR	GHS	12.94775912	2026-01-27	2026-01-28 03:07:40.148792
9279	GHS	EUR	0.07723344176640815	2026-01-27	2026-01-28 03:07:40.158231
9280	EUR	GIP	0.86820375	2026-01-27	2026-01-28 03:07:40.167667
9281	GIP	EUR	1.1518033641296757	2026-01-27	2026-01-28 03:07:40.177231
9282	EUR	GMD	88.00948994	2026-01-27	2026-01-28 03:07:40.186784
9284	EUR	GNF	10410.43669481	2026-01-27	2026-01-28 03:07:40.207773
9285	GNF	EUR	9.605744978004027e-05	2026-01-27	2026-01-28 03:07:40.232154
9286	EUR	GTQ	9.10122482	2026-01-27	2026-01-28 03:07:40.242242
9287	GTQ	EUR	0.10987532115485088	2026-01-27	2026-01-28 03:07:40.251468
9288	EUR	GYD	248.20236984	2026-01-27	2026-01-28 03:07:40.261247
9289	GYD	EUR	0.0040289703947816264	2026-01-27	2026-01-28 03:07:40.27055
9290	EUR	HKD	9.26531339	2026-01-27	2026-01-28 03:07:40.280316
9291	HKD	EUR	0.10792943076046348	2026-01-27	2026-01-28 03:07:40.290404
9292	EUR	HNL	31.3233567	2026-01-27	2026-01-28 03:07:40.323861
9293	HNL	EUR	0.03192505865758634	2026-01-27	2026-01-28 03:07:40.333693
9294	EUR	HRK	7.5345	2026-01-27	2026-01-28 03:07:40.343698
9295	HRK	EUR	0.13272280841462605	2026-01-27	2026-01-28 03:07:40.35361
9296	EUR	HTG	156.39308706	2026-01-27	2026-01-28 03:07:40.363453
9297	HTG	EUR	0.006394144516223734	2026-01-27	2026-01-28 03:07:40.372974
9298	EUR	HUF	381.60280377	2026-01-27	2026-01-28 03:07:40.382151
9299	HUF	EUR	0.002620525819309024	2026-01-27	2026-01-28 03:07:40.390898
9301	IDR	EUR	5.009605166435808e-05	2026-01-27	2026-01-28 03:07:40.431331
9302	EUR	ILS	3.70288397	2026-01-27	2026-01-28 03:07:40.440496
9303	ILS	EUR	0.2700597718161825	2026-01-27	2026-01-28 03:07:40.449894
9304	EUR	IMP	0.86820375	2026-01-27	2026-01-28 03:07:40.459375
9305	IMP	EUR	1.1518033641296757	2026-01-27	2026-01-28 03:07:40.469087
9306	EUR	INR	108.96326986	2026-01-27	2026-01-28 03:07:40.478391
9307	INR	EUR	0.009177404471110647	2026-01-27	2026-01-28 03:07:40.487531
9308	EUR	IQD	1554.70810242	2026-01-27	2026-01-28 03:07:40.523832
9309	IQD	EUR	0.0006432075567390674	2026-01-27	2026-01-28 03:07:40.533919
9310	EUR	IRR	1280585.65988786	2026-01-27	2026-01-28 03:07:40.544621
9311	IRR	EUR	7.808927050515068e-07	2026-01-27	2026-01-28 03:07:40.554161
9312	EUR	ISK	145.38277858	2026-01-27	2026-01-28 03:07:40.564267
9313	ISK	EUR	0.006878393780661775	2026-01-27	2026-01-28 03:07:40.574108
9314	EUR	JEP	0.86820375	2026-01-27	2026-01-28 03:07:40.58405
9315	JEP	EUR	1.1518033641296757	2026-01-27	2026-01-28 03:07:40.593565
9316	EUR	JMD	186.10371221	2026-01-27	2026-01-28 03:07:40.623755
9318	EUR	JOD	0.8424565	2026-01-27	2026-01-28 03:07:40.642697
9319	JOD	EUR	1.1870049076717908	2026-01-27	2026-01-28 03:07:40.656749
9320	EUR	JPY	183.38469533	2026-01-27	2026-01-28 03:07:40.666198
9321	JPY	EUR	0.005453017757018949	2026-01-27	2026-01-28 03:07:40.675431
9322	EUR	KES	153.15586542	2026-01-27	2026-01-28 03:07:40.684695
9323	KES	EUR	0.006529296134089906	2026-01-27	2026-01-28 03:07:40.694252
9324	EUR	KGS	103.9288991	2026-01-27	2026-01-28 03:07:40.704471
9325	KGS	EUR	0.00962196279052089	2026-01-27	2026-01-28 03:07:40.713853
9326	EUR	KHR	4780.57533197	2026-01-27	2026-01-28 03:07:40.733621
9327	KHR	EUR	0.00020917984354571728	2026-01-27	2026-01-28 03:07:40.742974
9328	EUR	KMF	491.96774998	2026-01-27	2026-01-28 03:07:40.753045
9329	KMF	EUR	0.0020326535632481054	2026-01-27	2026-01-28 03:07:40.762267
9330	EUR	KRW	1721.45540854	2026-01-27	2026-01-28 03:07:40.77153
9331	KRW	EUR	0.0005809038067666937	2026-01-27	2026-01-28 03:07:40.780962
9332	EUR	KWD	0.36444098	2026-01-27	2026-01-28 03:07:40.789593
9333	KWD	EUR	2.743928523076631	2026-01-27	2026-01-28 03:07:40.798403
9335	KYD	EUR	1.0162992653355545	2026-01-27	2026-01-28 03:07:40.835201
9336	EUR	KZT	596.4365345	2026-01-27	2026-01-28 03:07:40.844321
9337	KZT	EUR	0.0016766243215438038	2026-01-27	2026-01-28 03:07:40.853604
9338	EUR	LAK	25535.27109107	2026-01-27	2026-01-28 03:07:40.862528
9339	LAK	EUR	3.916151884323297e-05	2026-01-27	2026-01-28 03:07:40.872195
9340	EUR	LBP	106071.43955797	2026-01-27	2026-01-28 03:07:40.881524
9341	LBP	EUR	9.42760845112771e-06	2026-01-27	2026-01-28 03:07:40.891231
9342	EUR	LKR	367.19351521	2026-01-27	2026-01-28 03:07:40.900809
9343	LKR	EUR	0.0027233596416540596	2026-01-27	2026-01-28 03:07:40.923682
9344	EUR	LRD	219.2003796	2026-01-27	2026-01-28 03:07:40.933164
9345	LRD	EUR	0.004562035895306451	2026-01-27	2026-01-28 03:07:40.942383
9346	EUR	LSL	19.03120321	2026-01-27	2026-01-28 03:07:40.951904
9347	LSL	EUR	0.052545285180631514	2026-01-27	2026-01-28 03:07:40.960826
9348	EUR	LYD	7.49216894	2026-01-27	2026-01-28 03:07:40.969719
9349	LYD	EUR	0.133472697693867	2026-01-27	2026-01-28 03:07:40.97834
9350	EUR	MAD	10.78840904	2026-01-27	2026-01-28 03:07:40.987236
9352	EUR	MDL	19.9652265	2026-01-27	2026-01-28 03:07:41.029458
9353	MDL	EUR	0.050087085162795426	2026-01-27	2026-01-28 03:07:41.039094
9354	EUR	MGA	5350.55176784	2026-01-27	2026-01-28 03:07:41.048244
9355	MGA	EUR	0.0001868966124224038	2026-01-27	2026-01-28 03:07:41.057504
9356	EUR	MKD	61.63188415	2026-01-27	2026-01-28 03:07:41.066312
9357	MKD	EUR	0.016225367985930706	2026-01-27	2026-01-28 03:07:41.074972
9358	EUR	MMK	2495.18119457	2026-01-27	2026-01-28 03:07:41.084394
9359	MMK	EUR	0.00040077249787558297	2026-01-27	2026-01-28 03:07:41.094502
9360	EUR	MNT	4237.95807875	2026-01-27	2026-01-28 03:07:41.104269
9361	MNT	EUR	0.00023596269274446277	2026-01-27	2026-01-28 03:07:41.114419
9362	EUR	MOP	9.54327279	2026-01-27	2026-01-28 03:07:41.130777
9363	MOP	EUR	0.10478585512591221	2026-01-27	2026-01-28 03:07:41.140219
9364	EUR	MRU	47.41857196	2026-01-27	2026-01-28 03:07:41.149486
9365	MRU	EUR	0.02108878354336675	2026-01-27	2026-01-28 03:07:41.158223
9366	EUR	MUR	54.08614402	2026-01-27	2026-01-28 03:07:41.166823
9367	MUR	EUR	0.018489023725378157	2026-01-27	2026-01-28 03:07:41.175592
9369	MVR	EUR	0.05443721566367123	2026-01-27	2026-01-28 03:07:41.19406
9370	EUR	MWK	2059.58824687	2026-01-27	2026-01-28 03:07:41.203383
9371	MWK	EUR	0.00048553394180595133	2026-01-27	2026-01-28 03:07:41.231978
9372	EUR	MXN	20.59905352	2026-01-27	2026-01-28 03:07:41.241322
9373	MXN	EUR	0.04854591979330903	2026-01-27	2026-01-28 03:07:41.251068
9374	EUR	MYR	4.71347129	2026-01-27	2026-01-28 03:07:41.260329
9375	MYR	EUR	0.21215786380657045	2026-01-27	2026-01-28 03:07:41.269123
9376	EUR	MZN	75.72871989	2026-01-27	2026-01-28 03:07:41.278084
9377	MZN	EUR	0.013205029762190004	2026-01-27	2026-01-28 03:07:41.28671
9378	EUR	NAD	19.03120321	2026-01-27	2026-01-28 03:07:41.296855
9379	NAD	EUR	0.052545285180631514	2026-01-27	2026-01-28 03:07:41.30618
9380	EUR	NGN	1679.63509335	2026-01-27	2026-01-28 03:07:41.315349
9381	NGN	EUR	0.0005953674128143626	2026-01-27	2026-01-28 03:07:41.328412
9262	EUR	ERN	17.82348025	2026-01-27	2026-01-28 03:07:39.928497
9384	EUR	NOK	11.61947606	2026-01-27	2026-01-28 03:07:41.354815
9385	NOK	EUR	0.08606240030413213	2026-01-27	2026-01-28 03:07:41.363765
9386	EUR	NPR	174.42295423	2026-01-27	2026-01-28 03:07:41.373331
9387	NPR	EUR	0.005733190361409464	2026-01-27	2026-01-28 03:07:41.381964
9388	EUR	NZD	1.98995684	2026-01-27	2026-01-28 03:07:41.391132
9389	NZD	EUR	0.5025234617651305	2026-01-27	2026-01-28 03:07:41.400494
9390	EUR	OMR	0.4572553	2026-01-27	2026-01-28 03:07:41.410691
9391	OMR	EUR	2.18696207567195	2026-01-27	2026-01-28 03:07:41.431258
9392	EUR	PAB	1.18823202	2026-01-27	2026-01-28 03:07:41.440203
9393	PAB	EUR	0.8415864773615509	2026-01-27	2026-01-28 03:07:41.449111
9394	EUR	PEN	3.98274245	2026-01-27	2026-01-28 03:07:41.457827
9395	PEN	EUR	0.251083270523807	2026-01-27	2026-01-28 03:07:41.466716
9396	EUR	PGK	5.12097934	2026-01-27	2026-01-28 03:07:41.476023
9397	PGK	EUR	0.19527514828833503	2026-01-27	2026-01-28 03:07:41.485357
9398	EUR	PHP	70.22279224	2026-01-27	2026-01-28 03:07:41.494765
9399	PHP	EUR	0.014240390734995358	2026-01-27	2026-01-28 03:07:41.503797
9400	EUR	PKR	332.32691648	2026-01-27	2026-01-28 03:07:41.513565
9402	EUR	PLN	4.2064304	2026-01-27	2026-01-28 03:07:41.54145
9403	PLN	EUR	0.23773126021531224	2026-01-27	2026-01-28 03:07:41.549972
9404	EUR	PYG	7910.73970742	2026-01-27	2026-01-28 03:07:41.558882
9405	PYG	EUR	0.0001264104289845404	2026-01-27	2026-01-28 03:07:41.568211
9406	EUR	QAR	4.32516454	2026-01-27	2026-01-28 03:07:41.576999
9407	QAR	EUR	0.23120507688246236	2026-01-27	2026-01-28 03:07:41.586214
9408	EUR	RON	5.09772818	2026-01-27	2026-01-28 03:07:41.596523
9409	RON	EUR	0.19616581439616892	2026-01-27	2026-01-28 03:07:41.6068
9410	EUR	RSD	117.42398763	2026-01-27	2026-01-28 03:07:41.63268
9411	RSD	EUR	0.008516147511111398	2026-01-27	2026-01-28 03:07:41.65489
9412	EUR	RUB	90.89701326	2026-01-27	2026-01-28 03:07:41.672773
9413	RUB	EUR	0.011001461589718245	2026-01-27	2026-01-28 03:07:41.682579
9414	EUR	RWF	1723.73527825	2026-01-27	2026-01-28 03:07:41.696578
9415	RWF	EUR	0.0005801354840374545	2026-01-27	2026-01-28 03:07:41.706517
9416	EUR	SAR	4.45587006	2026-01-27	2026-01-28 03:07:41.723783
9417	SAR	EUR	0.2244230613852326	2026-01-27	2026-01-28 03:07:41.735326
9419	SBD	EUR	0.1045005438359827	2026-01-27	2026-01-28 03:07:41.755787
9420	EUR	SCR	17.0668129	2026-01-27	2026-01-28 03:07:41.765323
9421	SCR	EUR	0.0585932479519946	2026-01-27	2026-01-28 03:07:41.774499
9422	EUR	SDG	712.3676759	2026-01-27	2026-01-28 03:07:41.783567
9423	SDG	EUR	0.0014037694772388535	2026-01-27	2026-01-28 03:07:41.792799
9424	EUR	SEK	10.62259558	2026-01-27	2026-01-28 03:07:41.802487
9426	SEK	EUR	0.09413895054828021	2026-01-27	2026-01-28 03:07:41.832086
9427	EUR	SGD	1.50815025	2026-01-27	2026-01-28 03:07:41.842125
9428	SGD	EUR	0.6630639089175632	2026-01-27	2026-01-28 03:07:41.852109
9429	EUR	SHP	0.86820375	2026-01-27	2026-01-28 03:07:41.861262
9430	SHP	EUR	1.1518033641296757	2026-01-27	2026-01-28 03:07:41.871084
9431	EUR	SLE	28.49882248	2026-01-27	2026-01-28 03:07:41.880419
9432	SLE	EUR	0.035089169059591266	2026-01-27	2026-01-28 03:07:41.889371
9433	EUR	SOS	675.1443923	2026-01-27	2026-01-28 03:07:41.898497
9434	SOS	EUR	0.0014811646388609128	2026-01-27	2026-01-28 03:07:41.928305
9435	EUR	SRD	45.21028076	2026-01-27	2026-01-28 03:07:41.93742
9437	EUR	SSP	5390.0267369	2026-01-27	2026-01-28 03:07:41.955292
9438	SSP	EUR	0.0001855278366532067	2026-01-27	2026-01-28 03:07:41.964266
9439	EUR	STN	24.73334193	2026-01-27	2026-01-28 03:07:41.973432
9440	STN	EUR	0.04043125279350391	2026-01-27	2026-01-28 03:07:41.982081
9441	EUR	SYP	131.57451486	2026-01-27	2026-01-28 03:07:41.991618
9442	SYP	EUR	0.0076002560303113096	2026-01-27	2026-01-28 03:07:42.001383
9443	EUR	SZL	19.03120321	2026-01-27	2026-01-28 03:07:42.00978
9444	SZL	EUR	0.052545285180631514	2026-01-27	2026-01-28 03:07:42.032599
9445	EUR	THB	37.11165959	2026-01-27	2026-01-28 03:07:42.041252
9446	THB	EUR	0.026945709543785994	2026-01-27	2026-01-28 03:07:42.050198
9447	EUR	TJS	11.08508469	2026-01-27	2026-01-28 03:07:42.059285
9448	TJS	EUR	0.09021130897647657	2026-01-27	2026-01-28 03:07:42.068349
9449	EUR	TMT	4.15611406	2026-01-27	2026-01-28 03:07:42.077611
9450	TMT	EUR	0.24060937345882177	2026-01-27	2026-01-28 03:07:42.086899
9451	EUR	TND	3.38303122	2026-01-27	2026-01-28 03:07:42.096477
9452	TND	EUR	0.2955928973070488	2026-01-27	2026-01-28 03:07:42.105497
9454	TOP	EUR	0.3546255476925615	2026-01-27	2026-01-28 03:07:42.141278
9455	EUR	TRY	51.55830769	2026-01-27	2026-01-28 03:07:42.150846
9456	TRY	EUR	0.019395516354272332	2026-01-27	2026-01-28 03:07:42.160431
9457	EUR	TTD	8.05749033	2026-01-27	2026-01-28 03:07:42.170018
9458	TTD	EUR	0.12410812288247573	2026-01-27	2026-01-28 03:07:42.178871
9459	EUR	TVD	1.71698112	2026-01-27	2026-01-28 03:07:42.188429
9460	TVD	EUR	0.5824175865137061	2026-01-27	2026-01-28 03:07:42.223668
9461	EUR	TWD	37.41557432	2026-01-27	2026-01-28 03:07:42.234188
9462	TWD	EUR	0.026726838172986784	2026-01-27	2026-01-28 03:07:42.242832
9463	EUR	TZS	3021.40174362	2026-01-27	2026-01-28 03:07:42.251689
9464	TZS	EUR	0.00033097220590131804	2026-01-27	2026-01-28 03:07:42.260904
9465	EUR	UAH	51.22872448	2026-01-27	2026-01-28 03:07:42.270194
9466	UAH	EUR	0.01952029862446421	2026-01-27	2026-01-28 03:07:42.279226
9467	EUR	UGX	4209.24057716	2026-01-27	2026-01-28 03:07:42.28863
9468	UGX	EUR	0.00023757254584738088	2026-01-27	2026-01-28 03:07:42.29823
9469	EUR	USD	1.18823202	2026-01-27	2026-01-28 03:07:42.307009
9471	EUR	UYU	44.52639444	2026-01-27	2026-01-28 03:07:42.338212
9472	UYU	EUR	0.022458589171137928	2026-01-27	2026-01-28 03:07:42.348264
9473	EUR	UZS	14358.62127921	2026-01-27	2026-01-28 03:07:42.357691
9474	UZS	EUR	6.964456966686006e-05	2026-01-27	2026-01-28 03:07:42.367268
9475	EUR	VES	425.80048208	2026-01-27	2026-01-28 03:07:42.376406
9476	VES	EUR	0.002348517773195284	2026-01-27	2026-01-28 03:07:42.385699
9477	EUR	VND	31083.47212685	2026-01-27	2026-01-28 03:07:42.42359
9478	VND	EUR	3.2171438117307266e-05	2026-01-27	2026-01-28 03:07:42.433711
9479	EUR	VUV	141.91118844	2026-01-27	2026-01-28 03:07:42.443558
9480	VUV	EUR	0.007046660738964918	2026-01-27	2026-01-28 03:07:42.452419
9481	EUR	WST	3.22808691	2026-01-27	2026-01-28 03:07:42.461917
9482	WST	EUR	0.30978100276736353	2026-01-27	2026-01-28 03:07:42.471128
9483	EUR	XAF	655.95699997	2026-01-27	2026-01-28 03:07:42.480606
9484	XAF	EUR	0.001524490172443826	2026-01-27	2026-01-28 03:07:42.489858
9485	EUR	XCD	3.21520559	2026-01-27	2026-01-28 03:07:42.499807
9486	XCD	EUR	0.3110221017001902	2026-01-27	2026-01-28 03:07:42.510163
9488	XDR	EUR	1.159298445908265	2026-01-27	2026-01-28 03:07:42.537615
9489	EUR	XOF	655.95699997	2026-01-27	2026-01-28 03:07:42.546743
9490	XOF	EUR	0.001524490172443826	2026-01-27	2026-01-28 03:07:42.556353
9491	EUR	XPF	119.33174224	2026-01-27	2026-01-28 03:07:42.566557
9492	XPF	EUR	0.008380000000241344	2026-01-27	2026-01-28 03:07:42.576385
9493	EUR	YER	283.11365332	2026-01-27	2026-01-28 03:07:42.585609
9494	YER	EUR	0.0035321503865082472	2026-01-27	2026-01-28 03:07:42.595055
9495	EUR	ZAR	19.03120321	2026-01-27	2026-01-28 03:07:42.60517
9496	ZAR	EUR	0.052545285180631514	2026-01-27	2026-01-28 03:07:42.63123
9497	EUR	ZMW	23.2810368	2026-01-27	2026-01-28 03:07:42.640889
9498	ZMW	EUR	0.04295341348371564	2026-01-27	2026-01-28 03:07:42.650584
9499	EUR	ZWL	76032.61248095	2026-01-27	2026-01-28 03:07:42.660736
9500	ZWL	EUR	1.315225095350433e-05	2026-01-27	2026-01-28 03:07:42.670375
9180	EUR	AED	4.36378208	2026-01-27	2026-01-28 03:07:38.940073
9383	NIO	EUR	0.022930403189188906	2026-01-27	2026-01-28 03:07:41.345865
9181	AED	EUR	0.22915901428331636	2026-01-27	2026-01-28 03:07:38.946147
9187	AMD	EUR	0.0022501913783942	2026-01-27	2026-01-28 03:07:39.058319
9196	EUR	AWG	2.12693531	2026-01-27	2026-01-28 03:07:39.1738
9197	AWG	EUR	0.4701600445008363	2026-01-27	2026-01-28 03:07:39.182959
9198	EUR	AZN	2.01999577	2026-01-27	2026-01-28 03:07:39.19222
9211	BIF	EUR	0.00028495158989986363	2026-01-27	2026-01-28 03:07:39.374757
9226	EUR	BYN	3.38081629	2026-01-27	2026-01-28 03:07:39.546402
9227	BYN	EUR	0.2957865539626822	2026-01-27	2026-01-28 03:07:39.556371
9228	EUR	BZD	2.39195447	2026-01-27	2026-01-28 03:07:39.565198
9251	CZK	EUR	0.04125740341876924	2026-01-27	2026-01-28 03:07:39.808593
9264	EUR	ETB	184.47355234	2026-01-27	2026-01-28 03:07:39.947015
9283	GMD	EUR	0.01136241103864759	2026-01-27	2026-01-28 03:07:40.197499
9300	EUR	IDR	19961.65300012	2026-01-27	2026-01-28 03:07:40.400324
9317	JMD	EUR	0.005373347947361722	2026-01-27	2026-01-28 03:07:40.633521
9334	EUR	KYD	0.98396214	2026-01-27	2026-01-28 03:07:40.82423
9351	MAD	EUR	0.09269207315854609	2026-01-27	2026-01-28 03:07:40.996618
9368	EUR	MVR	18.36978596	2026-01-27	2026-01-28 03:07:41.184922
9382	EUR	NIO	43.61022315	2026-01-27	2026-01-28 03:07:41.33717
9401	PKR	EUR	0.003009085182121207	2026-01-27	2026-01-28 03:07:41.532245
9418	EUR	SBD	9.56932819	2026-01-27	2026-01-28 03:07:41.745709
9436	SRD	EUR	0.02211886286016508	2026-01-27	2026-01-28 03:07:41.94622
9453	EUR	TOP	2.8198758	2026-01-27	2026-01-28 03:07:42.131191
9470	USD	EUR	0.8415864773615509	2026-01-27	2026-01-28 03:07:42.328457
9487	EUR	XDR	0.86259065	2026-01-27	2026-01-28 03:07:42.528679
\.


--
-- Data for Name: expense_name_mappings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.expense_name_mappings (id, expense_name, subcategory, confidence, last_updated) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.expenses (id, user_id, budget_period_id, recurring_template_id, name, amount, category, subcategory, date, due_date, payment_method, notes, receipt_url, is_fixed_bill, created_at, currency, original_amount, exchange_rate_used, deleted_at, updated_at) FROM stdin;
174	1	\N	\N	Wolt	3542	Flexible Expenses	Food	2025-12-31	N/A	Credit card	\N	\N	f	2026-01-01 12:39:24.380325	EUR	\N	\N	\N	\N
175	1	\N	\N	Wolt	1999	Flexible Expenses	Food	2025-12-31	N/A	Credit card	\N	\N	f	2026-01-01 12:39:36.191134	EUR	\N	\N	\N	\N
176	1	\N	\N	Nordea Credit Interest	466	Flexible Expenses	Other	2026-01-01	N/A	Credit card	\N	\N	f	2026-01-01 12:40:22.722058	EUR	\N	\N	\N	\N
182	1	\N	\N	Groceries	3814	Flexible Expenses	Food	2026-01-04	N/A	Credit card	\N	\N	f	2026-01-05 12:33:19.680494	EUR	\N	\N	\N	2026-01-06 18:13:35.298588
183	1	\N	\N	Wolt	1426	Flexible Expenses	Food	2026-01-04	N/A	Credit card	\N	\N	f	2026-01-05 12:33:32.53605	EUR	\N	\N	\N	2026-01-06 18:13:42.974698
184	1	\N	\N	Wolt	2534	Flexible Expenses	Food	2026-01-05	N/A	Debit card	\N	\N	f	2026-01-06 18:14:38.39144	EUR	\N	\N	\N	2026-01-06 18:14:38.391444
185	1	\N	\N	Groceries	2395	Flexible Expenses	Food	2026-01-05	N/A	Debit card	\N	\N	f	2026-01-06 18:15:00.953954	EUR	\N	\N	\N	2026-01-06 18:15:00.953961
186	1	\N	\N	Wolt	603	Flexible Expenses	Food	2026-01-06	N/A	Debit card	\N	\N	f	2026-01-06 18:15:20.494311	EUR	\N	\N	\N	2026-01-06 18:15:20.494314
187	1	\N	\N	Wolt	3062	Flexible Expenses	Food	2026-01-07	N/A	Credit card	\N	\N	f	2026-01-08 10:03:26.62518	EUR	\N	\N	\N	2026-01-08 10:03:26.625184
188	1	\N	\N	Wolt	1468	Flexible Expenses	Food	2026-01-07	N/A	Credit card	\N	\N	f	2026-01-08 10:03:39.434257	EUR	\N	\N	\N	2026-01-08 10:03:47.99694
189	1	\N	\N	Wolt	2274	Flexible Expenses	Food	2026-01-09	N/A	Debit card	\N	\N	f	2026-01-10 00:25:14.806832	EUR	\N	\N	\N	2026-01-10 00:25:14.806835
190	1	\N	\N	Wolt	1858	Flexible Expenses	Food	2026-01-09	N/A	Debit card	\N	\N	f	2026-01-10 00:25:26.691559	EUR	\N	\N	\N	2026-01-10 00:25:26.691564
191	1	\N	\N	Nordea Bank Abp	465	Fixed Expenses	Other	2026-01-12	N/A	Debit card	\N	\N	f	2026-01-12 16:05:53.696254	EUR	\N	\N	\N	2026-01-12 16:05:53.696257
196	1	\N	\N	Wolt	2239	Flexible Expenses	Food	2026-01-13	N/A	Credit card	\N	\N	f	2026-01-15 23:47:08.590161	EUR	\N	\N	\N	2026-01-15 23:47:08.590165
198	1	\N	\N	Wolt	2524	Flexible Expenses	Food	2026-01-14	N/A	Credit card	\N	\N	f	2026-01-15 23:47:56.423906	EUR	\N	\N	\N	2026-01-15 23:47:56.423912
216	1	\N	30	Credit repayment	50000	Debt Payments	Credit Card	2026-01-20	N/A	Debit card	\N	\N	t	2026-01-19 18:58:20.325585	EUR	\N	\N	\N	2026-01-19 18:58:20.32559
203	1	\N	16	Discord	999	Fixed Expenses	Subscriptions	2026-02-16	N/A	Credit card	\N	\N	t	2026-01-18 21:27:25.190712	EUR	\N	\N	\N	2026-01-19 18:33:57.806246
177	1	\N	12	YouTube	1499	Flexible Expenses	Entertainment	2026-01-28	N/A	Debit card	\N	\N	t	2026-01-02 14:41:43.623428	EUR	\N	\N	\N	2026-01-19 18:34:04.698256
205	1	\N	15	Telia Dot	810	Fixed Expenses	Subscriptions	2026-02-15	N/A	Debit card	\N	\N	t	2026-01-18 21:27:25.273633	EUR	\N	\N	\N	2026-01-19 18:34:08.409446
204	1	\N	11	Insinööriliitto	3525	Fixed Expenses	Insurance	2026-02-15	N/A	Debit card	\N	\N	t	2026-01-18 21:27:25.265677	EUR	\N	\N	\N	2026-01-19 18:34:15.857654
209	1	\N	28	Klarna Turkish Airlines Business Payment	10479	Debt Payments	Klarna Turkish Airlines Business	2026-01-20	N/A	Debit card	\N	\N	t	2026-01-19 17:54:42.936954	EUR	\N	\N	\N	2026-01-19 18:34:17.394832
195	1	\N	24	LähiTapiola Keskinäinen Vakuutus	5515	Fixed Expenses	Insurance	2026-01-20	N/A	Debit card	\N	\N	t	2026-01-12 16:10:35.397464	EUR	\N	\N	\N	2026-01-19 18:34:18.322653
2	1	2	1	Telia	4546	Debt Payments	Telia Rahoitus	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:13.991189	EUR	\N	\N	\N	2025-12-04 16:06:13.991189
202	1	\N	\N	Zooplus	6895	Flexible Expenses	Cat Stuff	2026-01-20	N/A	Credit card	\N	\N	f	2026-01-16 09:14:28.773466	EUR	\N	\N	\N	2026-01-21 15:40:49.126815
208	1	\N	27	Credit payment	25000	Debt Payments	Credit Card	2026-01-20	N/A	Debit card	\N	\N	t	2026-01-19 17:51:34.176947	EUR	\N	\N	2026-01-19 18:56:49.480241	2026-01-19 18:56:49.480671
148	1	\N	5	Klarna Turkish Airlines Old	8881	Debt Payments	Klarna Turkish Airlines Old	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.243697	EUR	\N	\N	\N	2026-01-21 15:42:45.287292
217	1	\N	\N	Uber	1079	Flexible Expenses	Transportation	2026-01-22	N/A	Debit card	\N	\N	f	2026-01-23 11:42:46.83104	EUR	\N	\N	\N	2026-01-23 11:42:46.831042
218	1	\N	\N	Sodexo Nokia	880	Flexible Expenses	Food	2026-01-22	N/A	Debit card	\N	\N	f	2026-01-23 11:43:04.95733	EUR	\N	\N	\N	2026-01-23 11:43:04.957335
220	1	\N	\N	Wolt	1980	Flexible Expenses	Food	2026-01-22	N/A	Debit card	\N	\N	f	2026-01-23 11:43:29.118859	EUR	\N	\N	\N	2026-01-23 11:43:29.118862
235	1	\N	\N	Telia HBO Max (now cancelled)	1608	Flexible Expenses	Entertainment	2026-01-19	N/A	Debit card	\N	\N	f	2026-01-23 12:01:20.641965	EUR	\N	\N	\N	2026-01-23 12:01:20.641968
236	1	\N	\N	Wolt	2957	Flexible Expenses	Food	2026-01-23	N/A	Debit card	\N	\N	f	2026-01-23 16:35:02.824842	EUR	\N	\N	\N	2026-01-23 16:35:02.824845
178	1	\N	21	GH Copilot	2008	Fixed Expenses	Subscriptions	2026-01-26	N/A	Debit card	\N	\N	t	2026-01-02 14:41:43.653203	EUR	\N	\N	\N	2026-01-26 12:31:21.337085
237	1	\N	\N	Proton VPN	999	Flexible Expenses	Entertainment	2026-01-25	N/A	Debit card	\N	\N	f	2026-01-26 12:32:17.906339	EUR	\N	\N	\N	2026-01-26 12:32:17.906342
239	1	\N	21	GH Copilot	3000	Fixed Expenses	Subscriptions	2026-02-26	N/A	Debit card	\N	\N	t	2026-01-27 09:42:55.15057	EUR	\N	\N	\N	2026-01-27 09:42:55.150574
240	1	\N	33	Proton VPN	999	Fixed Expenses	Subscriptions	2026-02-25	N/A	Debit card	\N	\N	f	2026-01-27 09:42:55.160583	EUR	\N	\N	\N	2026-01-27 09:42:55.160586
241	1	\N	\N	Wolt	1946	Flexible Expenses	Food	2026-01-27	N/A	Debit card	\N	\N	f	2026-01-27 15:21:00.087737	EUR	\N	\N	\N	2026-01-27 15:21:00.087741
179	1	\N	\N	Groceries	1070	Flexible Expenses	Food	2026-01-01	N/A	Credit card	\N	\N	f	2026-01-02 14:42:24.505144	EUR	\N	\N	\N	2026-01-02 14:42:24.505147
192	1	\N	\N	Twitch Sub	998	Flexible Expenses	Entertainment	2026-01-09	N/A	Credit card	\N	\N	f	2026-01-12 16:06:58.770509	EUR	\N	\N	\N	2026-01-12 16:06:58.770514
197	1	\N	\N	Groceries 	3548	Flexible Expenses	Food	2026-01-13	N/A	Credit card	\N	\N	f	2026-01-15 23:47:29.784812	EUR	\N	\N	\N	2026-01-15 23:47:29.784816
200	1	\N	\N	Wolt	1478	Flexible Expenses	Food	2026-01-15	N/A	Debit card	\N	\N	f	2026-01-15 23:48:32.804414	EUR	\N	\N	\N	2026-01-15 23:48:32.80442
153	1	\N	15	Telia Dot	810	Fixed Expenses	Subscriptions	2026-01-16	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.320684	EUR	\N	\N	\N	2026-01-16 09:21:46.719367
210	1	\N	29	Emergency Fund Contribution	5000	Savings & Investments	Emergency Fund	2026-01-19	N/A	Debit card	\N	\N	f	2026-01-19 17:56:15.496308	EUR	\N	\N	\N	2026-01-19 17:56:15.496313
211	1	\N	\N	Wolt	2321	Flexible Expenses	Food	2026-01-17	N/A	Credit card	\N	\N	f	2026-01-19 17:57:27.172715	EUR	\N	\N	\N	2026-01-19 17:57:27.172718
212	1	\N	\N	Wolt	4009	Flexible Expenses	Food	2026-01-17	N/A	Credit card	\N	\N	f	2026-01-19 17:57:38.748356	EUR	\N	\N	\N	2026-01-19 17:57:38.74836
180	1	\N	23	Agria Eläinvakuutus	9456	Fixed Expenses	Insurance	2026-01-20	N/A	Debit card	\N	\N	t	2026-01-02 14:45:32.487023	EUR	\N	\N	\N	2026-01-19 18:34:20.78897
150	1	\N	2	Elisa	3535	Debt Payments	Elisa (Phone)	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.255682	EUR	\N	\N	\N	2026-01-19 18:34:21.792012
181	1	\N	\N	Credit Card Payment	24750	Debt Payments	Credit Card	2026-01-20	N/A	Debit card	\N	\N	f	2026-01-02 14:45:59.655067	EUR	\N	\N	2026-01-19 18:56:25.116789	2026-01-19 18:56:25.117159
206	1	\N	25	Credit card repayment	50000	Debt Payments	Credit Card	2026-01-20	N/A	Debit card	\N	\N	t	2026-01-18 21:34:01.969055	EUR	\N	\N	2026-01-19 18:56:37.612526	2026-01-19 18:56:37.612912
219	1	\N	\N	Wolt	1890	Flexible Expenses	Food	2026-01-22	N/A	Debit card	\N	\N	f	2026-01-23 11:43:19.083262	EUR	\N	\N	\N	2026-01-23 11:43:19.083265
221	1	\N	10	DNA	3490	Fixed Expenses	Subscriptions	2026-02-20	N/A	Debit card	\N	\N	t	2026-01-23 11:44:25.751397	EUR	\N	\N	\N	2026-01-23 11:44:25.7514
222	1	\N	8	Rent	94718	Fixed Expenses	Rent	2026-02-20	N/A	Debit card	\N	\N	t	2026-01-23 11:44:25.761172	EUR	\N	\N	\N	2026-01-23 11:44:25.761175
223	1	\N	4	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	2026-02-20	N/A	Debit card	\N	\N	t	2026-01-23 11:44:25.770099	EUR	\N	\N	\N	2026-01-23 11:44:25.770102
224	1	\N	5	Klarna Turkish Airlines Old	10080	Debt Payments	Klarna Turkish Airlines Old	2026-02-20	N/A	Debit card	\N	\N	t	2026-01-23 11:44:25.77904	EUR	\N	\N	\N	2026-01-23 11:44:25.779043
225	1	\N	28	Klarna Turkish Airlines Business Payment	10479	Debt Payments	Klarna Turkish Airlines Business	2026-02-20	N/A	Debit card	\N	\N	t	2026-01-23 11:44:25.787547	EUR	\N	\N	\N	2026-01-23 11:44:25.78755
226	1	\N	3	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	2026-02-20	N/A	Debit card	\N	\N	t	2026-01-23 11:44:25.838789	EUR	\N	\N	\N	2026-01-23 11:44:25.838795
227	1	\N	2	Elisa	3535	Debt Payments	Elisa (Phone)	2026-02-20	N/A	Debit card	\N	\N	t	2026-01-23 11:44:25.869972	EUR	\N	\N	\N	2026-01-23 11:44:25.869979
228	1	\N	18	Investment (Nordea) Contribution	5000	Savings & Investments	Investment (Nordea)	2026-02-20	N/A	Debit card	\N	\N	t	2026-01-23 11:44:25.881241	EUR	\N	\N	\N	2026-01-23 11:44:25.881246
229	1	\N	30	Credit repayment	50000	Debt Payments	Credit Card	2026-02-20	N/A	Debit card	\N	\N	t	2026-01-23 11:44:25.889867	EUR	\N	\N	\N	2026-01-23 11:44:25.88987
230	1	\N	29	Emergency Fund Contribution	5000	Savings & Investments	Emergency Fund	2026-02-19	N/A	Debit card	\N	\N	t	2026-01-23 11:44:25.898209	EUR	\N	\N	\N	2026-01-23 11:44:25.898212
232	1	\N	9	Fortum	3000	Fixed Expenses	Utilities	2026-02-20	N/A	Debit card	\N	\N	t	2026-01-23 11:44:25.91588	EUR	\N	\N	\N	2026-01-23 11:44:25.915883
233	1	\N	1	Telia	4546	Debt Payments	Telia Rahoitus	2026-02-20	N/A	Debit card	\N	\N	t	2026-01-23 11:44:25.924085	EUR	\N	\N	\N	2026-01-23 11:44:25.924087
231	1	\N	31	HBO Max	699	Flexible Expenses	Entertainment	2026-02-22	N/A	Debit card	\N	\N	f	2026-01-23 11:44:25.907677	EUR	\N	\N	2026-01-23 11:45:30.580056	2026-01-23 11:45:30.580857
238	1	\N	\N	Allmeat	8420	Flexible Expenses	Food	2026-01-25	N/A	Credit card	\N	\N	f	2026-01-26 12:33:28.299117	EUR	\N	\N	\N	2026-01-26 12:33:28.299121
242	1	\N	\N	Wolt	2786	Flexible Expenses	Food	2026-01-27	N/A	Debit card	\N	\N	f	2026-01-27 15:21:16.698581	EUR	\N	\N	\N	2026-01-27 15:21:16.698585
49	1	2	\N	Wolt	5004	Flexible Expenses	Food	2025-11-30	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.686852	EUR	\N	\N	\N	2025-12-04 16:06:14.686852
51	1	2	\N	Snapchat	99	Flexible Expenses	Entertainment	2025-11-30	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.707763	EUR	\N	\N	\N	2025-12-04 16:06:14.707763
52	1	2	\N	YouTube	1499	Flexible Expenses	Entertainment	2025-11-30	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.716167	EUR	\N	\N	\N	2025-12-04 16:06:14.716167
53	1	2	\N	Wolt	1478	Flexible Expenses	Food	2025-12-02	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.724467	EUR	\N	\N	\N	2025-12-04 16:06:14.724467
54	1	2	\N	Wolt	3356	Flexible Expenses	Food	2025-12-03	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.73294	EUR	\N	\N	\N	2025-12-04 16:06:14.73294
9	1	2	\N	Fortum	2651	Fixed Expenses	Utilities	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.056033	EUR	\N	\N	\N	2025-12-04 16:06:14.056033
193	1	\N	\N	Wolt	3757	Flexible Expenses	Food	2026-01-11	N/A	Credit card	\N	\N	f	2026-01-12 16:07:15.866414	EUR	\N	\N	\N	2026-01-12 16:07:15.866433
199	1	\N	\N	Groceries 	4719	Flexible Expenses	Food	2026-01-14	N/A	Credit card	\N	\N	f	2026-01-15 23:48:14.777834	EUR	\N	\N	\N	2026-01-15 23:48:14.777839
201	1	\N	\N	Wolt	2081	Flexible Expenses	Food	2026-01-15	N/A	Credit card	\N	\N	f	2026-01-15 23:48:51.326053	EUR	\N	\N	\N	2026-01-15 23:48:51.326059
213	1	\N	\N	Wolt	3041	Flexible Expenses	Food	2026-01-19	N/A	Credit card	\N	\N	f	2026-01-19 17:57:52.589001	EUR	\N	\N	\N	2026-01-19 17:57:52.589007
207	1	\N	26	Credit card repayment	50000	Debt Payments	Credit Card	2026-01-20	N/A	Debit card	\N	\N	t	2026-01-18 21:37:30.876504	EUR	\N	\N	2026-01-19 18:35:20.060431	2026-01-19 18:35:20.060733
234	1	\N	32	HBO Max	699	Flexible Expenses	Entertainment	2026-01-22	N/A	Debit card	\N	\N	f	2026-01-23 11:46:15.190893	EUR	\N	\N	\N	2026-01-23 11:46:44.722013
215	1	\N	12	YouTube	1499	Flexible Expenses	Entertainment	2026-01-30	N/A	Debit card	\N	\N	t	2026-01-19 18:33:06.698707	EUR	\N	\N	2026-01-23 12:08:31.189458	2026-01-23 12:08:31.190562
1	1	\N	\N	Pre-existing Credit Card Debt	141058	Debt	Credit Card	2025-11-19	N/A	Credit card	Existing credit card balance at budget period start	\N	f	2025-12-04 16:06:13.914645	EUR	\N	\N	\N	2025-12-04 16:06:13.914645
3	1	2	2	Elisa	3535	Debt Payments	Elisa (Phone)	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.001089	EUR	\N	\N	\N	2025-12-04 16:06:14.001089
4	1	2	3	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.009865	EUR	\N	\N	\N	2025-12-04 16:06:14.009865
5	1	2	4	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.018561	EUR	\N	\N	\N	2025-12-04 16:06:14.018561
6	1	2	5	Klarna Turkish Airlines Old	10080	Debt Payments	Klarna Turkish Airlines Old	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.030294	EUR	\N	\N	\N	2025-12-04 16:06:14.030294
7	1	2	\N	Rent	94718	Fixed Expenses	Rent	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.039037	EUR	\N	\N	\N	2025-12-04 16:06:14.039037
8	1	2	\N	DNA	3490	Fixed Expenses	Subscriptions	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.047386	EUR	\N	\N	\N	2025-12-04 16:06:14.047386
11	1	1	\N	Wise Europe SA	4233	Flexible Expenses	Shopping	2025-11-22	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.102966	EUR	\N	\N	\N	2025-12-04 16:06:14.102966
12	1	1	\N	Wise	3888	Flexible Expenses	Shopping	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.116186	EUR	\N	\N	\N	2025-12-04 16:06:14.116186
13	1	1	\N	UBER   *TRIP	18	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.125584	EUR	\N	\N	\N	2025-12-04 16:06:14.125584
14	1	1	\N	Nordea Responsible Global	5000	Flexible Expenses	Shopping	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.134744	EUR	\N	\N	\N	2025-12-04 16:06:14.134744
15	1	1	\N	UBER   *TRIP	37	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.143014	EUR	\N	\N	\N	2025-12-04 16:06:14.143014
16	1	1	\N	UBR* PENDING.UBER.COM	366	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.191232	EUR	\N	\N	\N	2025-12-04 16:06:14.191232
17	1	1	\N	UBR* PENDING.UBER.COM	277	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.2	EUR	\N	\N	\N	2025-12-04 16:06:14.2
18	1	1	\N	UBER   *TRIP	243	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.209241	EUR	\N	\N	\N	2025-12-04 16:06:14.209241
19	1	1	\N	UBER   *TRIP	73	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.217657	EUR	\N	\N	\N	2025-12-04 16:06:14.217657
20	1	1	\N	UBR* PENDING.UBER.COM	118	Flexible Expenses	Transportation	2025-11-24	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.225929	EUR	\N	\N	\N	2025-12-04 16:06:14.225929
21	1	2	\N	PAYPAL *DISNEYPLUS	1099	Fixed Expenses	Subscriptions	2025-11-28	N/A	Debit card	Imported from bank on 2025-11-28	\N	f	2025-12-04 16:06:14.234435	EUR	\N	\N	\N	2025-12-04 16:06:14.234435
22	1	2	\N	Retail NLD Amsterdam UBER *TRIP HELP.UBER.C	2059	Flexible Expenses	Transportation	2025-11-27	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.287782	EUR	\N	\N	\N	2025-12-04 16:06:14.287782
23	1	1	\N	Retail FIN Finland Wolt Oy	2614	Flexible Expenses	Food	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.297088	EUR	\N	\N	\N	2025-12-04 16:06:14.297088
24	1	1	\N	Retail FIN HELSINKI VFI*Armina Oy ITIS	6767	Flexible Expenses	Shopping	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.30562	EUR	\N	\N	\N	2025-12-04 16:06:14.30562
25	1	1	\N	Retail NLD HELP.UBER.COM UBER *TRIP	1969	Flexible Expenses	Transportation	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.313831	EUR	\N	\N	\N	2025-12-04 16:06:14.313831
26	1	1	\N	Retail NLD Amsterdam UBER *TRIP HELP.UBER.C	1939	Flexible Expenses	Transportation	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.322517	EUR	\N	\N	\N	2025-12-04 16:06:14.322517
27	1	1	\N	Retail FIN Helsinki BIBI Bistro	1619	Flexible Expenses	Shopping	2025-11-26	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.33067	EUR	\N	\N	\N	2025-12-04 16:06:14.33067
28	1	1	\N	Retail NLD Amsterdam UBER *TRIP HELP.UBER.C	1854	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.33925	EUR	\N	\N	\N	2025-12-04 16:06:14.33925
29	1	1	\N	Retail FIN Finland Wolt Oy	543	Flexible Expenses	Food	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.347687	EUR	\N	\N	\N	2025-12-04 16:06:14.347687
30	1	1	\N	Retail FIN Espoo KFC Iso Omena	1175	Flexible Expenses	Shopping	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.393561	EUR	\N	\N	\N	2025-12-04 16:06:14.393561
31	1	1	\N	Retail NLD HELP.UBER.COM UBER *TRIP	1697	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.401544	EUR	\N	\N	\N	2025-12-04 16:06:14.401544
32	1	1	\N	TRY 1182.18 Retail TUR ISTANBUL F17 OBICA MOZ	2487	Flexible Expenses	Shopping	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.409402	EUR	\N	\N	\N	2025-12-04 16:06:14.409402
33	1	1	\N	TRY 40.00 Retail NLD HELP.UBER.COM UBER *	84	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.417416	EUR	\N	\N	\N	2025-12-04 16:06:14.417416
34	1	1	\N	TRY 655.00 Retail NLD HELP.UBER.COM UBER *	1378	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.425739	EUR	\N	\N	\N	2025-12-04 16:06:14.425739
35	1	1	\N	TRY 1221.00 Retail TUR ISTANBUL TAKSI YONETIM	2577	Flexible Expenses	Shopping	2025-11-24	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.433975	EUR	\N	\N	\N	2025-12-04 16:06:14.433975
36	1	1	\N	Retail TUR ISTANBUL GNC AIRPORT HOTEL	100	Flexible Expenses	Shopping	2025-11-24	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.442823	EUR	\N	\N	\N	2025-12-04 16:06:14.442823
37	1	1	\N	Retail TUR ISTANBUL GNC AIRPORT HOTEL	3000	Flexible Expenses	Shopping	2025-11-24	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.493253	EUR	\N	\N	\N	2025-12-04 16:06:14.493253
38	1	1	\N	TRY 1650.00 Retail TUR ISTANBUL GNC AIRPORT H	3483	Flexible Expenses	Shopping	2025-11-24	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.502175	EUR	\N	\N	\N	2025-12-04 16:06:14.502175
39	1	1	\N	USD 67.95 Retail TUR ANKARA E-VISA TURKEY	6048	Flexible Expenses	Shopping	2025-11-23	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.510495	EUR	\N	\N	\N	2025-12-04 16:06:14.510495
40	1	1	\N	BDT 560.00 Retail BGD Shantinagar T FRESH &	405	Flexible Expenses	Shopping	2025-11-21	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.518961	EUR	\N	\N	\N	2025-12-04 16:06:14.518961
41	1	1	\N	BDT 400.00 Retail BGD Shantinagar T HAKKA EX	290	Flexible Expenses	Shopping	2025-11-21	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.527468	EUR	\N	\N	\N	2025-12-04 16:06:14.527468
42	1	1	\N	BDT 1680.00 Retail BGD Gulshan Model KIVAHAN	1223	Flexible Expenses	Shopping	2025-11-20	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.535601	EUR	\N	\N	\N	2025-12-04 16:06:14.535601
43	1	1	\N	BDT 470.00 Retail BGD Gulshan Model ALFRESCO	343	Flexible Expenses	Shopping	2025-11-20	N/A	Credit card	Imported from bank on 2025-11-28	\N	t	2025-12-04 16:06:14.587727	EUR	\N	\N	\N	2025-12-04 16:06:14.587727
44	1	1	\N	Payment to Klarna Turkish Airlines Old	4112	Debt Payments	Klarna Turkish Airlines Old	2025-11-26	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.597124	EUR	\N	\N	\N	2025-12-04 16:06:14.597124
45	1	2	11	Insinööriliitto	3525	Fixed Expenses	Insurance	2025-11-28	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.605679	EUR	\N	\N	\N	2025-12-04 16:06:14.605679
46	1	2	\N	Mee6	4203	Flexible Expenses	Entertainment	2025-11-29	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.614016	EUR	\N	\N	\N	2025-12-04 16:06:14.614016
47	1	2	\N	ImageGPT	2241	Flexible Expenses	Entertainment	2025-11-29	N/A	Debit card	\N	\N	f	2025-12-04 16:06:14.622792	EUR	\N	\N	\N	2025-12-04 16:06:14.622792
48	1	2	\N	Namecheap	637	Flexible Expenses	Entertainment	2025-11-29	N/A	Credit card	\N	\N	f	2025-12-04 16:06:14.631742	EUR	\N	\N	\N	2025-12-04 16:06:14.631742
10	1	1	\N	Credit card repayment	99104	Debt Payments	Credit Card	2025-11-20	N/A	Debit card	\N	\N	t	2025-12-04 16:06:14.094241	EUR	\N	\N	\N	2025-12-04 16:06:14.094241
55	1	3	\N	Wolt	6212	Flexible Expenses	Food	2025-12-04	N/A	Debit card	\N	\N	f	2025-12-04 16:07:50.508079	EUR	\N	\N	\N	2025-12-04 16:07:50.508079
56	1	3	\N	Wolt	3294	Flexible Expenses	Food	2025-12-04	N/A	Debit card	\N	\N	f	2025-12-04 16:09:32.892452	EUR	\N	\N	\N	2025-12-04 16:09:32.892452
57	1	3	\N	Wolt	1027	Flexible Expenses	Food	2025-12-05	N/A	Debit card	\N	\N	f	2025-12-05 11:18:41.340793	EUR	\N	\N	\N	2025-12-05 11:18:41.340793
58	1	3	\N	Wolt	2424	Flexible Expenses	Food	2025-12-05	N/A	Debit card	\N	\N	f	2025-12-05 11:18:55.891369	EUR	\N	\N	\N	2025-12-05 11:18:55.891369
59	1	3	\N	Wolt	3271	Flexible Expenses	Food	2025-12-06	N/A	Credit card	\N	\N	f	2025-12-06 10:25:51.052266	EUR	\N	\N	\N	2025-12-06 10:25:51.052266
60	1	3	\N	Wolt	2101	Flexible Expenses	Food	2025-12-05	N/A	Debit card	\N	\N	f	2025-12-06 14:11:36.395363	EUR	\N	\N	\N	2025-12-06 14:11:36.395363
61	1	\N	\N	Uber	1304	Flexible Expenses	Transportation	2025-12-07	N/A	Debit card	\N	\N	f	2025-12-07 17:29:07.343085	EUR	\N	\N	\N	2025-12-07 17:29:07.343085
62	1	\N	\N	Uber	1251	Flexible Expenses	Transportation	2025-12-07	N/A	Debit card	\N	\N	f	2025-12-07 17:29:33.885755	EUR	\N	\N	\N	2025-12-07 17:29:33.885755
63	1	\N	\N	Wolt	2840	Flexible Expenses	Food	2025-12-07	N/A	Debit card	\N	\N	f	2025-12-07 17:29:44.937947	EUR	\N	\N	\N	2025-12-07 17:29:44.937947
64	1	\N	\N	Nordea	465	Fixed Expenses	Subscriptions	2025-12-10	N/A	Debit card	\N	\N	f	2025-12-10 08:14:21.791929	EUR	\N	\N	\N	2025-12-10 08:14:21.791929
65	1	\N	\N	Wolt	1351	Flexible Expenses	Food	2025-12-10	N/A	Debit card	\N	\N	f	2025-12-10 10:55:44.808684	EUR	\N	\N	\N	2025-12-10 10:55:44.808684
66	1	\N	\N	Wolt	3054	Flexible Expenses	Food	2025-12-10	N/A	Debit card	\N	\N	f	2025-12-10 10:55:55.959342	EUR	\N	\N	\N	2025-12-10 10:55:55.959342
67	1	\N	\N	Uber	912	Flexible Expenses	Transportation	2025-12-11	N/A	Debit card	\N	\N	f	2025-12-11 10:47:24.381581	EUR	\N	\N	\N	2025-12-11 10:47:24.381581
68	1	\N	\N	Sodexo Nokia	860	Flexible Expenses	Food	2025-12-11	N/A	Debit card	\N	\N	f	2025-12-11 10:47:48.478915	EUR	\N	\N	\N	2025-12-11 10:47:48.478915
69	1	\N	\N	Settlement Survivors	692	Flexible Expenses	Entertainment	2025-12-11	N/A	Credit card	\N	\N	f	2025-12-11 10:48:29.418718	EUR	\N	\N	\N	2025-12-11 10:48:29.418718
70	1	\N	\N	Nordea Credit	99	Fixed Expenses	Subscriptions	2025-12-11	N/A	Credit card	\N	\N	f	2025-12-11 10:48:52.431043	EUR	\N	\N	\N	2025-12-11 10:48:52.431043
71	1	\N	\N	HSL	320	Flexible Expenses	Transportation	2025-12-11	N/A	Debit card	\N	\N	f	2025-12-11 21:22:50.721342	EUR	\N	\N	\N	2025-12-11 21:22:50.721342
72	1	\N	\N	Uber	1378	Flexible Expenses	Transportation	2025-11-25	N/A	Credit card	\N	\N	f	2025-12-11 21:24:18.577382	EUR	\N	\N	\N	2025-12-11 21:24:18.577382
73	1	\N	\N	Wolt	1626	Flexible Expenses	Food	2025-12-12	N/A	Debit card	\N	\N	f	2025-12-12 12:39:14.744577	EUR	\N	\N	\N	2025-12-12 12:39:14.744577
85	1	\N	\N	Wolt	1999	Flexible Expenses	Food	2025-12-12	N/A	Credit card	\N	\N	f	2025-12-12 23:57:15.117517	EUR	\N	\N	\N	2025-12-12 23:57:15.117517
86	1	\N	\N	Wolt	5129	Flexible Expenses	Food	2025-12-12	N/A	Credit card	\N	\N	f	2025-12-12 23:57:24.640442	EUR	\N	\N	\N	2025-12-12 23:57:24.640442
87	1	\N	\N	Verkkokauppa (OnePlus Buds Pro 4)	8590	Flexible Expenses	Shopping	2025-12-12	N/A	Debit card	\N	\N	f	2025-12-12 23:58:13.154874	EUR	\N	\N	\N	2025-12-12 23:58:13.154874
88	1	\N	\N	Adjusting credit	10	Fixed Expenses	Utilities	2025-12-12	N/A	Credit card	\N	\N	f	2025-12-12 23:58:48.067889	EUR	\N	\N	\N	2025-12-12 23:58:48.067889
78	1	\N	5	Klarna Turkish Airlines Old	10080	Debt Payments	Klarna Turkish Airlines Old	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.26532	EUR	\N	\N	\N	2025-12-12 12:42:47.26532
74	1	\N	1	Telia	4546	Debt Payments	Telia Rahoitus	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.226641	EUR	\N	\N	\N	2025-12-12 12:42:47.226641
75	1	\N	2	Elisa	3535	Debt Payments	Elisa (Phone)	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.237049	EUR	\N	\N	\N	2025-12-12 12:42:47.237049
76	1	\N	3	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.246338	EUR	\N	\N	\N	2025-12-12 12:42:47.246338
77	1	\N	4	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.255959	EUR	\N	\N	\N	2025-12-12 12:42:47.255959
82	1	\N	10	DNA	3490	Fixed Expenses	Subscriptions	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.33003	EUR	\N	\N	\N	2025-12-12 12:42:47.33003
80	1	\N	8	Rent	94718	Fixed Expenses	Rent	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.284605	EUR	\N	\N	\N	2025-12-12 12:42:47.284605
100	1	\N	\N	Caruna	4583	Fixed Expenses	Utilities	2025-12-19	N/A	Debit card	\N	\N	f	2025-12-13 00:01:33.115932	EUR	\N	\N	\N	2025-12-13 00:01:33.115932
114	1	\N	\N	Canva Subscription	600	Flexible Expenses	Shopping	2025-12-15	N/A	Debit card	\N	\N	f	2025-12-15 15:40:41.915651	EUR	\N	\N	\N	2025-12-15 15:40:41.915651
113	1	\N	15	Telia Dot	810	Fixed Expenses	Subscriptions	2025-12-15	N/A	Debit card	\N	\N	f	2025-12-15 15:08:07.937896	EUR	\N	\N	\N	2025-12-15 15:08:07.937896
115	1	\N	\N	Prime Video	699	Flexible Expenses	Entertainment	2025-12-15	N/A	Debit card	\N	\N	f	2025-12-15 15:41:37.334051	EUR	\N	\N	\N	2025-12-15 15:41:37.334051
118	1	\N	16	Discord	999	Fixed Expenses	Subscriptions	2025-12-16	N/A	Credit card	\N	\N	f	2025-12-16 14:24:00.304481	EUR	\N	\N	\N	2025-12-16 14:24:00.304481
121	1	\N	\N	Wolt	1711	Flexible Expenses	Food	2025-12-16	N/A	Debit card	\N	\N	f	2025-12-16 14:26:21.878437	EUR	\N	\N	\N	2025-12-16 14:26:21.878437
122	1	\N	\N	Wolt	2672	Flexible Expenses	Food	2025-12-16	N/A	Debit card	\N	\N	f	2025-12-16 14:26:27.815188	EUR	\N	\N	\N	2025-12-16 14:26:27.815188
128	1	\N	\N	Temu	6045	Flexible Expenses	Shopping	2025-12-17	N/A	Debit card	\N	\N	f	2025-12-17 09:38:16.68101	EUR	\N	\N	\N	2025-12-17 09:38:16.68101
130	1	\N	\N	Wolt	1487	Flexible Expenses	Food	2025-12-17	N/A	Credit card	\N	\N	f	2025-12-17 16:07:58.844461	EUR	\N	\N	\N	2025-12-17 16:07:58.844461
131	1	\N	\N	Wolt	2270	Flexible Expenses	Food	2025-12-17	N/A	Credit card	\N	\N	f	2025-12-17 16:08:11.427218	EUR	\N	\N	\N	2025-12-17 16:08:11.427218
132	1	\N	\N	Wolt	2365	Flexible Expenses	Food	2025-12-18	N/A	Debit card	\N	\N	f	2025-12-18 22:23:55.164613	EUR	\N	\N	\N	2025-12-18 22:23:55.164613
133	1	\N	\N	Netflix	949	Flexible Expenses	Entertainment	2025-12-18	N/A	Credit card	\N	\N	f	2025-12-18 22:24:50.576909	EUR	\N	\N	\N	2025-12-18 22:24:50.576909
134	1	\N	\N	Temu	4215	Flexible Expenses	Shopping	2025-12-19	N/A	Debit card	\N	\N	f	2025-12-19 07:53:36.408135	EUR	\N	\N	\N	2025-12-19 07:53:36.408135
81	1	\N	9	Fortum	1788	Fixed Expenses	Utilities	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-12 12:42:47.293648	EUR	\N	\N	\N	2025-12-12 12:42:47.293648
135	1	\N	\N	Savings	5000	Savings & Investments	Emergency Fund	2025-12-19	N/A	Debit card	\N	\N	f	2025-12-20 16:55:12.277545	EUR	\N	\N	\N	2025-12-20 16:55:12.277545
137	1	\N	\N	Klarna Turkish Airlines Business Payment	10479	Debt Payments	Klarna Turkish Airlines Business	2025-12-19	N/A	Debit card	\N	\N	f	2025-12-21 13:24:38.400549	EUR	\N	\N	\N	2025-12-21 13:24:38.400549
138	1	\N	\N	Wolt	2796	Flexible Expenses	Food	2025-12-21	N/A	Debit card	\N	\N	f	2025-12-21 13:25:10.284668	EUR	\N	\N	\N	2025-12-21 13:25:10.284668
140	1	\N	\N	Wolt	4549	Flexible Expenses	Food	2025-12-21	N/A	Debit card	\N	\N	f	2025-12-21 15:45:20.225022	EUR	\N	\N	\N	2025-12-21 15:45:20.225022
127	1	\N	\N	Zooplus	4946	Flexible Expenses	Cat Stuff	2025-12-17	N/A	Debit card	\N	\N	f	2025-12-16 23:57:32.64	EUR	\N	\N	\N	2025-12-16 23:57:32.64
125	1	\N	\N	Credit repayment	80000	Debt Payments	Credit Card	2025-12-19	N/A	Debit card	\N	\N	t	2025-12-16 23:56:34.555753	EUR	\N	\N	\N	2025-12-16 23:56:34.555753
141	1	\N	12	YouTube	1499	Flexible Expenses	Entertainment	2025-12-30	N/A	Debit card	\N	\N	t	2025-12-22 23:54:35.07162	EUR	\N	\N	\N	2025-12-22 23:54:35.07162
142	1	\N	16	Discord	999	Fixed Expenses	Subscriptions	2026-01-16	N/A	Credit card	\N	\N	t	2025-12-23 00:25:02.137551	EUR	\N	\N	\N	2025-12-23 00:25:02.137551
149	1	\N	18	Investment (Nordea) Contribution	5000	Savings & Investments	Investment (Nordea)	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-23 00:25:02.249619	EUR	\N	\N	\N	2025-12-23 00:25:02.249619
152	1	\N	11	Insinööriliitto	3525	Fixed Expenses	Insurance	2026-01-15	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.314166	EUR	\N	\N	\N	2025-12-23 00:25:02.314166
154	3	\N	\N	Emergency	55000	Savings & Investments	Emergency Fund	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-23 16:46:44.230719	EUR	\N	\N	\N	2025-12-23 16:46:44.230719
155	3	\N	\N	Wolt	2400	Fixed Expenses	Insurance	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-23 16:48:17.557856	EUR	\N	\N	\N	2025-12-23 16:48:17.557856
156	1	\N	\N	Proton vpn	999	Flexible Expenses	Entertainment	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-23 18:44:26.114863	EUR	\N	\N	\N	2025-12-23 18:44:26.114863
157	1	\N	\N	Wolt	3311	Flexible Expenses	Food	2025-12-23	N/A	Debit card	\N	\N	f	2025-12-24 01:18:34.460833	EUR	\N	\N	\N	2025-12-24 01:18:34.460833
158	1	\N	\N	Wolt	1520	Flexible Expenses	Food	2025-12-23	N/A	Credit card	\N	\N	f	2025-12-24 01:19:10.006105	EUR	\N	\N	\N	2025-12-24 01:19:10.006105
159	1	\N	\N	Wolt	1478	Flexible Expenses	Food	2025-12-24	N/A	Credit card	\N	\N	f	2025-12-24 22:52:06.079252	EUR	\N	\N	\N	2025-12-24 22:52:06.079252
163	1	\N	\N	Wolt	3131	Flexible Expenses	Food	2025-12-26	N/A	Credit card	\N	\N	f	2025-12-26 00:53:58.440674	EUR	\N	\N	\N	2025-12-26 00:53:58.440674
144	1	\N	10	DNA	3490	Fixed Expenses	Subscriptions	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.219266	EUR	\N	\N	\N	2026-01-19 18:34:23.493855
146	1	\N	3	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.231736	EUR	\N	\N	\N	2026-01-19 18:34:24.474393
145	1	\N	1	Telia	4546	Debt Payments	Telia Rahoitus	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.225717	EUR	\N	\N	\N	2026-01-19 18:34:26.771282
147	1	\N	8	Rent	94718	Fixed Expenses	Rent	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.237762	EUR	\N	\N	\N	2026-01-19 18:34:27.683826
160	1	\N	18	Investment (Nordea) Contribution	5000	Savings & Investments	Investment (Nordea)	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-25 20:33:33.013964	EUR	\N	\N	\N	2026-01-19 18:34:30.017943
151	1	\N	4	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.261507	EUR	\N	\N	\N	2026-01-19 18:34:31.093199
143	1	\N	9	Fortum	2725	Fixed Expenses	Utilities	2026-01-20	N/A	Debit card	\N	\N	t	2025-12-23 00:25:02.212115	EUR	\N	\N	\N	2026-01-22 05:19:01.090463
164	1	\N	\N	Wolt	2371	Flexible Expenses	Food	2025-12-26	N/A	Credit card	\N	\N	f	2025-12-26 00:54:07.718831	EUR	\N	\N	\N	2025-12-26 00:54:07.718831
162	1	\N	21	GH Copilot	2660	Fixed Expenses	Subscriptions	2025-12-25	N/A	Debit card	\N	\N	t	2025-12-25 22:52:49.855037	EUR	\N	\N	\N	2025-12-25 22:52:49.855037
169	1	\N	\N	Shakerapu Uber TO BE REFUNDED LATER	2717	Flexible Expenses	Transportation	2025-12-26	N/A	Debit card	\N	\N	f	2025-12-27 20:21:39.263007	EUR	\N	\N	\N	2025-12-27 20:21:39.263007
167	1	\N	\N	Pharmace	2087	Flexible Expenses	Health	2025-12-26	N/A	Credit card	\N	\N	f	2025-12-26 15:46:23.778589	EUR	\N	\N	\N	2025-12-26 15:46:23.778589
168	1	\N	\N	Ikea	4736	Flexible Expenses	Shopping	2025-12-26	N/A	Credit card	\N	\N	f	2025-12-26 16:08:29.451183	EUR	\N	\N	\N	2025-12-26 16:08:29.451183
170	1	\N	\N	Wolt	1351	Flexible Expenses	Food	2025-12-27	N/A	Credit card	\N	\N	f	2025-12-27 20:22:55.7972	EUR	\N	\N	\N	2025-12-27 20:22:55.7972
171	1	\N	\N	Wolt	2376	Flexible Expenses	Food	2025-12-27	N/A	Credit card	\N	\N	f	2025-12-27 20:23:17.984519	EUR	\N	\N	\N	2025-12-27 20:23:17.984519
172	1	\N	\N	Wolt	2696	Flexible Expenses	Food	2025-12-29	N/A	Credit card	\N	\N	f	2025-12-29 17:55:28.790884	EUR	\N	\N	\N	2025-12-29 17:55:28.790884
173	1	\N	\N	Wolt	2326	Flexible Expenses	Food	2025-12-29	N/A	Credit card	\N	\N	f	2025-12-29 17:55:41.000062	EUR	\N	\N	\N	2025-12-29 17:55:41.000062
194	1	\N	\N	Wolt	1998	Flexible Expenses	Food	2026-01-11	N/A	Credit card	\N	\N	f	2026-01-12 16:07:28.389005	EUR	\N	\N	\N	2026-01-12 16:07:28.389009
214	1	\N	\N	Groceries	2472	Flexible Expenses	Food	2026-01-19	N/A	Credit card	\N	\N	f	2026-01-19 17:58:09.211965	EUR	\N	\N	\N	2026-01-19 17:58:09.211969
\.


--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.goals (id, user_id, name, description, target_amount, target_date, subcategory_name, is_active, created_at, updated_at, initial_amount, deleted_at) FROM stdin;
4	3	Emergency Fund	For an emergency fund nigga	700000	\N	Emergency Fund	t	2025-12-23 16:44:06.685006	2025-12-23 16:44:06.68501	0	\N
3	1	Emergency Fund	\N	200000	\N	Emergency Fund	t	2025-12-23 00:02:04.667374	2025-12-25 14:46:43.906066	34754	\N
2	1	Investment (Nordea)	\N	100000	2026-12-31	Investment (Nordea)	t	2025-12-22 23:43:36.744481	2025-12-25 14:47:10.676058	5036	\N
\.


--
-- Data for Name: income; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.income (id, user_id, budget_period_id, type, amount, scheduled_date, actual_date, created_at, currency, original_amount, exchange_rate_used, deleted_at, updated_at, recurring_income_id) FROM stdin;
1	1	\N	Initial Balance	307200	2025-11-20	2025-11-20	2025-12-04 16:06:13.923676	EUR	\N	\N	\N	2025-12-04 16:06:13.923676	\N
2	1	2	Other	30350	2025-11-27	2025-11-27	2025-12-04 16:06:14.746151	EUR	\N	\N	\N	2025-12-04 16:06:14.746151	\N
3	1	\N	Salary	281545	2025-12-19	2025-12-19	2025-12-16 22:12:14.124386	EUR	\N	\N	\N	2025-12-16 22:12:14.124386	\N
5	3	\N	Initial Balance	200000	2025-12-23	2025-12-23	2025-12-23 16:45:25.789574	EUR	\N	\N	\N	2025-12-23 16:45:25.789574	\N
6	1	\N	Other	1700	2025-12-26	2025-12-26	2025-12-26 00:55:18.222986	EUR	\N	\N	\N	2025-12-26 00:55:18.222986	\N
7	1	\N	Other	33	2026-01-01	2026-01-01	2026-01-01 12:41:14.635775	EUR	\N	\N	\N	\N	\N
8	1	\N	Salary	281746	2026-01-20	2026-01-20	2026-01-15 23:49:52.274194	EUR	\N	\N	2026-01-19 16:38:51.053636	2026-01-19 16:38:51.055585	\N
9	1	\N	Salary	281746	2026-01-20	2026-01-20	2026-01-19 16:39:11.861294	EUR	\N	\N	2026-01-19 18:28:58.994363	2026-01-19 18:28:59.085335	1
10	1	\N	Salary	281746	2026-01-20	2026-01-20	2026-01-19 18:45:10.719005	EUR	\N	\N	\N	2026-01-19 18:45:10.719011	2
11	1	\N	Salary	281746	2026-02-20	2026-02-20	2026-01-27 09:42:55.210002	EUR	\N	\N	\N	2026-01-27 09:42:55.210007	2
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.password_reset_tokens (id, user_id, token, expires_at, is_used, created_at) FROM stdin;
\.


--
-- Data for Name: period_suggestions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.period_suggestions (id, user_id, budget_period_id, suggestion_type, amount, status, created_at) FROM stdin;
\.


--
-- Data for Name: rate_limits; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.rate_limits (id, key, "timestamp") FROM stdin;
1	127.0.0.1:auth.login	2026-01-02 13:32:06.521104
2	127.0.0.1:auth.login	2026-01-02 20:54:51.450792
3	127.0.0.1:auth.login	2026-01-03 12:53:04.83934
4	127.0.0.1:auth.login	2026-01-04 22:32:42.144205
5	127.0.0.1:auth.login	2026-01-05 12:32:46.10047
6	127.0.0.1:auth.login	2026-01-05 14:54:25.541707
7	127.0.0.1:auth.login	2026-01-06 18:12:52.600699
8	127.0.0.1:auth.login	2026-01-08 10:02:57.268147
9	127.0.0.1:auth.login	2026-01-10 00:21:43.369752
10	127.0.0.1:auth.login	2026-01-12 16:04:16.951563
11	127.0.0.1:auth.login	2026-01-13 00:26:23.566556
12	127.0.0.1:auth.login	2026-01-13 18:41:54.630062
13	127.0.0.1:auth.login	2026-01-13 18:42:03.575116
14	127.0.0.1:auth.login	2026-01-13 18:42:15.613276
15	127.0.0.1:auth.login	2026-01-13 18:42:25.250544
16	127.0.0.1:auth.login	2026-01-13 18:42:38.195113
17	127.0.0.1:auth.login	2026-01-15 23:45:20.471575
18	127.0.0.1:auth.login	2026-01-15 23:45:24.274068
19	127.0.0.1:auth.login	2026-01-16 09:06:30.568283
20	127.0.0.1:auth.login	2026-01-16 10:06:42.02259
21	127.0.0.1:auth.login	2026-01-16 11:40:13.712075
22	127.0.0.1:auth.login	2026-01-18 21:24:09.065068
23	127.0.0.1:auth.login	2026-01-19 16:38:00.417925
24	127.0.0.1:auth.login	2026-01-19 17:46:35.280538
25	127.0.0.1:auth.login	2026-01-19 18:56:12.750494
26	127.0.0.1:auth.login	2026-01-21 15:16:45.091887
27	127.0.0.1:auth.login	2026-01-22 05:16:40.241617
28	127.0.0.1:auth.login	2026-01-22 12:43:13.42789
29	127.0.0.1:auth.login	2026-01-22 13:20:27.523231
30	127.0.0.1:auth.login	2026-01-23 11:40:21.866482
31	127.0.0.1:auth.login	2026-01-23 16:33:48.568629
32	127.0.0.1:auth.login	2026-01-26 12:30:50.190803
33	127.0.0.1:auth.login	2026-01-26 14:45:16.884709
34	127.0.0.1:auth.login	2026-01-26 21:53:26.847495
35	127.0.0.1:auth.login	2026-01-27 09:41:55.3738
36	127.0.0.1:auth.login	2026-01-27 15:20:37.050101
\.


--
-- Data for Name: recurring_expenses; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.recurring_expenses (id, user_id, name, amount, category, subcategory, payment_method, frequency, frequency_value, day_of_month, day_of_week, start_date, end_date, next_due_date, is_active, is_fixed_bill, notes, created_at, updated_at, deleted_at) FROM stdin;
25	1	Credit card repayment	50000	Debt Payments	Credit Card	Debit card	monthly	\N	20	\N	2026-01-20	2026-01-20	2026-02-20	f	t	\N	2026-01-18 21:33:44.330619	2026-01-18 21:36:52.887576	2026-01-18 21:36:52.886845
8	1	Rent	94718	Fixed Expenses	Rent	Debit card	monthly	\N	20	\N	2025-12-20	\N	2026-03-20	t	t	\N	2025-12-04 16:06:13.820155	2026-01-23 11:44:25.763813	\N
12	1	YouTube	1499	Flexible Expenses	Entertainment	Debit card	monthly	\N	30	\N	2025-11-30	\N	2026-02-28	t	t	\N	2025-12-04 16:06:13.887384	2026-01-19 18:33:06.741192	\N
15	1	Telia Dot	810	Fixed Expenses	Subscriptions	Debit card	monthly	\N	15	\N	2026-01-15	\N	2026-03-15	t	t	\N	2025-12-15 15:08:07.74988	2026-01-19 18:33:06.746738	\N
4	1	Klarna Turkish Airlines New	10291	Debt Payments	Klarna Turkish Airlines New	Debit card	monthly	\N	20	\N	2025-11-20	\N	2026-03-20	t	t	\N	2025-12-04 16:06:13.797164	2026-01-23 11:44:25.772899	\N
11	1	Insinööriliitto	3525	Fixed Expenses	Insurance	Debit card	monthly	\N	15	\N	2026-01-15	\N	2026-03-15	t	t	\N	2025-12-04 16:06:13.836541	2026-01-19 18:33:06.750861	\N
16	1	Discord	999	Fixed Expenses	Subscriptions	Credit card	monthly	\N	16	\N	2026-01-16	\N	2026-03-16	t	t	\N	2025-12-16 14:23:59.9971	2026-01-19 18:33:06.755066	\N
5	1	Klarna Turkish Airlines Old	10080	Debt Payments	Klarna Turkish Airlines Old	Debit card	monthly	\N	20	\N	2025-11-24	\N	2026-03-20	t	t	\N	2025-12-04 16:06:13.802794	2026-01-23 11:44:25.781716	\N
28	1	Klarna Turkish Airlines Business Payment	10479	Debt Payments	Klarna Turkish Airlines Business	Debit card	monthly	\N	20	\N	2026-01-20	\N	2026-03-20	t	t	\N	2026-01-19 17:54:26.972551	2026-01-23 11:44:25.806184	\N
3	1	Klarna Gigantti	5323	Debt Payments	Klarna Gigantti	Debit card	monthly	\N	20	\N	2025-11-20	\N	2026-03-20	t	t	\N	2025-12-04 16:06:13.790754	2026-01-23 11:44:25.848845	\N
19	3	Emergency Fund Contribution	1500	Savings & Investments	Emergency Fund	Credit card	monthly	\N	1	\N	2025-12-23	\N	2025-12-23	t	f	\N	2025-12-23 16:44:37.639115	2025-12-23 16:44:37.639117	\N
2	1	Elisa	3535	Debt Payments	Elisa (Phone)	Debit card	monthly	\N	20	\N	2025-11-20	\N	2026-03-20	t	t	\N	2025-12-04 16:06:13.744124	2026-01-23 11:44:25.87389	\N
23	1	Agria Eläinvakuutus	9456	Fixed Expenses	Insurance	Debit card	custom	90	\N	\N	2026-01-20	\N	2026-04-20	t	t	\N	2026-01-02 14:45:24.04644	2026-01-19 18:33:06.760137	\N
18	1	Investment (Nordea) Contribution	5000	Savings & Investments	Investment (Nordea)	Debit card	monthly	\N	20	\N	2025-12-23	\N	2026-03-20	t	t	\N	2025-12-23 00:23:52.47975	2026-01-23 11:44:25.883908	\N
30	1	Credit repayment	50000	Debt Payments	Credit Card	Debit card	monthly	\N	20	\N	2026-01-20	\N	2026-03-20	t	t	\N	2026-01-19 18:58:13.656133	2026-01-23 11:44:25.892317	\N
29	1	Emergency Fund Contribution	5000	Savings & Investments	Emergency Fund	Debit card	monthly	\N	19	\N	2026-01-19	\N	2026-03-19	t	t	\N	2026-01-19 17:56:09.97969	2026-01-23 11:44:25.901173	\N
9	1	Fortum	3000	Fixed Expenses	Utilities	Debit card	monthly	\N	20	\N	2025-12-20	\N	2026-03-20	t	t	\N	2025-12-04 16:06:13.825636	2026-01-23 11:44:25.918464	\N
1	1	Telia	4546	Debt Payments	Telia Rahoitus	Debit card	monthly	\N	20	\N	2025-11-20	\N	2026-03-20	t	t	\N	2025-12-04 16:06:13.734805	2026-01-23 11:44:25.926875	\N
27	1	Credit payment	50000	Debt Payments	Credit Card	Debit card	monthly	\N	20	\N	2026-01-20	2026-01-20	2026-02-20	t	t	\N	2026-01-19 17:51:14.425002	2026-01-19 18:56:56.901751	2026-01-19 18:56:56.901141
26	1	Credit card repayment	50000	Debt Payments	Credit Card	Debit card	monthly	\N	20	\N	2026-01-20	2026-01-20	2026-02-20	t	t	\N	2026-01-18 21:36:23.770415	2026-01-19 17:51:34.171301	2026-01-19 17:47:30.090384
31	1	HBO Max	699	Flexible Expenses	Entertainment	Debit card	monthly	\N	22	\N	2026-01-22	\N	2026-03-22	t	f	\N	2026-01-23 11:44:03.064152	2026-01-23 11:46:15.184415	2026-01-23 11:45:40.380084
32	1	HBO Max	699	Flexible Expenses	Entertainment	Debit card	monthly	\N	22	\N	2026-01-22	\N	2026-03-22	t	f	\N	2026-01-23 11:46:04.732892	2026-01-23 11:46:15.193734	\N
21	1	GH Copilot	3000	Fixed Expenses	Subscriptions	Debit card	monthly	\N	26	\N	2025-12-25	\N	2026-03-26	t	t	\N	2025-12-25 22:52:44.319215	2026-01-27 09:42:55.156373	\N
33	1	Proton VPN	999	Fixed Expenses	Subscriptions	Debit card	monthly	\N	25	\N	2026-01-25	\N	2026-03-25	t	f	\N	2026-01-26 12:32:44.167597	2026-01-27 09:42:55.162286	\N
24	1	LähiTapiola Keskinäinen Vakuutus	5515	Fixed Expenses	Insurance	Debit card	custom	90	\N	\N	2026-01-20	\N	2026-04-20	t	t	\N	2026-01-12 16:10:26.347114	2026-01-19 18:33:06.592303	\N
10	1	DNA	3490	Fixed Expenses	Subscriptions	Debit card	monthly	\N	20	\N	2025-12-20	\N	2026-03-20	t	t	\N	2025-12-04 16:06:13.831015	2026-01-23 11:44:25.754385	\N
\.


--
-- Data for Name: recurring_income; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.recurring_income (id, user_id, name, amount, income_type, currency, frequency, frequency_value, day_of_month, day_of_week, start_date, end_date, next_due_date, is_active, notes, created_at, updated_at, deleted_at) FROM stdin;
1	1	Monthly Salary	281746	Salary	EUR	monthly	\N	20	\N	2026-01-20	\N	2026-01-20	t	\N	2026-01-19 16:39:06.184139	2026-01-19 18:44:34.413523	2026-01-19 18:44:34.4125
2	1	Monthly Salary	281746	Salary	EUR	monthly	\N	20	\N	2026-01-20	\N	2026-03-20	t	\N	2026-01-19 18:45:05.499847	2026-01-27 09:42:55.214615	\N
\.


--
-- Data for Name: salary_periods; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.salary_periods (id, user_id, initial_debit_balance, initial_credit_balance, credit_limit, credit_budget_allowance, salary_amount, total_budget_amount, fixed_bills_total, remaining_amount, weekly_budget, weekly_debit_budget, weekly_credit_budget, start_date, end_date, is_active, created_at, updated_at, num_sub_periods) FROM stdin;
3	3	200000	0	2000000	0	\N	200000	0	200000	50000	50000	0	2025-12-23	2026-01-22	t	2025-12-23 16:45:25.738348	2025-12-23 16:45:25.738348	4
2	1	289374	50178	150000	20000	\N	69558	239816	69558	17389	12389	5000	2025-12-20	2026-01-19	t	2025-12-17 10:14:43.940326	2025-12-17 10:14:43.940326	4
1	1	307200	8942	150000	0	\N	73462	233738	73462	18365	18365	0	2025-11-20	2025-12-19	t	2025-12-04 16:06:13.895815	2025-12-04 16:06:13.895815	4
5	1	55306	98848	150000	20000	\N	127061	229991	127061	12706	0	12706	2026-01-20	2026-02-19	t	2026-01-21 15:40:39.935612	2026-01-21 15:40:39.935617	10
\.


--
-- Data for Name: subcategories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.subcategories (id, user_id, category, name, is_system, is_active, created_at, updated_at) FROM stdin;
1	\N	Flexible Expenses	Food	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
2	\N	Savings & Investments	Other	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
3	\N	Fixed Expenses	Subscriptions	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
4	\N	Flexible Expenses	Shopping	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
5	\N	Fixed Expenses	Other	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
7	\N	Fixed Expenses	Rent	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
8	\N	Debt Payments	Other	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
9	\N	Flexible Expenses	Other	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
10	\N	Fixed Expenses	Insurance	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
13	\N	Debt Payments	Credit Card	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
14	\N	Flexible Expenses	Entertainment	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
15	\N	Fixed Expenses	Utilities	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
16	\N	Flexible Expenses	Transportation	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
17	\N	Flexible Expenses	Health	t	t	2025-12-22 23:31:58.214586	2025-12-22 23:31:58.214586
18	1	Flexible Expenses	Cat Stuff	f	t	2025-12-22 23:35:38.262498	2025-12-22 23:35:38.2625
20	1	Savings & Investments	Investment (Nordea)	f	t	2025-12-22 23:43:36.735751	2025-12-22 23:43:36.735753
21	1	Savings & Investments	Emergency Fund	f	t	2025-12-23 00:02:04.65833	2025-12-23 00:02:04.658332
22	3	Savings & Investments	Emergency Fund	f	t	2025-12-23 16:44:06.66174	2025-12-23 16:44:06.661744
23	3	Flexible Expenses	Bullshit spending	f	t	2025-12-23 16:50:54.530363	2025-12-23 16:51:33.969076
\.


--
-- Data for Name: user_defaults; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.user_defaults (id, user_id, default_expense_name, default_category, default_subcategory, default_payment_method) FROM stdin;
1	1	Wolt	Flexible Expenses	Food	credit
2	2	Wolt	Flexible Expenses	Food	credit
3	3	Wolt	Flexible Expenses	Food	credit
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, email, password_hash, created_at, failed_login_attempts, locked_until, recurring_lookahead_days, default_currency, balance_start_date, user_initial_debit_balance, user_initial_credit_limit, balance_mode, user_initial_credit_available, payment_date_adjustment) FROM stdin;
2	big-boss@bloom-tracker.app	scrypt:32768:8:1$rMuIqMrQKzV7RHjD$61d89186211c4125f5157f52013d9077d6d0c8711de2036fb01e48d9d8b367c63ee2d9d8ed92d9d149819526e0cc97c879237c3dac1d7ccc8ab535075e24992a	2025-12-05 22:12:33.602733	0	\N	14	EUR	\N	0	0	sync	0	exact_date
3	psarakismichail@gmail.com	scrypt:32768:8:1$k9ddNY6qoqP6pvQF$2473df38dc19c5554b6c1e5e37bb86f3211579fb7777ffd799d748e431e5f1c7f88387309348f5b51e917d6bdd44cec57d1f2bd8d4e9c0b15d0df9d54e7bfcbf	2025-12-23 15:51:20.404149	0	\N	14	EUR	2025-12-23	200000	2000000	sync	0	exact_date
1	saiyuriye.rafia@gmail.com	scrypt:32768:8:1$NTBL2jq9wdswJ317$a866f96e54aca726260d216f04bafb477ea426ef8b0e70d692ebf7cf7845861bffea341bc39be6659d6e06e7ec33768e519f3f35ba523f62a5df1bb625f9a905	2025-12-04 16:05:51.698396	0	\N	30	EUR	2025-11-20	307200	150000	sync	8942	previous_workday
\.


--
-- Name: budget_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.budget_periods_id_seq', 30, true);


--
-- Name: credit_card_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.credit_card_settings_id_seq', 3, true);


--
-- Name: debts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.debts_id_seq', 6, true);


--
-- Name: exchange_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.exchange_rates_id_seq', 10140, true);


--
-- Name: expense_name_mappings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.expense_name_mappings_id_seq', 1, false);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.expenses_id_seq', 242, true);


--
-- Name: goals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.goals_id_seq', 4, true);


--
-- Name: income_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.income_id_seq', 11, true);


--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.password_reset_tokens_id_seq', 1, false);


--
-- Name: period_suggestions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.period_suggestions_id_seq', 1, false);


--
-- Name: rate_limits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.rate_limits_id_seq', 36, true);


--
-- Name: recurring_expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.recurring_expenses_id_seq', 33, true);


--
-- Name: recurring_income_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.recurring_income_id_seq', 2, true);


--
-- Name: salary_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.salary_periods_id_seq', 5, true);


--
-- Name: subcategories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.subcategories_id_seq', 23, true);


--
-- Name: user_defaults_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.user_defaults_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: budget_periods budget_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.budget_periods
    ADD CONSTRAINT budget_periods_pkey PRIMARY KEY (id);


--
-- Name: credit_card_settings credit_card_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_card_settings
    ADD CONSTRAINT credit_card_settings_pkey PRIMARY KEY (id);


--
-- Name: credit_card_settings credit_card_settings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_card_settings
    ADD CONSTRAINT credit_card_settings_user_id_key UNIQUE (user_id);


--
-- Name: debts debts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_pkey PRIMARY KEY (id);


--
-- Name: exchange_rates exchange_rates_base_currency_target_currency_rate_date_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_base_currency_target_currency_rate_date_key UNIQUE (base_currency, target_currency, rate_date);


--
-- Name: exchange_rates exchange_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_pkey PRIMARY KEY (id);


--
-- Name: expense_name_mappings expense_name_mappings_expense_name_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expense_name_mappings
    ADD CONSTRAINT expense_name_mappings_expense_name_key UNIQUE (expense_name);


--
-- Name: expense_name_mappings expense_name_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expense_name_mappings
    ADD CONSTRAINT expense_name_mappings_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id);


--
-- Name: income income_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_key UNIQUE (token);


--
-- Name: period_suggestions period_suggestions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.period_suggestions
    ADD CONSTRAINT period_suggestions_pkey PRIMARY KEY (id);


--
-- Name: rate_limits rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_pkey PRIMARY KEY (id);


--
-- Name: recurring_expenses recurring_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_expenses
    ADD CONSTRAINT recurring_expenses_pkey PRIMARY KEY (id);


--
-- Name: recurring_income recurring_income_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_income
    ADD CONSTRAINT recurring_income_pkey PRIMARY KEY (id);


--
-- Name: salary_periods salary_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.salary_periods
    ADD CONSTRAINT salary_periods_pkey PRIMARY KEY (id);


--
-- Name: subcategories subcategories_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT subcategories_pkey PRIMARY KEY (id);


--
-- Name: subcategories uq_subcategory_user_category_name; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT uq_subcategory_user_category_name UNIQUE (user_id, category, name);


--
-- Name: user_defaults user_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_defaults
    ADD CONSTRAINT user_defaults_pkey PRIMARY KEY (id);


--
-- Name: user_defaults user_defaults_user_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_defaults
    ADD CONSTRAINT user_defaults_user_id_key UNIQUE (user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_budget_period_active; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_budget_period_active ON public.budget_periods USING btree (user_id, start_date, end_date);


--
-- Name: idx_debts_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_debts_deleted_at ON public.debts USING btree (deleted_at);


--
-- Name: idx_exchange_rate_lookup; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_exchange_rate_lookup ON public.exchange_rates USING btree (base_currency, target_currency, rate_date);


--
-- Name: idx_expenses_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_expenses_deleted_at ON public.expenses USING btree (deleted_at);


--
-- Name: idx_goal_user_active; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_goal_user_active ON public.goals USING btree (user_id, is_active);


--
-- Name: idx_goal_user_subcategory; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_goal_user_subcategory ON public.goals USING btree (user_id, subcategory_name);


--
-- Name: idx_goals_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_goals_deleted_at ON public.goals USING btree (deleted_at);


--
-- Name: idx_income_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_income_deleted_at ON public.income USING btree (deleted_at);


--
-- Name: idx_recurring_expenses_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_recurring_expenses_deleted_at ON public.recurring_expenses USING btree (deleted_at);


--
-- Name: ix_budget_periods_end_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_budget_periods_end_date ON public.budget_periods USING btree (end_date);


--
-- Name: ix_budget_periods_start_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_budget_periods_start_date ON public.budget_periods USING btree (start_date);


--
-- Name: ix_budget_periods_user_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_budget_periods_user_id ON public.budget_periods USING btree (user_id);


--
-- Name: ix_exchange_rates_base_currency; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_exchange_rates_base_currency ON public.exchange_rates USING btree (base_currency);


--
-- Name: ix_exchange_rates_rate_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_exchange_rates_rate_date ON public.exchange_rates USING btree (rate_date);


--
-- Name: ix_exchange_rates_target_currency; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_exchange_rates_target_currency ON public.exchange_rates USING btree (target_currency);


--
-- Name: ix_income_recurring_income_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_income_recurring_income_id ON public.income USING btree (recurring_income_id);


--
-- Name: ix_rate_limits_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_rate_limits_key ON public.rate_limits USING btree (key);


--
-- Name: ix_rate_limits_timestamp; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_rate_limits_timestamp ON public.rate_limits USING btree ("timestamp");


--
-- Name: ix_recurring_income_deleted_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_recurring_income_deleted_at ON public.recurring_income USING btree (deleted_at);


--
-- Name: ix_subcategories_category; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_subcategories_category ON public.subcategories USING btree (category);


--
-- Name: ix_subcategories_user_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_subcategories_user_id ON public.subcategories USING btree (user_id);


--
-- Name: uq_expense_recurring_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX uq_expense_recurring_date ON public.expenses USING btree (user_id, recurring_template_id, date) WHERE (recurring_template_id IS NOT NULL);


--
-- Name: uq_income_initial_balance_per_user; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX uq_income_initial_balance_per_user ON public.income USING btree (user_id) WHERE ((type)::text = 'Initial Balance'::text);


--
-- Name: budget_periods budget_periods_salary_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.budget_periods
    ADD CONSTRAINT budget_periods_salary_period_id_fkey FOREIGN KEY (salary_period_id) REFERENCES public.salary_periods(id);


--
-- Name: budget_periods budget_periods_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.budget_periods
    ADD CONSTRAINT budget_periods_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: credit_card_settings credit_card_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_card_settings
    ADD CONSTRAINT credit_card_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: debts debts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.debts
    ADD CONSTRAINT debts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: expenses expenses_budget_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_budget_period_id_fkey FOREIGN KEY (budget_period_id) REFERENCES public.budget_periods(id);


--
-- Name: expenses expenses_recurring_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_recurring_template_id_fkey FOREIGN KEY (recurring_template_id) REFERENCES public.recurring_expenses(id);


--
-- Name: expenses expenses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: goals fk_goal_user; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT fk_goal_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: income fk_income_recurring_income_id; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT fk_income_recurring_income_id FOREIGN KEY (recurring_income_id) REFERENCES public.recurring_income(id) ON DELETE SET NULL;


--
-- Name: subcategories fk_subcategory_user; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT fk_subcategory_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: goals goals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: income income_budget_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_budget_period_id_fkey FOREIGN KEY (budget_period_id) REFERENCES public.budget_periods(id);


--
-- Name: income income_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: period_suggestions period_suggestions_budget_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.period_suggestions
    ADD CONSTRAINT period_suggestions_budget_period_id_fkey FOREIGN KEY (budget_period_id) REFERENCES public.budget_periods(id);


--
-- Name: period_suggestions period_suggestions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.period_suggestions
    ADD CONSTRAINT period_suggestions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: recurring_expenses recurring_expenses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_expenses
    ADD CONSTRAINT recurring_expenses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: recurring_income recurring_income_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recurring_income
    ADD CONSTRAINT recurring_income_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: salary_periods salary_periods_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.salary_periods
    ADD CONSTRAINT salary_periods_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: subcategories subcategories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT subcategories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_defaults user_defaults_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_defaults
    ADD CONSTRAINT user_defaults_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

\unrestrict Iwb3VRGzJamRIAZ9Cv2xkJTFVE5W5g4PUZh5EBsyNifrvDYUObLZkGQgxluhwD5

